// WidgetBlueprintGeneratedClass UI_GamePoints.UI_GamePoints_C
// Size: 0x2b8 (Inherited: 0x260)
struct UUI_GamePoints_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Anim_ShowCustomString; // 0x268(0x08)
	struct UWidgetAnimation* Anim_ShowWidget; // 0x270(0x08)
	struct UTextBlock* TextBlock_Message; // 0x278(0x08)
	struct UTextBlock* TextBlock_Points; // 0x280(0x08)
	struct FText Message; // 0x288(0x18)
	struct FString customString; // 0x2a0(0x10)
	int32_t AddPoint; // 0x2b0(0x04)
	int32_t CurrentDisplayCharacters; // 0x2b4(0x04)

	void Construct(); // Function UI_GamePoints.UI_GamePoints_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_GamePoints(int32_t EntryPoint); // Function UI_GamePoints.UI_GamePoints_C.ExecuteUbergraph_UI_GamePoints // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

