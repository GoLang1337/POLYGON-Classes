// WidgetBlueprintGeneratedClass UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C
// Size: 0x2e0 (Inherited: 0x260)
struct UUI_Shop_Crowns_Item_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border_Bonus; // 0x268(0x08)
	struct UBorder* Border_Price; // 0x270(0x08)
	struct UButton* Button; // 0x278(0x08)
	struct UNamedSlot* NamedSlot_Icon; // 0x280(0x08)
	struct UTextBlock* TextBlock_Bonus; // 0x288(0x08)
	struct UTextBlock* TextBlock_CrownsWithoutBonus; // 0x290(0x08)
	struct UTextBlock* TextBlock_Price; // 0x298(0x08)
	struct UTextBlock* TextBlock_TotalCrownsNumber; // 0x2a0(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Focus; // 0x2a8(0x08)
	struct FString ItemId; // 0x2b0(0x10)
	int32_t TotalCrownsNumber; // 0x2c0(0x04)
	int32_t CrownsWithoutBonus; // 0x2c4(0x04)
	int32_t Bonus; // 0x2c8(0x04)
	float Price; // 0x2cc(0x04)
	struct FString OrdersID; // 0x2d0(0x10)

	void OnPlayFabResponse_5FD7BDC04705322F9775E4984587EC21(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.OnPlayFabResponse_5FD7BDC04705322F9775E4984587EC21 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_10B206114EF0E19AC81054942B496401(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.OnPlayFabResponse_10B206114EF0E19AC81054942B496401 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_A53B84FC45C9C3E2EDB378B17E5D2F40(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.OnPlayFabResponse_A53B84FC45C9C3E2EDB378B17E5D2F40 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_Crowns_Item_Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.BndEvt__UI_Shop_Crowns_Item_Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_Crowns_Item_Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.BndEvt__UI_Shop_Crowns_Item_Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_Crowns_Item_Button_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.BndEvt__UI_Shop_Crowns_Item_Button_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void StartPurchase_Success(struct FClientStartPurchaseResult Result, struct UObject* customData); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.StartPurchase_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void StartPurchase_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.StartPurchase_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PayForPurchase_Success(struct FClientPayForPurchaseResult Result, struct UObject* customData); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.PayForPurchase_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PayForPurchase_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.PayForPurchase_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void MicroTxnAuthorizationResponse_Event(int32_t AppID, struct FString OrderID, bool bAuthorized); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.MicroTxnAuthorizationResponse_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ConfirmPurchase_Success(struct FClientConfirmPurchaseResult Result, struct UObject* customData); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.ConfirmPurchase_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ConfirmPurchase_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.ConfirmPurchase_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Shop_Crowns_Item(int32_t EntryPoint); // Function UI_Shop_Crowns_Item.UI_Shop_Crowns_Item_C.ExecuteUbergraph_UI_Shop_Crowns_Item // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

