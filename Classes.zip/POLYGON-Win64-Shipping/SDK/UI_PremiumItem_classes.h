// WidgetBlueprintGeneratedClass UI_PremiumItem.UI_PremiumItem_C
// Size: 0x30c (Inherited: 0x260)
struct UUI_PremiumItem_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border; // 0x268(0x08)
	struct UButton* Button; // 0x270(0x08)
	struct UImage* Image_Icon; // 0x278(0x08)
	struct UMultiLineEditableText* MultiLineEditableText_ItemName; // 0x280(0x08)
	struct UTextBlock* TextBlock_Count; // 0x288(0x08)
	struct UTextBlock* TextBlock_ItemPrice; // 0x290(0x08)
	struct UTexture2D* ItemIcon; // 0x298(0x08)
	struct FText DisplayName; // 0x2a0(0x18)
	struct FText DisplayCount; // 0x2b8(0x18)
	struct FText DisplayPrice; // 0x2d0(0x18)
	struct FString ItemId; // 0x2e8(0x10)
	struct FString Catalog; // 0x2f8(0x10)
	int32_t Price; // 0x308(0x04)

	void PreConstruct(bool IsDesignTime); // Function UI_PremiumItem.UI_PremiumItem_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_PremiumItem.UI_PremiumItem_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function UI_PremiumItem.UI_PremiumItem_C.BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_PremiumItem.UI_PremiumItem_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_PremiumItem(int32_t EntryPoint); // Function UI_PremiumItem.UI_PremiumItem_C.ExecuteUbergraph_UI_PremiumItem // (Final|UbergraphFunction) // @ game+0x1847880
};

