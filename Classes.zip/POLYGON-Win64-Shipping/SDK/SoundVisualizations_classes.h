// Class SoundVisualizations.SoundVisualizationStatics
// Size: 0x28 (Inherited: 0x28)
struct USoundVisualizationStatics : UBlueprintFunctionLibrary {

	void GetAmplitude(struct USoundWave* SoundWave, int32_t Channel, float StartTime, float TimeLength, int32_t AmplitudeBuckets, struct TArray<float> OutAmplitudes); // Function SoundVisualizations.SoundVisualizationStatics.GetAmplitude // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xe6bb70
	void CalculateFrequencySpectrum(struct USoundWave* SoundWave, int32_t Channel, float StartTime, float TimeLength, int32_t SpectrumWidth, struct TArray<float> OutSpectrum); // Function SoundVisualizations.SoundVisualizationStatics.CalculateFrequencySpectrum // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xe6b990
};

