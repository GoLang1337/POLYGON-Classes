// BlueprintGeneratedClass BP_SupportBox_Health.BP_SupportBox_Health_C
// Size: 0x248 (Inherited: 0x248)
struct ABP_SupportBox_Health_C : ASupportBox_Health {
};

