// WidgetBlueprintGeneratedClass UI_ServerList.UI_ServerList_C
// Size: 0x2f0 (Inherited: 0x260)
struct UUI_ServerList_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* RotateRefreshButton; // 0x268(0x08)
	struct UBorder* Border_JoinServer_Background; // 0x270(0x08)
	struct UButton* Button_JoinServer; // 0x278(0x08)
	struct UButton* Button_Refresh; // 0x280(0x08)
	struct UImage* Image_MapPreview; // 0x288(0x08)
	struct UScrollBox* ScrollBox_ServerList; // 0x290(0x08)
	struct USizeBox* SizeBox_ServerInfo; // 0x298(0x08)
	struct UTextBlock* TextBlock_ServerCurrentPlayerNumber; // 0x2a0(0x08)
	struct UTextBlock* TextBlock_ServerTotalPlayersNumber; // 0x2a8(0x08)
	struct FString ServerMap; // 0x2b0(0x10)
	struct UVaRestRequestJSON* RequestServerPing; // 0x2c0(0x08)
	struct TArray<struct UUI_ServerInfo_C*> Servers; // 0x2c8(0x10)
	struct UUI_ServerInfo_C* SelectedServer; // 0x2d8(0x08)
	struct FMulticastInlineDelegate OnServerListUpdated; // 0x2e0(0x10)

	void JoinServerHovered(bool IsHover); // Function UI_ServerList.UI_ServerList_C.JoinServerHovered // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_BD2973D548B7F64DD83E2E9B2D8B15E5(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_ServerList.UI_ServerList_C.OnPlayFabResponse_BD2973D548B7F64DD83E2E9B2D8B15E5 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_ServerList.UI_ServerList_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void SearchServers(); // Function UI_ServerList.UI_ServerList_C.SearchServers // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Refresh_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature(); // Function UI_ServerList.UI_ServerList_C.BndEvt__Button_Refresh_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void GetCurrentGames_Success(struct FClientCurrentGamesResult Result, struct UObject* customData); // Function UI_ServerList.UI_ServerList_C.GetCurrentGames_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void GetCurrentGames_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_ServerList.UI_ServerList_C.GetCurrentGames_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ServerSelected_Event(struct UUI_ServerInfo_C* Server Info); // Function UI_ServerList.UI_ServerList_C.ServerSelected_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnRemovedFromFocusPath(struct FFocusEvent InFocusEvent); // Function UI_ServerList.UI_ServerList_C.OnRemovedFromFocusPath // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_JoinServer_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_ServerList.UI_ServerList_C.BndEvt__Button_JoinServer_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_JoinServer_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function UI_ServerList.UI_ServerList_C.BndEvt__Button_JoinServer_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_JoinServer_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature(); // Function UI_ServerList.UI_ServerList_C.BndEvt__Button_JoinServer_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_ServerList(int32_t EntryPoint); // Function UI_ServerList.UI_ServerList_C.ExecuteUbergraph_UI_ServerList // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
	void OnServerListUpdated__DelegateSignature(); // Function UI_ServerList.UI_ServerList_C.OnServerListUpdated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

