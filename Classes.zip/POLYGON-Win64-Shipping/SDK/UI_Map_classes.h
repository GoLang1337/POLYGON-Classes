// WidgetBlueprintGeneratedClass UI_Map.UI_Map_C
// Size: 0x2f8 (Inherited: 0x260)
struct UUI_Map_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* Map; // 0x268(0x08)
	struct UOverlay* MapOverlay; // 0x270(0x08)
	struct UMaterialInstanceDynamic* Mat; // 0x278(0x08)
	bool Draw; // 0x280(0x01)
	char pad_281[0x3]; // 0x281(0x03)
	float Zoom; // 0x284(0x04)
	struct UObject* UI_PlayerIcon; // 0x288(0x08)
	struct FMapInfo MapInfo; // 0x290(0x68)

	void ConvertCharacterPositionToMap(float X, float Y); // Function UI_Map.UI_Map_C.ConvertCharacterPositionToMap // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void AddOtherPlayerIcon(struct APawn* PlayerCharacter); // Function UI_Map.UI_Map_C.AddOtherPlayerIcon // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void AddOtherIcon(struct AActor* Owner); // Function UI_Map.UI_Map_C.AddOtherIcon // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Map.UI_Map_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void SetMapPosition(); // Function UI_Map.UI_Map_C.SetMapPosition // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Map(int32_t EntryPoint); // Function UI_Map.UI_Map_C.ExecuteUbergraph_UI_Map // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

