// BlueprintGeneratedClass BP_Item_Accessory_StandartAccessory.BP_Item_Accessory_StandartAccessory_C
// Size: 0x288 (Inherited: 0x280)
struct ABP_Item_Accessory_StandartAccessory_C : AItem_Module_General {
	struct USceneComponent* DefaultSceneRoot; // 0x280(0x08)
};

