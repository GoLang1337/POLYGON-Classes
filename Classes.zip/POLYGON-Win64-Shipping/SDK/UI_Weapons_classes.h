// WidgetBlueprintGeneratedClass UI_Weapons.UI_Weapons_C
// Size: 0x280 (Inherited: 0x260)
struct UUI_Weapons_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* Image_Primary; // 0x268(0x08)
	struct UImage* Image_Secondary; // 0x270(0x08)
	struct ABP_PG_Character_General_C* Character; // 0x278(0x08)

	void Construct(); // Function UI_Weapons.UI_Weapons_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnSetPawn_Event(); // Function UI_Weapons.UI_Weapons_C.OnSetPawn_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnSetPrimaryWeapon_Event(); // Function UI_Weapons.UI_Weapons_C.OnSetPrimaryWeapon_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnSetSecondaryWeapon_Event(); // Function UI_Weapons.UI_Weapons_C.OnSetSecondaryWeapon_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnSetCurrentWeapon_Event(); // Function UI_Weapons.UI_Weapons_C.OnSetCurrentWeapon_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Weapons(int32_t EntryPoint); // Function UI_Weapons.UI_Weapons_C.ExecuteUbergraph_UI_Weapons // (Final|UbergraphFunction) // @ game+0x1847880
};

