// BlueprintGeneratedClass BP_PG_PlayerState_Menu.BP_PG_PlayerState_Menu_C
// Size: 0x340 (Inherited: 0x338)
struct ABP_PG_PlayerState_Menu_C : APG_PlayerState_Menu {
	struct USceneComponent* DefaultSceneRoot; // 0x338(0x08)
};

