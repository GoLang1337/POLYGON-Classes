// Class SoundCueTemplates.SoundCueTemplate
// Size: 0x590 (Inherited: 0x590)
struct USoundCueTemplate : USoundCue {
};

// Class SoundCueTemplates.SoundCueContainer
// Size: 0x590 (Inherited: 0x590)
struct USoundCueContainer : USoundCueTemplate {
};

// Class SoundCueTemplates.SoundCueDistanceCrossfade
// Size: 0x590 (Inherited: 0x590)
struct USoundCueDistanceCrossfade : USoundCueTemplate {
};

// Class SoundCueTemplates.SoundCueTemplateSettings
// Size: 0x38 (Inherited: 0x38)
struct USoundCueTemplateSettings : UDeveloperSettings {
};

