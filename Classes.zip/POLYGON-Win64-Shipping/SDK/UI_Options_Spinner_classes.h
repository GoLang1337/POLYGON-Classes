// WidgetBlueprintGeneratedClass UI_Options_Spinner.UI_Options_Spinner_C
// Size: 0x2b8 (Inherited: 0x260)
struct UUI_Options_Spinner_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* LeftButton; // 0x268(0x08)
	struct UButton* RightButton; // 0x270(0x08)
	struct UTextBlock* TextBlock_Label; // 0x278(0x08)
	struct FString SelectValue; // 0x280(0x10)
	struct FName CVarName; // 0x290(0x08)
	struct TArray<struct FST_Option> Options; // 0x298(0x10)
	struct FMulticastInlineDelegate OnChangedValue; // 0x2a8(0x10)

	void ApplyValue(); // Function UI_Options_Spinner.UI_Options_Spinner_C.ApplyValue // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void GetValue(struct FString NewParam); // Function UI_Options_Spinner.UI_Options_Spinner_C.GetValue // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void SetValue(struct FString Value); // Function UI_Options_Spinner.UI_Options_Spinner_C.SetValue // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Next(); // Function UI_Options_Spinner.UI_Options_Spinner_C.Next // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Previous(); // Function UI_Options_Spinner.UI_Options_Spinner_C.Previous // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Options_Spinner.UI_Options_Spinner_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__RightButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_Options_Spinner.UI_Options_Spinner_C.BndEvt__RightButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__LeftButton_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function UI_Options_Spinner.UI_Options_Spinner_C.BndEvt__LeftButton_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Options_Spinner(int32_t EntryPoint); // Function UI_Options_Spinner.UI_Options_Spinner_C.ExecuteUbergraph_UI_Options_Spinner // (Final|UbergraphFunction) // @ game+0x1847880
	void OnChangedValue__DelegateSignature(struct FString Value); // Function UI_Options_Spinner.UI_Options_Spinner_C.OnChangedValue__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

