// Enum VictoryBPLibrary.ESpeedUnit
enum class ESpeedUnit : uint8 {
	CentimeterPerSecond = 0,
	FootPerSecond = 1,
	MeterPerSecond = 2,
	MeterPerMinute = 3,
	KilometerPerSecond = 4,
	KilometerPerMinute = 5,
	KilometerPerHour = 6,
	MilePerHour = 7,
	Knot = 8,
	Mach = 9,
	SpeedOfLight = 10,
	YardPerSecond = 11,
	ESpeedUnit_MAX = 12
};

// Enum VictoryBPLibrary.EJoyGraphicsFullScreen
enum class EJoyGraphicsFullScreen : uint8 {
	FullScreen = 0,
	WindowedFullScreen = 1,
	WindowedFullScreenPerformance = 2,
	EJoyGraphicsFullScreen_Max = 3
};

// Enum VictoryBPLibrary.EVictoryHMDDevice
enum class EVictoryHMDDevice : uint8 {
	None = 0,
	OculusRift = 1,
	Morpheus = 2,
	ES2GenericStereoMesh = 3,
	SteamVR = 4,
	GearVR = 5,
	EVictoryHMDDevice_MAX = 6
};

// Enum VictoryBPLibrary.EJoyImageFormats
enum class EJoyImageFormats : uint8 {
	JPG = 0,
	PNG = 1,
	BMP = 2,
	ICO = 3,
	EXR = 4,
	ICNS = 5,
	EJoyImageFormats_MAX = 6
};

// ScriptStruct VictoryBPLibrary.LevelStreamInstanceInfo
// Size: 0x30 (Inherited: 0x00)
struct FLevelStreamInstanceInfo {
	struct FName PackageName; // 0x00(0x08)
	struct FName PackageNameToLoad; // 0x08(0x08)
	struct FVector Location; // 0x10(0x0c)
	struct FRotator Rotation; // 0x1c(0x0c)
	char bShouldBeLoaded : 1; // 0x28(0x01)
	char bShouldBeVisible : 1; // 0x28(0x01)
	char bShouldBlockOnLoad : 1; // 0x28(0x01)
	char pad_28_3 : 5; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	int32_t LODIndex; // 0x2c(0x04)
};

// ScriptStruct VictoryBPLibrary.VictoryInputAxis
// Size: 0x40 (Inherited: 0x00)
struct FVictoryInputAxis {
	struct FString AxisName; // 0x00(0x10)
	struct FString KeyAsString; // 0x10(0x10)
	struct FKey Key; // 0x20(0x18)
	float Scale; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// ScriptStruct VictoryBPLibrary.VictoryInput
// Size: 0x40 (Inherited: 0x00)
struct FVictoryInput {
	struct FString ActionName; // 0x00(0x10)
	struct FKey Key; // 0x10(0x18)
	struct FString KeyAsString; // 0x28(0x10)
	char bShift : 1; // 0x38(0x01)
	char bCtrl : 1; // 0x38(0x01)
	char bAlt : 1; // 0x38(0x01)
	char bCmd : 1; // 0x38(0x01)
	char pad_38_4 : 4; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct VictoryBPLibrary.VictorySubtitleCue
// Size: 0x20 (Inherited: 0x00)
struct FVictorySubtitleCue {
	struct FText SubtitleText; // 0x00(0x18)
	float Time; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

