// WidgetBlueprintGeneratedClass UI_ServerInfo.UI_ServerInfo_C
// Size: 0x300 (Inherited: 0x260)
struct UUI_ServerInfo_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border_Background; // 0x268(0x08)
	struct UButton* Button_Connect; // 0x270(0x08)
	struct UButton* Button_SelectServer; // 0x278(0x08)
	struct UImage* Image_MapImage; // 0x280(0x08)
	struct USizeBox* SizeBox; // 0x288(0x08)
	struct UTextBlock* Text_CurrentPlayersNumber; // 0x290(0x08)
	struct UTextBlock* Text_Ping; // 0x298(0x08)
	struct UTextBlock* Text_ServerMap; // 0x2a0(0x08)
	struct UTextBlock* Text_ServerMode; // 0x2a8(0x08)
	struct UTextBlock* Text_ServerName; // 0x2b0(0x08)
	struct UTextBlock* Text_TotalPlayersNumber; // 0x2b8(0x08)
	struct UTextBlock* TextBlock_Slash; // 0x2c0(0x08)
	enum class ERegion ServerRegion; // 0x2c8(0x01)
	char pad_2C9[0x3]; // 0x2c9(0x03)
	int32_t Ping; // 0x2cc(0x04)
	struct UPlayFabJsonObject* ServerInfo; // 0x2d0(0x08)
	struct UPlayFabJsonObject* ServerSettings; // 0x2d8(0x08)
	bool IsSelected; // 0x2e0(0x01)
	char pad_2E1[0x7]; // 0x2e1(0x07)
	struct FMulticastInlineDelegate ServerSelected; // 0x2e8(0x10)
	struct UUI_ExperimentalMode_Tooltip_C* UI_ExperimentalModeTooltip; // 0x2f8(0x08)

	struct UWidget* GenerateTooltipForExperimentalMode(); // Function UI_ServerInfo.UI_ServerInfo_C.GenerateTooltipForExperimentalMode // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void SetIsSelected(bool IsSelected); // Function UI_ServerInfo.UI_ServerInfo_C.SetIsSelected // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetPing(int32_t Ping); // Function UI_ServerInfo.UI_ServerInfo_C.SetPing // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetServerName(); // Function UI_ServerInfo.UI_ServerInfo_C.SetServerName // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetServerMapInfo(); // Function UI_ServerInfo.UI_ServerInfo_C.SetServerMapInfo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void HoverButton(bool Hover?); // Function UI_ServerInfo.UI_ServerInfo_C.HoverButton // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_SelectServer_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature(); // Function UI_ServerInfo.UI_ServerInfo_C.BndEvt__Button_SelectServer_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_SelectServer_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_ServerInfo.UI_ServerInfo_C.BndEvt__Button_SelectServer_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_SelectServer_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function UI_ServerInfo.UI_ServerInfo_C.BndEvt__Button_SelectServer_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Connect_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature(); // Function UI_ServerInfo.UI_ServerInfo_C.BndEvt__Button_Connect_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_ServerInfo.UI_ServerInfo_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ConnectToServer(); // Function UI_ServerInfo.UI_ServerInfo_C.ConnectToServer // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetRegionPing(); // Function UI_ServerInfo.UI_ServerInfo_C.SetRegionPing // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_ServerInfo(int32_t EntryPoint); // Function UI_ServerInfo.UI_ServerInfo_C.ExecuteUbergraph_UI_ServerInfo // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
	void ServerSelected__DelegateSignature(struct UUI_ServerInfo_C* Server Info); // Function UI_ServerInfo.UI_ServerInfo_C.ServerSelected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

