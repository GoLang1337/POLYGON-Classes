// BlueprintGeneratedClass LVL_Storage_Canal_Night.LVL_Storage_Canal_Night_C
// Size: 0x228 (Inherited: 0x228)
struct ALVL_Storage_Canal_Night_C : ALevelScriptActor {
};

