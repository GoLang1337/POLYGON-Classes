// BlueprintGeneratedClass BP_Road.BP_Road_C
// Size: 0x232 (Inherited: 0x220)
struct ABP_Road_C : AActor {
	struct USplineComponent* Spline; // 0x220(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x228(0x08)
	bool Close?; // 0x230(0x01)
	bool UnVisible RedLine; // 0x231(0x01)

	void UserConstructionScript(); // Function BP_Road.BP_Road_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

