// WidgetBlueprintGeneratedClass UI_Solder_Customization_ItemInfo.UI_Solder_Customization_ItemInfo_C
// Size: 0x2c8 (Inherited: 0x260)
struct UUI_Solder_Customization_ItemInfo_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UMultiLineEditableText* MultiLineEditableText_CompatibleModules; // 0x268(0x08)
	struct UMultiLineEditableText* MultiLineEditableText_Description; // 0x270(0x08)
	struct UTextBlock* TextBlock_ItemName; // 0x278(0x08)
	struct UUI_ItemParameter_C* UI_ItemParameter_AccuracyHip; // 0x280(0x08)
	struct UUI_ItemParameter_C* UI_ItemParameter_AccuracySight; // 0x288(0x08)
	struct UUI_ItemParameter_C* UI_ItemParameter_Damage; // 0x290(0x08)
	struct UUI_ItemParameter_C* UI_ItemParameter_MagazineCapacity; // 0x298(0x08)
	struct UUI_ItemParameter_C* UI_ItemParameter_Range; // 0x2a0(0x08)
	struct UUI_ItemParameter_C* UI_ItemParameter_RateOfFire; // 0x2a8(0x08)
	struct UVerticalBox* VerticalBox_CompatibleModules; // 0x2b0(0x08)
	struct FName ItemId; // 0x2b8(0x08)
	struct AItem_General* ItemClass; // 0x2c0(0x08)

	void ResetInfo(); // Function UI_Solder_Customization_ItemInfo.UI_Solder_Customization_ItemInfo_C.ResetInfo // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetItemInfoAsWeapon(); // Function UI_Solder_Customization_ItemInfo.UI_Solder_Customization_ItemInfo_C.SetItemInfoAsWeapon // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetItemInfo(struct AItem_General* ItemClass); // Function UI_Solder_Customization_ItemInfo.UI_Solder_Customization_ItemInfo_C.SetItemInfo // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Solder_Customization_ItemInfo.UI_Solder_Customization_ItemInfo_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Solder_Customization_ItemInfo(int32_t EntryPoint); // Function UI_Solder_Customization_ItemInfo.UI_Solder_Customization_ItemInfo_C.ExecuteUbergraph_UI_Solder_Customization_ItemInfo // (Final|UbergraphFunction) // @ game+0x1847880
};

