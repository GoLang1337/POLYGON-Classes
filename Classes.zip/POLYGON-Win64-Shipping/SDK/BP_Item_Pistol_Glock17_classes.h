// BlueprintGeneratedClass BP_Item_Pistol_Glock17.BP_Item_Pistol_Glock17_C
// Size: 0x418 (Inherited: 0x418)
struct ABP_Item_Pistol_Glock17_C : AItem_Weapon_Pistol {
};

