// WidgetBlueprintGeneratedClass DefaultBindCapturePrompt.DefaultBindCapturePrompt_C
// Size: 0x2c0 (Inherited: 0x2c0)
struct UDefaultBindCapturePrompt_C : UBindCapturePrompt {
};

