// WidgetBlueprintGeneratedClass UI_Multiplayer.UI_Multiplayer_C
// Size: 0x2a8 (Inherited: 0x260)
struct UUI_Multiplayer_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UHorizontalBox* HorizontalBox_Header; // 0x268(0x08)
	struct UUI_Button_C* UI_Button_CreateServer; // 0x270(0x08)
	struct UUI_Button_C* UI_Button_Quickmatch; // 0x278(0x08)
	struct UUI_Button_C* UI_Button_ServerList; // 0x280(0x08)
	struct UUI_CreateServer_C* UI_CreateServer; // 0x288(0x08)
	struct UUI_QuickMatchWidget_C* UI_QuickMatchWidget_Valley; // 0x290(0x08)
	struct UUI_ServerList_C* UI_ServerList; // 0x298(0x08)
	struct UWidgetSwitcher* WidgetSwitcher; // 0x2a0(0x08)

	void ConnectToServer(struct UUI_ServerInfo_C* ServerInfo); // Function UI_Multiplayer.UI_Multiplayer_C.ConnectToServer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SelectBestServer(struct UUI_ServerInfo_C* BestServer); // Function UI_Multiplayer.UI_Multiplayer_C.SelectBestServer // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void Construct(); // Function UI_Multiplayer.UI_Multiplayer_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Quickmatch_K2Node_ComponentBoundEvent_3_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Multiplayer.UI_Multiplayer_C.BndEvt__UI_Button_Quickmatch_K2Node_ComponentBoundEvent_3_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_ServerList_K2Node_ComponentBoundEvent_4_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Multiplayer.UI_Multiplayer_C.BndEvt__UI_Button_ServerList_K2Node_ComponentBoundEvent_4_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_CreateServer_K2Node_ComponentBoundEvent_5_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Multiplayer.UI_Multiplayer_C.BndEvt__UI_Button_CreateServer_K2Node_ComponentBoundEvent_5_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void OnClick_Event(struct UUI_Button_C* Button); // Function UI_Multiplayer.UI_Multiplayer_C.OnClick_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Matchmake(); // Function UI_Multiplayer.UI_Multiplayer_C.Matchmake // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnServerListUpdated_Event(); // Function UI_Multiplayer.UI_Multiplayer_C.OnServerListUpdated_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Multiplayer(int32_t EntryPoint); // Function UI_Multiplayer.UI_Multiplayer_C.ExecuteUbergraph_UI_Multiplayer // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

