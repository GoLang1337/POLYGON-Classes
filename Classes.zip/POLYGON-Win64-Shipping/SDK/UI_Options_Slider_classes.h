// WidgetBlueprintGeneratedClass UI_Options_Slider.UI_Options_Slider_C
// Size: 0x299 (Inherited: 0x260)
struct UUI_Options_Slider_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct USlider* Slider; // 0x268(0x08)
	struct FName CVarName; // 0x270(0x08)
	float MinValue; // 0x278(0x04)
	float MaxValue; // 0x27c(0x04)
	float SelectValue; // 0x280(0x04)
	char pad_284[0x4]; // 0x284(0x04)
	struct FMulticastInlineDelegate OnValueChanged; // 0x288(0x10)
	bool AutoApply; // 0x298(0x01)

	void ApplyValue(); // Function UI_Options_Slider.UI_Options_Slider_C.ApplyValue // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void GetValue(float Value); // Function UI_Options_Slider.UI_Options_Slider_C.GetValue // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void SetValue(float Value); // Function UI_Options_Slider.UI_Options_Slider_C.SetValue // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Options_Slider.UI_Options_Slider_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Options_Slider.UI_Options_Slider_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Slider_K2Node_ComponentBoundEvent_0_OnFloatValueChangedEvent__DelegateSignature(float Value); // Function UI_Options_Slider.UI_Options_Slider_C.BndEvt__Slider_K2Node_ComponentBoundEvent_0_OnFloatValueChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Slider_K2Node_ComponentBoundEvent_1_OnMouseCaptureEndEvent__DelegateSignature(); // Function UI_Options_Slider.UI_Options_Slider_C.BndEvt__Slider_K2Node_ComponentBoundEvent_1_OnMouseCaptureEndEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Options_Slider(int32_t EntryPoint); // Function UI_Options_Slider.UI_Options_Slider_C.ExecuteUbergraph_UI_Options_Slider // (Final|UbergraphFunction) // @ game+0x1847880
	void OnValueChanged__DelegateSignature(float Value); // Function UI_Options_Slider.UI_Options_Slider_C.OnValueChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

