// WidgetBlueprintGeneratedClass UI_MatchResult_ReceivedGamePoints.UI_MatchResult_ReceivedGamePoints_C
// Size: 0x348 (Inherited: 0x260)
struct UUI_MatchResult_ReceivedGamePoints_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* NewLevel; // 0x268(0x08)
	struct UImage* Image_CurrentLevel; // 0x270(0x08)
	struct UImage* Image_NextLevel; // 0x278(0x08)
	struct UImage* Lines; // 0x280(0x08)
	struct UProgressBar* ProgressBar_InitialLevel; // 0x288(0x08)
	struct UProgressBar* ProgressBar_NextLevel; // 0x290(0x08)
	struct UProgressBar* ProgressBar_PremiumProgress; // 0x298(0x08)
	struct UTextBlock* TextBlock_InitialLevel; // 0x2a0(0x08)
	struct UTextBlock* TextBlock_InitialProgress; // 0x2a8(0x08)
	struct UTextBlock* TextBlock_NextLevel; // 0x2b0(0x08)
	struct UTextBlock* TextBlock_PremiumProgress; // 0x2b8(0x08)
	struct UTextBlock* TextBlock_ProgressForNextLevel; // 0x2c0(0x08)
	struct UTextBlock* TextBlock_ReceivedGamePoints; // 0x2c8(0x08)
	struct UTextBlock* TextBlock_TimeToGameRestart; // 0x2d0(0x08)
	struct ABP_PG_PlayerState_Game_C* PlayerState; // 0x2d8(0x08)
	struct FLevelInfo InitialLevelInfo; // 0x2e0(0x20)
	struct FLevelInfo NextLevelInfo; // 0x300(0x20)
	float GeneralGamePoints; // 0x320(0x04)
	char pad_324[0x4]; // 0x324(0x04)
	struct UAudioComponent* SoundProgress; // 0x328(0x08)
	float PremiumGamePoints; // 0x330(0x04)
	float Alpha; // 0x334(0x04)
	struct UObject* GameState; // 0x338(0x08)
	struct FTimerHandle Timer_StartAddExp; // 0x340(0x08)

	void SetProgress(float CurrentProgress, bool IsPremium?); // Function UI_MatchResult_ReceivedGamePoints.UI_MatchResult_ReceivedGamePoints_C.SetProgress // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void GoToNextLevel(); // Function UI_MatchResult_ReceivedGamePoints.UI_MatchResult_ReceivedGamePoints_C.GoToNextLevel // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_MatchResult_ReceivedGamePoints.UI_MatchResult_ReceivedGamePoints_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function UI_MatchResult_ReceivedGamePoints.UI_MatchResult_ReceivedGamePoints_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Display(); // Function UI_MatchResult_ReceivedGamePoints.UI_MatchResult_ReceivedGamePoints_C.Display // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Destruct(); // Function UI_MatchResult_ReceivedGamePoints.UI_MatchResult_ReceivedGamePoints_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void StartAddExpEvent(); // Function UI_MatchResult_ReceivedGamePoints.UI_MatchResult_ReceivedGamePoints_C.StartAddExpEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnGameTimer_Event(); // Function UI_MatchResult_ReceivedGamePoints.UI_MatchResult_ReceivedGamePoints_C.OnGameTimer_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnSetTotalProgress_Event(); // Function UI_MatchResult_ReceivedGamePoints.UI_MatchResult_ReceivedGamePoints_C.OnSetTotalProgress_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_MatchResult_ReceivedGamePoints(int32_t EntryPoint); // Function UI_MatchResult_ReceivedGamePoints.UI_MatchResult_ReceivedGamePoints_C.ExecuteUbergraph_UI_MatchResult_ReceivedGamePoints // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

