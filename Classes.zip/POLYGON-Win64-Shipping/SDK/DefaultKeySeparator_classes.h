// WidgetBlueprintGeneratedClass DefaultKeySeparator.DefaultKeySeparator_C
// Size: 0x260 (Inherited: 0x260)
struct UDefaultKeySeparator_C : UUserWidget {
};

