// BlueprintGeneratedClass BP_Item_Underbarrel_StandartUnderbarrel.BP_Item_Underbarrel_StandartUnderbarrel_C
// Size: 0x288 (Inherited: 0x280)
struct ABP_Item_Underbarrel_StandartUnderbarrel_C : AItem_Module_General {
	struct USceneComponent* DefaultSceneRoot; // 0x280(0x08)
};

