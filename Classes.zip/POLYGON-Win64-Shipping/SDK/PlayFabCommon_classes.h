// Class PlayFabCommon.PlayFabAuthenticationContext
// Size: 0x68 (Inherited: 0x28)
struct UPlayFabAuthenticationContext : UObject {
	struct FString ClientSessionTicket; // 0x28(0x10)
	struct FString EntityToken; // 0x38(0x10)
	struct FString DeveloperSecretKey; // 0x48(0x10)
	struct FString PlayFabId; // 0x58(0x10)

	void SetPlayFabId(struct FString InKey); // Function PlayFabCommon.PlayFabAuthenticationContext.SetPlayFabId // (Final|Native|Public|BlueprintCallable) // @ game+0x12cfc10
	void SetEntityToken(struct FString InToken); // Function PlayFabCommon.PlayFabAuthenticationContext.SetEntityToken // (Final|Native|Public|BlueprintCallable) // @ game+0x12cfb10
	void SetDeveloperSecretKey(struct FString InKey); // Function PlayFabCommon.PlayFabAuthenticationContext.SetDeveloperSecretKey // (Final|Native|Public|BlueprintCallable) // @ game+0x12cf9e0
	void SetClientSessionTicket(struct FString InTicket); // Function PlayFabCommon.PlayFabAuthenticationContext.SetClientSessionTicket // (Final|Native|Public|BlueprintCallable) // @ game+0x12cf8b0
	struct FString GetPlayFabId(); // Function PlayFabCommon.PlayFabAuthenticationContext.GetPlayFabId // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x12cf880
	struct FString GetEntityToken(); // Function PlayFabCommon.PlayFabAuthenticationContext.GetEntityToken // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x12cf850
	struct FString GetDeveloperSecretKey(); // Function PlayFabCommon.PlayFabAuthenticationContext.GetDeveloperSecretKey // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x12cf7e0
	struct FString GetClientSessionTicket(); // Function PlayFabCommon.PlayFabAuthenticationContext.GetClientSessionTicket // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x12cf770
	void ForgetAllCredentials(); // Function PlayFabCommon.PlayFabAuthenticationContext.ForgetAllCredentials // (Final|Native|Public|BlueprintCallable) // @ game+0x12cf6f0
	void ClientAdminSecurityCheck(); // Function PlayFabCommon.PlayFabAuthenticationContext.ClientAdminSecurityCheck // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x12cf6a0
};

// Class PlayFabCommon.PlayFabRuntimeSettings
// Size: 0x58 (Inherited: 0x28)
struct UPlayFabRuntimeSettings : UObject {
	struct FString ProductionEnvironmentURL; // 0x28(0x10)
	struct FString TitleId; // 0x38(0x10)
	struct FString DeveloperSecretKey; // 0x48(0x10)
};

