// BlueprintGeneratedClass BP_Item_Sniper_Barret.BP_Item_Sniper_Barret_C
// Size: 0x410 (Inherited: 0x410)
struct ABP_Item_Sniper_Barret_C : AItem_Weapon_Sniper {
};

