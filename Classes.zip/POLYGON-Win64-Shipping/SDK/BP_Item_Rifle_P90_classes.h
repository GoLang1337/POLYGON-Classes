// BlueprintGeneratedClass BP_Item_Rifle_P90.BP_Item_Rifle_P90_C
// Size: 0x410 (Inherited: 0x410)
struct ABP_Item_Rifle_P90_C : AItem_Weapon_Rifle {
};

