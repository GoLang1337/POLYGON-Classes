// WidgetBlueprintGeneratedClass UI_SupportBox_Health.UI_SupportBox_Health_C
// Size: 0x260 (Inherited: 0x260)
struct UUI_SupportBox_Health_C : UUserWidget {
};

