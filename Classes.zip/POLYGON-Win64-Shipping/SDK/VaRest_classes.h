// Class VaRest.VaRestJsonObject
// Size: 0x38 (Inherited: 0x28)
struct UVaRestJsonObject : UObject {
	char pad_28[0x10]; // 0x28(0x10)

	bool WriteToFilePath(struct FString Path, bool bIsRelativeToProjectDir); // Function VaRest.VaRestJsonObject.WriteToFilePath // (Final|Native|Public|BlueprintCallable) // @ game+0xac1a20
	void SetStringField(struct FString FieldName, struct FString StringValue); // Function VaRest.VaRestJsonObject.SetStringField // (Final|Native|Public|BlueprintCallable) // @ game+0xac15b0
	void SetStringArrayField(struct FString FieldName, struct TArray<struct FString> StringArray); // Function VaRest.VaRestJsonObject.SetStringArrayField // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xac1480
	void SetObjectField(struct FString FieldName, struct UVaRestJsonObject* JsonObject); // Function VaRest.VaRestJsonObject.SetObjectField // (Final|Native|Public|BlueprintCallable) // @ game+0xac1280
	void SetObjectArrayField(struct FString FieldName, struct TArray<struct UVaRestJsonObject*> ObjectArray); // Function VaRest.VaRestJsonObject.SetObjectArrayField // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xac1180
	void SetNumberField(struct FString FieldName, float Number); // Function VaRest.VaRestJsonObject.SetNumberField // (Final|Native|Public|BlueprintCallable) // @ game+0xac1090
	void SetNumberArrayField(struct FString FieldName, struct TArray<float> NumberArray); // Function VaRest.VaRestJsonObject.SetNumberArrayField // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xac0f90
	void SetMapFields_uint8(struct TMap<struct FString, char> Fields); // Function VaRest.VaRestJsonObject.SetMapFields_uint8 // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xac0e70
	void SetMapFields_string(struct TMap<struct FString, struct FString> Fields); // Function VaRest.VaRestJsonObject.SetMapFields_string // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xac0d50
	void SetMapFields_int64(struct TMap<struct FString, int64_t> Fields); // Function VaRest.VaRestJsonObject.SetMapFields_int64 // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xac0c30
	void SetMapFields_int32(struct TMap<struct FString, int32_t> Fields); // Function VaRest.VaRestJsonObject.SetMapFields_int32 // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xac0b10
	void SetMapFields_bool(struct TMap<struct FString, bool> Fields); // Function VaRest.VaRestJsonObject.SetMapFields_bool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xac09f0
	void SetIntegerField(struct FString FieldName, int32_t Number); // Function VaRest.VaRestJsonObject.SetIntegerField // (Final|Native|Public|BlueprintCallable) // @ game+0xac0910
	void SetInt64Field(struct FString FieldName, int64_t Number); // Function VaRest.VaRestJsonObject.SetInt64Field // (Final|Native|Public|BlueprintCallable) // @ game+0xac0830
	void SetField(struct FString FieldName, struct UVaRestJsonValue* JsonValue); // Function VaRest.VaRestJsonObject.SetField // (Final|Native|Public|BlueprintCallable) // @ game+0xac0650
	void SetBoolField(struct FString FieldName, bool InValue); // Function VaRest.VaRestJsonObject.SetBoolField // (Final|Native|Public|BlueprintCallable) // @ game+0xac0400
	void SetBoolArrayField(struct FString FieldName, struct TArray<bool> BoolArray); // Function VaRest.VaRestJsonObject.SetBoolArrayField // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xac0300
	void SetArrayField(struct FString FieldName, struct TArray<struct UVaRestJsonValue*> inArray); // Function VaRest.VaRestJsonObject.SetArrayField // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xac00b0
	void Reset(); // Function VaRest.VaRestJsonObject.Reset // (Final|Native|Public|BlueprintCallable) // @ game+0xac0010
	void RemoveField(struct FString FieldName); // Function VaRest.VaRestJsonObject.RemoveField // (Final|Native|Public|BlueprintCallable) // @ game+0xabfed0
	void MergeJsonObject(struct UVaRestJsonObject* InJsonObject, bool Overwrite); // Function VaRest.VaRestJsonObject.MergeJsonObject // (Final|Native|Public|BlueprintCallable) // @ game+0xabfca0
	bool HasField(struct FString FieldName); // Function VaRest.VaRestJsonObject.HasField // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabfa30
	struct FString GetStringField(struct FString FieldName); // Function VaRest.VaRestJsonObject.GetStringField // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf610
	struct TArray<struct FString> GetStringArrayField(struct FString FieldName); // Function VaRest.VaRestJsonObject.GetStringArrayField // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf520
	struct UVaRestJsonObject* GetObjectField(struct FString FieldName); // Function VaRest.VaRestJsonObject.GetObjectField // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf1f0
	struct TArray<struct UVaRestJsonObject*> GetObjectArrayField(struct FString FieldName); // Function VaRest.VaRestJsonObject.GetObjectArrayField // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf0e0
	float GetNumberField(struct FString FieldName); // Function VaRest.VaRestJsonObject.GetNumberField // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf030
	struct TArray<float> GetNumberArrayField(struct FString FieldName); // Function VaRest.VaRestJsonObject.GetNumberArrayField // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabef20
	int32_t GetIntegerField(struct FString FieldName); // Function VaRest.VaRestJsonObject.GetIntegerField // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabee70
	int64_t GetInt64Field(struct FString FieldName); // Function VaRest.VaRestJsonObject.GetInt64Field // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabedc0
	struct TArray<struct FString> GetFieldNames(); // Function VaRest.VaRestJsonObject.GetFieldNames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabed40
	struct UVaRestJsonValue* GetField(struct FString FieldName); // Function VaRest.VaRestJsonObject.GetField // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabec90
	bool GetBoolField(struct FString FieldName); // Function VaRest.VaRestJsonObject.GetBoolField // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabebe0
	struct TArray<bool> GetBoolArrayField(struct FString FieldName); // Function VaRest.VaRestJsonObject.GetBoolArrayField // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabead0
	struct TArray<struct UVaRestJsonValue*> GetArrayField(struct FString FieldName); // Function VaRest.VaRestJsonObject.GetArrayField // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabea00
	struct FString EncodeJsonToSingleString(); // Function VaRest.VaRestJsonObject.EncodeJsonToSingleString // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabe930
	struct FString EncodeJson(); // Function VaRest.VaRestJsonObject.EncodeJson // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabe8e0
	bool DecodeJson(struct FString JsonString, bool bUseIncrementalParser); // Function VaRest.VaRestJsonObject.DecodeJson // (Final|Native|Public|BlueprintCallable) // @ game+0xabe690
};

// Class VaRest.VaRestJsonValue
// Size: 0x38 (Inherited: 0x28)
struct UVaRestJsonValue : UObject {
	char pad_28[0x10]; // 0x28(0x10)

	void Reset(); // Function VaRest.VaRestJsonValue.Reset // (Final|Native|Public|BlueprintCallable) // @ game+0xac0030
	bool IsNull(); // Function VaRest.VaRestJsonValue.IsNull // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabfb80
	struct FString GetTypeString(); // Function VaRest.VaRestJsonValue.GetTypeString // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf710
	enum class EVaJson GetType(); // Function VaRest.VaRestJsonValue.GetType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf6e0
	struct FString AsString(); // Function VaRest.VaRestJsonValue.AsString // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabdc00
	struct UVaRestJsonObject* AsObject(); // Function VaRest.VaRestJsonValue.AsObject // (Final|Native|Public|BlueprintCallable) // @ game+0xabdbd0
	float AsNumber(); // Function VaRest.VaRestJsonValue.AsNumber // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabdba0
	int32_t AsInt64(); // Function VaRest.VaRestJsonValue.AsInt64 // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabdb70
	int32_t AsInt32(); // Function VaRest.VaRestJsonValue.AsInt32 // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabdb40
	bool AsBool(); // Function VaRest.VaRestJsonValue.AsBool // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabdb10
	struct TArray<struct UVaRestJsonValue*> AsArray(); // Function VaRest.VaRestJsonValue.AsArray // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabdac0
};

// Class VaRest.VaRestLibrary
// Size: 0x28 (Inherited: 0x28)
struct UVaRestLibrary : UBlueprintFunctionLibrary {

	struct FString StringToSha1(struct FString StringToHash); // Function VaRest.VaRestLibrary.StringToSha1 // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xac1960
	struct FString StringToMd5(struct FString StringToHash); // Function VaRest.VaRestLibrary.StringToMd5 // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xac18a0
	struct FString PercentEncode(struct FString Source); // Function VaRest.VaRestLibrary.PercentEncode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xabfd70
	enum class EVaRestHttpStatusCode HTTPStatusIntToEnum(int32_t StatusCode); // Function VaRest.VaRestLibrary.HTTPStatusIntToEnum // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xabf9b0
	struct FVaRestURL GetWorldURL(struct UObject* WorldContextObject); // Function VaRest.VaRestLibrary.GetWorldURL // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xabf830
	struct FString GetVaRestVersion(); // Function VaRest.VaRestLibrary.GetVaRestVersion // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xabf7e0
	struct UVaRestSettings* GetVaRestSettings(); // Function VaRest.VaRestLibrary.GetVaRestSettings // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xabf7b0
	bool Base64EncodeData(struct TArray<char> Data, struct FString Dest); // Function VaRest.VaRestLibrary.Base64EncodeData // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xabdf10
	struct FString Base64Encode(struct FString Source); // Function VaRest.VaRestLibrary.Base64Encode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xabde50
	bool Base64DecodeData(struct FString Source, struct TArray<char> Dest); // Function VaRest.VaRestLibrary.Base64DecodeData // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xabdd50
	bool Base64Decode(struct FString Source, struct FString Dest); // Function VaRest.VaRestLibrary.Base64Decode // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xabdc50
};

// Class VaRest.VaRestRequestJSON
// Size: 0x1c8 (Inherited: 0x28)
struct UVaRestRequestJSON : UObject {
	struct FMulticastInlineDelegate OnRequestComplete; // 0x28(0x10)
	struct FMulticastInlineDelegate OnRequestFail; // 0x38(0x10)
	char pad_48[0x40]; // 0x48(0x40)
	int32_t ResponseSize; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
	struct FString ResponseContent; // 0x90(0x10)
	bool bIsValidJsonResponse; // 0xa0(0x01)
	char pad_A1[0xf]; // 0xa1(0x0f)
	struct UVaRestJsonObject* RequestJsonObj; // 0xb0(0x08)
	char pad_B8[0x30]; // 0xb8(0x30)
	struct UVaRestJsonObject* ResponseJsonObj; // 0xe8(0x08)
	struct UVaRestJsonValue* ResponseJsonValue; // 0xf0(0x08)
	char pad_F8[0xd0]; // 0xf8(0xd0)

	void SetVerb(enum class EVaRestRequestVerb Verb); // Function VaRest.VaRestRequestJSON.SetVerb // (Final|Native|Public|BlueprintCallable) // @ game+0xac17f0
	void SetURL(struct FString URL); // Function VaRest.VaRestRequestJSON.SetURL // (Final|Native|Public|BlueprintCallable) // @ game+0xac1750
	void SetStringRequestContent(struct FString Content); // Function VaRest.VaRestRequestJSON.SetStringRequestContent // (Final|Native|Public|BlueprintCallable) // @ game+0xac16b0
	void SetResponseObject(struct UVaRestJsonObject* JsonObject); // Function VaRest.VaRestRequestJSON.SetResponseObject // (Final|Native|Public|BlueprintCallable) // @ game+0xac13f0
	void SetRequestObject(struct UVaRestJsonObject* JsonObject); // Function VaRest.VaRestRequestJSON.SetRequestObject // (Final|Native|Public|BlueprintCallable) // @ game+0xac1360
	void SetHeader(struct FString HeaderName, struct FString HeaderValue); // Function VaRest.VaRestRequestJSON.SetHeader // (Final|Native|Public|BlueprintCallable) // @ game+0xac0730
	void SetCustomVerb(struct FString Verb); // Function VaRest.VaRestRequestJSON.SetCustomVerb // (Final|Native|Public|BlueprintCallable) // @ game+0xac0560
	void SetContentType(enum class EVaRestRequestContentType ContentType); // Function VaRest.VaRestRequestJSON.SetContentType // (Final|Native|Public|BlueprintCallable) // @ game+0xac04e0
	void SetBinaryRequestContent(struct TArray<char> Content); // Function VaRest.VaRestRequestJSON.SetBinaryRequestContent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xac0250
	void SetBinaryContentType(struct FString ContentType); // Function VaRest.VaRestRequestJSON.SetBinaryContentType // (Final|Native|Public|BlueprintCallable) // @ game+0xac01b0
	void ResetResponseData(); // Function VaRest.VaRestRequestJSON.ResetResponseData // (Final|Native|Public|BlueprintCallable) // @ game+0xac0090
	void ResetRequestData(); // Function VaRest.VaRestRequestJSON.ResetRequestData // (Final|Native|Public|BlueprintCallable) // @ game+0xac0070
	void ResetData(); // Function VaRest.VaRestRequestJSON.ResetData // (Final|Native|Public|BlueprintCallable) // @ game+0xac0050
	int32_t RemoveTag(struct FName Tag); // Function VaRest.VaRestRequestJSON.RemoveTag // (Final|Native|Public|BlueprintCallable) // @ game+0xabff70
	void ProcessURL(struct FString URL); // Function VaRest.VaRestRequestJSON.ProcessURL // (Native|Public|BlueprintCallable) // @ game+0xabfe30
	bool HasTag(struct FName Tag); // Function VaRest.VaRestRequestJSON.HasTag // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabfae0
	struct FString GetURL(); // Function VaRest.VaRestRequestJSON.GetURL // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf760
	enum class EVaRestRequestStatus GetStatus(); // Function VaRest.VaRestRequestJSON.GetStatus // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf4f0
	struct UVaRestJsonValue* GetResponseValue(); // Function VaRest.VaRestRequestJSON.GetResponseValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf4c0
	struct UVaRestJsonObject* GetResponseObject(); // Function VaRest.VaRestRequestJSON.GetResponseObject // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf490
	struct FString GetResponseHeader(struct FString HeaderName); // Function VaRest.VaRestRequestJSON.GetResponseHeader // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xabf3c0
	struct FString GetResponseContentAsString(bool bCacheResponseContent); // Function VaRest.VaRestRequestJSON.GetResponseContentAsString // (Final|Native|Public|BlueprintCallable) // @ game+0xabf300
	int32_t GetResponseCode(); // Function VaRest.VaRestRequestJSON.GetResponseCode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf2d0
	struct UVaRestJsonObject* GetRequestObject(); // Function VaRest.VaRestRequestJSON.GetRequestObject // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabf2a0
	struct TArray<struct FString> GetAllResponseHeaders(); // Function VaRest.VaRestRequestJSON.GetAllResponseHeaders // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabe980
	void ExecuteProcessRequest(); // Function VaRest.VaRestRequestJSON.ExecuteProcessRequest // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Cancel(); // Function VaRest.VaRestRequestJSON.Cancel // (Final|Native|Public|BlueprintCallable) // @ game+0xabe1f0
	void ApplyURL(struct FString URL, struct UVaRestJsonObject* Result, struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo); // Function VaRest.VaRestRequestJSON.ApplyURL // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xabd920
	void AddTag(struct FName Tag); // Function VaRest.VaRestRequestJSON.AddTag // (Final|Native|Public|BlueprintCallable) // @ game+0xabd890
};

// Class VaRest.VaRestSettings
// Size: 0x30 (Inherited: 0x28)
struct UVaRestSettings : UObject {
	bool bExtendedLog; // 0x28(0x01)
	bool bUseChunkedParser; // 0x29(0x01)
	char pad_2A[0x6]; // 0x2a(0x06)
};

// Class VaRest.VaRestSubsystem
// Size: 0x80 (Inherited: 0x30)
struct UVaRestSubsystem : UEngineSubsystem {
	struct TMap<struct UVaRestRequestJSON*, struct FVaRestCallResponse> RequestMap; // 0x30(0x50)

	struct UVaRestJsonObject* StaticConstructVaRestJsonObject(); // Function VaRest.VaRestSubsystem.StaticConstructVaRestJsonObject // (Final|Native|Static|Public) // @ game+0xac1870
	struct UVaRestJsonObject* LoadJsonFromFile(struct FString Path, bool bIsRelativeToContentDir); // Function VaRest.VaRestSubsystem.LoadJsonFromFile // (Final|Native|Public|BlueprintCallable) // @ game+0xabfbb0
	struct UVaRestJsonValue* DecodeJsonValue(struct FString JsonString); // Function VaRest.VaRestSubsystem.DecodeJsonValue // (Final|Native|Public|BlueprintCallable) // @ game+0xabe830
	struct UVaRestJsonObject* DecodeJsonObject(struct FString JsonString); // Function VaRest.VaRestSubsystem.DecodeJsonObject // (Final|Native|Public|BlueprintCallable) // @ game+0xabe780
	struct UVaRestRequestJSON* ConstructVaRestRequestExt(enum class EVaRestRequestVerb Verb, enum class EVaRestRequestContentType ContentType); // Function VaRest.VaRestSubsystem.ConstructVaRestRequestExt // (Final|Native|Public|BlueprintCallable) // @ game+0xabe5b0
	struct UVaRestRequestJSON* ConstructVaRestRequest(); // Function VaRest.VaRestSubsystem.ConstructVaRestRequest // (Final|Native|Public|BlueprintCallable) // @ game+0xabe580
	struct UVaRestJsonObject* ConstructVaRestJsonObject(); // Function VaRest.VaRestSubsystem.ConstructVaRestJsonObject // (Final|Native|Public|BlueprintCallable) // @ game+0xabe550
	struct UVaRestJsonValue* ConstructJsonValueString(struct FString StringValue); // Function VaRest.VaRestSubsystem.ConstructJsonValueString // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xabe4a0
	struct UVaRestJsonValue* ConstructJsonValueObject(struct UVaRestJsonObject* JsonObject); // Function VaRest.VaRestSubsystem.ConstructJsonValueObject // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xabe400
	struct UVaRestJsonValue* ConstructJsonValueNumber(float Number); // Function VaRest.VaRestSubsystem.ConstructJsonValueNumber // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xabe370
	struct UVaRestJsonValue* ConstructJsonValueBool(bool InValue); // Function VaRest.VaRestSubsystem.ConstructJsonValueBool // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xabe2d0
	struct UVaRestJsonValue* ConstructJsonValueArray(struct TArray<struct UVaRestJsonValue*> inArray); // Function VaRest.VaRestSubsystem.ConstructJsonValueArray // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xabe210
	void CallURL(struct FString URL, enum class EVaRestRequestVerb Verb, enum class EVaRestRequestContentType ContentType, struct UVaRestJsonObject* VaRestJson, struct FDelegate Callback); // Function VaRest.VaRestSubsystem.CallURL // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xabe030
};

