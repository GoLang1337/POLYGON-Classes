// BlueprintGeneratedClass BP_Item_Skin_M14_02.BP_Item_Skin_M14_02_C
// Size: 0x290 (Inherited: 0x288)
struct ABP_Item_Skin_M14_02_C : AItem_Module_Skin {
	struct USceneComponent* DefaultSceneRoot; // 0x288(0x08)
};

