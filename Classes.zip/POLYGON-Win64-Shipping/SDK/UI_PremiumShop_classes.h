// WidgetBlueprintGeneratedClass UI_PremiumShop.UI_PremiumShop_C
// Size: 0x2b8 (Inherited: 0x260)
struct UUI_PremiumShop_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UHorizontalBox* HorizontalBox_Header; // 0x268(0x08)
	struct UMultiLineEditableText* MultiLineEditableText_178; // 0x270(0x08)
	struct UUI_Button_C* UI_Button_Crowns; // 0x278(0x08)
	struct UUI_Button_C* UI_Button_Skin; // 0x280(0x08)
	struct UUI_Button_C* UI_Button_Subscriptions; // 0x288(0x08)
	struct UUI_PremiumShop_Crowns_C* UI_PremiumShop_Crowns; // 0x290(0x08)
	struct UUI_PremiumShop_Skin_C* UI_PremiumShop_Skin; // 0x298(0x08)
	struct UUI_PremiumShop_Subscriptions_C* UI_PremiumShop_Subscriptions; // 0x2a0(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Main; // 0x2a8(0x08)
	struct ABP_PG_PlayerState_Menu_C* PlayerState; // 0x2b0(0x08)

	void ParsePlayerInventory(); // Function UI_PremiumShop.UI_PremiumShop_C.ParsePlayerInventory // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void DiselectAllButtonsInHeader(); // Function UI_PremiumShop.UI_PremiumShop_C.DiselectAllButtonsInHeader // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Weapon_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_PremiumShop.UI_PremiumShop_C.BndEvt__UI_Button_Weapon_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Subscriptions_K2Node_ComponentBoundEvent_0_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_PremiumShop.UI_PremiumShop_C.BndEvt__UI_Button_Subscriptions_K2Node_ComponentBoundEvent_0_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Skin_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_PremiumShop.UI_PremiumShop_C.BndEvt__UI_Button_Skin_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void OnUpdatePlayerCombinedInfo_Event(); // Function UI_PremiumShop.UI_PremiumShop_C.OnUpdatePlayerCombinedInfo_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_PremiumShop.UI_PremiumShop_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_PremiumShop(int32_t EntryPoint); // Function UI_PremiumShop.UI_PremiumShop_C.ExecuteUbergraph_UI_PremiumShop // (Final|UbergraphFunction) // @ game+0x1847880
};

