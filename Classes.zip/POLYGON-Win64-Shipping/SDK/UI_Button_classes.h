// WidgetBlueprintGeneratedClass UI_Button.UI_Button_C
// Size: 0x308 (Inherited: 0x260)
struct UUI_Button_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Hovered; // 0x268(0x08)
	struct UBorder* Border; // 0x270(0x08)
	struct UButton* Button; // 0x278(0x08)
	struct UTextBlock* TextBlock_Name; // 0x280(0x08)
	struct FText Name; // 0x288(0x18)
	struct FMulticastInlineDelegate OnClick; // 0x2a0(0x10)
	int32_t FontSize; // 0x2b0(0x04)
	bool IsSelected; // 0x2b4(0x01)
	bool DisplayBorder; // 0x2b5(0x01)
	bool AlwaysDisplayBackground; // 0x2b6(0x01)
	char pad_2B7[0x1]; // 0x2b7(0x01)
	struct FName GeneralColorID; // 0x2b8(0x08)
	struct FName SelectColorID; // 0x2c0(0x08)
	struct FName DisableColorID; // 0x2c8(0x08)
	struct FName HoveredColorID; // 0x2d0(0x08)
	struct FLinearColor SelectColor; // 0x2d8(0x10)
	struct FLinearColor DisableColor; // 0x2e8(0x10)
	struct FMargin TextPadding; // 0x2f8(0x10)

	void SetButtonColor(); // Function UI_Button.UI_Button_C.SetButtonColor // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetSelectButton(bool IsSelected); // Function UI_Button.UI_Button_C.SetSelectButton // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Button.UI_Button_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function UI_Button.UI_Button_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_Button.UI_Button_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function UI_Button.UI_Button_C.BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void Click(); // Function UI_Button.UI_Button_C.Click // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Button(int32_t EntryPoint); // Function UI_Button.UI_Button_C.ExecuteUbergraph_UI_Button // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
	void OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Button.UI_Button_C.OnClick__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

