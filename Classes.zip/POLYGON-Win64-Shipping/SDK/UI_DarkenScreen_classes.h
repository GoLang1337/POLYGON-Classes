// WidgetBlueprintGeneratedClass UI_DarkenScreen.UI_DarkenScreen_C
// Size: 0x274 (Inherited: 0x260)
struct UUI_DarkenScreen_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	bool SmoothStart; // 0x268(0x01)
	char pad_269[0x3]; // 0x269(0x03)
	float TargetOpacity; // 0x26c(0x04)
	float InterpSpeed; // 0x270(0x04)

	void Construct(); // Function UI_DarkenScreen.UI_DarkenScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void RemoveDarken(); // Function UI_DarkenScreen.UI_DarkenScreen_C.RemoveDarken // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function UI_DarkenScreen.UI_DarkenScreen_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void SmoothStartEvent(); // Function UI_DarkenScreen.UI_DarkenScreen_C.SmoothStartEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_DarkenScreen(int32_t EntryPoint); // Function UI_DarkenScreen.UI_DarkenScreen_C.ExecuteUbergraph_UI_DarkenScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

