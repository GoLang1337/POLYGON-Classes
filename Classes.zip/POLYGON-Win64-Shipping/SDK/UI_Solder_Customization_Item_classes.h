// WidgetBlueprintGeneratedClass UI_Solder_Customization_Item.UI_Solder_Customization_Item_C
// Size: 0x310 (Inherited: 0x260)
struct UUI_Solder_Customization_Item_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Hover; // 0x268(0x08)
	struct UBorder* Border; // 0x270(0x08)
	struct UBorder* Border_IsEquipped; // 0x278(0x08)
	struct UButton* Button; // 0x280(0x08)
	struct UHorizontalBox* HorizontalBox_Condition; // 0x288(0x08)
	struct UImage* Image_Corner; // 0x290(0x08)
	struct UImage* Image_ItemIcon; // 0x298(0x08)
	struct UProgressBar* ProgressBar_Condition; // 0x2a0(0x08)
	struct USizeBox* SizeBox; // 0x2a8(0x08)
	struct UTextBlock* TextBlock_Condition; // 0x2b0(0x08)
	struct UTextBlock* TextBlock_ItemName; // 0x2b8(0x08)
	bool IsEquipped; // 0x2c0(0x01)
	char pad_2C1[0x7]; // 0x2c1(0x07)
	struct FMulticastInlineDelegate ClickDelegate; // 0x2c8(0x10)
	struct AItem_General* ItemClass; // 0x2d8(0x08)
	struct UPlayFabJsonObject* ItemJson; // 0x2e0(0x08)
	struct UUI_Solder_Customization_C* UI_Customization; // 0x2e8(0x08)
	bool IsLocked; // 0x2f0(0x01)
	char pad_2F1[0x7]; // 0x2f1(0x07)
	struct FMulticastInlineDelegate HoveredDelegate; // 0x2f8(0x10)
	struct UUserWidget* Widget Class; // 0x308(0x08)

	void SetVisibleLoadingSlot(enum class ESlateVisibility InVisibility); // Function UI_Solder_Customization_Item.UI_Solder_Customization_Item_C.SetVisibleLoadingSlot // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetIsEquipped(bool IsEquipped); // Function UI_Solder_Customization_Item.UI_Solder_Customization_Item_C.SetIsEquipped // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ParseItemInfo(struct UPlayFabJsonObject* ItemJson); // Function UI_Solder_Customization_Item.UI_Solder_Customization_Item_C.ParseItemInfo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_487557984C86D004694AA696B812CA7F(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_Solder_Customization_Item.UI_Solder_Customization_Item_C.OnPlayFabResponse_487557984C86D004694AA696B812CA7F // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function UI_Solder_Customization_Item.UI_Solder_Customization_Item_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_Solder_Customization_Item.UI_Solder_Customization_Item_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonPressedEvent__DelegateSignature(); // Function UI_Solder_Customization_Item.UI_Solder_Customization_Item_C.BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteCloudScript_Success(struct FClientExecuteCloudScriptResult Result, struct UObject* customData); // Function UI_Solder_Customization_Item.UI_Solder_Customization_Item_C.ExecuteCloudScript_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteCloudScript_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_Solder_Customization_Item.UI_Solder_Customization_Item_C.ExecuteCloudScript_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Solder_Customization_Item(int32_t EntryPoint); // Function UI_Solder_Customization_Item.UI_Solder_Customization_Item_C.ExecuteUbergraph_UI_Solder_Customization_Item // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
	void HoveredDelegate__DelegateSignature(struct UUI_Solder_Customization_Item_C* Item, bool IsHover); // Function UI_Solder_Customization_Item.UI_Solder_Customization_Item_C.HoveredDelegate__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ClickDelegate__DelegateSignature(struct UUI_Solder_Customization_Item_C* Item); // Function UI_Solder_Customization_Item.UI_Solder_Customization_Item_C.ClickDelegate__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

