// BlueprintGeneratedClass BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C
// Size: 0x5d0 (Inherited: 0x5a0)
struct ABP_PG_PlayerController_Menu_C : APG_PlayerController_Menu {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5a0(0x08)
	struct UUI_GeneralMenuScreen_C* UI_GeneralMenuScreen; // 0x5a8(0x08)
	struct ABP_MenuCharacter_C* MenuCharacter; // 0x5b0(0x08)
	struct UUI_ErrorMessage_C* UI_ErrorMessage; // 0x5b8(0x08)
	struct TArray<struct ACameraActor*> Cameras; // 0x5c0(0x10)

	void SwitchCamera(struct FName CameraTag); // Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.SwitchCamera // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ReceiveBeginPlay(); // Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void ShowError(struct FText ErrorMessage, struct FText ErrorDetails); // Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.ShowError // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_PG_PlayerController_Menu(int32_t EntryPoint); // Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.ExecuteUbergraph_BP_PG_PlayerController_Menu // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

