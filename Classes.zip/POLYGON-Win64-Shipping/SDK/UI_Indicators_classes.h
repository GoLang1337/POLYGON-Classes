// WidgetBlueprintGeneratedClass UI_Indicators.UI_Indicators_C
// Size: 0x2b8 (Inherited: 0x260)
struct UUI_Indicators_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* Lines; // 0x268(0x08)
	struct UImage* LinesRainbow; // 0x270(0x08)
	struct UProgressBar* ProgressBar_Health; // 0x278(0x08)
	struct UProgressBar* ProgressBar_Stamina; // 0x280(0x08)
	struct UTextBlock* TextBlock_CurrentNumberAmmo; // 0x288(0x08)
	struct UTextBlock* TextBlock_Health; // 0x290(0x08)
	struct UTextBlock* TextBlock_NumberGrenades; // 0x298(0x08)
	struct UTextBlock* TextBlock_StockAmmo; // 0x2a0(0x08)
	struct APG_Character* Character; // 0x2a8(0x08)
	struct ABP_PG_PlayerState_Game_C* PlayerState; // 0x2b0(0x08)

	void Construct(); // Function UI_Indicators.UI_Indicators_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Indicators.UI_Indicators_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnSetPawn_Event(); // Function UI_Indicators.UI_Indicators_C.OnSetPawn_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnChangeHealth_Event(); // Function UI_Indicators.UI_Indicators_C.OnChangeHealth_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnSetCurrentWeapon_Event(); // Function UI_Indicators.UI_Indicators_C.OnSetCurrentWeapon_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnChangeNumberGrenades_Event(); // Function UI_Indicators.UI_Indicators_C.OnChangeNumberGrenades_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function UI_Indicators.UI_Indicators_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnChangeStockAmmo_Event(); // Function UI_Indicators.UI_Indicators_C.OnChangeStockAmmo_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnChangeCurrentNumberAmmo_Event(); // Function UI_Indicators.UI_Indicators_C.OnChangeCurrentNumberAmmo_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Indicators(int32_t EntryPoint); // Function UI_Indicators.UI_Indicators_C.ExecuteUbergraph_UI_Indicators // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

