// WidgetBlueprintGeneratedClass UI_ChatMessage.UI_ChatMessage_C
// Size: 0x2a8 (Inherited: 0x260)
struct UUI_ChatMessage_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UMultiLineEditableText* MultiLineEditableText_Message; // 0x268(0x08)
	struct UTextBlock* TextBlock_MessageType; // 0x270(0x08)
	struct UTextBlock* TextBlock_PlayerName; // 0x278(0x08)
	struct FChatMessage Message; // 0x280(0x20)
	struct ABP_PG_PlayerState_Game_C* PlayerState; // 0x2a0(0x08)

	void PreConstruct(bool IsDesignTime); // Function UI_ChatMessage.UI_ChatMessage_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_ChatMessage(int32_t EntryPoint); // Function UI_ChatMessage.UI_ChatMessage_C.ExecuteUbergraph_UI_ChatMessage // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

