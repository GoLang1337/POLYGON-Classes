// WidgetBlueprintGeneratedClass UI_GameVersion.UI_GameVersion_C
// Size: 0x288 (Inherited: 0x260)
struct UUI_GameVersion_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UTextBlock* PlayerId; // 0x268(0x08)
	struct UTextBlock* VectorX; // 0x270(0x08)
	struct UTextBlock* VectorY; // 0x278(0x08)
	struct UTextBlock* Version; // 0x280(0x08)

	void Construct(); // Function UI_GameVersion.UI_GameVersion_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void SetPlayerPosition(); // Function UI_GameVersion.UI_GameVersion_C.SetPlayerPosition // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_GameVersion(int32_t EntryPoint); // Function UI_GameVersion.UI_GameVersion_C.ExecuteUbergraph_UI_GameVersion // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

