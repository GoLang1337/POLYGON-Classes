// BlueprintGeneratedClass BP_Item_Sniper_SVU.BP_Item_Sniper_SVU_C
// Size: 0x410 (Inherited: 0x410)
struct ABP_Item_Sniper_SVU_C : AItem_Weapon_Sniper {
};

