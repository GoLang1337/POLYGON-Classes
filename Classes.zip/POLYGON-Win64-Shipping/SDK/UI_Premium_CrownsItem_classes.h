// WidgetBlueprintGeneratedClass UI_Premium_CrownsItem.UI_Premium_CrownsItem_C
// Size: 0x36c (Inherited: 0x260)
struct UUI_Premium_CrownsItem_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border; // 0x268(0x08)
	struct UBorder* Border_Sale; // 0x270(0x08)
	struct UButton* Button; // 0x278(0x08)
	struct UImage* Image_Icon; // 0x280(0x08)
	struct UOverlay* Overlay_OldPrice; // 0x288(0x08)
	struct UTextBlock* TextBlock_Count; // 0x290(0x08)
	struct UTextBlock* TextBlock_ItemName; // 0x298(0x08)
	struct UTextBlock* TextBlock_ItemPrice; // 0x2a0(0x08)
	struct UTextBlock* TextBlock_ItemPrice_OldPrice; // 0x2a8(0x08)
	struct UTexture2D* ItemIcon; // 0x2b0(0x08)
	struct FText DisplayName; // 0x2b8(0x18)
	struct FText DisplayCount; // 0x2d0(0x18)
	struct FText DisplayPrice; // 0x2e8(0x18)
	struct FString ItemId; // 0x300(0x10)
	struct FString Catalog; // 0x310(0x10)
	int32_t Quantity; // 0x320(0x04)
	int32_t Price; // 0x324(0x04)
	struct FString OrdersID; // 0x328(0x10)
	bool IsSale; // 0x338(0x01)
	char pad_339[0x7]; // 0x339(0x07)
	struct FString OldPrice; // 0x340(0x10)
	struct FWidgetTransform CustomTransform; // 0x350(0x1c)

	void OnPlayFabResponse_0E1A506D409F11A92E983DADEFAB5F90(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.OnPlayFabResponse_0E1A506D409F11A92E983DADEFAB5F90 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_5D0DEFEB42E445781F6BEAB4872CBFF6(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.OnPlayFabResponse_5D0DEFEB42E445781F6BEAB4872CBFF6 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_BF5AE71E42CAEB97F1628F8331C5B43A(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.OnPlayFabResponse_BF5AE71E42CAEB97F1628F8331C5B43A // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void StartPurchase_Success(struct FClientStartPurchaseResult Result, struct UObject* customData); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.StartPurchase_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void StartPurchase_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.StartPurchase_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PayForPurchase_Success(struct FClientPayForPurchaseResult Result, struct UObject* customData); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.PayForPurchase_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PayForPurchase_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.PayForPurchase_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ConfirmPurchase_Success(struct FClientConfirmPurchaseResult Result, struct UObject* customData); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.ConfirmPurchase_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ConfirmPurchase_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.ConfirmPurchase_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void MicroTxnAuthorizationResponse_Event(int32_t AppID, struct FString OrderID, bool bAuthorized); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.MicroTxnAuthorizationResponse_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Premium_CrownsItem(int32_t EntryPoint); // Function UI_Premium_CrownsItem.UI_Premium_CrownsItem_C.ExecuteUbergraph_UI_Premium_CrownsItem // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

