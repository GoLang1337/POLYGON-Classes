// WidgetBlueprintGeneratedClass UI_MatchResult.UI_MatchResult_C
// Size: 0x2a0 (Inherited: 0x260)
struct UUI_MatchResult_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Emergence; // 0x268(0x08)
	struct UButton* Button_Exit; // 0x270(0x08)
	struct UImage* Lines; // 0x278(0x08)
	struct UTextBlock* TextBlock_CapturePointsBlueTeam; // 0x280(0x08)
	struct UTextBlock* TextBlock_CapturePointsRedTeam; // 0x288(0x08)
	struct UUI_MatchResult_ReceivedGamePoints_C* UI_MatchResult_ReceivedGamePoints; // 0x290(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_MatchResult; // 0x298(0x08)

	void ShowGameResult(); // Function UI_MatchResult.UI_MatchResult_C.ShowGameResult // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_MatchResult.UI_MatchResult_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Exit_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_MatchResult.UI_MatchResult_C.BndEvt__Button_Exit_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_MatchResult(int32_t EntryPoint); // Function UI_MatchResult.UI_MatchResult_C.ExecuteUbergraph_UI_MatchResult // (Final|UbergraphFunction) // @ game+0x1847880
};

