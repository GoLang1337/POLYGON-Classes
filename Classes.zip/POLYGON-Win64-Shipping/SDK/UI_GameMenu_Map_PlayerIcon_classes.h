// WidgetBlueprintGeneratedClass UI_GameMenu_Map_PlayerIcon.UI_GameMenu_Map_PlayerIcon_C
// Size: 0x298 (Inherited: 0x260)
struct UUI_GameMenu_Map_PlayerIcon_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* PlayerIcon; // 0x268(0x08)
	struct APawn* PlayerCharacter; // 0x270(0x08)
	float MapDimension; // 0x278(0x04)
	char pad_27C[0x4]; // 0x27c(0x04)
	struct FTimerHandle Timer; // 0x280(0x08)
	float MapSizeX; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
	struct UUI_GameMenu_Map_C* Map; // 0x290(0x08)

	struct FVector2D ConvertWorldPositionToMap(struct AActor* Actor); // Function UI_GameMenu_Map_PlayerIcon.UI_GameMenu_Map_PlayerIcon_C.ConvertWorldPositionToMap // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void Construct(); // Function UI_GameMenu_Map_PlayerIcon.UI_GameMenu_Map_PlayerIcon_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void SetPosition(); // Function UI_GameMenu_Map_PlayerIcon.UI_GameMenu_Map_PlayerIcon_C.SetPosition // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_GameMenu_Map_PlayerIcon(int32_t EntryPoint); // Function UI_GameMenu_Map_PlayerIcon.UI_GameMenu_Map_PlayerIcon_C.ExecuteUbergraph_UI_GameMenu_Map_PlayerIcon // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

