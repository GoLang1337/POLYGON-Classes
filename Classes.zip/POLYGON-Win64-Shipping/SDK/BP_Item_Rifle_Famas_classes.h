// BlueprintGeneratedClass BP_Item_Rifle_Famas.BP_Item_Rifle_Famas_C
// Size: 0x410 (Inherited: 0x410)
struct ABP_Item_Rifle_Famas_C : AItem_Weapon_Rifle {
};

