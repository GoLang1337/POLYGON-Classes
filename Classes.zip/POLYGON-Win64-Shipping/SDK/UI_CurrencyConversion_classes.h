// WidgetBlueprintGeneratedClass UI_CurrencyConversion.UI_CurrencyConversion_C
// Size: 0x2b8 (Inherited: 0x260)
struct UUI_CurrencyConversion_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button_Cancel; // 0x268(0x08)
	struct UButton* Button_Convert; // 0x270(0x08)
	struct UEditableTextBox* EditableTextBox_ConvertiblePC; // 0x278(0x08)
	struct UOverlay* Overlay_Loading; // 0x280(0x08)
	struct UTextBlock* TextBlock_ConvertibleGC; // 0x288(0x08)
	struct UTextBlock* TextBlock_CurrentNumberPC; // 0x290(0x08)
	struct UTextBlock* TextBlock_PossibleConvertToGC; // 0x298(0x08)
	struct UUI_LoadingIcon_C* UI_LoadingIcon; // 0x2a0(0x08)
	int32_t ConvertibleCount; // 0x2a8(0x04)
	char pad_2AC[0x4]; // 0x2ac(0x04)
	struct ABP_PG_PlayerController_Menu_C* PlayerController; // 0x2b0(0x08)

	void OnPlayFabResponse_10DA6E1A47DDAE9E800A5AA5BB90550A(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_CurrencyConversion.UI_CurrencyConversion_C.OnPlayFabResponse_10DA6E1A47DDAE9E800A5AA5BB90550A // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_CurrencyConversion.UI_CurrencyConversion_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_CurrencyConversion_EditableTextBox_ConvertiblePC_K2Node_ComponentBoundEvent_1_OnEditableTextBoxChangedEvent__DelegateSignature(struct FText Text); // Function UI_CurrencyConversion.UI_CurrencyConversion_C.BndEvt__UI_CurrencyConversion_EditableTextBox_ConvertiblePC_K2Node_ComponentBoundEvent_1_OnEditableTextBoxChangedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_CurrencyConversion_Button_Cancel_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function UI_CurrencyConversion.UI_CurrencyConversion_C.BndEvt__UI_CurrencyConversion_Button_Cancel_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_CurrencyConversion_Button_Convert_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature(); // Function UI_CurrencyConversion.UI_CurrencyConversion_C.BndEvt__UI_CurrencyConversion_Button_Convert_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ConvertCurrency_Success(struct FClientExecuteCloudScriptResult Result, struct UObject* customData); // Function UI_CurrencyConversion.UI_CurrencyConversion_C.ConvertCurrency_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ConvertCurrency_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_CurrencyConversion.UI_CurrencyConversion_C.ConvertCurrency_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_CurrencyConversion(int32_t EntryPoint); // Function UI_CurrencyConversion.UI_CurrencyConversion_C.ExecuteUbergraph_UI_CurrencyConversion // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

