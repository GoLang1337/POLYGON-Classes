// WidgetBlueprintGeneratedClass UI_HitIndicator.UI_HitIndicator_C
// Size: 0x284 (Inherited: 0x260)
struct UUI_HitIndicator_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* StartAnimation; // 0x268(0x08)
	struct UImage* Image_Indicator; // 0x270(0x08)
	struct FVector FromLocation; // 0x278(0x0c)

	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function UI_HitIndicator.UI_HitIndicator_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_HitIndicator.UI_HitIndicator_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_HitIndicator(int32_t EntryPoint); // Function UI_HitIndicator.UI_HitIndicator_C.ExecuteUbergraph_UI_HitIndicator // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

