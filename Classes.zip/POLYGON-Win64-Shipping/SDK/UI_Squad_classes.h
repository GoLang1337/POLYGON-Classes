// WidgetBlueprintGeneratedClass UI_Squad.UI_Squad_C
// Size: 0x300 (Inherited: 0x260)
struct UUI_Squad_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Visible; // 0x268(0x08)
	struct UBorder* Border_Ready; // 0x270(0x08)
	struct UButton* Button_CreateSquad; // 0x278(0x08)
	struct UButton* Button_Ready; // 0x280(0x08)
	struct UButton* Button_Squad; // 0x288(0x08)
	struct UImage* LinesRainbow; // 0x290(0x08)
	struct UOverlay* Overlay_Loading; // 0x298(0x08)
	struct UTextBlock* TextBlock_Ready; // 0x2a0(0x08)
	struct UTextBlock* TextBlock_Squad; // 0x2a8(0x08)
	struct UUI_Squad_PlayerSlot_C* UI_Squad_PlayerSlot_2; // 0x2b0(0x08)
	struct UUI_Squad_PlayerSlot_C* UI_Squad_PlayerSlot_3; // 0x2b8(0x08)
	struct UUI_Squad_PlayerSlot_C* UI_Squad_PlayerSlot_4; // 0x2c0(0x08)
	struct UWidgetSwitcher* WidgetSwitcher; // 0x2c8(0x08)
	bool IsReady; // 0x2d0(0x01)
	char pad_2D1[0x7]; // 0x2d1(0x07)
	struct FString NameMyPlayer; // 0x2d8(0x10)
	bool IsVisibleSquad; // 0x2e8(0x01)
	char pad_2E9[0x7]; // 0x2e9(0x07)
	struct UPlayFabJsonObject* PlayFapGroup; // 0x2f0(0x08)
	struct UObject* PlayerController; // 0x2f8(0x08)

	void SetNameMyPlayer(struct FString PlayerName); // Function UI_Squad.UI_Squad_C.SetNameMyPlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Ready_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function UI_Squad.UI_Squad_C.BndEvt__Button_Ready_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Squad_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature(); // Function UI_Squad.UI_Squad_C.BndEvt__Button_Squad_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Squad_PlayerSlot_1_K2Node_ComponentBoundEvent_0_OnClickDelegate__DelegateSignature(struct UUI_Squad_PlayerSlot_C* Slot); // Function UI_Squad.UI_Squad_C.BndEvt__UI_Squad_PlayerSlot_1_K2Node_ComponentBoundEvent_0_OnClickDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Squad_PlayerSlot_2_K2Node_ComponentBoundEvent_1_OnClickDelegate__DelegateSignature(struct UUI_Squad_PlayerSlot_C* Slot); // Function UI_Squad.UI_Squad_C.BndEvt__UI_Squad_PlayerSlot_2_K2Node_ComponentBoundEvent_1_OnClickDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Squad_PlayerSlot_3_K2Node_ComponentBoundEvent_6_OnClickDelegate__DelegateSignature(struct UUI_Squad_PlayerSlot_C* Slot); // Function UI_Squad.UI_Squad_C.BndEvt__UI_Squad_PlayerSlot_3_K2Node_ComponentBoundEvent_6_OnClickDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Squad.UI_Squad_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_CreateSquad_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature(); // Function UI_Squad.UI_Squad_C.BndEvt__Button_CreateSquad_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Squad.UI_Squad_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Destruct(); // Function UI_Squad.UI_Squad_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Squad(int32_t EntryPoint); // Function UI_Squad.UI_Squad_C.ExecuteUbergraph_UI_Squad // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

