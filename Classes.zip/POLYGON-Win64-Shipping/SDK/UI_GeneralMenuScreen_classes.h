// WidgetBlueprintGeneratedClass UI_GeneralMenuScreen.UI_GeneralMenuScreen_C
// Size: 0x378 (Inherited: 0x260)
struct UUI_GeneralMenuScreen_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* BuyPremiumHovered; // 0x268(0x08)
	struct UButton* Button_Exit; // 0x270(0x08)
	struct UButton* Button_Progress; // 0x278(0x08)
	struct UButton* Button_Settings; // 0x280(0x08)
	struct UHorizontalBox* HorizontalBox_Header; // 0x288(0x08)
	struct UImage* Image_LevelIcon; // 0x290(0x08)
	struct UImage* Image_LevelProgress; // 0x298(0x08)
	struct UImage* Lines; // 0x2a0(0x08)
	struct UScaleBox* ScaleBox_Header; // 0x2a8(0x08)
	struct UTextBlock* TextBlock_Level; // 0x2b0(0x08)
	struct UUI_Button_Line_C* UI_Button_Home; // 0x2b8(0x08)
	struct UUI_Button_Line_C* UI_Button_Multiplayer; // 0x2c0(0x08)
	struct UUI_Button_Line_C* UI_Button_Shop; // 0x2c8(0x08)
	struct UUI_Button_Line_C* UI_Button_Soldier; // 0x2d0(0x08)
	struct UUI_Counter_C* UI_Counter_Coin; // 0x2d8(0x08)
	struct UUI_Counter_C* UI_Counter_PremiumCoin; // 0x2e0(0x08)
	struct UUI_GameVersion_C* UI_GameVersion; // 0x2e8(0x08)
	struct UUI_HomeScreen_C* UI_HomeScreen; // 0x2f0(0x08)
	struct UUI_LoginScreen_C* UI_LoginScreen; // 0x2f8(0x08)
	struct UUI_Multiplayer_C* UI_Multiplayer; // 0x300(0x08)
	struct UUI_Options_C* UI_Options; // 0x308(0x08)
	struct UUI_PremiumShop_C* UI_PremiumShop; // 0x310(0x08)
	struct UUI_Shop_C* UI_Shop; // 0x318(0x08)
	struct UUI_Solder_C* UI_Solder; // 0x320(0x08)
	struct UUI_Squad_C* UI_Squad; // 0x328(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Main; // 0x330(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Menu; // 0x338(0x08)
	struct ABP_PG_PlayerState_Menu_C* PlayerState; // 0x340(0x08)
	struct TArray<struct FST_RegionPing> PingRegions; // 0x348(0x10)
	struct TArray<struct UPlayFabJsonObject*> Regions; // 0x358(0x10)
	struct FMulticastInlineDelegate OnUpdatePingOfRegions; // 0x368(0x10)

	void GetRegionWithMinPing(enum class ERegion Region); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.GetRegionWithMinPing // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void ParsePlayerInventory(); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.ParsePlayerInventory // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ParsePlayerProgress(); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.ParsePlayerProgress // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetActivePage(int32_t Index, struct UUI_Button_Line_C* Button); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.SetActivePage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_EADE0AC846565E30975953AB28B095E4(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.OnPlayFabResponse_EADE0AC846565E30975953AB28B095E4 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_ServerSearch_K2Node_ComponentBoundEvent_2_OnPressed__DelegateSignature(struct UUI_Button_Line_C* Button); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.BndEvt__UI_Button_ServerSearch_K2Node_ComponentBoundEvent_2_OnPressed__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_CreateServer_K2Node_ComponentBoundEvent_1_OnPressed__DelegateSignature(struct UUI_Button_Line_C* Button); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.BndEvt__UI_Button_CreateServer_K2Node_ComponentBoundEvent_1_OnPressed__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Exit_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.BndEvt__Button_Exit_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Shop_K2Node_ComponentBoundEvent_3_OnPressed__DelegateSignature(struct UUI_Button_Line_C* Button); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.BndEvt__UI_Button_Shop_K2Node_ComponentBoundEvent_3_OnPressed__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Soldier_K2Node_ComponentBoundEvent_4_OnPressed__DelegateSignature(struct UUI_Button_Line_C* Button); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.BndEvt__UI_Button_Soldier_K2Node_ComponentBoundEvent_4_OnPressed__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Progress_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature(); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.BndEvt__Button_Progress_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Settings_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature(); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.BndEvt__Button_Settings_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Options_K2Node_ComponentBoundEvent_7_ClickBackDelegate__DelegateSignature(); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.BndEvt__UI_Options_K2Node_ComponentBoundEvent_7_ClickBackDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Counter_PremiumCoin_K2Node_ComponentBoundEvent_9_OnClickDelegate__DelegateSignature(struct UUI_Counter_C* Counter); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.BndEvt__UI_Counter_PremiumCoin_K2Node_ComponentBoundEvent_9_OnClickDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void OnUpdatePlayerCombinedInfo_Event(); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.OnUpdatePlayerCombinedInfo_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void RequestRegionPing(); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.RequestRegionPing // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void GetGameServerRegions_Success(struct FClientGameServerRegionsResult Result, struct UObject* customData); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.GetGameServerRegions_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void GetGameServerRegions_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.GetGameServerRegions_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnRequestComplete_Event(struct UVaRestRequestJSON* Request); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.OnRequestComplete_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnSetPlayerId_Event(); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.OnSetPlayerId_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_GeneralMenuScreen_UI_Counter_Coin_K2Node_ComponentBoundEvent_8_OnClickDelegate__DelegateSignature(struct UUI_Counter_C* Counter); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.BndEvt__UI_GeneralMenuScreen_UI_Counter_Coin_K2Node_ComponentBoundEvent_8_OnClickDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_GeneralMenuScreen(int32_t EntryPoint); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.ExecuteUbergraph_UI_GeneralMenuScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
	void OnUpdatePingOfRegions__DelegateSignature(); // Function UI_GeneralMenuScreen.UI_GeneralMenuScreen_C.OnUpdatePingOfRegions__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

