// Enum NetDebugStats.ENetDebugStatConnectionState
enum class ENetDebugStatConnectionState : uint8 {
	Invalid = 0,
	Closed = 1,
	Pending = 2,
	Open = 3,
	ENetDebugStatConnectionState_MAX = 4
};

// ScriptStruct NetDebugStats.NetDebugStatPackets
// Size: 0x08 (Inherited: 0x00)
struct FNetDebugStatPackets {
	int32_t InPackets; // 0x00(0x04)
	int32_t OutPackets; // 0x04(0x04)
};

// ScriptStruct NetDebugStats.NetDebugStatBytes
// Size: 0x08 (Inherited: 0x00)
struct FNetDebugStatBytes {
	float InBytes; // 0x00(0x04)
	float OutBytes; // 0x04(0x04)
};

