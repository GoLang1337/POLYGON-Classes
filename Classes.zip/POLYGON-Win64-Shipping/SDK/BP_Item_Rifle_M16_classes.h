// BlueprintGeneratedClass BP_Item_Rifle_M16.BP_Item_Rifle_M16_C
// Size: 0x420 (Inherited: 0x410)
struct ABP_Item_Rifle_M16_C : AItem_Weapon_Rifle {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x410(0x08)
	struct UStaticMeshComponent* Sight; // 0x418(0x08)

	void SetSight(); // Function BP_Item_Rifle_M16.BP_Item_Rifle_M16_C.SetSight // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ReceiveBeginPlay(); // Function BP_Item_Rifle_M16.BP_Item_Rifle_M16_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void OnSetWeaponModules_Event(); // Function BP_Item_Rifle_M16.BP_Item_Rifle_M16_C.OnSetWeaponModules_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_Item_Rifle_M16(int32_t EntryPoint); // Function BP_Item_Rifle_M16.BP_Item_Rifle_M16_C.ExecuteUbergraph_BP_Item_Rifle_M16 // (Final|UbergraphFunction) // @ game+0x1847880
};

