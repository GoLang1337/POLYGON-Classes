// BlueprintGeneratedClass CameraShake_SniperShot.CameraShake_SniperShot_C
// Size: 0x180 (Inherited: 0x180)
struct UCameraShake_SniperShot_C : UMatineeCameraShake {
};

