// WidgetBlueprintGeneratedClass UI_Shop_Weapon.UI_Shop_Weapon_C
// Size: 0x2b9 (Inherited: 0x260)
struct UUI_Shop_Weapon_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UHorizontalBox* HorizontalBox_Header; // 0x268(0x08)
	struct UOverlay* Overlay_WeaponInfo; // 0x270(0x08)
	struct UUI_Button_C* UI_Button_Modules; // 0x278(0x08)
	struct UUI_Button_C* UI_Button_Primary; // 0x280(0x08)
	struct UUI_Button_C* UI_Button_Secondary; // 0x288(0x08)
	struct UUI_Shop_WeaponInfo_C* UI_Shop_WeaponInfo; // 0x290(0x08)
	struct UUI_Shop_WeaponModules_C* UI_Shop_WeaponModules; // 0x298(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_WeaponClass; // 0x2a0(0x08)
	struct UWrapBox* WrapBox_PrimaryWeapons; // 0x2a8(0x08)
	struct UWrapBox* WrapBox_SecondaryWeapons; // 0x2b0(0x08)
	bool PrimaryWeaponsInfo; // 0x2b8(0x01)

	void SetActivePage(int32_t Index, struct UUI_Button_C* Button); // Function UI_Shop_Weapon.UI_Shop_Weapon_C.SetActivePage // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetWeaponIsHovered(struct UUI_ShopItem_C* Weapon, bool IsHovered); // Function UI_Shop_Weapon.UI_Shop_Weapon_C.SetWeaponIsHovered // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void AddNewWeaponItem(struct AItem_Weapon_General* WeaponClass, struct UUI_ShopItem_C* CreatedItem); // Function UI_Shop_Weapon.UI_Shop_Weapon_C.AddNewWeaponItem // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Shop_Weapon.UI_Shop_Weapon_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void IsHoveredDelegate_Event(struct UUI_ShopItem_C* Item, bool IsHovered); // Function UI_Shop_Weapon.UI_Shop_Weapon_C.IsHoveredDelegate_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Primary_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Shop_Weapon.UI_Shop_Weapon_C.BndEvt__UI_Button_Primary_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Secondary_K2Node_ComponentBoundEvent_3_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Shop_Weapon.UI_Shop_Weapon_C.BndEvt__UI_Button_Secondary_K2Node_ComponentBoundEvent_3_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_Weapon_UI_Button_Modules_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Shop_Weapon.UI_Shop_Weapon_C.BndEvt__UI_Shop_Weapon_UI_Button_Modules_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Shop_Weapon(int32_t EntryPoint); // Function UI_Shop_Weapon.UI_Shop_Weapon_C.ExecuteUbergraph_UI_Shop_Weapon // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

