// WidgetBlueprintGeneratedClass UI_KickReason.UI_KickReason_C
// Size: 0x290 (Inherited: 0x260)
struct UUI_KickReason_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button_OK; // 0x268(0x08)
	struct UMultiLineEditableText* MultiLineEditableText_Reason; // 0x270(0x08)
	struct FText Reason; // 0x278(0x18)

	void PreConstruct(bool IsDesignTime); // Function UI_KickReason.UI_KickReason_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_KickReason_Button_OK_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_KickReason.UI_KickReason_C.BndEvt__UI_KickReason_Button_OK_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_KickReason.UI_KickReason_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_KickReason(int32_t EntryPoint); // Function UI_KickReason.UI_KickReason_C.ExecuteUbergraph_UI_KickReason // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

