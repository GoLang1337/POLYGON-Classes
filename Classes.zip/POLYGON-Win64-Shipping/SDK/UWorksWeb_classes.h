// Class UWorksWeb.UWorksInterfaceWeb
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWeb : UUWorksInterface {
};

// Class UWorksWeb.UWorksInterfaceWebApps
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebApps : UUWorksInterfaceWeb {

	void UpToDateCheckMinimal(int32_t AppID, int32_t Version, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebApps.UpToDateCheckMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99e1d0
	struct UUWorksRequestWebUpToDateCheck* UpToDateCheck(); // Function UWorksWeb.UWorksInterfaceWebApps.UpToDateCheck // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99e1a0
	void SetAppBuildLiveMinimal(struct FString Key, int32_t AppID, int32_t BuildId, struct FString BetaKey, struct FString Description, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebApps.SetAppBuildLiveMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99dcf0
	struct UUWorksRequestWebSetAppBuildLive* SetAppBuildLive(); // Function UWorksWeb.UWorksInterfaceWebApps.SetAppBuildLive // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99dcc0
	void GetServersAtAddressMinimal(struct FString Addr, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebApps.GetServersAtAddressMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99b530
	struct UUWorksRequestWebGetServersAtAddress* GetServersAtAddress(); // Function UWorksWeb.UWorksInterfaceWebApps.GetServersAtAddress // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99b500
	void GetServerListMinimal(struct FString Key, struct FString Filter, int32_t Limit, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebApps.GetServerListMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99b2f0
	struct UUWorksRequestWebGetServerList* GetServerList(); // Function UWorksWeb.UWorksInterfaceWebApps.GetServerList // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99b2c0
	void GetPlayersBannedMinimal(struct FString Key, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebApps.GetPlayersBannedMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99b140
	struct UUWorksRequestWebGetPlayersBanned* GetPlayersBanned(); // Function UWorksWeb.UWorksInterfaceWebApps.GetPlayersBanned // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99b110
	void GetCheatingReportsListMinimal(struct FString Key, int32_t AppID, int32_t TimeBegin, int32_t TimeEnd, bool bIncludeReports, bool bIncludeBans, struct FString ReportIDMin, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebApps.GetCheatingReportsListMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99aa80
	struct UUWorksRequestWebGetCheatingReportsList* GetCheatingReportsList(); // Function UWorksWeb.UWorksInterfaceWebApps.GetCheatingReportsList // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99aa50
	void GetAppListMinimal(struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebApps.GetAppListMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99a980
	struct UUWorksRequestWebGetAppList* GetAppList(); // Function UWorksWeb.UWorksInterfaceWebApps.GetAppList // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99a950
	void GetAppDepotVersionsMinimal(struct FString Key, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebApps.GetAppDepotVersionsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99a7d0
	struct UUWorksRequestWebGetAppDepotVersions* GetAppDepotVersions(); // Function UWorksWeb.UWorksInterfaceWebApps.GetAppDepotVersions // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99a7a0
	void GetAppBuildsMinimal(struct FString Key, int32_t AppID, int32_t Count, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebApps.GetAppBuildsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99a5f0
	struct UUWorksRequestWebGetAppBuilds* GetAppBuilds(); // Function UWorksWeb.UWorksInterfaceWebApps.GetAppBuilds // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99a5c0
	void GetAppBetasMinimal(struct FString Key, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebApps.GetAppBetasMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99a440
	struct UUWorksRequestWebGetAppBetas* GetAppBetas(); // Function UWorksWeb.UWorksInterfaceWebApps.GetAppBetas // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99a410
};

// Class UWorksWeb.UWorksInterfaceWebBroadcast
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebBroadcast : UUWorksInterfaceWeb {

	void PostGameDataFrameMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString BroadcastID, struct FString FrameData, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebBroadcast.PostGameDataFrameMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99c2d0
	struct UUWorksRequestWebPostGameDataFrame* PostGameDataFrame(); // Function UWorksWeb.UWorksInterfaceWebBroadcast.PostGameDataFrame // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99c2a0
};

// Class UWorksWeb.UWorksInterfaceWebCheatReporting
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebCheatReporting : UUWorksInterfaceWeb {

	void StartSecureMultiplayerSessionMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.StartSecureMultiplayerSessionMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99dff0
	struct UUWorksRequestWebStartSecureMultiplayerSession* StartSecureMultiplayerSession(); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.StartSecureMultiplayerSession // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99dfc0
	void RequestVacStatusForUserMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString SessionId, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.RequestVacStatusForUserMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99da80
	struct UUWorksRequestWebRequestVacStatusForUser* RequestVacStatusForUser(); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.RequestVacStatusForUser // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99da50
	void RequestPlayerGameBanMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FUWorksSteamID ReportID, struct FString CheatDescription, int32_t Duration, bool bDelayBan, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.RequestPlayerGameBanMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99d730
	struct UUWorksRequestWebRequestPlayerGameBan* RequestPlayerGameBan(); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.RequestPlayerGameBan // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99d700
	void ReportPlayerCheatingMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FUWorksSteamID SteamIDReporter, int32_t AppData, bool bHeuristic, bool bDetection, bool bPlayerReport, bool bNoReportID, int32_t GameMode, int32_t SuspicionStartTime, int32_t Severity, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.ReportPlayerCheatingMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99d2c0
	struct UUWorksRequestWebReportPlayerCheating* ReportPlayerCheating(); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.ReportPlayerCheating // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99d290
	void ReportCheatDataMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString PathAndFileName, struct FString WebCheatURL, struct FString TimeNow, struct FString TimeStarted, struct FString TimeStopped, struct FString CheatName, int32_t GameProcessID, int32_t CheatProcessID, struct FString CheatParamA, struct FString CheatParamB, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.ReportCheatDataMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99cb80
	struct UUWorksRequestWebReportCheatData* ReportCheatData(); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.ReportCheatData // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99cb50
	void RemovePlayerGameBanMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.RemovePlayerGameBanMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99c5d0
	struct UUWorksRequestWebRemovePlayerGameBan* RemovePlayerGameBan(); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.RemovePlayerGameBan // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99c5a0
	void GetCheatingReportsMinimal(struct FString Key, int32_t AppID, int32_t TimeEnd, int32_t TimeBegin, struct FString ReportIDMin, bool bIncludeReports, bool bIncludeBans, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.GetCheatingReportsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99ada0
	struct UUWorksRequestWebGetCheatingReports* GetCheatingReports(); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.GetCheatingReports // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99aa20
	void EndSecureMultiplayerSessionMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString SessionId, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.EndSecureMultiplayerSessionMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x999c00
	struct UUWorksRequestWebEndSecureMultiplayerSession* EndSecureMultiplayerSession(); // Function UWorksWeb.UWorksInterfaceWebCheatReporting.EndSecureMultiplayerSession // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x999bd0
};

// Class UWorksWeb.UWorksInterfaceWebCommunity
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebCommunity : UUWorksInterfaceWeb {

	void ReportAbuseMinimal(struct FString Key, struct FUWorksSteamID SteamIDActor, struct FUWorksSteamID SteamIDTarget, int32_t AppID, char AbuseType, char ContentType, struct FString Description, struct FString GID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebCommunity.ReportAbuseMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99c7b0
	struct UUWorksRequestWebReportAbuse* ReportAbuse(); // Function UWorksWeb.UWorksInterfaceWebCommunity.ReportAbuse // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99c780
};

// Class UWorksWeb.UWorksInterfaceWebEcon
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebEcon : UUWorksInterfaceWeb {

	void GetTradeOffersSummaryMinimal(struct FString Key, int32_t TimeLastVisit, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEcon.GetTradeOffersSummaryMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99c120
	struct UUWorksRequestWebGetTradeOffersSummary* GetTradeOffersSummary(); // Function UWorksWeb.UWorksInterfaceWebEcon.GetTradeOffersSummary // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99c0f0
	void GetTradeOffersMinimal(struct FString Key, bool bGetSentOffers, bool bGetReceivedOffers, bool bGetDescription, struct FString Language, bool bActiveOnly, bool bHistoricalOnly, int32_t TimeHistoricalCutoff, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEcon.GetTradeOffersMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99bd70
	struct UUWorksRequestWebGetTradeOffers* GetTradeOffers(); // Function UWorksWeb.UWorksInterfaceWebEcon.GetTradeOffers // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99bd40
	void GetTradeOfferMinimal(struct FString Key, struct FString TradeOfferID, struct FString Language, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEcon.GetTradeOfferMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99bae0
	struct UUWorksRequestWebGetTradeOffer* GetTradeOffer(); // Function UWorksWeb.UWorksInterfaceWebEcon.GetTradeOffer // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99bab0
	void GetTradeHistoryMinimal(struct FString Key, int32_t MaxTrades, int32_t StartAfterTime, struct FString StartAfterTradeID, bool bNavigatingBack, bool bGetDescription, struct FString Language, bool bIncludeFailed, bool bIncludeTotal, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEcon.GetTradeHistoryMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99b6a0
	struct UUWorksRequestWebGetTradeHistory* GetTradeHistory(); // Function UWorksWeb.UWorksInterfaceWebEcon.GetTradeHistory // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99b670
	void FlushInventoryCacheMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString ContextID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEcon.FlushInventoryCacheMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99a1d0
	struct UUWorksRequestWebFlushInventoryCache* FlushInventoryCache(); // Function UWorksWeb.UWorksInterfaceWebEcon.FlushInventoryCache // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99a1a0
	void FlushContextCacheMinimal(struct FString Key, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEcon.FlushContextCacheMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99a020
	struct UUWorksRequestWebFlushContextCache* FlushContextCache(); // Function UWorksWeb.UWorksInterfaceWebEcon.FlushContextCache // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x999ff0
	void FlushAssetAppearanceCacheMinimal(struct FString Key, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEcon.FlushAssetAppearanceCacheMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x999e70
	struct UUWorksRequestWebFlushAssetAppearanceCache* FlushAssetAppearanceCache(); // Function UWorksWeb.UWorksInterfaceWebEcon.FlushAssetAppearanceCache // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x999e40
	void DeclineTradeOfferMinimal(struct FString Key, struct FString TradeOfferID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEcon.DeclineTradeOfferMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x999a00
	struct UUWorksRequestWebDeclineTradeOffer* DeclineTradeOffer(); // Function UWorksWeb.UWorksInterfaceWebEcon.DeclineTradeOffer // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9999d0
	void CancelTradeOfferMinimal(struct FString Key, struct FString TradeOfferID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEcon.CancelTradeOfferMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x999800
	struct UUWorksRequestWebCancelTradeOffer* CancelTradeOffer(); // Function UWorksWeb.UWorksInterfaceWebEcon.CancelTradeOffer // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9997d0
};

// Class UWorksWeb.UWorksInterfaceWebEconMarket
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebEconMarket : UUWorksInterfaceWeb {

	void GetPopularMinimal(struct FString Key, struct FString Language, int32_t Rows, int32_t Start, int32_t FilterAppID, int32_t ECurrency, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEconMarket.GetPopularMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a20a0
	struct UUWorksRequestWebGetPopular* GetPopular(); // Function UWorksWeb.UWorksInterfaceWebEconMarket.GetPopular // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a2070
	void GetMarketEligibilityMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEconMarket.GetMarketEligibilityMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a1d40
	struct UUWorksRequestWebGetMarketEligibility* GetMarketEligibility(); // Function UWorksWeb.UWorksInterfaceWebEconMarket.GetMarketEligibility // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a1d10
	void GetAssetIDMinimal(struct FString Key, int32_t AppID, struct FString ListingID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEconMarket.GetAssetIDMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a1230
	struct UUWorksRequestWebGetAssetID* GetAssetID(); // Function UWorksWeb.UWorksInterfaceWebEconMarket.GetAssetID // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a1200
	void CancelAppListingsForUserMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, bool bSynchronous, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEconMarket.CancelAppListingsForUserMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99f7a0
	struct UUWorksRequestWebCancelAppListingsForUser* CancelAppListingsForUser(); // Function UWorksWeb.UWorksInterfaceWebEconMarket.CancelAppListingsForUser // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99f770
};

// Class UWorksWeb.UWorksInterfaceWebEconomy
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebEconomy : UUWorksInterfaceWeb {

	void StartTradeMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID PartyA, struct FUWorksSteamID PartyB, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEconomy.StartTradeMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a3f20
	struct UUWorksRequestWebStartTrade* StartTrade(); // Function UWorksWeb.UWorksInterfaceWebEconomy.StartTrade // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a3ef0
	void StartAssetTransactionMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString AssetID0, int32_t AssetQuantity0, struct FString Currency, struct FString Language, struct FString IPAddress, struct FString Referrer, bool bClientAuth, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEconomy.StartAssetTransactionMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a39b0
	struct UUWorksRequestWebStartAssetTransaction* StartAssetTransaction(); // Function UWorksWeb.UWorksInterfaceWebEconomy.StartAssetTransaction // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a3980
	void GetMarketPricesMinimal(struct FString Key, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEconomy.GetMarketPricesMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a1ef0
	struct UUWorksRequestWebGetMarketPrices* GetMarketPrices(); // Function UWorksWeb.UWorksInterfaceWebEconomy.GetMarketPrices // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a1ec0
	void GetExportedAssetsForUserMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString ContextID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEconomy.GetExportedAssetsForUserMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a1740
	struct UUWorksRequestWebGetExportedAssetsForUser* GetExportedAssetsForUser(); // Function UWorksWeb.UWorksInterfaceWebEconomy.GetExportedAssetsForUser // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a1710
	void GetAssetPricesMinimal(struct FString Key, int32_t AppID, struct FString Currency, struct FString Language, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEconomy.GetAssetPricesMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a1470
	struct UUWorksRequestWebGetAssetPrices* GetAssetPrices(); // Function UWorksWeb.UWorksInterfaceWebEconomy.GetAssetPrices // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a1440
	void GetAssetClassInfoMinimal(struct FString Key, int32_t AppID, int32_t ClassCount, struct FString ClassID0, struct FString Language, struct FString InstanceID0, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEconomy.GetAssetClassInfoMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a0ea0
	struct UUWorksRequestWebGetAssetClassInfo* GetAssetClassInfo(); // Function UWorksWeb.UWorksInterfaceWebEconomy.GetAssetClassInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a0e70
	void FinalizeAssetTransactionMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString TxnID, struct FString Language, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEconomy.FinalizeAssetTransactionMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a0880
	struct UUWorksRequestWebFinalizeAssetTransaction* FinalizeAssetTransaction(); // Function UWorksWeb.UWorksInterfaceWebEconomy.FinalizeAssetTransaction // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a0850
	void CanTradeMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FUWorksSteamID TargetId, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebEconomy.CanTradeMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99f580
	struct UUWorksRequestWebCanTrade* CanTrade(); // Function UWorksWeb.UWorksInterfaceWebEconomy.CanTrade // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99f550
};

// Class UWorksWeb.UWorksInterfaceWebGameInventory
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebGameInventory : UUWorksInterfaceWeb {

	void SupportGetAssetHistoryMinimal(struct FString Key, int32_t AppID, struct FString AssetID, struct FString ContextID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameInventory.SupportGetAssetHistoryMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a4140
	struct UUWorksRequestWebSupportGetAssetHistory* SupportGetAssetHistory(); // Function UWorksWeb.UWorksInterfaceWebGameInventory.SupportGetAssetHistory // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a4110
	void HistoryExecuteCommandsMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString ContextID, struct FString ActorId, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameInventory.HistoryExecuteCommandsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a2ca0
	struct UUWorksRequestWebHistoryExecuteCommands* HistoryExecuteCommands(); // Function UWorksWeb.UWorksInterfaceWebGameInventory.HistoryExecuteCommands // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a2c70
	void GetUserHistoryMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString ContextID, int32_t StartTime, int32_t EndTime, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameInventory.GetUserHistoryMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a29b0
	struct UUWorksRequestWebGetUserHistory* GetUserHistory(); // Function UWorksWeb.UWorksInterfaceWebGameInventory.GetUserHistory // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a2980
	void GetHistoryCommandDetailsMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString Command, struct FString ContextID, struct FString Arguments, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameInventory.GetHistoryCommandDetailsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a19b0
	struct UUWorksRequestWebGetHistoryCommandDetails* GetHistoryCommandDetails(); // Function UWorksWeb.UWorksInterfaceWebGameInventory.GetHistoryCommandDetails // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a1980
};

// Class UWorksWeb.UWorksInterfaceWebGameNotifications
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebGameNotifications : UUWorksInterfaceWeb {

	void UpdateSessionMinimal(struct FString Key, struct FString SessionId, int32_t AppID, struct FUWorksTitle Title, struct FUWorksUsers Users, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.UpdateSessionMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a4410
	struct UUWorksRequestWebUpdateSession* UpdateSession(); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.UpdateSession // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a43e0
	void RequestNotificationsMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.RequestNotificationsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a31a0
	struct UUWorksRequestWebRequestNotifications* RequestNotifications(); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.RequestNotifications // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a3170
	void GetSessionDetailsForAppMinimal(struct FString Key, struct FUWorksSessions Sessions, int32_t AppID, struct FString Language, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.GetSessionDetailsForAppMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a2740
	struct UUWorksRequestWebGetSessionDetailsForApp* GetSessionDetailsForApp(); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.GetSessionDetailsForApp // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a2710
	void EnumerateSessionsForAppMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, bool bIncludeAllUserMessages, bool bIncludeAuthUserMessage, struct FString Language, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.EnumerateSessionsForAppMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a0570
	struct UUWorksRequestWebEnumerateSessionsForApp* EnumerateSessionsForApp(); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.EnumerateSessionsForApp // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a0540
	void DeleteSessionMinimal(struct FString Key, struct FString SessionId, int32_t AppID, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.DeleteSessionMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a0300
	void DeleteSessionBatchMinimal(struct FString Key, struct FString SessionId, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.DeleteSessionBatchMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a00f0
	struct UUWorksRequestWebDeleteSessionBatch* DeleteSessionBatch(); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.DeleteSessionBatch // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a00c0
	struct UUWorksRequestWebDeleteSession* DeleteSession(); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.DeleteSession // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a0090
	void CreateSessionMinimal(struct FString Key, int32_t AppID, struct FString Context, struct FUWorksTitle Title, struct FUWorksUsers Users, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.CreateSessionMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99fc20
	struct UUWorksRequestWebCreateSession* CreateSession(); // Function UWorksWeb.UWorksInterfaceWebGameNotifications.CreateSession // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99fbf0
};

// Class UWorksWeb.UWorksInterfaceWebGameServers
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebGameServers : UUWorksInterfaceWeb {

	void SetMemoMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FString Memo, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameServers.SetMemoMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a3770
	struct UUWorksRequestWebSetMemo* SetMemo(); // Function UWorksWeb.UWorksInterfaceWebGameServers.SetMemo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a3740
	void SetBanStatusMinimal(struct FString Key, struct FUWorksSteamID SteamID, bool bBanned, int32_t BanSeconds, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameServers.SetBanStatusMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a3530
	struct UUWorksRequestWebSetBanStatus* SetBanStatus(); // Function UWorksWeb.UWorksInterfaceWebGameServers.SetBanStatus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a3500
	void ResetLoginTokenMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameServers.ResetLoginTokenMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a3380
	struct UUWorksRequestWebResetLoginToken* ResetLoginToken(); // Function UWorksWeb.UWorksInterfaceWebGameServers.ResetLoginToken // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a3350
	void QueryLoginTokenMinimal(struct FString Key, struct FString LoginToken, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameServers.QueryLoginTokenMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a2fa0
	struct UUWorksRequestWebQueryLoginToken* QueryLoginToken(); // Function UWorksWeb.UWorksInterfaceWebGameServers.QueryLoginToken // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a2f70
	void GetServerSteamIDsByIPMinimal(struct FString Key, struct FString ServerIPs, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameServers.GetServerSteamIDsByIPMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a2540
	struct UUWorksRequestWebGetServerSteamIDsByIP* GetServerSteamIDsByIP(); // Function UWorksWeb.UWorksInterfaceWebGameServers.GetServerSteamIDsByIP // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a2510
	void GetServerIPsBySteamIDMinimal(struct FString Key, struct FUWorksSteamID ServerSteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameServers.GetServerIPsBySteamIDMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a2390
	struct UUWorksRequestWebGetServerIPsBySteamID* GetServerIPsBySteamID(); // Function UWorksWeb.UWorksInterfaceWebGameServers.GetServerIPsBySteamID // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a2360
	void GetAccountPublicInfoMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameServers.GetAccountPublicInfoMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a0cf0
	struct UUWorksRequestWebGetAccountPublicInfo* GetAccountPublicInfo(); // Function UWorksWeb.UWorksInterfaceWebGameServers.GetAccountPublicInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a0cc0
	void GetAccountListMinimal(struct FString Key, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameServers.GetAccountListMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a0b80
	struct UUWorksRequestWebGetAccountList* GetAccountList(); // Function UWorksWeb.UWorksInterfaceWebGameServers.GetAccountList // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a0b50
	void DeleteAccountMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameServers.DeleteAccountMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99ff10
	struct UUWorksRequestWebDeleteAccount* DeleteAccount(); // Function UWorksWeb.UWorksInterfaceWebGameServers.DeleteAccount // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99fee0
	void CreateAccountMinimal(struct FString Key, int32_t AppID, struct FString Memo, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameServers.CreateAccountMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x99f9e0
	struct UUWorksRequestWebCreateAccount* CreateAccount(); // Function UWorksWeb.UWorksInterfaceWebGameServers.CreateAccount // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99f9b0
};

// Class UWorksWeb.UWorksInterfaceWebGameServerStats
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebGameServerStats : UUWorksInterfaceWeb {

	void GetGameServerPlayerStatsForGameMinimal(struct FString Key, struct FUWorksGameID GameID, int32_t AppID, struct FString RangeStart, struct FString RangeEnd, int32_t MaxResults, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebGameServerStats.GetGameServerPlayerStatsForGameMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a7470
	struct UUWorksRequestWebGetGameServerPlayerStatsForGame* GetGameServerPlayerStatsForGame(); // Function UWorksWeb.UWorksInterfaceWebGameServerStats.GetGameServerPlayerStatsForGame // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a7440
};

// Class UWorksWeb.UWorksInterfaceWebInventory
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebInventory : UUWorksInterfaceWeb {

	void GetQuantityMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FUWorksSteamItemDef ItemDefID, bool bForce, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebInventory.GetQuantityMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a8370
	struct UUWorksRequestWebGetQuantity* GetQuantity(); // Function UWorksWeb.UWorksInterfaceWebInventory.GetQuantity // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a8340
	void GetPriceSheetMinimal(struct FString Key, int32_t ECurrency, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebInventory.GetPriceSheetMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a81c0
	struct UUWorksRequestWebGetPriceSheet* GetPriceSheet(); // Function UWorksWeb.UWorksInterfaceWebInventory.GetPriceSheet // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a8190
	void GetItemDefsMinimal(struct FString Key, int32_t AppID, struct FString ModifiedSince, struct TArray<struct FUWorksSteamItemDef> ItemDefIDs, struct TArray<struct FUWorksSteamItemDef> WorkshopIDs, int32_t CacheMaxAgeSeconds, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebInventory.GetItemDefsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a7990
	struct UUWorksRequestWebGetItemDefs* GetItemDefs(); // Function UWorksWeb.UWorksInterfaceWebInventory.GetItemDefs // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a7960
	void GetInventoryMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebInventory.GetInventoryMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a77b0
	struct UUWorksRequestWebGetInventory* GetInventory(); // Function UWorksWeb.UWorksInterfaceWebInventory.GetInventory // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a7780
	void ExchangeItemMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct TArray<struct FUWorksSteamItemInstanceID> MaterialsItemID, struct TArray<int32_t> MaterialsQuantity, struct FUWorksSteamItemDef OutputItemDefID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebInventory.ExchangeItemMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a6ab0
	struct UUWorksRequestWebExchangeItem* ExchangeItem(); // Function UWorksWeb.UWorksInterfaceWebInventory.ExchangeItem // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a6a80
	void ConsumeItemMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamItemInstanceID ItemId, int32_t Quantity, struct FUWorksSteamID SteamID, struct FString RequestID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebInventory.ConsumeItemMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a6570
	struct UUWorksRequestWebConsumeItem* ConsumeItem(); // Function UWorksWeb.UWorksInterfaceWebInventory.ConsumeItem // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a6540
	void ConsolidateMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct TArray<struct FUWorksSteamItemDef> ItemDefID, bool bForce, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebInventory.ConsolidateMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a62a0
	struct UUWorksRequestWebConsolidate* Consolidate(); // Function UWorksWeb.UWorksInterfaceWebInventory.Consolidate // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a6270
	void AddPromoItemMinimal(struct FString Key, int32_t AppID, struct FUWorksSteamItemDef ItemDefID, struct FString ItemPropsJSON, struct FUWorksSteamID SteamID, bool bNotify, struct FString RequestID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebInventory.AddPromoItemMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a5990
	struct UUWorksRequestWebAddPromoItem* AddPromoItem(); // Function UWorksWeb.UWorksInterfaceWebInventory.AddPromoItem // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a5960
	void AddItemMinimal(struct FString Key, int32_t AppID, struct TArray<struct FUWorksSteamItemDef> ItemDefID, struct FString ItemPropsJSON, struct FUWorksSteamID SteamID, bool bNotify, struct FString RequestID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebInventory.AddItemMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a55a0
	struct UUWorksRequestWebAddItem* AddItem(); // Function UWorksWeb.UWorksInterfaceWebInventory.AddItem // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a5570
};

// Class UWorksWeb.UWorksInterfaceWebLeaderboards
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebLeaderboards : UUWorksInterfaceWeb {

	void SetLeaderboardScoreMinimal(struct FString Key, int32_t AppID, int32_t LeaderboardID, struct FUWorksSteamID SteamID, int32_t Score, struct FString ScoreMethod, struct TArray<char> Details, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebLeaderboards.SetLeaderboardScoreMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9aab60
	struct UUWorksRequestWebSetLeaderboardScore* SetLeaderboardScore(); // Function UWorksWeb.UWorksInterfaceWebLeaderboards.SetLeaderboardScore // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9aab30
	void ResetLeaderboardMinimal(struct FString Key, int32_t AppID, int32_t LeaderboardID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebLeaderboards.ResetLeaderboardMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9aa980
	struct UUWorksRequestWebResetLeaderboard* ResetLeaderboard(); // Function UWorksWeb.UWorksInterfaceWebLeaderboards.ResetLeaderboard // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9aa950
	void GetLeaderboardsForGameMinimal(struct FString Key, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebLeaderboards.GetLeaderboardsForGameMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a8010
	struct UUWorksRequestWebGetLeaderboardsForGame* GetLeaderboardsForGame(); // Function UWorksWeb.UWorksInterfaceWebLeaderboards.GetLeaderboardsForGame // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a7fe0
	void GetLeaderboardEntriesMinimal(struct FString Key, int32_t AppID, int32_t RangeStart, int32_t RangeEnd, int32_t LeaderboardID, int32_t DataRequest, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebLeaderboards.GetLeaderboardEntriesMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a7d20
	struct UUWorksRequestWebGetLeaderboardEntries* GetLeaderboardEntries(); // Function UWorksWeb.UWorksInterfaceWebLeaderboards.GetLeaderboardEntries // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a7cf0
	void FindOrCreateLeaderboardMinimal(struct FString Key, int32_t AppID, struct FString Name, struct FString SortMethod, struct FString DisplayType, bool bCreateIfNotFound, bool bOnlyTrustedWrites, bool bOnlyFriendsReads, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebLeaderboards.FindOrCreateLeaderboardMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a7030
	struct UUWorksRequestWebFindOrCreateLeaderboard* FindOrCreateLeaderboard(); // Function UWorksWeb.UWorksInterfaceWebLeaderboards.FindOrCreateLeaderboard // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a7000
	void DeleteLeaderboardMinimal(struct FString Key, int32_t AppID, struct FString Name, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebLeaderboards.DeleteLeaderboardMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a6870
	struct UUWorksRequestWebDeleteLeaderboard* DeleteLeaderboard(); // Function UWorksWeb.UWorksInterfaceWebLeaderboards.DeleteLeaderboard // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a6840
};

// Class UWorksWeb.UWorksInterfaceWebMicroTxn
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebMicroTxn : UUWorksInterfaceWeb {

	void RefundTxnMinimal(struct FString Key, struct FString OrderID, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.RefundTxnMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9aa740
	struct UUWorksRequestWebRefundTxn* RefundTxn(); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.RefundTxn // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9aa710
	void QueryTxnMinimal(struct FString Key, int32_t AppID, struct FString OrderID, struct FString TransID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.QueryTxnMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9aa470
	struct UUWorksRequestWebQueryTxn* QueryTxn(); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.QueryTxn // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9aa440
	void ProcessAgreementMinimal(struct FString Key, struct FString OrderID, struct FUWorksSteamID SteamID, struct FString AgreementID, int32_t AppID, int32_t Amount, struct FString Currency, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.ProcessAgreementMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9aa0a0
	struct UUWorksRequestWebProcessAgreement* ProcessAgreement(); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.ProcessAgreement // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9aa070
	void InitTxnMinimal(struct FString Key, struct FString OrderID, struct FUWorksSteamID SteamID, int32_t AppID, int32_t ItemCount, struct FString Language, struct FString Currency, struct TArray<struct FUWorksSteamItemDef> ItemIds, struct TArray<int32_t> Quantities, struct TArray<int32_t> Amounts, struct TArray<struct FString> Descriptions, struct TArray<struct FString> Categories, struct TArray<int32_t> AssociatedBundles, struct TArray<struct FString> BillingTypes, struct TArray<struct FString> StartDates, struct TArray<struct FString> EndDates, struct TArray<struct FString> Periods, struct TArray<int32_t> Frequencies, struct TArray<struct FString> RecurringAmounts, int32_t BundleCount, struct TArray<int32_t> BundleIDs, struct TArray<int32_t> BundleQuantities, struct TArray<struct FString> BundleDescriptions, struct TArray<struct FString> BundleCategories, enum class EUWorksUserSession UserSession, struct FString IPAddress, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.InitTxnMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a8cc0
	struct UUWorksRequestWebInitTxn* InitTxn(); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.InitTxn // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a8c90
	void GetUserInfoMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FString IPAddress, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.GetUserInfoMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a8a80
	struct UUWorksRequestWebGetUserInfo* GetUserInfo(); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.GetUserInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a8a50
	void GetUserAgreementInfoMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.GetUserAgreementInfoMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a88a0
	struct UUWorksRequestWebGetUserAgreementInfo* GetUserAgreementInfo(); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.GetUserAgreementInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a8870
	void GetReportMinimal(struct FString Key, int32_t AppID, struct FString Time, enum class EUWorksReportType Type, int32_t MaxResults, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.GetReportMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a85f0
	struct UUWorksRequestWebGetReport* GetReport(); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.GetReport // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a85c0
	void FinalizeTxnMinimal(struct FString Key, struct FString OrderID, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.FinalizeTxnMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a6df0
	struct UUWorksRequestWebFinalizeTxn* FinalizeTxn(); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.FinalizeTxn // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a6dc0
	void CancelAgreementMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FString AgreementID, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.CancelAgreementMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a6030
	struct UUWorksRequestWebCancelAgreement* CancelAgreement(); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.CancelAgreement // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a6000
	void AdjustAgreementMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FString AgreementID, int32_t AppID, struct FString NextProcessDate, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.AdjustAgreementMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9a5d30
	struct UUWorksRequestWebAdjustAgreement* AdjustAgreement(); // Function UWorksWeb.UWorksInterfaceWebMicroTxn.AdjustAgreement // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a5d00
};

// Class UWorksWeb.UWorksInterfaceWebNews
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebNews : UUWorksInterfaceWeb {

	void GetNewsForAppMinimal(int32_t AppID, int32_t MaxLength, int32_t EndDate, int32_t Count, struct FString Feeds, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebNews.GetNewsForAppMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9accc0
	void GetNewsForAppAuthedMinimal(struct FString Key, int32_t AppID, int32_t MaxLength, int32_t EndDate, int32_t Count, struct FString Feeds, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebNews.GetNewsForAppAuthedMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9ac9f0
	struct UUWorksRequestWebGetNewsForAppAuthed* GetNewsForAppAuthed(); // Function UWorksWeb.UWorksInterfaceWebNews.GetNewsForAppAuthed // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ac9c0
	struct UUWorksRequestWebGetNewsForApp* GetNewsForApp(); // Function UWorksWeb.UWorksInterfaceWebNews.GetNewsForApp // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ac990
};

// Class UWorksWeb.UWorksInterfaceWebPlayer
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebPlayer : UUWorksInterfaceWeb {

	void RecordOfflinePlaytimeMinimal(struct FUWorksSteamID SteamID, struct FString Ticket, struct FUWorksPlaySessions PlaySessions, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPlayer.RecordOfflinePlaytimeMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9afcc0
	struct UUWorksRequestWebRecordOfflinePlaytime* RecordOfflinePlaytime(); // Function UWorksWeb.UWorksInterfaceWebPlayer.RecordOfflinePlaytime // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9afc90
	void IsPlayingSharedGameMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppIDPlaying, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPlayer.IsPlayingSharedGameMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9ad960
	struct UUWorksRequestWebIsPlayingSharedGame* IsPlayingSharedGame(); // Function UWorksWeb.UWorksInterfaceWebPlayer.IsPlayingSharedGame // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ad930
	void GetSteamLevelMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPlayer.GetSteamLevelMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9ad590
	struct UUWorksRequestWebGetSteamLevel* GetSteamLevel(); // Function UWorksWeb.UWorksInterfaceWebPlayer.GetSteamLevel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ad560
	void GetRecentlyPlayedGamesMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t Count, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPlayer.GetRecentlyPlayedGamesMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9ad3b0
	struct UUWorksRequestWebGetRecentlyPlayedGames* GetRecentlyPlayedGames(); // Function UWorksWeb.UWorksInterfaceWebPlayer.GetRecentlyPlayedGames // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ad380
	void GetOwnedGamesMinimal(struct FString Key, struct FUWorksSteamID SteamID, bool bIncludeAppInfo, bool bIncludePlayedFreeGames, struct TArray<int32_t> AppIDsFilter, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPlayer.GetOwnedGamesMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9acf30
	struct UUWorksRequestWebGetOwnedGames* GetOwnedGames(); // Function UWorksWeb.UWorksInterfaceWebPlayer.GetOwnedGames // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9acf00
	void GetCommunityBadgeProgressMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t BadgeID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPlayer.GetCommunityBadgeProgressMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9ac7e0
	struct UUWorksRequestWebGetCommunityBadgeProgress* GetCommunityBadgeProgress(); // Function UWorksWeb.UWorksInterfaceWebPlayer.GetCommunityBadgeProgress // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ac7b0
	void GetBadgesMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPlayer.GetBadgesMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9ac480
	struct UUWorksRequestWebGetBadges* GetBadges(); // Function UWorksWeb.UWorksInterfaceWebPlayer.GetBadges // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ac450
};

// Class UWorksWeb.UWorksInterfaceWebPublishedFile
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebPublishedFile : UUWorksInterfaceWeb {

	void UpdateTagsMinimal(struct FString Key, struct FUWorksPublishedFileID PublishedFileID, int32_t AppID, struct TArray<struct FString> AddTags, struct TArray<struct FString> RemoveTags, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPublishedFile.UpdateTagsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b0d20
	struct UUWorksRequestWebUpdateTags* UpdateTags(); // Function UWorksWeb.UWorksInterfaceWebPublishedFile.UpdateTags // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b0cf0
	void SetDeveloperMetadataMinimal(struct FString Key, struct FUWorksPublishedFileID PublishedFileID, int32_t AppID, struct FString MetaData, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPublishedFile.SetDeveloperMetadataMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b03f0
	struct UUWorksRequestWebSetDeveloperMetadata* SetDeveloperMetadata(); // Function UWorksWeb.UWorksInterfaceWebPublishedFile.SetDeveloperMetadata // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b03c0
	void QueryFilesMinimal(struct FString Key, char QueryType, int32_t Page, int32_t CreatorAppID, int32_t AppID, struct TArray<struct FString> RequiredTags, struct TArray<struct FString> ExcludedTags, struct TArray<struct FString> RequiredFlags, struct TArray<struct FString> OmittedFlags, struct FString SearchText, char FileType, struct FUWorksPublishedFileID ChildPublishedFileID, int32_t Days, bool bIncludeRecentVotesOnly, struct FUWorksRequiredKVTags RequiredKVTags, bool bTotalOnly, bool bIDsOnly, bool bReturnVoteData, bool bReturnTags, bool bReturnKVTags, bool bReturnPreviews, bool bReturnChildren, bool bReturnShortDescription, bool bReturnForSaleData, int32_t ReturnPlaytimeStats, int32_t NumPerPage, bool bMatchAllTags, int32_t CacheMaxAgeSeconds, int32_t Language, bool bReturnMetadata, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPublishedFile.QueryFilesMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9ade00
	struct UUWorksRequestWebQueryFiles* QueryFiles(); // Function UWorksWeb.UWorksInterfaceWebPublishedFile.QueryFiles // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9addd0
};

// Class UWorksWeb.UWorksInterfaceWebPublishedItemSearch
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebPublishedItemSearch : UUWorksInterfaceWeb {

	void ResultSetSummaryMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t TagCount, int32_t UserTagCount, bool bHasAppAdminAccess, int32_t FileType, struct TArray<struct FString> Tags, struct TArray<struct FString> UserTags, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPublishedItemSearch.ResultSetSummaryMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9afea0
	struct UUWorksRequestWebResultSetSummary* ResultSetSummary(); // Function UWorksWeb.UWorksInterfaceWebPublishedItemSearch.ResultSetSummary // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9afe70
	void RankedByVoteMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t StartIndex, int32_t Count, int32_t TagCount, int32_t UserTagCount, bool bHasAppAdminAccess, int32_t FileType, struct TArray<struct FString> Tags, struct TArray<struct FString> UserTags, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPublishedItemSearch.RankedByVoteMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9af6f0
	struct UUWorksRequestWebRankedByVote* RankedByVote(); // Function UWorksWeb.UWorksInterfaceWebPublishedItemSearch.RankedByVote // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9af6c0
	void RankedByTrendMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t StartIndex, int32_t Count, int32_t TagCount, int32_t UserTagCount, bool bHasAppAdminAccess, int32_t FileType, int32_t Days, struct TArray<struct FString> Tags, struct TArray<struct FString> UserTags, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPublishedItemSearch.RankedByTrendMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9af0f0
	struct UUWorksRequestWebRankedByTrend* RankedByTrend(); // Function UWorksWeb.UWorksInterfaceWebPublishedItemSearch.RankedByTrend // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9af0c0
	void RankedByPublicationOrderMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t StartIndex, int32_t Count, int32_t TagCount, int32_t UserTagCount, bool bHasAppAdminAccess, int32_t FileType, struct TArray<struct FString> Tags, struct TArray<struct FString> UserTags, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPublishedItemSearch.RankedByPublicationOrderMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9aeb20
	struct UUWorksRequestWebRankedByPublicationOrder* RankedByPublicationOrder(); // Function UWorksWeb.UWorksInterfaceWebPublishedItemSearch.RankedByPublicationOrder // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9aeaf0
};

// Class UWorksWeb.UWorksInterfaceWebPublishedItemVoting
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebPublishedItemVoting : UUWorksInterfaceWeb {

	void UserVoteSummaryMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t Count, struct TArray<int32_t> PublishedFileIDs, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPublishedItemVoting.UserVoteSummaryMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b1120
	struct UUWorksRequestWebUserVoteSummary* UserVoteSummary(); // Function UWorksWeb.UWorksInterfaceWebPublishedItemVoting.UserVoteSummary // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b10f0
	void ItemVoteSummaryMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t Count, struct TArray<int32_t> PublishedFileIDs, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebPublishedItemVoting.ItemVoteSummaryMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9adb40
	struct UUWorksRequestWebItemVoteSummary* ItemVoteSummary(); // Function UWorksWeb.UWorksInterfaceWebPublishedItemVoting.ItemVoteSummary // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9adb10
};

// Class UWorksWeb.UWorksInterfaceWebRemoteStorage
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebRemoteStorage : UUWorksInterfaceWeb {

	void UnsubscribePublishedFileMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t PublishedFileID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.UnsubscribePublishedFileMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b0b00
	struct UUWorksRequestWebUnsubscribePublishedFile* UnsubscribePublishedFile(); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.UnsubscribePublishedFile // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b0ad0
	void SubscribePublishedFileMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t PublishedFileID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.SubscribePublishedFileMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b08e0
	struct UUWorksRequestWebSubscribePublishedFile* SubscribePublishedFile(); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.SubscribePublishedFile // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b08b0
	void SetUGCUsedByGCMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t UGCID, int32_t AppID, bool bUsed, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.SetUGCUsedByGCMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b0660
	struct UUWorksRequestWebSetUGCUsedByGC* SetUGCUsedByGC(); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.SetUGCUsedByGC // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b0630
	void GetUGCFileDetailsMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t UGCID, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.GetUGCFileDetailsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9ad740
	struct UUWorksRequestWebGetUGCFileDetails* GetUGCFileDetails(); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.GetUGCFileDetails // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ad710
	void GetPublishedFileDetailsMinimal(int32_t ItemCount, struct TArray<int32_t> PublishedFileIDs, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.GetPublishedFileDetailsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9ad200
	struct UUWorksRequestWebGetPublishedFileDetails* GetPublishedFileDetails(); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.GetPublishedFileDetails // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ad1d0
	void GetCollectionDetailsMinimal(int32_t CollectionCount, struct TArray<int32_t> PublishedFileIDs, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.GetCollectionDetailsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9ac630
	struct UUWorksRequestWebGetCollectionDetails* GetCollectionDetails(); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.GetCollectionDetails // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ac600
	void EnumerateUserSubscribedFilesMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t ListType, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.EnumerateUserSubscribedFilesMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9ac260
	struct UUWorksRequestWebEnumerateUserSubscribedFiles* EnumerateUserSubscribedFiles(); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.EnumerateUserSubscribedFiles // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ac230
	void EnumerateUserPublishedFilesMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.EnumerateUserPublishedFilesMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9ac080
	struct UUWorksRequestWebEnumerateUserPublishedFiles* EnumerateUserPublishedFiles(); // Function UWorksWeb.UWorksInterfaceWebRemoteStorage.EnumerateUserPublishedFiles // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ac050
};

// Class UWorksWeb.UWorksInterfaceWebUser
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebUser : UUWorksInterfaceWeb {

	void ResolveVanityURLMinimal(struct FString Key, struct FString VanityURL, char URLType, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUser.ResolveVanityURLMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b5c50
	struct UUWorksRequestWebResolveVanityURL* ResolveVanityURL(); // Function UWorksWeb.UWorksInterfaceWebUser.ResolveVanityURL // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b5c20
	void GrantPackageMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t PackageID, struct FString IPAddress, struct FString ThirdPartyKey, int32_t ThirdPartyAppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUser.GrantPackageMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b5730
	struct UUWorksRequestWebGrantPackage* GrantPackage(); // Function UWorksWeb.UWorksInterfaceWebUser.GrantPackage // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b5700
	void GetUserGroupListMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUser.GetUserGroupListMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b53a0
	struct UUWorksRequestWebGetUserGroupList* GetUserGroupList(); // Function UWorksWeb.UWorksInterfaceWebUser.GetUserGroupList // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b5370
	void GetPublisherAppOwnershipMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUser.GetPublisherAppOwnershipMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b4fb0
	void GetPublisherAppOwnershipChangesMinimal(struct FString Key, struct FString PackageRowVersion, struct FString CDKeyRowVersion, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUser.GetPublisherAppOwnershipChangesMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b4d50
	struct UUWorksRequestWebGetPublisherAppOwnershipChanges* GetPublisherAppOwnershipChanges(); // Function UWorksWeb.UWorksInterfaceWebUser.GetPublisherAppOwnershipChanges // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b4d20
	struct UUWorksRequestWebGetPublisherAppOwnership* GetPublisherAppOwnership(); // Function UWorksWeb.UWorksInterfaceWebUser.GetPublisherAppOwnership // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b4cf0
	void GetPlayerSummariesMinimal(struct FString Key, struct FString SteamIDs, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUser.GetPlayerSummariesMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b4b20
	struct UUWorksRequestWebGetPlayerSummaries* GetPlayerSummaries(); // Function UWorksWeb.UWorksInterfaceWebUser.GetPlayerSummaries // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b4af0
	void GetPlayerBansMinimal(struct FString Key, struct FString SteamIDs, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUser.GetPlayerBansMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b4920
	struct UUWorksRequestWebGetPlayerBans* GetPlayerBans(); // Function UWorksWeb.UWorksInterfaceWebUser.GetPlayerBans // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b48f0
	void GetFriendListMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FString Relationship, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUser.GetFriendListMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b3bf0
	struct UUWorksRequestWebGetFriendList* GetFriendList(); // Function UWorksWeb.UWorksInterfaceWebUser.GetFriendList // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b3bc0
	void GetAppPriceInfoMinimal(struct FString Key, struct FUWorksSteamID SteamID, struct FString AppIDs, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUser.GetAppPriceInfoMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b37d0
	struct UUWorksRequestWebGetAppPriceInfo* GetAppPriceInfo(); // Function UWorksWeb.UWorksInterfaceWebUser.GetAppPriceInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b37a0
	void CheckAppOwnershipMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUser.CheckAppOwnershipMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b35f0
	struct UUWorksRequestWebCheckAppOwnership* CheckAppOwnership(); // Function UWorksWeb.UWorksInterfaceWebUser.CheckAppOwnership // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b35c0
};

// Class UWorksWeb.UWorksInterfaceWebUserAuth
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebUserAuth : UUWorksInterfaceWeb {

	void AuthenticateUserTicketMinimal(struct FString Key, int32_t AppID, struct FString Ticket, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUserAuth.AuthenticateUserTicketMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b33b0
	struct UUWorksRequestWebAuthenticateUserTicket* AuthenticateUserTicket(); // Function UWorksWeb.UWorksInterfaceWebUserAuth.AuthenticateUserTicket // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b3380
	void AuthenticateUserMinimal(struct FUWorksSteamID SteamID, struct TArray<char> SessionKey, struct TArray<char> EncryptedLoginKey, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUserAuth.AuthenticateUserMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b3180
	struct UUWorksRequestWebAuthenticateUser* AuthenticateUser(); // Function UWorksWeb.UWorksInterfaceWebUserAuth.AuthenticateUser // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b3150
};

// Class UWorksWeb.UWorksInterfaceWebUserStats
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebUserStats : UUWorksInterfaceWeb {

	void SetUserStatsForGameMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t Count, struct TArray<struct FString> Name, struct TArray<int32_t> Value, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUserStats.SetUserStatsForGameMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b6cf0
	struct UUWorksRequestWebSetUserStatsForGame* SetUserStatsForGame(); // Function UWorksWeb.UWorksInterfaceWebUserStats.SetUserStatsForGame // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b6cc0
	void GetUserStatsForGameMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUserStats.GetUserStatsForGameMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b5550
	struct UUWorksRequestWebGetUserStatsForGame* GetUserStatsForGame(); // Function UWorksWeb.UWorksInterfaceWebUserStats.GetUserStatsForGame // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b5520
	void GetSchemaForGameMinimal(struct FString Key, int32_t AppID, struct FString Language, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUserStats.GetSchemaForGameMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b5160
	struct UUWorksRequestWebGetSchemaForGame* GetSchemaForGame(); // Function UWorksWeb.UWorksInterfaceWebUserStats.GetSchemaForGame // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b5130
	void GetPlayerAchievementsMinimal(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString Language, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUserStats.GetPlayerAchievementsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b46b0
	struct UUWorksRequestWebGetPlayerAchievements* GetPlayerAchievements(); // Function UWorksWeb.UWorksInterfaceWebUserStats.GetPlayerAchievements // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b4680
	void GetNumberOfCurrentPlayersMinimal(int32_t AppID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUserStats.GetNumberOfCurrentPlayersMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b44f0
	struct UUWorksRequestWebGetNumberOfCurrentPlayers* GetNumberOfCurrentPlayers(); // Function UWorksWeb.UWorksInterfaceWebUserStats.GetNumberOfCurrentPlayers // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b44c0
	void GetGlobalStatsForGameMinimal(int32_t AppID, int32_t Count, struct TArray<struct FString> Name, int32_t StartDate, int32_t EndDate, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUserStats.GetGlobalStatsForGameMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b3f40
	struct UUWorksRequestWebGetGlobalStatsForGame* GetGlobalStatsForGame(); // Function UWorksWeb.UWorksInterfaceWebUserStats.GetGlobalStatsForGame // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b3f10
	void GetGlobalAchievementPercentagesForAppMinimal(struct FUWorksGameID GameID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebUserStats.GetGlobalAchievementPercentagesForAppMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b3e30
	struct UUWorksRequestWebGetGlobalAchievementPercentagesForApp* GetGlobalAchievementPercentagesForApp(); // Function UWorksWeb.UWorksInterfaceWebUserStats.GetGlobalAchievementPercentagesForApp // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b3e00
};

// Class UWorksWeb.UWorksInterfaceWebWorkshop
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceWebWorkshop : UUWorksInterfaceWeb {

	void SetItemPaymentRulesMinimal(struct FString Key, int32_t AppID, int32_t GameItemID, struct FUWorksAssociatedWorkshopFiles AssociatedWorkshopFiles, struct FUWorksPartnerAccounts PartnerAccounts, bool bMakeWorkshopFilesSubscribable, bool bValidateOnly, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebWorkshop.SetItemPaymentRulesMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b69f0
	struct UUWorksRequestWebSetItemPaymentRules* SetItemPaymentRules(); // Function UWorksWeb.UWorksInterfaceWebWorkshop.SetItemPaymentRules // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b69c0
	void PopulateItemDescriptionsMinimal(struct FString Key, int32_t AppID, struct FUWorksLanguages Languages, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebWorkshop.PopulateItemDescriptionsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b5a70
	struct UUWorksRequestWebPopulateItemDescriptions* PopulateItemDescriptions(); // Function UWorksWeb.UWorksInterfaceWebWorkshop.PopulateItemDescriptions // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b5a40
	void GetItemDailyRevenueMinimal(struct FString Key, int32_t AppID, struct FString ItemId, int32_t DateStart, int32_t DateEnd, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebWorkshop.GetItemDailyRevenueMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b4240
	struct UUWorksRequestWebGetItemDailyRevenue* GetItemDailyRevenue(); // Function UWorksWeb.UWorksInterfaceWebWorkshop.GetItemDailyRevenue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b4210
	void GetFinalizedContributorsMinimal(struct FString Key, int32_t AppID, int32_t GameItemID, struct FDelegate Delegate); // Function UWorksWeb.UWorksInterfaceWebWorkshop.GetFinalizedContributorsMinimal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b3a10
	struct UUWorksRequestWebGetFinalizedContributors* GetFinalizedContributors(); // Function UWorksWeb.UWorksInterfaceWebWorkshop.GetFinalizedContributors // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b39e0
};

// Class UWorksWeb.UWorksRequestWeb
// Size: 0xa0 (Inherited: 0x28)
struct UUWorksRequestWeb : UUWorksRequest {
	char pad_28[0x78]; // 0x28(0x78)

	bool IsActive(); // Function UWorksWeb.UWorksRequestWeb.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	struct FString GetStatus(); // Function UWorksWeb.UWorksRequestWeb.GetStatus // (Native|Public|BlueprintCallable) // @ game+0x9f4b90
	void Deactivate(); // Function UWorksWeb.UWorksRequestWeb.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksWeb.UWorksRequestWeb.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksWeb.UWorksRequestWebGetAppBetas
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetAppBetas : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID); // Function UWorksWeb.UWorksRequestWebGetAppBetas.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9b5e60
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetAppBetas.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetAppBuilds
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetAppBuilds : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, int32_t Count); // Function UWorksWeb.UWorksRequestWebGetAppBuilds.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9b5f90
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetAppBuilds.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetAppDepotVersions
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetAppDepotVersions : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID); // Function UWorksWeb.UWorksRequestWebGetAppDepotVersions.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9b5e60
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetAppDepotVersions.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetAppList
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetAppList : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetAppList.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetCheatingReportsList
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetCheatingReportsList : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, int32_t TimeBegin, int32_t TimeEnd, bool bIncludeReports, bool bIncludeBans, struct FString ReportIDMin); // Function UWorksWeb.UWorksRequestWebGetCheatingReportsList.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9b60f0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetCheatingReportsList.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetPlayersBanned
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetPlayersBanned : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID); // Function UWorksWeb.UWorksRequestWebGetPlayersBanned.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9b5e60
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetPlayersBanned.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetServerList
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetServerList : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString Filter, int32_t Limit); // Function UWorksWeb.UWorksRequestWebGetServerList.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9b63c0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetServerList.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetServersAtAddress
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetServersAtAddress : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Addr); // Function UWorksWeb.UWorksRequestWebGetServersAtAddress.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9b6570
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetServersAtAddress.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebSetAppBuildLive
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebSetAppBuildLive : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, int32_t BuildId, struct FString BetaKey, struct FString Description); // Function UWorksWeb.UWorksRequestWebSetAppBuildLive.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9b6660
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebSetAppBuildLive.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebUpToDateCheck
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebUpToDateCheck : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(int32_t AppID, int32_t VersionToCheck); // Function UWorksWeb.UWorksRequestWebUpToDateCheck.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9b68f0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebUpToDateCheck.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebPostGameDataFrame
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebPostGameDataFrame : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString BroadcastID, struct FString FrameData); // Function UWorksWeb.UWorksRequestWebPostGameDataFrame.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bc950
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebPostGameDataFrame.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebReportPlayerCheating
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebReportPlayerCheating : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FUWorksSteamID SteamIDReporter, int32_t AppData, bool bHeuristic, bool bDetection, bool bPlayerReport, bool bNoReportID, int32_t GameMode, int32_t SuspicionStartTime, int32_t Severity); // Function UWorksWeb.UWorksRequestWebReportPlayerCheating.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bd740
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebReportPlayerCheating.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebRequestPlayerGameBan
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebRequestPlayerGameBan : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FUWorksSteamID ReportID, struct FString CheatDescription, int32_t Duration, bool bDelayBan); // Function UWorksWeb.UWorksRequestWebRequestPlayerGameBan.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bdb10
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebRequestPlayerGameBan.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebRemovePlayerGameBan
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebRemovePlayerGameBan : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.UWorksRequestWebRemovePlayerGameBan.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bcbe0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebRemovePlayerGameBan.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetCheatingReports
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetCheatingReports : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, int32_t TimeEnd, int32_t TimeBegin, struct FString ReportIDMin, bool bIncludeReports, bool bIncludeBans, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebGetCheatingReports.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bb680
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetCheatingReports.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebRequestVacStatusForUser
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebRequestVacStatusForUser : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString SessionId); // Function UWorksWeb.UWorksRequestWebRequestVacStatusForUser.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ba7d0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebRequestVacStatusForUser.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebStartSecureMultiplayerSession
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebStartSecureMultiplayerSession : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.UWorksRequestWebStartSecureMultiplayerSession.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bcbe0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebStartSecureMultiplayerSession.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebEndSecureMultiplayerSession
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebEndSecureMultiplayerSession : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString SessionId); // Function UWorksWeb.UWorksRequestWebEndSecureMultiplayerSession.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ba7d0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebEndSecureMultiplayerSession.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebReportCheatData
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebReportCheatData : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString PathAndFileName, struct FString WebCheatURL, struct FString TimeNow, struct FString TimeStarted, struct FString TimeStopped, struct FString CheatName, int32_t GameProcessID, int32_t CheatProcessID, struct FString CheatParamA, struct FString CheatParamB); // Function UWorksWeb.UWorksRequestWebReportCheatData.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bd090
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebReportCheatData.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebReportAbuse
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebReportAbuse : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamIDActor, struct FUWorksSteamID SteamIDTarget, int32_t AppID, char AbuseType, char ContentType, struct FString Description, struct FString GID); // Function UWorksWeb.UWorksRequestWebReportAbuse.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bcd40
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebReportAbuse.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetTradeHistory
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetTradeHistory : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t MaxTrades, int32_t StartAfterTime, struct FString StartAfterTradeID, bool bNavigatingBack, bool bGetDescription, struct FString Language, bool bIncludeFailed, bool bIncludeTotal); // Function UWorksWeb.UWorksRequestWebGetTradeHistory.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bbf40
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetTradeHistory.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebFlushInventoryCache
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebFlushInventoryCache : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString ContextID); // Function UWorksWeb.UWorksRequestWebFlushInventoryCache.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bad80
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebFlushInventoryCache.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebFlushAssetAppearanceCache
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebFlushAssetAppearanceCache : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID); // Function UWorksWeb.UWorksRequestWebFlushAssetAppearanceCache.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bac50
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebFlushAssetAppearanceCache.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebFlushContextCache
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebFlushContextCache : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID); // Function UWorksWeb.UWorksRequestWebFlushContextCache.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bac50
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebFlushContextCache.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetTradeOffers
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetTradeOffers : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, bool bGetSentOffers, bool bGetReceivedOffers, bool bGetDescription, struct FString Language, bool bActiveOnly, bool bHistoricalOnly, int32_t TimeHistoricalCutoff); // Function UWorksWeb.UWorksRequestWebGetTradeOffers.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bc500
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetTradeOffers.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetTradeOffer
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetTradeOffer : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString TradeOfferID, struct FString Language); // Function UWorksWeb.UWorksRequestWebGetTradeOffer.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bc2f0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetTradeOffer.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetTradeOffersSummary
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetTradeOffersSummary : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t TimeLastVisit); // Function UWorksWeb.UWorksRequestWebGetTradeOffersSummary.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bc820
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetTradeOffersSummary.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebDeclineTradeOffer
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebDeclineTradeOffer : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString TradeOfferID); // Function UWorksWeb.UWorksRequestWebDeclineTradeOffer.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ba650
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebDeclineTradeOffer.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebCancelTradeOffer
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebCancelTradeOffer : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString TradeOfferID); // Function UWorksWeb.UWorksRequestWebCancelTradeOffer.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ba650
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebCancelTradeOffer.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetMarketEligibility
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetMarketEligibility : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebGetMarketEligibility.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bbb90
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetMarketEligibility.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebCancelAppListingsForUser
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebCancelAppListingsForUser : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, bool bSynchronous); // Function UWorksWeb.UWorksRequestWebCancelAppListingsForUser.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ba4b0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebCancelAppListingsForUser.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetAssetID
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetAssetID : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString ListingID); // Function UWorksWeb.UWorksRequestWebGetAssetID.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bb290
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetAssetID.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetPopular
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetPopular : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString Language, int32_t Rows, int32_t Start, int32_t FilterAppID, int32_t ECurrency); // Function UWorksWeb.UWorksRequestWebGetPopular.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bbcc0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetPopular.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebCanTrade
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebCanTrade : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FUWorksSteamID TargetId); // Function UWorksWeb.UWorksRequestWebCanTrade.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ba310
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebCanTrade.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebFinalizeAssetTransaction
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebFinalizeAssetTransaction : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString TxnID, struct FString Language); // Function UWorksWeb.UWorksRequestWebFinalizeAssetTransaction.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ba9c0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebFinalizeAssetTransaction.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetAssetClassInfo
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetAssetClassInfo : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, int32_t ClassCount, struct FString ClassID, struct FString Language, struct FString InstanceID); // Function UWorksWeb.UWorksRequestWebGetAssetClassInfo.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9baf70
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetAssetClassInfo.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetAssetPrices
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetAssetPrices : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString Currency, struct FString Language); // Function UWorksWeb.UWorksRequestWebGetAssetPrices.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bb440
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetAssetPrices.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetExportedAssetsForUser
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetExportedAssetsForUser : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString ContextID); // Function UWorksWeb.UWorksRequestWebGetExportedAssetsForUser.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bb9a0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetExportedAssetsForUser.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetMarketPrices
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetMarketPrices : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID); // Function UWorksWeb.UWorksRequestWebGetMarketPrices.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9b5e60
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetMarketPrices.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebStartAssetTransaction
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebStartAssetTransaction : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString AssetID, int32_t AssetQuantity, struct FString Currency, struct FString Language, struct FString IPAddress, struct FString Referrer, bool bClientAuth); // Function UWorksWeb.UWorksRequestWebStartAssetTransaction.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bddd0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebStartAssetTransaction.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebStartTrade
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebStartTrade : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID PartyA, struct FUWorksSteamID PartyB); // Function UWorksWeb.UWorksRequestWebStartTrade.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9be2a0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebStartTrade.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetHistoryCommandDetails
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetHistoryCommandDetails : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString Command, struct FString ContextID, struct FString Arguments); // Function UWorksWeb.UWorksRequestWebGetHistoryCommandDetails.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c32c0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetHistoryCommandDetails.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetUserHistory
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetUserHistory : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString ContextID, int32_t StartTime, int32_t EndTime); // Function UWorksWeb.UWorksRequestWebGetUserHistory.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c4220
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetUserHistory.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebHistoryExecuteCommands
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebHistoryExecuteCommands : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString ContextID, struct FString ActorId); // Function UWorksWeb.UWorksRequestWebHistoryExecuteCommands.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c44a0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebHistoryExecuteCommands.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebSupportGetAssetHistory
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebSupportGetAssetHistory : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString AssetID, struct FString ContextID); // Function UWorksWeb.UWorksRequestWebSupportGetAssetHistory.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c4c10
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebSupportGetAssetHistory.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebCreateSession
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebCreateSession : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString Context, struct FUWorksTitle Title, struct FUWorksUsers Users, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebCreateSession.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c2380
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebCreateSession.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebUpdateSession
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebUpdateSession : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString SessionId, int32_t AppID, struct FUWorksTitle Title, struct FUWorksUsers Users, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebUpdateSession.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c4e50
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebUpdateSession.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebEnumerateSessionsForApp
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebEnumerateSessionsForApp : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, bool bIncludeAllUserMessages, bool bIncludeAuthUserMessage, struct FString Language); // Function UWorksWeb.UWorksRequestWebEnumerateSessionsForApp.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c29a0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebEnumerateSessionsForApp.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetSessionDetailsForApp
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetSessionDetailsForApp : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSessions Sessions, int32_t AppID, struct FString Language); // Function UWorksWeb.UWorksRequestWebGetSessionDetailsForApp.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c4030
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetSessionDetailsForApp.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebRequestNotifications
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebRequestNotifications : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.UWorksRequestWebRequestNotifications.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bcbe0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebRequestNotifications.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebDeleteSession
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebDeleteSession : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString SessionId, int32_t AppID, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebDeleteSession.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c2600
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebDeleteSession.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebDeleteSessionBatch
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebDeleteSessionBatch : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString SessionId, int32_t AppID); // Function UWorksWeb.UWorksRequestWebDeleteSessionBatch.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c27f0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebDeleteSessionBatch.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetAccountList
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetAccountList : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key); // Function UWorksWeb.UWorksRequestWebGetAccountList.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c2f00
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetAccountList.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebCreateAccount
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebCreateAccount : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString Memo); // Function UWorksWeb.UWorksRequestWebCreateAccount.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c21d0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebCreateAccount.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebSetMemo
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebSetMemo : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, struct FString Memo); // Function UWorksWeb.UWorksRequestWebSetMemo.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c4a60
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebSetMemo.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebResetLoginToken
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebResetLoginToken : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebResetLoginToken.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bbb90
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebResetLoginToken.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebDeleteAccount
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebDeleteAccount : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebDeleteAccount.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bbb90
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebDeleteAccount.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetAccountPublicInfo
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetAccountPublicInfo : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebGetAccountPublicInfo.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bbb90
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetAccountPublicInfo.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebQueryLoginToken
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebQueryLoginToken : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString LoginToken); // Function UWorksWeb.UWorksRequestWebQueryLoginToken.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c4730
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebQueryLoginToken.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebSetBanStatus
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebSetBanStatus : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, bool bBanned, int32_t BanSeconds); // Function UWorksWeb.UWorksRequestWebSetBanStatus.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c48b0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebSetBanStatus.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetServerSteamIDsByIP
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetServerSteamIDsByIP : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString ServerIPs); // Function UWorksWeb.UWorksRequestWebGetServerSteamIDsByIP.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c3eb0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetServerSteamIDsByIP.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetServerIPsBySteamID
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetServerIPsBySteamID : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID ServerSteamID); // Function UWorksWeb.UWorksRequestWebGetServerIPsBySteamID.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c3d80
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetServerIPsBySteamID.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetGameServerPlayerStatsForGame
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetGameServerPlayerStatsForGame : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksGameID GameID, int32_t AppID, struct FString RangeStart, struct FString RangeEnd, int32_t MaxResults); // Function UWorksWeb.UWorksRequestWebGetGameServerPlayerStatsForGame.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c2ff0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetGameServerPlayerStatsForGame.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebAddItem
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebAddItem : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct TArray<struct FUWorksSteamItemDef> ItemDefID, struct FString ItemPropsJSON, struct FUWorksSteamID SteamID, bool bNotify, struct FString RequestID); // Function UWorksWeb.UWorksRequestWebAddItem.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c16a0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebAddItem.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebAddPromoItem
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebAddPromoItem : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamItemDef ItemDefID, struct FString ItemPropsJSON, struct FUWorksSteamID SteamID, bool bNotify, struct FString RequestID); // Function UWorksWeb.UWorksRequestWebAddPromoItem.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c1a00
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebAddPromoItem.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebConsumeItem
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebConsumeItem : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamItemInstanceID ItemId, int32_t Quantity, struct FUWorksSteamID SteamID, struct FString RequestID); // Function UWorksWeb.UWorksRequestWebConsumeItem.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c1f50
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebConsumeItem.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebExchangeItem
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebExchangeItem : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct TArray<struct FUWorksSteamItemInstanceID> MaterialsItemID, struct TArray<int32_t> MaterialsQuantity, struct FUWorksSteamItemDef OutputItemDefID); // Function UWorksWeb.UWorksRequestWebExchangeItem.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c2c30
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebExchangeItem.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetInventory
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetInventory : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebGetInventory.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c35e0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetInventory.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetItemDefs
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetItemDefs : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString ModifiedSince, struct TArray<struct FUWorksSteamItemDef> ItemDefIDs, struct TArray<struct FUWorksSteamItemDef> WorkshopIDs, int32_t CacheMaxAgeSeconds); // Function UWorksWeb.UWorksRequestWebGetItemDefs.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c3740
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetItemDefs.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetPriceSheet
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetPriceSheet : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t ECurrency); // Function UWorksWeb.UWorksRequestWebGetPriceSheet.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c3a60
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetPriceSheet.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebConsolidate
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebConsolidate : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct TArray<struct FUWorksSteamItemDef> ItemDefID, bool bForce); // Function UWorksWeb.UWorksRequestWebConsolidate.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c1d10
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebConsolidate.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetQuantity
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetQuantity : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FUWorksSteamItemDef ItemDefID, bool bForce); // Function UWorksWeb.UWorksRequestWebGetQuantity.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c3b90
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetQuantity.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebDeleteLeaderboard
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebDeleteLeaderboard : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString Name); // Function UWorksWeb.UWorksRequestWebDeleteLeaderboard.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c7de0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebDeleteLeaderboard.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebFindOrCreateLeaderboard
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebFindOrCreateLeaderboard : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString Name, struct FString SortMethod, struct FString DisplayType, bool bCreateIfNotFound, bool bOnlyTrustedWrites, bool bOnlyFriendsReads); // Function UWorksWeb.UWorksRequestWebFindOrCreateLeaderboard.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c8140
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebFindOrCreateLeaderboard.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetLeaderboardEntries
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetLeaderboardEntries : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, int32_t RangeStart, int32_t RangeEnd, int32_t LeaderboardID, int32_t DataRequest, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebGetLeaderboardEntries.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c8650
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetLeaderboardEntries.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetLeaderboardsForGame
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetLeaderboardsForGame : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID); // Function UWorksWeb.UWorksRequestWebGetLeaderboardsForGame.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9b5e60
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetLeaderboardsForGame.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebResetLeaderboard
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebResetLeaderboard : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, int32_t LeaderboardID); // Function UWorksWeb.UWorksRequestWebResetLeaderboard.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9cb1e0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebResetLeaderboard.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebSetLeaderboardScore
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebSetLeaderboardScore : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, int32_t LeaderboardID, struct FUWorksSteamID SteamID, int32_t Score, struct FString ScoreMethod, struct TArray<char> Details); // Function UWorksWeb.UWorksRequestWebSetLeaderboardScore.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9cb340
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebSetLeaderboardScore.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebAdjustAgreement
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebAdjustAgreement : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, struct FString AgreementID, int32_t AppID, struct FString NextProcessDate); // Function UWorksWeb.UWorksRequestWebAdjustAgreement.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c7970
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebAdjustAgreement.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebCancelAgreement
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebCancelAgreement : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, struct FString AgreementID, int32_t AppID); // Function UWorksWeb.UWorksRequestWebCancelAgreement.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c7bf0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebCancelAgreement.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebFinalizeTxn
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebFinalizeTxn : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString OrderID, int32_t AppID); // Function UWorksWeb.UWorksRequestWebFinalizeTxn.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c7f90
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebFinalizeTxn.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetReport
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetReport : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString Time, enum class EUWorksReportType Type, int32_t MaxResults); // Function UWorksWeb.UWorksRequestWebGetReport.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c90e0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetReport.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetUserAgreementInfo
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetUserAgreementInfo : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.UWorksRequestWebGetUserAgreementInfo.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c9320
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetUserAgreementInfo.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetUserInfo
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetUserInfo : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, struct FString IPAddress); // Function UWorksWeb.UWorksRequestWebGetUserInfo.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c9480
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetUserInfo.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebInitTxn
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebInitTxn : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString OrderID, struct FUWorksSteamID SteamID, int32_t AppID, int32_t ItemCount, struct FString Language, struct FString Currency, struct TArray<struct FUWorksSteamItemDef> ItemIds, struct TArray<int32_t> Quantities, struct TArray<int32_t> Amounts, struct TArray<struct FString> Descriptions, struct TArray<struct FString> Categories, struct TArray<int32_t> AssociatedBundles, struct TArray<struct FString> BillingTypes, struct TArray<struct FString> StartDates, struct TArray<struct FString> EndDates, struct TArray<struct FString> Periods, struct TArray<int32_t> Frequencies, struct TArray<struct FString> RecurringAmounts, int32_t BundleCount, struct TArray<int32_t> BundleIDs, struct TArray<int32_t> BundleQuantities, struct TArray<struct FString> BundleDescriptions, struct TArray<struct FString> BundleCategories, enum class EUWorksUserSession UserSession, struct FString IPAddress); // Function UWorksWeb.UWorksRequestWebInitTxn.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c9630
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebInitTxn.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebProcessAgreement
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebProcessAgreement : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString OrderID, struct FUWorksSteamID SteamID, struct FString AgreementID, int32_t AppID, int32_t Amount, struct FString Currency); // Function UWorksWeb.UWorksRequestWebProcessAgreement.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9caae0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebProcessAgreement.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebQueryTxn
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebQueryTxn : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString OrderID, struct FString TransID); // Function UWorksWeb.UWorksRequestWebQueryTxn.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9cae40
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebQueryTxn.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebRefundTxn
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebRefundTxn : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString OrderID, int32_t AppID); // Function UWorksWeb.UWorksRequestWebRefundTxn.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c7f90
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebRefundTxn.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetNewsForApp
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetNewsForApp : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(int32_t AppID, int32_t MaxLength, int32_t EndDate, int32_t Count, struct FString Feeds); // Function UWorksWeb.UWorksRequestWebGetNewsForApp.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c88c0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetNewsForApp.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetNewsForAppAuthed
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetNewsForAppAuthed : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, int32_t MaxLength, int32_t EndDate, int32_t Count, struct FString Feeds); // Function UWorksWeb.UWorksRequestWebGetNewsForAppAuthed.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c8ab0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetNewsForAppAuthed.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebRecordOfflinePlaytime
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebRecordOfflinePlaytime : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FUWorksSteamID SteamID, struct FString Ticket, struct FUWorksPlaySessions PlaySessions); // Function UWorksWeb.UWorksRequestWebRecordOfflinePlaytime.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9cb080
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebRecordOfflinePlaytime.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetRecentlyPlayedGames
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetRecentlyPlayedGames : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t Count); // Function UWorksWeb.UWorksRequestWebGetRecentlyPlayedGames.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c8f80
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetRecentlyPlayedGames.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetOwnedGames
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetOwnedGames : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, bool bIncludeAppInfo, bool bIncludePlayedFreeGames, struct TArray<int32_t> AppIDsFilter); // Function UWorksWeb.UWorksRequestWebGetOwnedGames.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c8d30
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetOwnedGames.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetSteamLevel
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetSteamLevel : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebGetSteamLevel.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bbb90
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetSteamLevel.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetBadges
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetBadges : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebGetBadges.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9bbb90
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetBadges.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetCommunityBadgeProgress
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetCommunityBadgeProgress : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t BadgeID); // Function UWorksWeb.UWorksRequestWebGetCommunityBadgeProgress.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c84f0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetCommunityBadgeProgress.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebIsPlayingSharedGame
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebIsPlayingSharedGame : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppIDPlaying); // Function UWorksWeb.UWorksRequestWebIsPlayingSharedGame.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ca980
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebIsPlayingSharedGame.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebQueryFiles
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebQueryFiles : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, char QueryType, int32_t Page, int32_t CreatorAppID, int32_t AppID, struct TArray<struct FString> RequiredTags, struct TArray<struct FString> ExcludedTags, struct TArray<struct FString> RequiredFlags, struct TArray<struct FString> OmittedFlags, struct FString SearchText, char FileType, struct FUWorksPublishedFileID ChildPublishedFileID, int32_t Days, bool bIncludeRecentVotesOnly, struct FUWorksRequiredKVTags RequiredKVTags, bool bTotalOnly, bool bIDsOnly, bool bReturnVoteData, bool bReturnTags, bool bReturnKVTags, bool bReturnPreviews, bool bReturnChildren, bool bReturnShortDescription, bool bReturnForSaleData, int32_t ReturnPlaytimeStats, int32_t NumPerPage, bool bMatchAllTags, int32_t CacheMaxAgeSeconds, int32_t Language, bool bReturnMetadata); // Function UWorksWeb.UWorksRequestWebQueryFiles.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9cf500
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebQueryFiles.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebSetDeveloperMetadata
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebSetDeveloperMetadata : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksPublishedFileID PublishedFileID, int32_t AppID, struct FString MetaData); // Function UWorksWeb.UWorksRequestWebSetDeveloperMetadata.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d12a0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebSetDeveloperMetadata.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebUpdateTags
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebUpdateTags : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksPublishedFileID PublishedFileID, int32_t AppID, struct TArray<struct FString> AddTags, struct TArray<struct FString> RemoveTags); // Function UWorksWeb.UWorksRequestWebUpdateTags.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d1820
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebUpdateTags.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebRankedByPublicationOrder
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebRankedByPublicationOrder : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t StartIndex, int32_t Count, int32_t TagCount, int32_t UserTagCount, bool bHasAppAdminAccess, int32_t FileType, struct TArray<struct FString> Tags, struct TArray<struct FString> UserTags); // Function UWorksWeb.UWorksRequestWebRankedByPublicationOrder.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d0190
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebRankedByPublicationOrder.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebRankedByTrend
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebRankedByTrend : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t StartIndex, int32_t Count, int32_t TagCount, int32_t UserTagCount, bool bHasAppAdminAccess, int32_t FileType, int32_t Days, struct TArray<struct FString> Tags, struct TArray<struct FString> UserTags); // Function UWorksWeb.UWorksRequestWebRankedByTrend.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d06d0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebRankedByTrend.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebRankedByVote
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebRankedByVote : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t StartIndex, int32_t Count, int32_t TagCount, int32_t UserTagCount, bool bHasAppAdminAccess, int32_t FileType, struct TArray<struct FString> Tags, struct TArray<struct FString> UserTags); // Function UWorksWeb.UWorksRequestWebRankedByVote.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d0190
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebRankedByVote.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebResultSetSummary
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebResultSetSummary : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t TagCount, int32_t UserTagCount, bool bHasAppAdminAccess, int32_t FileType, struct TArray<struct FString> Tags, struct TArray<struct FString> UserTags); // Function UWorksWeb.UWorksRequestWebResultSetSummary.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d0df0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebResultSetSummary.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebItemVoteSummary
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebItemVoteSummary : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t Count, struct TArray<int32_t> PublishedFileIDs); // Function UWorksWeb.UWorksRequestWebItemVoteSummary.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9cf2c0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebItemVoteSummary.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebUserVoteSummary
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebUserVoteSummary : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t Count, struct TArray<int32_t> PublishedFileIDs); // Function UWorksWeb.UWorksRequestWebUserVoteSummary.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9cf2c0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebUserVoteSummary.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebEnumerateUserPublishedFiles
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebEnumerateUserPublishedFiles : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.UWorksRequestWebEnumerateUserPublishedFiles.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c9320
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebEnumerateUserPublishedFiles.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebEnumerateUserSubscribedFiles
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebEnumerateUserSubscribedFiles : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t ListType); // Function UWorksWeb.UWorksRequestWebEnumerateUserSubscribedFiles.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ce230
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebEnumerateUserSubscribedFiles.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetCollectionDetails
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetCollectionDetails : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(int32_t CollectionCount, struct TArray<int32_t> PublishedFileIDs); // Function UWorksWeb.UWorksRequestWebGetCollectionDetails.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ce580
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetCollectionDetails.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetPublishedFileDetails
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetPublishedFileDetails : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(int32_t ItemCount, struct TArray<int32_t> PublishedFileIDs); // Function UWorksWeb.UWorksRequestWebGetPublishedFileDetails.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ce9e0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetPublishedFileDetails.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetUGCFileDetails
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetUGCFileDetails : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t UGCID, int32_t AppID); // Function UWorksWeb.UWorksRequestWebGetUGCFileDetails.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9cee50
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetUGCFileDetails.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebSetUGCUsedByGC
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebSetUGCUsedByGC : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t UGCID, int32_t AppID, bool bUsed); // Function UWorksWeb.UWorksRequestWebSetUGCUsedByGC.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d1490
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebSetUGCUsedByGC.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebSubscribePublishedFile
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebSubscribePublishedFile : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t PublishedFileID); // Function UWorksWeb.UWorksRequestWebSubscribePublishedFile.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d1680
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebSubscribePublishedFile.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebUnsubscribePublishedFile
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebUnsubscribePublishedFile : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t PublishedFileID); // Function UWorksWeb.UWorksRequestWebUnsubscribePublishedFile.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d1680
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebUnsubscribePublishedFile.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebCheckAppOwnership
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebCheckAppOwnership : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.UWorksRequestWebCheckAppOwnership.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c9320
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebCheckAppOwnership.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetAppPriceInfo
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetAppPriceInfo : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, struct FString AppIDs); // Function UWorksWeb.UWorksRequestWebGetAppPriceInfo.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ce3d0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetAppPriceInfo.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetFriendList
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetFriendList : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, struct FString Relationship); // Function UWorksWeb.UWorksRequestWebGetFriendList.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ce6b0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetFriendList.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetPlayerBans
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetPlayerBans : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString SteamIDs); // Function UWorksWeb.UWorksRequestWebGetPlayerBans.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ce860
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetPlayerBans.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetPlayerSummaries
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetPlayerSummaries : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString SteamIDs); // Function UWorksWeb.UWorksRequestWebGetPlayerSummaries.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ce860
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetPlayerSummaries.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetPublisherAppOwnership
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetPublisherAppOwnership : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebGetPublisherAppOwnership.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ceb10
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetPublisherAppOwnership.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetPublisherAppOwnershipChanges
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetPublisherAppOwnershipChanges : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString PackageRowVersion, struct FString CDKeyRowVersion); // Function UWorksWeb.UWorksRequestWebGetPublisherAppOwnershipChanges.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9cec40
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetPublisherAppOwnershipChanges.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetUserGroupList
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetUserGroupList : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.UWorksRequestWebGetUserGroupList.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ceb10
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetUserGroupList.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGrantPackage
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGrantPackage : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t PackageID, struct FString IPAddress, struct FString ThirdPartyKey, int32_t ThirdPartyAppID); // Function UWorksWeb.UWorksRequestWebGrantPackage.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9ceff0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGrantPackage.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebResolveVanityURL
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebResolveVanityURL : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FString VanityURL, char URLType); // Function UWorksWeb.UWorksRequestWebResolveVanityURL.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d0c40
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebResolveVanityURL.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebAuthenticateUser
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebAuthenticateUser : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FUWorksSteamID SteamID, struct TArray<char> SessionKey, struct TArray<char> EncryptedLoginKey); // Function UWorksWeb.UWorksRequestWebAuthenticateUser.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d7370
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebAuthenticateUser.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebAuthenticateUserTicket
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebAuthenticateUserTicket : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString Ticket); // Function UWorksWeb.UWorksRequestWebAuthenticateUserTicket.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d7510
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebAuthenticateUserTicket.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetGlobalAchievementPercentagesForApp
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetGlobalAchievementPercentagesForApp : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FUWorksGameID GameID); // Function UWorksWeb.UWorksRequestWebGetGlobalAchievementPercentagesForApp.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d7820
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetGlobalAchievementPercentagesForApp.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetGlobalStatsForGame
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetGlobalStatsForGame : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(int32_t AppID, int32_t Count, struct TArray<struct FString> Name, int32_t StartDate, int32_t EndDate); // Function UWorksWeb.UWorksRequestWebGetGlobalStatsForGame.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d78b0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetGlobalStatsForGame.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetNumberOfCurrentPlayers
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetNumberOfCurrentPlayers : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(int32_t AppID); // Function UWorksWeb.UWorksRequestWebGetNumberOfCurrentPlayers.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d7d70
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetNumberOfCurrentPlayers.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetPlayerAchievements
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetPlayerAchievements : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString Language); // Function UWorksWeb.UWorksRequestWebGetPlayerAchievements.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d7e00
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetPlayerAchievements.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetSchemaForGame
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetSchemaForGame : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString Language); // Function UWorksWeb.UWorksRequestWebGetSchemaForGame.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d7ff0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetSchemaForGame.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetUserStatsForGame
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetUserStatsForGame : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.UWorksRequestWebGetUserStatsForGame.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9c9320
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetUserStatsForGame.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebSetUserStatsForGame
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebSetUserStatsForGame : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t Count, struct TArray<struct FString> Name, struct TArray<int32_t> Value); // Function UWorksWeb.UWorksRequestWebSetUserStatsForGame.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d8580
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebSetUserStatsForGame.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebSetItemPaymentRules
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebSetItemPaymentRules : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, int32_t GameItemID, struct FUWorksAssociatedWorkshopFiles AssociatedWorkshopFiles, struct FUWorksPartnerAccounts PartnerAccounts, bool bMakeWorkshopFilesSubscribable, bool bValidateOnly); // Function UWorksWeb.UWorksRequestWebSetItemPaymentRules.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d8300
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebSetItemPaymentRules.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetFinalizedContributors
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetFinalizedContributors : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, int32_t GameItemID); // Function UWorksWeb.UWorksRequestWebGetFinalizedContributors.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d76c0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetFinalizedContributors.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebGetItemDailyRevenue
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebGetItemDailyRevenue : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FString ItemId, int32_t DateStart, int32_t DateEnd); // Function UWorksWeb.UWorksRequestWebGetItemDailyRevenue.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d7b30
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebGetItemDailyRevenue.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.UWorksRequestWebPopulateItemDescriptions
// Size: 0xc0 (Inherited: 0xa0)
struct UUWorksRequestWebPopulateItemDescriptions : UUWorksRequestWeb {
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xa0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xb0(0x10)

	void SetInput(struct FString Key, int32_t AppID, struct FUWorksLanguages Languages); // Function UWorksWeb.UWorksRequestWebPopulateItemDescriptions.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x9d81a0
	void GetOutput(struct FString Content); // Function UWorksWeb.UWorksRequestWebPopulateItemDescriptions.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b45d0
};

// Class UWorksWeb.GetAppBetasNode
// Size: 0x40 (Inherited: 0x30)
struct UGetAppBetasNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetAppBetasNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetAppBetasNode* GetAppBetasNode(struct FString Key, int32_t AppID); // Function UWorksWeb.GetAppBetasNode.GetAppBetasNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d5070
};

// Class UWorksWeb.GetAppBuildsNode
// Size: 0x40 (Inherited: 0x30)
struct UGetAppBuildsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetAppBuildsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetAppBuildsNode* GetAppBuildsNode(struct FString Key, int32_t AppID, int32_t Count); // Function UWorksWeb.GetAppBuildsNode.GetAppBuildsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d51a0
};

// Class UWorksWeb.GetAppDepotVersionsNode
// Size: 0x40 (Inherited: 0x30)
struct UGetAppDepotVersionsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetAppDepotVersionsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetAppDepotVersionsNode* GetAppDepotVersionsNode(struct FString Key, int32_t AppID); // Function UWorksWeb.GetAppDepotVersionsNode.GetAppDepotVersionsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d5300
};

// Class UWorksWeb.GetAppListNode
// Size: 0x40 (Inherited: 0x30)
struct UGetAppListNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetAppListNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetAppListNode* GetAppListNode(); // Function UWorksWeb.GetAppListNode.GetAppListNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d5430
};

// Class UWorksWeb.GetCheatingReportsListNode
// Size: 0x40 (Inherited: 0x30)
struct UGetCheatingReportsListNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetCheatingReportsListNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetCheatingReportsListNode* GetCheatingReportsListNode(struct FString Key, int32_t AppID, int32_t TimeBegin, int32_t TimeEnd, bool bIncludeReports, bool bIncludeBans, struct FString ReportIDMin); // Function UWorksWeb.GetCheatingReportsListNode.GetCheatingReportsListNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d5460
};

// Class UWorksWeb.GetPlayersBannedNode
// Size: 0x40 (Inherited: 0x30)
struct UGetPlayersBannedNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetPlayersBannedNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetPlayersBannedNode* GetPlayersBannedNode(struct FString Key, int32_t AppID); // Function UWorksWeb.GetPlayersBannedNode.GetPlayersBannedNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d5a20
};

// Class UWorksWeb.GetServerListNode
// Size: 0x40 (Inherited: 0x30)
struct UGetServerListNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetServerListNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetServerListNode* GetServerListNode(struct FString Key, struct FString Filter, int32_t Limit); // Function UWorksWeb.GetServerListNode.GetServerListNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d5b50
};

// Class UWorksWeb.GetServersAtAddressNode
// Size: 0x40 (Inherited: 0x30)
struct UGetServersAtAddressNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetServersAtAddressNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetServersAtAddressNode* GetServersAtAddressNode(struct FString Addr); // Function UWorksWeb.GetServersAtAddressNode.GetServersAtAddressNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d5d00
};

// Class UWorksWeb.SetAppBuildLiveNode
// Size: 0x40 (Inherited: 0x30)
struct USetAppBuildLiveNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct USetAppBuildLiveNode* SetAppBuildLiveNode(struct FString Key, int32_t AppID, int32_t BuildId, struct FString BetaKey, struct FString Description); // Function UWorksWeb.SetAppBuildLiveNode.SetAppBuildLiveNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d70f0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.SetAppBuildLiveNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.UpToDateCheckNode
// Size: 0x40 (Inherited: 0x30)
struct UUpToDateCheckNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UUpToDateCheckNode* UpToDateCheckNode(int32_t AppID, int32_t Version); // Function UWorksWeb.UpToDateCheckNode.UpToDateCheckNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d8a50
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.UpToDateCheckNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.PostGameDataFrameNode
// Size: 0x40 (Inherited: 0x30)
struct UPostGameDataFrameNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UPostGameDataFrameNode* PostGameDataFrameNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString BroadcastID, struct FString FrameData); // Function UWorksWeb.PostGameDataFrameNode.PostGameDataFrameNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d5df0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.PostGameDataFrameNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.ReportPlayerCheatingNode
// Size: 0x40 (Inherited: 0x30)
struct UReportPlayerCheatingNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UReportPlayerCheatingNode* ReportPlayerCheatingNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FUWorksSteamID SteamIDReporter, int32_t AppData, bool bHeuristic, bool bDetection, bool bPlayerReport, bool bNoReportID, int32_t GameMode, int32_t SuspicionStartTime, int32_t Severity); // Function UWorksWeb.ReportPlayerCheatingNode.ReportPlayerCheatingNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d6870
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.ReportPlayerCheatingNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.RequestPlayerGameBanNode
// Size: 0x40 (Inherited: 0x30)
struct URequestPlayerGameBanNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct URequestPlayerGameBanNode* RequestPlayerGameBanNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FUWorksSteamID ReportID, struct FString CheatDescription, int32_t Duration, bool bDelayBan); // Function UWorksWeb.RequestPlayerGameBanNode.RequestPlayerGameBanNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d6c40
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.RequestPlayerGameBanNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.RemovePlayerGameBanNode
// Size: 0x40 (Inherited: 0x30)
struct URemovePlayerGameBanNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct URemovePlayerGameBanNode* RemovePlayerGameBanNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.RemovePlayerGameBanNode.RemovePlayerGameBanNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d6070
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.RemovePlayerGameBanNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.GetCheatingReportsNode
// Size: 0x40 (Inherited: 0x30)
struct UGetCheatingReportsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetCheatingReportsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetCheatingReportsNode* GetCheatingReportsNode(struct FString Key, int32_t AppID, int32_t TimeEnd, int32_t TimeBegin, struct FString ReportIDMin, bool bIncludeReports, bool bIncludeBans, struct FUWorksSteamID SteamID); // Function UWorksWeb.GetCheatingReportsNode.GetCheatingReportsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d5720
};

// Class UWorksWeb.RequestVacStatusForUserNode
// Size: 0x40 (Inherited: 0x30)
struct URequestVacStatusForUserNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct URequestVacStatusForUserNode* RequestVacStatusForUserNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString SessionId); // Function UWorksWeb.RequestVacStatusForUserNode.RequestVacStatusForUserNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d6f00
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.RequestVacStatusForUserNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.StartSecureMultiplayerSessionNode
// Size: 0x40 (Inherited: 0x30)
struct UStartSecureMultiplayerSessionNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UStartSecureMultiplayerSessionNode* StartSecureMultiplayerSessionNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.StartSecureMultiplayerSessionNode.StartSecureMultiplayerSessionNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d88f0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.StartSecureMultiplayerSessionNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.EndSecureMultiplayerSessionNode
// Size: 0x40 (Inherited: 0x30)
struct UEndSecureMultiplayerSessionNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.EndSecureMultiplayerSessionNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UEndSecureMultiplayerSessionNode* EndSecureMultiplayerSessionNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString SessionId); // Function UWorksWeb.EndSecureMultiplayerSessionNode.EndSecureMultiplayerSessionNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d4e80
};

// Class UWorksWeb.ReportCheatDataNode
// Size: 0x40 (Inherited: 0x30)
struct UReportCheatDataNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UReportCheatDataNode* ReportCheatDataNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString PathAndFileName, struct FString WebCheatURL, struct FString TimeNow, struct FString TimeStarted, struct FString TimeStopped, struct FString CheatName, int32_t GameProcessID, int32_t CheatProcessID, struct FString CheatParamA, struct FString CheatParamB); // Function UWorksWeb.ReportCheatDataNode.ReportCheatDataNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9d61d0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.ReportCheatDataNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.ReportAbuseNode
// Size: 0x40 (Inherited: 0x30)
struct UReportAbuseNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UReportAbuseNode* ReportAbuseNode(struct FString Key, struct FUWorksSteamID SteamIDActor, struct FUWorksSteamID SteamIDTarget, int32_t AppID, char AbuseType, char ContentType, struct FString Description, struct FString GID); // Function UWorksWeb.ReportAbuseNode.ReportAbuseNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9de060
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.ReportAbuseNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.GetTradeHistoryNode
// Size: 0x40 (Inherited: 0x30)
struct UGetTradeHistoryNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetTradeHistoryNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetTradeHistoryNode* GetTradeHistoryNode(struct FString Key, int32_t MaxTrades, int32_t StartAfterTime, struct FString StartAfterTradeID, bool bNavigatingBack, bool bGetDescription, struct FString Language, bool bIncludeFailed, bool bIncludeTotal); // Function UWorksWeb.GetTradeHistoryNode.GetTradeHistoryNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dd180
};

// Class UWorksWeb.FlushInventoryCacheNode
// Size: 0x40 (Inherited: 0x30)
struct UFlushInventoryCacheNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.FlushInventoryCacheNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UFlushInventoryCacheNode* FlushInventoryCacheNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString ContextID); // Function UWorksWeb.FlushInventoryCacheNode.FlushInventoryCacheNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dbed0
};

// Class UWorksWeb.FlushAssetAppearanceCacheNode
// Size: 0x40 (Inherited: 0x30)
struct UFlushAssetAppearanceCacheNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.FlushAssetAppearanceCacheNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UFlushAssetAppearanceCacheNode* FlushAssetAppearanceCacheNode(struct FString Key, int32_t AppID); // Function UWorksWeb.FlushAssetAppearanceCacheNode.FlushAssetAppearanceCacheNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dbc70
};

// Class UWorksWeb.FlushContextCacheNode
// Size: 0x40 (Inherited: 0x30)
struct UFlushContextCacheNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.FlushContextCacheNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UFlushContextCacheNode* FlushContextCacheNode(struct FString Key, int32_t AppID); // Function UWorksWeb.FlushContextCacheNode.FlushContextCacheNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dbda0
};

// Class UWorksWeb.GetTradeOffersNode
// Size: 0x40 (Inherited: 0x30)
struct UGetTradeOffersNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetTradeOffersNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetTradeOffersNode* GetTradeOffersNode(struct FString Key, bool bGetSentOffers, bool bGetReceivedOffers, bool bGetDescription, struct FString Language, bool bActiveOnly, bool bHistoricalOnly, int32_t TimeHistoricalCutoff); // Function UWorksWeb.GetTradeOffersNode.GetTradeOffersNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dd730
};

// Class UWorksWeb.GetTradeOfferNode
// Size: 0x40 (Inherited: 0x30)
struct UGetTradeOfferNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetTradeOfferNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetTradeOfferNode* GetTradeOfferNode(struct FString Key, struct FString TradeOfferID, struct FString Language); // Function UWorksWeb.GetTradeOfferNode.GetTradeOfferNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dd520
};

// Class UWorksWeb.GetTradeOffersSummaryNode
// Size: 0x40 (Inherited: 0x30)
struct UGetTradeOffersSummaryNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetTradeOffersSummaryNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetTradeOffersSummaryNode* GetTradeOffersSummaryNode(struct FString Key, int32_t TimeLastVisit); // Function UWorksWeb.GetTradeOffersSummaryNode.GetTradeOffersSummaryNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dda50
};

// Class UWorksWeb.DeclineTradeOfferNode
// Size: 0x40 (Inherited: 0x30)
struct UDeclineTradeOfferNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.DeclineTradeOfferNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UDeclineTradeOfferNode* DeclineTradeOfferNode(struct FString Key, struct FString TradeOfferID); // Function UWorksWeb.DeclineTradeOfferNode.DeclineTradeOfferNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9db870
};

// Class UWorksWeb.CancelTradeOfferNode
// Size: 0x40 (Inherited: 0x30)
struct UCancelTradeOfferNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.CancelTradeOfferNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UCancelTradeOfferNode* CancelTradeOfferNode(struct FString Key, struct FString TradeOfferID); // Function UWorksWeb.CancelTradeOfferNode.CancelTradeOfferNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9db6f0
};

// Class UWorksWeb.GetMarketEligibilityNode
// Size: 0x40 (Inherited: 0x30)
struct UGetMarketEligibilityNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetMarketEligibilityNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetMarketEligibilityNode* GetMarketEligibilityNode(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.GetMarketEligibilityNode.GetMarketEligibilityNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dccc0
};

// Class UWorksWeb.CancelAppListingsForUserNode
// Size: 0x40 (Inherited: 0x30)
struct UCancelAppListingsForUserNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.CancelAppListingsForUserNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UCancelAppListingsForUserNode* CancelAppListingsForUserNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, bool bSynchronous); // Function UWorksWeb.CancelAppListingsForUserNode.CancelAppListingsForUserNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9db550
};

// Class UWorksWeb.GetAssetIDNode
// Size: 0x40 (Inherited: 0x30)
struct UGetAssetIDNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetAssetIDNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetAssetIDNode* GetAssetIDNode(struct FString Key, int32_t AppID, struct FString ListingID); // Function UWorksWeb.GetAssetIDNode.GetAssetIDNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dc3d0
};

// Class UWorksWeb.GetPopularNode
// Size: 0x40 (Inherited: 0x30)
struct UGetPopularNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetPopularNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetPopularNode* GetPopularNode(struct FString Key, struct FString Language, int32_t Rows, int32_t Start, int32_t FilterAppID, int32_t ECurrency); // Function UWorksWeb.GetPopularNode.GetPopularNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dcf20
};

// Class UWorksWeb.CanTradeNode
// Size: 0x40 (Inherited: 0x30)
struct UCanTradeNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.CanTradeNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UCanTradeNode* CanTradeNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FUWorksSteamID TargetId); // Function UWorksWeb.CanTradeNode.CanTradeNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9db3c0
};

// Class UWorksWeb.FinalizeAssetTransactionNode
// Size: 0x40 (Inherited: 0x30)
struct UFinalizeAssetTransactionNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.FinalizeAssetTransactionNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UFinalizeAssetTransactionNode* FinalizeAssetTransactionNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString TxnID, struct FString Language); // Function UWorksWeb.FinalizeAssetTransactionNode.FinalizeAssetTransactionNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9db9f0
};

// Class UWorksWeb.GetAssetClassInfoNode
// Size: 0x40 (Inherited: 0x30)
struct UGetAssetClassInfoNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetAssetClassInfoNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetAssetClassInfoNode* GetAssetClassInfoNode(struct FString Key, int32_t AppID, int32_t ClassCount, struct FString ClassID0, struct FString Language, struct FString InstanceID0); // Function UWorksWeb.GetAssetClassInfoNode.GetAssetClassInfoNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dc0c0
};

// Class UWorksWeb.GetAssetPricesNode
// Size: 0x40 (Inherited: 0x30)
struct UGetAssetPricesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetAssetPricesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetAssetPricesNode* GetAssetPricesNode(struct FString Key, int32_t AppID, struct FString Currency, struct FString Language); // Function UWorksWeb.GetAssetPricesNode.GetAssetPricesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dc580
};

// Class UWorksWeb.GetExportedAssetsForUserNode
// Size: 0x40 (Inherited: 0x30)
struct UGetExportedAssetsForUserNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetExportedAssetsForUserNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetExportedAssetsForUserNode* GetExportedAssetsForUserNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString ContextID); // Function UWorksWeb.GetExportedAssetsForUserNode.GetExportedAssetsForUserNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dc7c0
};

// Class UWorksWeb.GetMarketPricesNode
// Size: 0x40 (Inherited: 0x30)
struct UGetMarketPricesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetMarketPricesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetMarketPricesNode* GetMarketPricesNode(struct FString Key, int32_t AppID); // Function UWorksWeb.GetMarketPricesNode.GetMarketPricesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dcdf0
};

// Class UWorksWeb.StartAssetTransactionNode
// Size: 0x40 (Inherited: 0x30)
struct UStartAssetTransactionNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UStartAssetTransactionNode* StartAssetTransactionNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString AssetID0, int32_t AssetQuantity0, struct FString Currency, struct FString Language, struct FString IPAddress, struct FString Referrer, bool bClientAuth); // Function UWorksWeb.StartAssetTransactionNode.StartAssetTransactionNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9de3a0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.StartAssetTransactionNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.StartTradeNode
// Size: 0x40 (Inherited: 0x30)
struct UStartTradeNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UStartTradeNode* StartTradeNode(struct FString Key, int32_t AppID, struct FUWorksSteamID PartyA, struct FUWorksSteamID PartyB); // Function UWorksWeb.StartTradeNode.StartTradeNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9de870
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.StartTradeNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.GetHistoryCommandDetailsNode
// Size: 0x40 (Inherited: 0x30)
struct UGetHistoryCommandDetailsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetHistoryCommandDetailsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetHistoryCommandDetailsNode* GetHistoryCommandDetailsNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString Command, struct FString ContextID, struct FString Arguments); // Function UWorksWeb.GetHistoryCommandDetailsNode.GetHistoryCommandDetailsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dc9b0
};

// Class UWorksWeb.GetUserHistoryNode
// Size: 0x40 (Inherited: 0x30)
struct UGetUserHistoryNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetUserHistoryNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetUserHistoryNode* GetUserHistoryNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString ContextID, int32_t StartTime, int32_t EndTime); // Function UWorksWeb.GetUserHistoryNode.GetUserHistoryNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ddb80
};

// Class UWorksWeb.HistoryExecuteCommandsNode
// Size: 0x40 (Inherited: 0x30)
struct UHistoryExecuteCommandsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.HistoryExecuteCommandsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UHistoryExecuteCommandsNode* HistoryExecuteCommandsNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FString ContextID, struct FString ActorId); // Function UWorksWeb.HistoryExecuteCommandsNode.HistoryExecuteCommandsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ddde0
};

// Class UWorksWeb.SupportGetAssetHistoryNode
// Size: 0x40 (Inherited: 0x30)
struct USupportGetAssetHistoryNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct USupportGetAssetHistoryNode* SupportGetAssetHistoryNode(struct FString Key, int32_t AppID, struct FString AssetID, struct FString ContextID); // Function UWorksWeb.SupportGetAssetHistoryNode.SupportGetAssetHistoryNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9dea00
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.SupportGetAssetHistoryNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.CreateSessionNode
// Size: 0x40 (Inherited: 0x30)
struct UCreateSessionNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.CreateSessionNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UCreateSessionNode* CreateSessionNode(struct FString Key, int32_t AppID, struct FString Context, struct FUWorksTitle Title, struct FUWorksUsers Users, struct FUWorksSteamID SteamID); // Function UWorksWeb.CreateSessionNode.CreateSessionNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e2330
};

// Class UWorksWeb.UpdateSessionNode
// Size: 0x40 (Inherited: 0x30)
struct UUpdateSessionNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UUpdateSessionNode* UpdateSessionNode(struct FString Key, struct FString SessionId, int32_t AppID, struct FUWorksTitle Title, struct FUWorksUsers Users, struct FUWorksSteamID SteamID); // Function UWorksWeb.UpdateSessionNode.UpdateSessionNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e47e0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.UpdateSessionNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.EnumerateSessionsForAppNode
// Size: 0x40 (Inherited: 0x30)
struct UEnumerateSessionsForAppNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.EnumerateSessionsForAppNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UEnumerateSessionsForAppNode* EnumerateSessionsForAppNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, bool bIncludeAllUserMessages, bool bIncludeAuthUserMessage, struct FString Language); // Function UWorksWeb.EnumerateSessionsForAppNode.EnumerateSessionsForAppNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e2a60
};

// Class UWorksWeb.GetSessionDetailsForAppNode
// Size: 0x40 (Inherited: 0x30)
struct UGetSessionDetailsForAppNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetSessionDetailsForAppNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetSessionDetailsForAppNode* GetSessionDetailsForAppNode(struct FString Key, struct FUWorksSessions Sessions, int32_t AppID, struct FString Language); // Function UWorksWeb.GetSessionDetailsForAppNode.GetSessionDetailsForAppNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e3e90
};

// Class UWorksWeb.RequestNotificationsNode
// Size: 0x40 (Inherited: 0x30)
struct URequestNotificationsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct URequestNotificationsNode* RequestNotificationsNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.RequestNotificationsNode.RequestNotificationsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e4200
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.RequestNotificationsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.DeleteSessionNode
// Size: 0x40 (Inherited: 0x30)
struct UDeleteSessionNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.DeleteSessionNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UDeleteSessionNode* DeleteSessionNode(struct FString Key, struct FString SessionId, int32_t AppID, struct FUWorksSteamID SteamID); // Function UWorksWeb.DeleteSessionNode.DeleteSessionNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e2870
};

// Class UWorksWeb.DeleteSessionBatchNode
// Size: 0x40 (Inherited: 0x30)
struct UDeleteSessionBatchNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.DeleteSessionBatchNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UDeleteSessionBatchNode* DeleteSessionBatchNode(struct FString Key, struct FString SessionId, int32_t AppID); // Function UWorksWeb.DeleteSessionBatchNode.DeleteSessionBatchNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e26c0
};

// Class UWorksWeb.GetAccountListNode
// Size: 0x40 (Inherited: 0x30)
struct UGetAccountListNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetAccountListNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetAccountListNode* GetAccountListNode(struct FString Key); // Function UWorksWeb.GetAccountListNode.GetAccountListNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e2f90
};

// Class UWorksWeb.CreateAccountNode
// Size: 0x40 (Inherited: 0x30)
struct UCreateAccountNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.CreateAccountNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UCreateAccountNode* CreateAccountNode(struct FString Key, int32_t AppID, struct FString Memo); // Function UWorksWeb.CreateAccountNode.CreateAccountNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e2180
};

// Class UWorksWeb.SetMemoNode
// Size: 0x40 (Inherited: 0x30)
struct USetMemoNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct USetMemoNode* SetMemoNode(struct FString Key, struct FUWorksSteamID SteamID, struct FString Memo); // Function UWorksWeb.SetMemoNode.SetMemoNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e4630
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.SetMemoNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.ResetLoginTokenNode
// Size: 0x40 (Inherited: 0x30)
struct UResetLoginTokenNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UResetLoginTokenNode* ResetLoginTokenNode(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.ResetLoginTokenNode.ResetLoginTokenNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e4360
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.ResetLoginTokenNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.DeleteAccountNode
// Size: 0x40 (Inherited: 0x30)
struct UDeleteAccountNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.DeleteAccountNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UDeleteAccountNode* DeleteAccountNode(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.DeleteAccountNode.DeleteAccountNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e2590
};

// Class UWorksWeb.GetAccountPublicInfoNode
// Size: 0x40 (Inherited: 0x30)
struct UGetAccountPublicInfoNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetAccountPublicInfoNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetAccountPublicInfoNode* GetAccountPublicInfoNode(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.GetAccountPublicInfoNode.GetAccountPublicInfoNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e3080
};

// Class UWorksWeb.QueryLoginTokenNode
// Size: 0x40 (Inherited: 0x30)
struct UQueryLoginTokenNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UQueryLoginTokenNode* QueryLoginTokenNode(struct FString Key, struct FString LoginToken); // Function UWorksWeb.QueryLoginTokenNode.QueryLoginTokenNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e4080
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.QueryLoginTokenNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.SetBanStatusNode
// Size: 0x40 (Inherited: 0x30)
struct USetBanStatusNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct USetBanStatusNode* SetBanStatusNode(struct FString Key, struct FUWorksSteamID SteamID, bool bBanned, int32_t BanSeconds); // Function UWorksWeb.SetBanStatusNode.SetBanStatusNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e4490
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.SetBanStatusNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.GetServerSteamIDsByIPNode
// Size: 0x40 (Inherited: 0x30)
struct UGetServerSteamIDsByIPNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetServerSteamIDsByIPNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetServerSteamIDsByIPNode* GetServerSteamIDsByIPNode(struct FString Key, struct FString ServerIPs); // Function UWorksWeb.GetServerSteamIDsByIPNode.GetServerSteamIDsByIPNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e3d10
};

// Class UWorksWeb.GetServerIPsBySteamIDNode
// Size: 0x40 (Inherited: 0x30)
struct UGetServerIPsBySteamIDNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetServerIPsBySteamIDNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetServerIPsBySteamIDNode* GetServerIPsBySteamIDNode(struct FString Key, struct FUWorksSteamID ServerSteamID); // Function UWorksWeb.GetServerIPsBySteamIDNode.GetServerIPsBySteamIDNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e3be0
};

// Class UWorksWeb.GetGameServerPlayerStatsForGameNode
// Size: 0x40 (Inherited: 0x30)
struct UGetGameServerPlayerStatsForGameNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetGameServerPlayerStatsForGameNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetGameServerPlayerStatsForGameNode* GetGameServerPlayerStatsForGameNode(struct FString Key, struct FUWorksGameID GameID, int32_t AppID, struct FString RangeStart, struct FString RangeEnd, int32_t MaxResults); // Function UWorksWeb.GetGameServerPlayerStatsForGameNode.GetGameServerPlayerStatsForGameNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e31b0
};

// Class UWorksWeb.AddItemNode
// Size: 0x40 (Inherited: 0x30)
struct UAddItemNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.AddItemNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UAddItemNode* AddItemNode(struct FString Key, int32_t AppID, struct TArray<struct FUWorksSteamItemDef> ItemDefID, struct FString ItemPropsJSON, struct FUWorksSteamID SteamID, bool bNotify, struct FString RequestID); // Function UWorksWeb.AddItemNode.AddItemNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e1670
};

// Class UWorksWeb.AddPromoItemNode
// Size: 0x40 (Inherited: 0x30)
struct UAddPromoItemNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.AddPromoItemNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UAddPromoItemNode* AddPromoItemNode(struct FString Key, int32_t AppID, struct FUWorksSteamItemDef ItemDefID, struct FString ItemPropsJSON, struct FUWorksSteamID SteamID, bool bNotify, struct FString RequestID); // Function UWorksWeb.AddPromoItemNode.AddPromoItemNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e19d0
};

// Class UWorksWeb.ConsumeItemNode
// Size: 0x40 (Inherited: 0x30)
struct UConsumeItemNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.ConsumeItemNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UConsumeItemNode* ConsumeItemNode(struct FString Key, int32_t AppID, struct FUWorksSteamItemInstanceID ItemId, int32_t Quantity, struct FUWorksSteamID SteamID, struct FString RequestID); // Function UWorksWeb.ConsumeItemNode.ConsumeItemNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e1f10
};

// Class UWorksWeb.ExchangeItemNode
// Size: 0x40 (Inherited: 0x30)
struct UExchangeItemNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.ExchangeItemNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UExchangeItemNode* ExchangeItemNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct TArray<struct FUWorksSteamItemInstanceID> MaterialsItemID, struct TArray<int32_t> MaterialsQuantity, struct FUWorksSteamItemDef OutputItemDefID); // Function UWorksWeb.ExchangeItemNode.ExchangeItemNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e2ce0
};

// Class UWorksWeb.GetInventoryNode
// Size: 0x40 (Inherited: 0x30)
struct UGetInventoryNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetInventoryNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetInventoryNode* GetInventoryNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID); // Function UWorksWeb.GetInventoryNode.GetInventoryNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e3460
};

// Class UWorksWeb.GetItemDefsNode
// Size: 0x40 (Inherited: 0x30)
struct UGetItemDefsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetItemDefsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetItemDefsNode* GetItemDefsNode(struct FString Key, int32_t AppID, struct FString ModifiedSince, struct TArray<struct FUWorksSteamItemDef> ItemDefIDs, struct TArray<struct FUWorksSteamItemDef> WorkshopIDs, int32_t CacheMaxAgeSeconds); // Function UWorksWeb.GetItemDefsNode.GetItemDefsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e35c0
};

// Class UWorksWeb.GetPriceSheetNode
// Size: 0x40 (Inherited: 0x30)
struct UGetPriceSheetNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetPriceSheetNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetPriceSheetNode* GetPriceSheetNode(struct FString Key, int32_t ECurrency); // Function UWorksWeb.GetPriceSheetNode.GetPriceSheetNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e38d0
};

// Class UWorksWeb.ConsolidateNode
// Size: 0x40 (Inherited: 0x30)
struct UConsolidateNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.ConsolidateNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UConsolidateNode* ConsolidateNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct TArray<struct FUWorksSteamItemDef> ItemDefID, bool bForce); // Function UWorksWeb.ConsolidateNode.ConsolidateNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e1ce0
};

// Class UWorksWeb.GetQuantityNode
// Size: 0x40 (Inherited: 0x30)
struct UGetQuantityNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetQuantityNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetQuantityNode* GetQuantityNode(struct FString Key, int32_t AppID, struct FUWorksSteamID SteamID, struct FUWorksSteamItemDef ItemDefID, bool bForce); // Function UWorksWeb.GetQuantityNode.GetQuantityNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e3a00
};

// Class UWorksWeb.DeleteLeaderboardNode
// Size: 0x40 (Inherited: 0x30)
struct UDeleteLeaderboardNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.DeleteLeaderboardNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UDeleteLeaderboardNode* DeleteLeaderboardNode(struct FString Key, int32_t AppID, struct FString Name); // Function UWorksWeb.DeleteLeaderboardNode.DeleteLeaderboardNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e75c0
};

// Class UWorksWeb.FindOrCreateLeaderboardNode
// Size: 0x40 (Inherited: 0x30)
struct UFindOrCreateLeaderboardNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.FindOrCreateLeaderboardNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UFindOrCreateLeaderboardNode* FindOrCreateLeaderboardNode(struct FString Key, int32_t AppID, struct FString Name, struct FString SortMethod, struct FString DisplayType, bool bCreateIfNotFound, bool bOnlyTrustedWrites, bool bOnlyFriendsReads); // Function UWorksWeb.FindOrCreateLeaderboardNode.FindOrCreateLeaderboardNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e7920
};

// Class UWorksWeb.GetLeaderboardEntriesNode
// Size: 0x40 (Inherited: 0x30)
struct UGetLeaderboardEntriesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetLeaderboardEntriesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetLeaderboardEntriesNode* GetLeaderboardEntriesNode(struct FString Key, int32_t AppID, int32_t RangeStart, int32_t RangeEnd, int32_t LeaderboardID, int32_t DataRequest, struct FUWorksSteamID SteamID); // Function UWorksWeb.GetLeaderboardEntriesNode.GetLeaderboardEntriesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e7f60
};

// Class UWorksWeb.GetLeaderboardsForGameNode
// Size: 0x40 (Inherited: 0x30)
struct UGetLeaderboardsForGameNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetLeaderboardsForGameNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetLeaderboardsForGameNode* GetLeaderboardsForGameNode(struct FString Key, int32_t AppID); // Function UWorksWeb.GetLeaderboardsForGameNode.GetLeaderboardsForGameNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e81c0
};

// Class UWorksWeb.ResetLeaderboardNode
// Size: 0x40 (Inherited: 0x30)
struct UResetLeaderboardNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UResetLeaderboardNode* ResetLeaderboardNode(struct FString Key, int32_t AppID, int32_t LeaderboardID); // Function UWorksWeb.ResetLeaderboardNode.ResetLeaderboardNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9eae80
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.ResetLeaderboardNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.SetLeaderboardScoreNode
// Size: 0x40 (Inherited: 0x30)
struct USetLeaderboardScoreNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct USetLeaderboardScoreNode* SetLeaderboardScoreNode(struct FString Key, int32_t AppID, int32_t LeaderboardID, struct FUWorksSteamID SteamID, int32_t Score, struct FString ScoreMethod, struct TArray<char> Details); // Function UWorksWeb.SetLeaderboardScoreNode.SetLeaderboardScoreNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9eafe0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.SetLeaderboardScoreNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.AdjustAgreementNode
// Size: 0x40 (Inherited: 0x30)
struct UAdjustAgreementNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.AdjustAgreementNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UAdjustAgreementNode* AdjustAgreementNode(struct FString Key, struct FUWorksSteamID SteamID, struct FString AgreementID, int32_t AppID, struct FString NextProcessDate); // Function UWorksWeb.AdjustAgreementNode.AdjustAgreementNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e7150
};

// Class UWorksWeb.CancelAgreementNode
// Size: 0x40 (Inherited: 0x30)
struct UCancelAgreementNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.CancelAgreementNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UCancelAgreementNode* CancelAgreementNode(struct FString Key, struct FUWorksSteamID SteamID, struct FString AgreementID, int32_t AppID); // Function UWorksWeb.CancelAgreementNode.CancelAgreementNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e73d0
};

// Class UWorksWeb.FinalizeTxnNode
// Size: 0x40 (Inherited: 0x30)
struct UFinalizeTxnNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.FinalizeTxnNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UFinalizeTxnNode* FinalizeTxnNode(struct FString Key, struct FString OrderID, int32_t AppID); // Function UWorksWeb.FinalizeTxnNode.FinalizeTxnNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e7770
};

// Class UWorksWeb.GetReportNode
// Size: 0x40 (Inherited: 0x30)
struct UGetReportNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetReportNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetReportNode* GetReportNode(struct FString Key, int32_t AppID, struct FString Time, enum class EUWorksReportType Type, int32_t MaxResults); // Function UWorksWeb.GetReportNode.GetReportNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e8ad0
};

// Class UWorksWeb.GetUserAgreementInfoNode
// Size: 0x40 (Inherited: 0x30)
struct UGetUserAgreementInfoNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetUserAgreementInfoNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetUserAgreementInfoNode* GetUserAgreementInfoNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.GetUserAgreementInfoNode.GetUserAgreementInfoNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e8e20
};

// Class UWorksWeb.GetUserInfoNode
// Size: 0x40 (Inherited: 0x30)
struct UGetUserInfoNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetUserInfoNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetUserInfoNode* GetUserInfoNode(struct FString Key, struct FUWorksSteamID SteamID, struct FString IPAddress); // Function UWorksWeb.GetUserInfoNode.GetUserInfoNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e8f80
};

// Class UWorksWeb.InitTxnNode
// Size: 0x40 (Inherited: 0x30)
struct UInitTxnNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.InitTxnNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UInitTxnNode* InitTxnNode(struct FString Key, struct FString OrderID, struct FUWorksSteamID SteamID, int32_t AppID, int32_t ItemCount, struct FString Language, struct FString Currency, struct TArray<struct FUWorksSteamItemDef> ItemIds, struct TArray<int32_t> Quantities, struct TArray<int32_t> Amounts, struct TArray<struct FString> Descriptions, struct TArray<struct FString> Categories, struct TArray<int32_t> AssociatedBundles, struct TArray<struct FString> BillingTypes, struct TArray<struct FString> StartDates, struct TArray<struct FString> EndDates, struct TArray<struct FString> Periods, struct TArray<int32_t> Frequencies, struct TArray<struct FString> RecurringAmounts, int32_t BundleCount, struct TArray<int32_t> BundleIDs, struct TArray<int32_t> BundleQuantities, struct TArray<struct FString> BundleDescriptions, struct TArray<struct FString> BundleCategories, enum class EUWorksUserSession UserSession, struct FString IPAddress); // Function UWorksWeb.InitTxnNode.InitTxnNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e9130
};

// Class UWorksWeb.ProcessAgreementNode
// Size: 0x40 (Inherited: 0x30)
struct UProcessAgreementNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UProcessAgreementNode* ProcessAgreementNode(struct FString Key, struct FString OrderID, struct FUWorksSteamID SteamID, struct FString AgreementID, int32_t AppID, int32_t Amount, struct FString Currency); // Function UWorksWeb.ProcessAgreementNode.ProcessAgreementNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ea5f0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.ProcessAgreementNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.QueryTxnNode
// Size: 0x40 (Inherited: 0x30)
struct UQueryTxnNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UQueryTxnNode* QueryTxnNode(struct FString Key, int32_t AppID, struct FString OrderID, struct FString TransID); // Function UWorksWeb.QueryTxnNode.QueryTxnNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ea930
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.QueryTxnNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.RefundTxnNode
// Size: 0x40 (Inherited: 0x30)
struct URefundTxnNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct URefundTxnNode* RefundTxnNode(struct FString Key, struct FString OrderID, int32_t AppID); // Function UWorksWeb.RefundTxnNode.RefundTxnNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9eacd0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.RefundTxnNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.GetNewsForAppNode
// Size: 0x40 (Inherited: 0x30)
struct UGetNewsForAppNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetNewsForAppNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetNewsForAppNode* GetNewsForAppNode(int32_t AppID, int32_t MaxLength, int32_t EndDate, int32_t Count, struct FString Feeds); // Function UWorksWeb.GetNewsForAppNode.GetNewsForAppNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e8560
};

// Class UWorksWeb.GetNewsForAppAuthedNode
// Size: 0x40 (Inherited: 0x30)
struct UGetNewsForAppAuthedNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetNewsForAppAuthedNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetNewsForAppAuthedNode* GetNewsForAppAuthedNode(struct FString Key, int32_t AppID, int32_t MaxLength, int32_t EndDate, int32_t Count, struct FString Feeds); // Function UWorksWeb.GetNewsForAppAuthedNode.GetNewsForAppAuthedNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e82f0
};

// Class UWorksWeb.RecordOfflinePlaytimeNode
// Size: 0x40 (Inherited: 0x30)
struct URecordOfflinePlaytimeNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct URecordOfflinePlaytimeNode* RecordOfflinePlaytimeNode(struct FUWorksSteamID SteamID, struct FString Ticket, struct FUWorksPlaySessions PlaySessions); // Function UWorksWeb.RecordOfflinePlaytimeNode.RecordOfflinePlaytimeNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9eab70
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.RecordOfflinePlaytimeNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.GetRecentlyPlayedGamesNode
// Size: 0x40 (Inherited: 0x30)
struct UGetRecentlyPlayedGamesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetRecentlyPlayedGamesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetRecentlyPlayedGamesNode* GetRecentlyPlayedGamesNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t Count); // Function UWorksWeb.GetRecentlyPlayedGamesNode.GetRecentlyPlayedGamesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e8970
};

// Class UWorksWeb.GetOwnedGamesNode
// Size: 0x40 (Inherited: 0x30)
struct UGetOwnedGamesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetOwnedGamesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetOwnedGamesNode* GetOwnedGamesNode(struct FString Key, struct FUWorksSteamID SteamID, bool bIncludeAppInfo, bool bIncludePlayedFreeGames, struct TArray<int32_t> AppIDsFilter); // Function UWorksWeb.GetOwnedGamesNode.GetOwnedGamesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e8730
};

// Class UWorksWeb.GetSteamLevelNode
// Size: 0x40 (Inherited: 0x30)
struct UGetSteamLevelNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetSteamLevelNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetSteamLevelNode* GetSteamLevelNode(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.GetSteamLevelNode.GetSteamLevelNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e8cf0
};

// Class UWorksWeb.GetBadgesNode
// Size: 0x40 (Inherited: 0x30)
struct UGetBadgesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetBadgesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetBadgesNode* GetBadgesNode(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.GetBadgesNode.GetBadgesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e7cd0
};

// Class UWorksWeb.GetCommunityBadgeProgressNode
// Size: 0x40 (Inherited: 0x30)
struct UGetCommunityBadgeProgressNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetCommunityBadgeProgressNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetCommunityBadgeProgressNode* GetCommunityBadgeProgressNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t BadgeID); // Function UWorksWeb.GetCommunityBadgeProgressNode.GetCommunityBadgeProgressNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9e7e00
};

// Class UWorksWeb.IsPlayingSharedGameNode
// Size: 0x40 (Inherited: 0x30)
struct UIsPlayingSharedGameNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.IsPlayingSharedGameNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UIsPlayingSharedGameNode* IsPlayingSharedGameNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppIDPlaying); // Function UWorksWeb.IsPlayingSharedGameNode.IsPlayingSharedGameNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ea490
};

// Class UWorksWeb.QueryFilesNode
// Size: 0x40 (Inherited: 0x30)
struct UQueryFilesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UQueryFilesNode* QueryFilesNode(struct FString Key, char QueryType, int32_t Page, int32_t CreatorAppID, int32_t AppID, struct TArray<struct FString> RequiredTags, struct TArray<struct FString> ExcludedTags, struct TArray<struct FString> RequiredFlags, struct TArray<struct FString> OmittedFlags, struct FString SearchText, char FileType, struct FUWorksPublishedFileID ChildPublishedFileID, int32_t Days, bool bIncludeRecentVotesOnly, struct FUWorksRequiredKVTags RequiredKVTags, bool bTotalOnly, bool bIDsOnly, bool bReturnVoteData, bool bReturnTags, bool bReturnKVTags, bool bReturnPreviews, bool bReturnChildren, bool bReturnShortDescription, bool bReturnForSaleData, int32_t ReturnPlaytimeStats, int32_t NumPerPage, bool bMatchAllTags, int32_t CacheMaxAgeSeconds, int32_t Language, bool bReturnMetadata); // Function UWorksWeb.QueryFilesNode.QueryFilesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ef4e0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.QueryFilesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.SetDeveloperMetadataNode
// Size: 0x40 (Inherited: 0x30)
struct USetDeveloperMetadataNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct USetDeveloperMetadataNode* SetDeveloperMetadataNode(struct FString Key, struct FUWorksPublishedFileID PublishedFileID, int32_t AppID, struct FString MetaData); // Function UWorksWeb.SetDeveloperMetadataNode.SetDeveloperMetadataNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f17d0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.SetDeveloperMetadataNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.UpdateTagsNode
// Size: 0x40 (Inherited: 0x30)
struct UUpdateTagsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UUpdateTagsNode* UpdateTagsNode(struct FString Key, struct FUWorksPublishedFileID PublishedFileID, int32_t AppID, struct TArray<struct FString> AddTags, struct TArray<struct FString> RemoveTags); // Function UWorksWeb.UpdateTagsNode.UpdateTagsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f1ec0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.UpdateTagsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.RankedByPublicationOrderNode
// Size: 0x40 (Inherited: 0x30)
struct URankedByPublicationOrderNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct URankedByPublicationOrderNode* RankedByPublicationOrderNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t StartIndex, int32_t Count, int32_t TagCount, int32_t UserTagCount, bool bHasAppAdminAccess, int32_t FileType, struct TArray<struct FString> Tags, struct TArray<struct FString> UserTags); // Function UWorksWeb.RankedByPublicationOrderNode.RankedByPublicationOrderNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f0170
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.RankedByPublicationOrderNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.RankedByTrendNode
// Size: 0x40 (Inherited: 0x30)
struct URankedByTrendNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct URankedByTrendNode* RankedByTrendNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t StartIndex, int32_t Count, int32_t TagCount, int32_t UserTagCount, bool bHasAppAdminAccess, int32_t FileType, int32_t Days, struct TArray<struct FString> Tags, struct TArray<struct FString> UserTags); // Function UWorksWeb.RankedByTrendNode.RankedByTrendNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f06b0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.RankedByTrendNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.RankedByVoteNode
// Size: 0x40 (Inherited: 0x30)
struct URankedByVoteNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct URankedByVoteNode* RankedByVoteNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t StartIndex, int32_t Count, int32_t TagCount, int32_t UserTagCount, bool bHasAppAdminAccess, int32_t FileType, struct TArray<struct FString> Tags, struct TArray<struct FString> UserTags); // Function UWorksWeb.RankedByVoteNode.RankedByVoteNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f0c40
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.RankedByVoteNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.ResultSetSummaryNode
// Size: 0x40 (Inherited: 0x30)
struct UResultSetSummaryNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UResultSetSummaryNode* ResultSetSummaryNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t TagCount, int32_t UserTagCount, bool bHasAppAdminAccess, int32_t FileType, struct TArray<struct FString> Tags, struct TArray<struct FString> UserTags); // Function UWorksWeb.ResultSetSummaryNode.ResultSetSummaryNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f1330
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.ResultSetSummaryNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.ItemVoteSummaryNode
// Size: 0x40 (Inherited: 0x30)
struct UItemVoteSummaryNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.ItemVoteSummaryNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UItemVoteSummaryNode* ItemVoteSummaryNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t Count, struct TArray<int32_t> PublishedFileIDs); // Function UWorksWeb.ItemVoteSummaryNode.ItemVoteSummaryNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ef2c0
};

// Class UWorksWeb.UserVoteSummaryNode
// Size: 0x40 (Inherited: 0x30)
struct UUserVoteSummaryNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UUserVoteSummaryNode* UserVoteSummaryNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t Count, struct TArray<int32_t> PublishedFileIDs); // Function UWorksWeb.UserVoteSummaryNode.UserVoteSummaryNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f2250
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.UserVoteSummaryNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.EnumerateUserPublishedFilesNode
// Size: 0x40 (Inherited: 0x30)
struct UEnumerateUserPublishedFilesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.EnumerateUserPublishedFilesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UEnumerateUserPublishedFilesNode* EnumerateUserPublishedFilesNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.EnumerateUserPublishedFilesNode.EnumerateUserPublishedFilesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ede60
};

// Class UWorksWeb.EnumerateUserSubscribedFilesNode
// Size: 0x40 (Inherited: 0x30)
struct UEnumerateUserSubscribedFilesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.EnumerateUserSubscribedFilesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UEnumerateUserSubscribedFilesNode* EnumerateUserSubscribedFilesNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t ListType); // Function UWorksWeb.EnumerateUserSubscribedFilesNode.EnumerateUserSubscribedFilesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9edfc0
};

// Class UWorksWeb.GetCollectionDetailsNode
// Size: 0x40 (Inherited: 0x30)
struct UGetCollectionDetailsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetCollectionDetailsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetCollectionDetailsNode* GetCollectionDetailsNode(int32_t CollectionCount, struct TArray<int32_t> PublishedFileIDs); // Function UWorksWeb.GetCollectionDetailsNode.GetCollectionDetailsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ee300
};

// Class UWorksWeb.GetPublishedFileDetailsNode
// Size: 0x40 (Inherited: 0x30)
struct UGetPublishedFileDetailsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetPublishedFileDetailsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetPublishedFileDetailsNode* GetPublishedFileDetailsNode(int32_t ItemCount, struct TArray<int32_t> PublishedFileIDs); // Function UWorksWeb.GetPublishedFileDetailsNode.GetPublishedFileDetailsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ee8e0
};

// Class UWorksWeb.GetUGCFileDetailsNode
// Size: 0x40 (Inherited: 0x30)
struct UGetUGCFileDetailsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetUGCFileDetailsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetUGCFileDetailsNode* GetUGCFileDetailsNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t UGCID, int32_t AppID); // Function UWorksWeb.GetUGCFileDetailsNode.GetUGCFileDetailsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9eed50
};

// Class UWorksWeb.SetUGCUsedByGCNode
// Size: 0x40 (Inherited: 0x30)
struct USetUGCUsedByGCNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct USetUGCUsedByGCNode* SetUGCUsedByGCNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t UGCID, int32_t AppID, bool bUsed); // Function UWorksWeb.SetUGCUsedByGCNode.SetUGCUsedByGCNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f19c0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.SetUGCUsedByGCNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.SubscribePublishedFileNode
// Size: 0x40 (Inherited: 0x30)
struct USubscribePublishedFileNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct USubscribePublishedFileNode* SubscribePublishedFileNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t PublishedFileID); // Function UWorksWeb.SubscribePublishedFileNode.SubscribePublishedFileNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f1ba0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.SubscribePublishedFileNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.UnsubscribePublishedFileNode
// Size: 0x40 (Inherited: 0x30)
struct UUnsubscribePublishedFileNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UUnsubscribePublishedFileNode* UnsubscribePublishedFileNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t PublishedFileID); // Function UWorksWeb.UnsubscribePublishedFileNode.UnsubscribePublishedFileNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f1d30
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.UnsubscribePublishedFileNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.CheckAppOwnershipNode
// Size: 0x40 (Inherited: 0x30)
struct UCheckAppOwnershipNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.CheckAppOwnershipNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UCheckAppOwnershipNode* CheckAppOwnershipNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.CheckAppOwnershipNode.CheckAppOwnershipNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9edd00
};

// Class UWorksWeb.GetAppPriceInfoNode
// Size: 0x40 (Inherited: 0x30)
struct UGetAppPriceInfoNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetAppPriceInfoNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetAppPriceInfoNode* GetAppPriceInfoNode(struct FString Key, struct FUWorksSteamID SteamID, struct FString AppIDs); // Function UWorksWeb.GetAppPriceInfoNode.GetAppPriceInfoNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ee150
};

// Class UWorksWeb.GetFriendListNode
// Size: 0x40 (Inherited: 0x30)
struct UGetFriendListNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetFriendListNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetFriendListNode* GetFriendListNode(struct FString Key, struct FUWorksSteamID SteamID, struct FString Relationship); // Function UWorksWeb.GetFriendListNode.GetFriendListNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ee430
};

// Class UWorksWeb.GetPlayerBansNode
// Size: 0x40 (Inherited: 0x30)
struct UGetPlayerBansNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetPlayerBansNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetPlayerBansNode* GetPlayerBansNode(struct FString Key, struct FString SteamIDs); // Function UWorksWeb.GetPlayerBansNode.GetPlayerBansNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ee5e0
};

// Class UWorksWeb.GetPlayerSummariesNode
// Size: 0x40 (Inherited: 0x30)
struct UGetPlayerSummariesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetPlayerSummariesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetPlayerSummariesNode* GetPlayerSummariesNode(struct FString Key, struct FString SteamIDs); // Function UWorksWeb.GetPlayerSummariesNode.GetPlayerSummariesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ee760
};

// Class UWorksWeb.GetPublisherAppOwnershipNode
// Size: 0x40 (Inherited: 0x30)
struct UGetPublisherAppOwnershipNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetPublisherAppOwnershipNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetPublisherAppOwnershipNode* GetPublisherAppOwnershipNode(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.GetPublisherAppOwnershipNode.GetPublisherAppOwnershipNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9eec20
};

// Class UWorksWeb.GetPublisherAppOwnershipChangesNode
// Size: 0x40 (Inherited: 0x30)
struct UGetPublisherAppOwnershipChangesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetPublisherAppOwnershipChangesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetPublisherAppOwnershipChangesNode* GetPublisherAppOwnershipChangesNode(struct FString Key, struct FString PackageRowVersion, struct FString CDKeyRowVersion); // Function UWorksWeb.GetPublisherAppOwnershipChangesNode.GetPublisherAppOwnershipChangesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9eea10
};

// Class UWorksWeb.GetUserGroupListNode
// Size: 0x40 (Inherited: 0x30)
struct UGetUserGroupListNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetUserGroupListNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetUserGroupListNode* GetUserGroupListNode(struct FString Key, struct FUWorksSteamID SteamID); // Function UWorksWeb.GetUserGroupListNode.GetUserGroupListNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9eeee0
};

// Class UWorksWeb.GrantPackageNode
// Size: 0x40 (Inherited: 0x30)
struct UGrantPackageNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GrantPackageNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGrantPackageNode* GrantPackageNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t PackageID, struct FString IPAddress, struct FString ThirdPartyKey, int32_t ThirdPartyAppID); // Function UWorksWeb.GrantPackageNode.GrantPackageNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ef010
};

// Class UWorksWeb.ResolveVanityURLNode
// Size: 0x40 (Inherited: 0x30)
struct UResolveVanityURLNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UResolveVanityURLNode* ResolveVanityURLNode(struct FString Key, struct FString VanityURL, char URLType); // Function UWorksWeb.ResolveVanityURLNode.ResolveVanityURLNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f1180
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.ResolveVanityURLNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.AuthenticateUserNode
// Size: 0x40 (Inherited: 0x30)
struct UAuthenticateUserNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.AuthenticateUserNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UAuthenticateUserNode* AuthenticateUserNode(struct FUWorksSteamID SteamID, struct TArray<char> SessionKey, struct TArray<char> EncryptedLoginKey); // Function UWorksWeb.AuthenticateUserNode.AuthenticateUserNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f3d80
};

// Class UWorksWeb.AuthenticateUserTicketNode
// Size: 0x40 (Inherited: 0x30)
struct UAuthenticateUserTicketNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.AuthenticateUserTicketNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UAuthenticateUserTicketNode* AuthenticateUserTicketNode(struct FString Key, int32_t AppID, struct FString Ticket); // Function UWorksWeb.AuthenticateUserTicketNode.AuthenticateUserTicketNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f3f20
};

// Class UWorksWeb.GetGlobalAchievementPercentagesForAppNode
// Size: 0x40 (Inherited: 0x30)
struct UGetGlobalAchievementPercentagesForAppNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetGlobalAchievementPercentagesForAppNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetGlobalAchievementPercentagesForAppNode* GetGlobalAchievementPercentagesForAppNode(struct FUWorksGameID GameID); // Function UWorksWeb.GetGlobalAchievementPercentagesForAppNode.GetGlobalAchievementPercentagesForAppNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f4230
};

// Class UWorksWeb.GetGlobalStatsForGameNode
// Size: 0x40 (Inherited: 0x30)
struct UGetGlobalStatsForGameNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetGlobalStatsForGameNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetGlobalStatsForGameNode* GetGlobalStatsForGameNode(int32_t AppID, int32_t Count, struct TArray<struct FString> Name, int32_t StartDate, int32_t EndDate); // Function UWorksWeb.GetGlobalStatsForGameNode.GetGlobalStatsForGameNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f42c0
};

// Class UWorksWeb.GetNumberOfCurrentPlayersNode
// Size: 0x40 (Inherited: 0x30)
struct UGetNumberOfCurrentPlayersNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetNumberOfCurrentPlayersNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetNumberOfCurrentPlayersNode* GetNumberOfCurrentPlayersNode(int32_t AppID); // Function UWorksWeb.GetNumberOfCurrentPlayersNode.GetNumberOfCurrentPlayersNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f4760
};

// Class UWorksWeb.GetPlayerAchievementsNode
// Size: 0x40 (Inherited: 0x30)
struct UGetPlayerAchievementsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetPlayerAchievementsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetPlayerAchievementsNode* GetPlayerAchievementsNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, struct FString Language); // Function UWorksWeb.GetPlayerAchievementsNode.GetPlayerAchievementsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f47f0
};

// Class UWorksWeb.GetSchemaForGameNode
// Size: 0x40 (Inherited: 0x30)
struct UGetSchemaForGameNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetSchemaForGameNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetSchemaForGameNode* GetSchemaForGameNode(struct FString Key, int32_t AppID, struct FString Language); // Function UWorksWeb.GetSchemaForGameNode.GetSchemaForGameNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f49e0
};

// Class UWorksWeb.GetUserStatsForGameNode
// Size: 0x40 (Inherited: 0x30)
struct UGetUserStatsForGameNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetUserStatsForGameNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetUserStatsForGameNode* GetUserStatsForGameNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksWeb.GetUserStatsForGameNode.GetUserStatsForGameNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f4c30
};

// Class UWorksWeb.SetUserStatsForGameNode
// Size: 0x40 (Inherited: 0x30)
struct USetUserStatsForGameNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct USetUserStatsForGameNode* SetUserStatsForGameNode(struct FString Key, struct FUWorksSteamID SteamID, int32_t AppID, int32_t Count, struct TArray<struct FString> Name, struct TArray<int32_t> Value); // Function UWorksWeb.SetUserStatsForGameNode.SetUserStatsForGameNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f5150
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.SetUserStatsForGameNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.SetItemPaymentRulesNode
// Size: 0x40 (Inherited: 0x30)
struct USetItemPaymentRulesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct USetItemPaymentRulesNode* SetItemPaymentRulesNode(struct FString Key, int32_t AppID, int32_t GameItemID, struct FUWorksAssociatedWorkshopFiles AssociatedWorkshopFiles, struct FUWorksPartnerAccounts PartnerAccounts, bool bMakeWorkshopFilesSubscribable, bool bValidateOnly); // Function UWorksWeb.SetItemPaymentRulesNode.SetItemPaymentRulesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f4ef0
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.SetItemPaymentRulesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksWeb.GetFinalizedContributorsNode
// Size: 0x40 (Inherited: 0x30)
struct UGetFinalizedContributorsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetFinalizedContributorsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetFinalizedContributorsNode* GetFinalizedContributorsNode(struct FString Key, int32_t AppID, int32_t GameItemID); // Function UWorksWeb.GetFinalizedContributorsNode.GetFinalizedContributorsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f40d0
};

// Class UWorksWeb.GetItemDailyRevenueNode
// Size: 0x40 (Inherited: 0x30)
struct UGetItemDailyRevenueNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.GetItemDailyRevenueNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
	struct UGetItemDailyRevenueNode* GetItemDailyRevenueNode(struct FString Key, int32_t AppID, struct FString ItemId, int32_t DateStart, int32_t DateEnd); // Function UWorksWeb.GetItemDailyRevenueNode.GetItemDailyRevenueNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f4540
};

// Class UWorksWeb.PopulateItemDescriptionsNode
// Size: 0x40 (Inherited: 0x30)
struct UPopulateItemDescriptionsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UPopulateItemDescriptionsNode* PopulateItemDescriptionsNode(struct FString Key, int32_t AppID, struct FUWorksLanguages Languages); // Function UWorksWeb.PopulateItemDescriptionsNode.PopulateItemDescriptionsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9f4d90
	void OnRequestCompleted(bool bSuccessful, struct FString Content); // Function UWorksWeb.PopulateItemDescriptionsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

