// Class UWorksUtilities.UWorksLibrary
// Size: 0x28 (Inherited: 0x28)
struct UUWorksLibrary : UUWorks {
};

// Class UWorksUtilities.UWorksLibraryConversions
// Size: 0x28 (Inherited: 0x28)
struct UUWorksLibraryConversions : UUWorksLibrary {

	struct FString GetCurrentProcessId(); // Function UWorksUtilities.UWorksLibraryConversions.GetCurrentProcessId // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fab90
	struct TArray<char> ConvertStringToBytes(struct FString Data); // Function UWorksUtilities.UWorksLibraryConversions.ConvertStringToBytes // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fa520
	struct FString ConvertBytesToString(struct TArray<char> Data); // Function UWorksUtilities.UWorksLibraryConversions.ConvertBytesToString // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fa420
	struct FString ConvertBytesToHEXString(struct TArray<char> Data); // Function UWorksUtilities.UWorksLibraryConversions.ConvertBytesToHEXString // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fa320
};

// Class UWorksUtilities.UWorksLibraryGameID
// Size: 0x28 (Inherited: 0x28)
struct UUWorksLibraryGameID : UUWorksLibrary {

	void SetIdentifier(struct FUWorksGameID GameID, struct FString Identifier); // Function UWorksUtilities.UWorksLibraryGameID.SetIdentifier // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9fc120
	void Reset(struct FUWorksGameID GameID); // Function UWorksUtilities.UWorksLibraryGameID.Reset // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9fbe40
	bool IsValid(struct FUWorksGameID GameID); // Function UWorksUtilities.UWorksLibraryGameID.IsValid // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb940
	bool IsSteamApp(struct FUWorksGameID GameID); // Function UWorksUtilities.UWorksLibraryGameID.IsSteamApp // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb8b0
	bool IsShortcut(struct FUWorksGameID GameID); // Function UWorksUtilities.UWorksLibraryGameID.IsShortcut // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb820
	bool IsP2PFile(struct FUWorksGameID GameID); // Function UWorksUtilities.UWorksLibraryGameID.IsP2PFile // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb700
	bool IsMod(struct FUWorksGameID GameID); // Function UWorksUtilities.UWorksLibraryGameID.IsMod // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb670
	bool IsIdenticalWith(struct FUWorksGameID A, struct FUWorksGameID B); // Function UWorksUtilities.UWorksLibraryGameID.IsIdenticalWith // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb480
	int32_t GetModID(struct FUWorksGameID GameID); // Function UWorksUtilities.UWorksLibraryGameID.GetModID // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9facc0
	struct FString GetIdentifier(struct FUWorksGameID GameID); // Function UWorksUtilities.UWorksLibraryGameID.GetIdentifier // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fabe0
	int32_t GetAppID(struct FUWorksGameID GameID); // Function UWorksUtilities.UWorksLibraryGameID.GetAppID // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fab00
	struct FUWorksGameID ConstructFromParametersC(int32_t AppID, int32_t ModID); // Function UWorksUtilities.UWorksLibraryGameID.ConstructFromParametersC // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fa070
	struct FUWorksGameID ConstructFromParametersB(int32_t AppID); // Function UWorksUtilities.UWorksLibraryGameID.ConstructFromParametersB // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9f9e70
	struct FUWorksGameID ConstructFromParametersA(struct FString Identifier); // Function UWorksUtilities.UWorksLibraryGameID.ConstructFromParametersA // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9f9d80
};

// Class UWorksUtilities.UWorksLibraryLex
// Size: 0x28 (Inherited: 0x28)
struct UUWorksLibraryLex : UUWorksLibrary {

	struct FUWorksUGCUpdateHandle WriteUGCUpdateHandle(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteUGCUpdateHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fc9f0
	struct FUWorksUGCQueryHandle WriteUGCQueryHandle(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteUGCQueryHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fc9f0
	struct FUWorksUGCHandle WriteUGCHandle(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteUGCHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fc9f0
	struct FUWorksUGCFileWriteStreamHandle WriteUGCFileWriteStreamHandle(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteUGCFileWriteStreamHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fc9f0
	struct FUWorksTicketHandle WriteTicketHandle(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteTicketHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fcbd0
	struct FUWorksSteamUser WriteSteamUser(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteSteamUser // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fccc0
	struct FUWorksSteamPipe WriteSteamPipe(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteSteamPipe // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fccc0
	struct FUWorksSteamLeaderboardEntries WriteSteamLeaderboardEntries(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteSteamLeaderboardEntries // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fc9f0
	struct FUWorksSteamLeaderboard WriteSteamLeaderboard(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteSteamLeaderboard // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fc9f0
	struct FUWorksSteamInventoryResult WriteSteamInventoryResult(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteSteamInventoryResult // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fccc0
	struct FUWorksScreenshotHandle WriteScreenshotHandle(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteScreenshotHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fcbd0
	struct FUWorksFriendsGroupID WriteFriendsGroupID(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteFriendsGroupID // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fcae0
	struct FUWorksControllerHandle WriteControllerHandle(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteControllerHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fc9f0
	struct FUWorksControllerDigitalActionHandle WriteControllerDigitalActionHandle(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteControllerDigitalActionHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fc9f0
	struct FUWorksControllerAnalogActionHandle WriteControllerAnalogActionHandle(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteControllerAnalogActionHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fc9f0
	struct FUWorksControllerActionSetHandle WriteControllerActionSetHandle(struct FString Value); // Function UWorksUtilities.UWorksLibraryLex.WriteControllerActionSetHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fc9f0
	struct FString ReadUGCUpdateHandle(struct FUWorksUGCUpdateHandle Value); // Function UWorksUtilities.UWorksLibraryLex.ReadUGCUpdateHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fba60
	struct FString ReadUGCQueryHandle(struct FUWorksUGCQueryHandle Value); // Function UWorksUtilities.UWorksLibraryLex.ReadUGCQueryHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fba60
	struct FString ReadUGCHandle(struct FUWorksUGCHandle Value); // Function UWorksUtilities.UWorksLibraryLex.ReadUGCHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fbd80
	struct FString ReadUGCFileWriteStreamHandle(struct FUWorksUGCFileWriteStreamHandle Value); // Function UWorksUtilities.UWorksLibraryLex.ReadUGCFileWriteStreamHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fba60
	struct FString ReadTicketHandle(struct FUWorksTicketHandle Value); // Function UWorksUtilities.UWorksLibraryLex.ReadTicketHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fbba0
	struct FString ReadSteamUser(struct FUWorksSteamUser Value); // Function UWorksUtilities.UWorksLibraryLex.ReadSteamUser // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fbce0
	struct FString ReadSteamPipe(struct FUWorksSteamPipe Value); // Function UWorksUtilities.UWorksLibraryLex.ReadSteamPipe // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fbce0
	struct FString ReadSteamLeaderboardEntries(struct FUWorksSteamLeaderboardEntries Value); // Function UWorksUtilities.UWorksLibraryLex.ReadSteamLeaderboardEntries // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fba60
	struct FString ReadSteamLeaderboard(struct FUWorksSteamLeaderboard Value); // Function UWorksUtilities.UWorksLibraryLex.ReadSteamLeaderboard // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fba60
	struct FString ReadSteamInventoryResult(struct FUWorksSteamInventoryResult Value); // Function UWorksUtilities.UWorksLibraryLex.ReadSteamInventoryResult // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fbc40
	struct FString ReadScreenshotHandle(struct FUWorksScreenshotHandle Value); // Function UWorksUtilities.UWorksLibraryLex.ReadScreenshotHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fbba0
	struct FString ReadFriendsGroupID(struct FUWorksFriendsGroupID Value); // Function UWorksUtilities.UWorksLibraryLex.ReadFriendsGroupID // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fbb00
	struct FString ReadControllerHandle(struct FUWorksControllerHandle Value); // Function UWorksUtilities.UWorksLibraryLex.ReadControllerHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fba60
	struct FString ReadControllerDigitalActionHandle(struct FUWorksControllerDigitalActionHandle Value); // Function UWorksUtilities.UWorksLibraryLex.ReadControllerDigitalActionHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fba60
	struct FString ReadControllerAnalogActionHandle(struct FUWorksControllerAnalogActionHandle Value); // Function UWorksUtilities.UWorksLibraryLex.ReadControllerAnalogActionHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fba60
	struct FString ReadControllerActionSetHandle(struct FUWorksControllerActionSetHandle Value); // Function UWorksUtilities.UWorksLibraryLex.ReadControllerActionSetHandle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fba60
};

// Class UWorksUtilities.UWorksLibrarySteamID
// Size: 0x28 (Inherited: 0x28)
struct UUWorksLibrarySteamID : UUWorksLibrary {

	void SetUniverse(struct FUWorksSteamID SteamID, enum class EUWorksUniverse Universe); // Function UWorksUtilities.UWorksLibrarySteamID.SetUniverse // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9fc920
	void SetParametersC(struct FUWorksSteamID SteamID, enum class EUWorksUniverse Universe, enum class EUWorksAccountType AccountType, struct FString AccountID, struct FString AccountInstance); // Function UWorksUtilities.UWorksLibrarySteamID.SetParametersC // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9fc6e0
	void SetParametersB(struct FUWorksSteamID SteamID, enum class EUWorksUniverse Universe, enum class EUWorksAccountType AccountType, struct FString AccountID); // Function UWorksUtilities.UWorksLibrarySteamID.SetParametersB // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9fc530
	void SetParametersA(struct FUWorksSteamID SteamID, enum class EUWorksUniverse Universe, enum class EUWorksAccountType AccountType, struct FString Identifier); // Function UWorksUtilities.UWorksLibrarySteamID.SetParametersA // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9fc380
	void SetIdentifier(struct FUWorksSteamID SteamID, struct FString Identifier); // Function UWorksUtilities.UWorksLibrarySteamID.SetIdentifier // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9fc250
	void SetAccountInstance(struct FUWorksSteamID SteamID, struct FString AccountInstance); // Function UWorksUtilities.UWorksLibrarySteamID.SetAccountInstance // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9fbff0
	void SetAccountID(struct FUWorksSteamID SteamID, struct FString AccountID); // Function UWorksUtilities.UWorksLibrarySteamID.SetAccountID // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9fbec0
	bool IsValid(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsValid // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb9d0
	bool IsPersistentGameServerAccount(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsPersistentGameServerAccount // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb790
	bool IsLobby(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsLobby // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb5e0
	bool IsIndividualAccount(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsIndividualAccount // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb550
	bool IsIdenticalWith(struct FUWorksSteamID A, struct FUWorksSteamID B); // Function UWorksUtilities.UWorksLibrarySteamID.IsIdenticalWith // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb480
	bool IsGameServerAccount(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsGameServerAccount // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb3f0
	bool IsContentServerAccount(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsContentServerAccount // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb360
	bool IsConsoleUserAccount(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsConsoleUserAccount // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb2d0
	bool IsClanAccount(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsClanAccount // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb240
	bool IsChatAccount(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsChatAccount // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb1b0
	bool IsBlankAnonAccount(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsBlankAnonAccount // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb120
	bool IsAnonUserAccount(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsAnonUserAccount // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb090
	bool IsAnonGameServerAccount(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsAnonGameServerAccount // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fb000
	bool IsAnonAccount(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.IsAnonAccount // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9faf70
	bool HasNoIndividualInstance(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.HasNoIndividualInstance // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9faee0
	enum class EUWorksUniverse GetUniverse(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.GetUniverse // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fae50
	struct FString GetStaticAccountKey(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.GetStaticAccountKey // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fada0
	struct FString GetIdentifier(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.GetIdentifier // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fabe0
	enum class EUWorksAccountType GetAccountType(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.GetAccountType // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9faa70
	struct FString GetAccountInstance(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.GetAccountInstance // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fa9c0
	struct FString GetAccountID(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.GetAccountID // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fa910
	void CreateBlankAnonUserLogon(struct FUWorksSteamID SteamID, enum class EUWorksUniverse Universe); // Function UWorksUtilities.UWorksLibrarySteamID.CreateBlankAnonUserLogon // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9fa730
	void CreateBlankAnonLogon(struct FUWorksSteamID SteamID, enum class EUWorksUniverse Universe); // Function UWorksUtilities.UWorksLibrarySteamID.CreateBlankAnonLogon // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9fa660
	struct FUWorksSteamID ConstructFromParametersC(enum class EUWorksUniverse Universe, enum class EUWorksAccountType AccountType, struct FString AccountID, struct FString AccountInstance); // Function UWorksUtilities.UWorksLibrarySteamID.ConstructFromParametersC // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fa130
	struct FUWorksSteamID ConstructFromParametersB(enum class EUWorksUniverse Universe, enum class EUWorksAccountType AccountType, struct FString AccountID); // Function UWorksUtilities.UWorksLibrarySteamID.ConstructFromParametersB // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9f9f00
	struct FUWorksSteamID ConstructFromParametersA(struct FString Identifier); // Function UWorksUtilities.UWorksLibrarySteamID.ConstructFromParametersA // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9f9d80
	void ClearIndividualInstance(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.ClearIndividualInstance // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9f9d00
	void Clear(struct FUWorksSteamID SteamID); // Function UWorksUtilities.UWorksLibrarySteamID.Clear // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9f9d00
};

// Class UWorksUtilities.UWorksLibraryTickets
// Size: 0x28 (Inherited: 0x28)
struct UUWorksLibraryTickets : UUWorksLibrary {
};

// Class UWorksUtilities.UWorksManager
// Size: 0x28 (Inherited: 0x28)
struct UUWorksManager : UUWorks {
};

// Class UWorksUtilities.UWorksManagerNetwork
// Size: 0x90 (Inherited: 0x28)
struct UUWorksManagerNetwork : UUWorksManager {
	char pad_28[0x58]; // 0x28(0x58)
	struct FMulticastInlineDelegate RefreshComplete; // 0x80(0x10)

	void Refresh(); // Function UWorksUtilities.UWorksManagerNetwork.Refresh // (Final|Native|Public|BlueprintCallable) // @ game+0x9fbe20
	struct FString GetNetDriverClassName(); // Function UWorksUtilities.UWorksManagerNetwork.GetNetDriverClassName // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fad50
	struct UUWorksManagerNetwork* GetManagerNetwork(); // Function UWorksUtilities.UWorksManagerNetwork.GetManagerNetwork // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9fac90
	void CreateSessionUWorks(struct FName SessionName, int32_t NumPublicConnections, bool bIsLANMatch); // Function UWorksUtilities.UWorksManagerNetwork.CreateSessionUWorks // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa800
};

