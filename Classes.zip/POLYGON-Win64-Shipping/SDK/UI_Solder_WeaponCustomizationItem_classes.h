// WidgetBlueprintGeneratedClass UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C
// Size: 0x2f2 (Inherited: 0x260)
struct UUI_Solder_WeaponCustomizationItem_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* HoverIfNotAvaliable; // 0x268(0x08)
	struct UWidgetAnimation* Hover; // 0x270(0x08)
	struct UBorder* Border; // 0x278(0x08)
	struct UBorder* Border_IsEquipped; // 0x280(0x08)
	struct UButton* Button; // 0x288(0x08)
	struct UImage* Image_ItemIcon; // 0x290(0x08)
	struct USizeBox* SizeBox; // 0x298(0x08)
	struct UTextBlock* TextBlock_ItemName; // 0x2a0(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_IsAvaliable; // 0x2a8(0x08)
	struct AItem_Module_General* ModuleClass; // 0x2b0(0x08)
	bool IsEquipped; // 0x2b8(0x01)
	char pad_2B9[0x7]; // 0x2b9(0x07)
	struct FMulticastInlineDelegate ClickDelegate; // 0x2c0(0x10)
	struct UPlayFabJsonObject* WeaponDataJson; // 0x2d0(0x08)
	struct UPlayFabJsonObject* ModuleDataJson; // 0x2d8(0x08)
	struct UUI_Solder_WeaponCustomization_C* UI_WeaponCustomization; // 0x2e0(0x08)
	struct UPlayFabJsonObject* JsonRequest; // 0x2e8(0x08)
	bool IsLocked; // 0x2f0(0x01)
	bool IsAvaliable; // 0x2f1(0x01)

	void SetIsAvaliable(bool IsAvaliable); // Function UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C.SetIsAvaliable // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetVisibleLoadingSlot(enum class ESlateVisibility InVisibility); // Function UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C.SetVisibleLoadingSlot // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetIsEquipped(bool IsEquipped); // Function UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C.SetIsEquipped // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_3342D2A64568AA5D78B4D1BA42BF904F(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C.OnPlayFabResponse_3342D2A64568AA5D78B4D1BA42BF904F // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonPressedEvent__DelegateSignature(); // Function UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C.BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteCloudScript_Success(struct FClientExecuteCloudScriptResult Result, struct UObject* customData); // Function UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C.ExecuteCloudScript_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteCloudScript_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C.ExecuteCloudScript_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Solder_WeaponCustomizationItem(int32_t EntryPoint); // Function UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C.ExecuteUbergraph_UI_Solder_WeaponCustomizationItem // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
	void ClickDelegate__DelegateSignature(struct UUI_Solder_WeaponCustomizationItem_C* Item); // Function UI_Solder_WeaponCustomizationItem.UI_Solder_WeaponCustomizationItem_C.ClickDelegate__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

