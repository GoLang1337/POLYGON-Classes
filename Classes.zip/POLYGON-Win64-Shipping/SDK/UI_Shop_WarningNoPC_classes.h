// WidgetBlueprintGeneratedClass UI_Shop_WarningNoPC.UI_Shop_WarningNoPC_C
// Size: 0x294 (Inherited: 0x260)
struct UUI_Shop_WarningNoPC_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border_BattlePass_Border; // 0x268(0x08)
	struct UButton* Button_No; // 0x270(0x08)
	struct UButton* Button_Yes; // 0x278(0x08)
	struct UImage* Image_BattlePass_Background; // 0x280(0x08)
	struct UTextBlock* TextBlock_Count; // 0x288(0x08)
	int32_t LackCurrency; // 0x290(0x04)

	void BndEvt__UI_WarningNoPC_Button_No_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_Shop_WarningNoPC.UI_Shop_WarningNoPC_C.BndEvt__UI_WarningNoPC_Button_No_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_WarningNoPC_Button_Yes_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function UI_Shop_WarningNoPC.UI_Shop_WarningNoPC_C.BndEvt__UI_WarningNoPC_Button_Yes_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Shop_WarningNoPC.UI_Shop_WarningNoPC_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Shop_WarningNoPC(int32_t EntryPoint); // Function UI_Shop_WarningNoPC.UI_Shop_WarningNoPC_C.ExecuteUbergraph_UI_Shop_WarningNoPC // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

