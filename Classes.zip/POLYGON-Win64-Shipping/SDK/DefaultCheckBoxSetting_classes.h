// WidgetBlueprintGeneratedClass DefaultCheckBoxSetting.DefaultCheckBoxSetting_C
// Size: 0x2b8 (Inherited: 0x2b8)
struct UDefaultCheckBoxSetting_C : UCheckBoxSetting {
};

