// WidgetBlueprintGeneratedClass UI_KillLog_Entry.UI_KillLog_Entry_C
// Size: 0x2b2 (Inherited: 0x260)
struct UUI_KillLog_Entry_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Hidden; // 0x268(0x08)
	struct UHorizontalBox* HorizontalBox_Headshot; // 0x270(0x08)
	struct UImage* Image_GrenadeKill; // 0x278(0x08)
	struct UTextBlock* TextBlock_Killed; // 0x280(0x08)
	struct UTextBlock* TextBlock_Killer; // 0x288(0x08)
	struct UTextBlock* TextBlock_Weapon; // 0x290(0x08)
	struct APG_PlayerState_Game* MyPlayerState; // 0x298(0x08)
	struct APG_PlayerState_Game* killed; // 0x2a0(0x08)
	struct APG_PlayerState_Game* killer; // 0x2a8(0x08)
	bool isHeadshot; // 0x2b0(0x01)
	bool isGrenade; // 0x2b1(0x01)

	void Construct(); // Function UI_KillLog_Entry.UI_KillLog_Entry_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_KillLog_Entry.UI_KillLog_Entry_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_KillLog_Entry(int32_t EntryPoint); // Function UI_KillLog_Entry.UI_KillLog_Entry_C.ExecuteUbergraph_UI_KillLog_Entry // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

