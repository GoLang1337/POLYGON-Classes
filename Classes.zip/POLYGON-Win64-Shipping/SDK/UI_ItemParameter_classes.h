// WidgetBlueprintGeneratedClass UI_ItemParameter.UI_ItemParameter_C
// Size: 0x29d (Inherited: 0x260)
struct UUI_ItemParameter_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UProgressBar* ProgressBar_Parameter; // 0x268(0x08)
	struct UTextBlock* TextBlock_Parameter; // 0x270(0x08)
	struct UTextBlock* TextBlock_ParameterName; // 0x278(0x08)
	struct FText ParameterName; // 0x280(0x18)
	float MaxParameter; // 0x298(0x04)
	bool IsRound; // 0x29c(0x01)

	void PreConstruct(bool IsDesignTime); // Function UI_ItemParameter.UI_ItemParameter_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void SetNewParameter(float NewParameter); // Function UI_ItemParameter.UI_ItemParameter_C.SetNewParameter // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_ItemParameter(int32_t EntryPoint); // Function UI_ItemParameter.UI_ItemParameter_C.ExecuteUbergraph_UI_ItemParameter // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

