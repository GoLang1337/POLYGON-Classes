// WidgetBlueprintGeneratedClass UI_Shop_Crowns.UI_Shop_Crowns_C
// Size: 0x290 (Inherited: 0x260)
struct UUI_Shop_Crowns_C : UUserWidget {
	struct UUI_Shop_Crowns_Item_C* UI_Shop_Crowns_Item; // 0x260(0x08)
	struct UUI_Shop_Crowns_Item_C* UI_Shop_Crowns_Item_2; // 0x268(0x08)
	struct UUI_Shop_Crowns_Item_C* UI_Shop_Crowns_Item_3; // 0x270(0x08)
	struct UUI_Shop_Crowns_Item_C* UI_Shop_Crowns_Item_4; // 0x278(0x08)
	struct UUI_Shop_Crowns_Item_C* UI_Shop_Crowns_Item_5; // 0x280(0x08)
	struct UUI_Shop_Crowns_Item_C* UI_Shop_Crowns_Item_6; // 0x288(0x08)
};

