// WidgetBlueprintGeneratedClass UI_Shop_VIP_Button.UI_Shop_VIP_Button_C
// Size: 0x2d0 (Inherited: 0x260)
struct UUI_Shop_VIP_Button_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button; // 0x268(0x08)
	struct UImage* Image_Crowns; // 0x270(0x08)
	struct UOverlay* Overlay_Loading; // 0x278(0x08)
	struct UTextBlock* Text_Day; // 0x280(0x08)
	struct UTextBlock* Text_DaysNumber; // 0x288(0x08)
	struct UTextBlock* Text_PriceForDay; // 0x290(0x08)
	struct UTextBlock* TextBlock_Price; // 0x298(0x08)
	struct UUI_LoadingIcon_C* UI_LoadingIcon; // 0x2a0(0x08)
	struct FString ItemId; // 0x2a8(0x10)
	int32_t DaysNumber; // 0x2b8(0x04)
	int32_t Price; // 0x2bc(0x04)
	int32_t PriceForDay; // 0x2c0(0x04)
	bool CanBuy; // 0x2c4(0x01)
	char pad_2C5[0x3]; // 0x2c5(0x03)
	struct ABP_PG_PlayerController_Menu_C* PlayerController; // 0x2c8(0x08)

	void SetCanBuy(int32_t PC); // Function UI_Shop_VIP_Button.UI_Shop_VIP_Button_C.SetCanBuy // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_089383D84669101F1269ABB1AD6D1DB1(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_Shop_VIP_Button.UI_Shop_VIP_Button_C.OnPlayFabResponse_089383D84669101F1269ABB1AD6D1DB1 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Shop_VIP_Button.UI_Shop_VIP_Button_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_VIP_Button_Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_Shop_VIP_Button.UI_Shop_VIP_Button_C.BndEvt__UI_Shop_VIP_Button_Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void OnClickedBuy(); // Function UI_Shop_VIP_Button.UI_Shop_VIP_Button_C.OnClickedBuy // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PurchaseVIP_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_Shop_VIP_Button.UI_Shop_VIP_Button_C.PurchaseVIP_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PurchaseVIP_Success(struct FClientExecuteCloudScriptResult Result, struct UObject* customData); // Function UI_Shop_VIP_Button.UI_Shop_VIP_Button_C.PurchaseVIP_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Shop_VIP_Button(int32_t EntryPoint); // Function UI_Shop_VIP_Button.UI_Shop_VIP_Button_C.ExecuteUbergraph_UI_Shop_VIP_Button // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

