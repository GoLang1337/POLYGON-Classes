// WidgetBlueprintGeneratedClass UI_PremiumShop_Crowns.UI_PremiumShop_Crowns_C
// Size: 0x2a0 (Inherited: 0x260)
struct UUI_PremiumShop_Crowns_C : UUserWidget {
	struct UUI_Premium_CrownsItem_C* UI_PremiumItem_1200Crowns; // 0x260(0x08)
	struct UUI_Premium_CrownsItem_C* UI_PremiumItem_2500Crowns; // 0x268(0x08)
	struct UUI_Premium_CrownsItem_C* UI_PremiumItem_5000Crowns; // 0x270(0x08)
	struct UUI_Premium_CrownsItem_C* UI_PremiumItem_5000Crowns_2; // 0x278(0x08)
	struct UUI_Premium_CrownsItem_C* UI_PremiumItem_5000Crowns_3; // 0x280(0x08)
	struct UUI_Premium_CrownsItem_C* UI_PremiumItem_5000Crowns_4; // 0x288(0x08)
	struct UUI_Premium_CrownsItem_C* UI_PremiumItem_5000Crowns_5; // 0x290(0x08)
	struct UUI_Premium_CrownsItem_C* UI_PremiumItem_500Crowns; // 0x298(0x08)
};

