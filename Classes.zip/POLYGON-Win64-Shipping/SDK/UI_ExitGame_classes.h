// WidgetBlueprintGeneratedClass UI_ExitGame.UI_ExitGame_C
// Size: 0x278 (Inherited: 0x260)
struct UUI_ExitGame_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button_No; // 0x268(0x08)
	struct UButton* Button_Yes; // 0x270(0x08)

	void BndEvt__Button_Yes_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_ExitGame.UI_ExitGame_C.BndEvt__Button_Yes_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_No_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function UI_ExitGame.UI_ExitGame_C.BndEvt__Button_No_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_ExitGame(int32_t EntryPoint); // Function UI_ExitGame.UI_ExitGame_C.ExecuteUbergraph_UI_ExitGame // (Final|UbergraphFunction) // @ game+0x1847880
};

