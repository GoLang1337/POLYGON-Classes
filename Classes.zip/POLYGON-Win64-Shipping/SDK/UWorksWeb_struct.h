// Enum UWorksWeb.EUWorksUserSession
enum class EUWorksUserSession : uint8 {
	None = 0,
	Client = 1,
	Web = 2,
	EUWorksUserSession_MAX = 3
};

// Enum UWorksWeb.EUWorksReportType
enum class EUWorksReportType : uint8 {
	None = 0,
	GameSales = 1,
	SteamStore = 2,
	Settlement = 3,
	EUWorksReportType_MAX = 4
};

// Enum UWorksWeb.FUWorksHTTPResponse
enum class FUWorksHTTPResponse : uint8 {
	Unknown = 0,
	Continue = 1,
	SwitchProtocol = 2,
	Ok = 3,
	Created = 4,
	Accepted = 5,
	Partial = 6,
	NoContent = 7,
	ResetContent = 8,
	PartialContent = 9,
	Ambiguous = 10,
	Moved = 11,
	Redirect = 12,
	RedirectMethod = 13,
	NotModified = 14,
	UseProxy = 15,
	RedirectKeepVerb = 16,
	BadRequest = 17,
	Denied = 18,
	PaymentReq = 19,
	Forbidden = 20,
	NotFound = 21,
	BadMethod = 22,
	NoneAcceptable = 23,
	ProxyAuthReq = 24,
	RequestTimeout = 25,
	Conflict = 26,
	Gone = 27,
	LengthRequired = 28,
	PrecondFailed = 29,
	RequestTooLarge = 30,
	UriTooLong = 31,
	UnsupportedMedia = 32,
	TooManyRequests = 33,
	RetryWith = 34,
	ServerError = 35,
	NotSupported = 36,
	BadGateway = 37,
	ServiceUnavail = 38,
	GatewayTimeout = 39,
	VersionNotSup = 40,
	FUWorksHTTPResponse_MAX = 41
};

// ScriptStruct UWorksWeb.UWorksAnnexWebApps
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebApps {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebBroadcast
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebBroadcast {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebCheatReporting
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebCheatReporting {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebCommunity
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebCommunity {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebEcon
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebEcon {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebEconMarket
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebEconMarket {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebEconomy
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebEconomy {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebGameInventory
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebGameInventory {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksSessions
// Size: 0x01 (Inherited: 0x00)
struct FUWorksSessions {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksUsers
// Size: 0x01 (Inherited: 0x00)
struct FUWorksUsers {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksTitle
// Size: 0x01 (Inherited: 0x00)
struct FUWorksTitle {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebGameNotifications
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebGameNotifications {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebGameServers
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebGameServers {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebGameServerStats
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebGameServerStats {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebInventory
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebInventory {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebLeaderboards
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebLeaderboards {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebMicroTxn
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebMicroTxn {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebNews
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebNews {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksPlaySessions
// Size: 0x01 (Inherited: 0x00)
struct FUWorksPlaySessions {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebPlayer
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebPlayer {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksRequiredKVTags
// Size: 0x01 (Inherited: 0x00)
struct FUWorksRequiredKVTags {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebPublishedFile
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebPublishedFile {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebPublishedItemSearch
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebPublishedItemSearch {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebPublishedItemVoting
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebPublishedItemVoting {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebRemoteStorage
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebRemoteStorage {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebUser
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebUser {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebUserAuth
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebUserAuth {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebUserStats
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebUserStats {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksLanguages
// Size: 0x01 (Inherited: 0x00)
struct FUWorksLanguages {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksPartnerAccounts
// Size: 0x01 (Inherited: 0x00)
struct FUWorksPartnerAccounts {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAssociatedWorkshopFiles
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAssociatedWorkshopFiles {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksWeb.UWorksAnnexWebWorkshop
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexWebWorkshop {
	char pad_0[0x1]; // 0x00(0x01)
};

