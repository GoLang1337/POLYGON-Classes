// WidgetBlueprintGeneratedClass UI_GeneralGameScreen.UI_GeneralGameScreen_C
// Size: 0x2b4 (Inherited: 0x260)
struct UUI_GeneralGameScreen_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UUI_Chat_C* UI_Chat; // 0x268(0x08)
	struct UUI_EscapeMenu_C* UI_EscapeMenu; // 0x270(0x08)
	struct UUI_GameMenuScreen_C* UI_GameMenuScreen; // 0x278(0x08)
	struct UUI_GamePointsWindow_C* UI_GamePointsWindow; // 0x280(0x08)
	struct UUI_GameScreen_C* UI_GameScreen; // 0x288(0x08)
	struct UUI_KillLog_C* UI_KillLog; // 0x290(0x08)
	struct UUI_MatchResult_C* UI_MatchResult; // 0x298(0x08)
	struct UUI_Scoreboard_C* UI_Scoreboard; // 0x2a0(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Main; // 0x2a8(0x08)
	int32_t ActiveScreenIndex; // 0x2b0(0x04)

	void ToggleMenu(); // Function UI_GeneralGameScreen.UI_GeneralGameScreen_C.ToggleMenu // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetActiveScreenIndex(int32_t Index); // Function UI_GeneralGameScreen.UI_GeneralGameScreen_C.SetActiveScreenIndex // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function UI_GeneralGameScreen.UI_GeneralGameScreen_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_GeneralGameScreen.UI_GeneralGameScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnNewLevelReceived_Event(); // Function UI_GeneralGameScreen.UI_GeneralGameScreen_C.OnNewLevelReceived_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnTeamWon_Event(); // Function UI_GeneralGameScreen.UI_GeneralGameScreen_C.OnTeamWon_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_GeneralGameScreen(int32_t EntryPoint); // Function UI_GeneralGameScreen.UI_GeneralGameScreen_C.ExecuteUbergraph_UI_GeneralGameScreen // (Final|UbergraphFunction) // @ game+0x1847880
};

