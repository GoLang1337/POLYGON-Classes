// BlueprintGeneratedClass CameraShake_ThrowGrenade.CameraShake_ThrowGrenade_C
// Size: 0x180 (Inherited: 0x180)
struct UCameraShake_ThrowGrenade_C : UMatineeCameraShake {
};

