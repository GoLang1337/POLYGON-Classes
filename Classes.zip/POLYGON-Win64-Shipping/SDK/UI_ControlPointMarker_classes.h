// WidgetBlueprintGeneratedClass UI_ControlPointMarker.UI_ControlPointMarker_C
// Size: 0x2a0 (Inherited: 0x260)
struct UUI_ControlPointMarker_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* ControlPointImage; // 0x268(0x08)
	struct USizeBox* SizeBox; // 0x270(0x08)
	enum class EControlPoint PointName; // 0x278(0x01)
	char pad_279[0x3]; // 0x279(0x03)
	float Size; // 0x27c(0x04)
	struct AControlPoint* ControlPointReference; // 0x280(0x08)
	float TargetOpacity; // 0x288(0x04)
	bool AllowPlayerSpawn; // 0x28c(0x01)
	char pad_28D[0x3]; // 0x28d(0x03)
	struct FMulticastInlineDelegate SelectAsSpawnPointDelegate; // 0x290(0x10)

	void ResetSpawnPoint(); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.ResetSpawnPoint // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetSize(float NewSize); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.SetSize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetName(); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.SetName // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void SelectAsSpawnPoint(); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.SelectAsSpawnPoint // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void AttachMarkerToControlPoint(); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.AttachMarkerToControlPoint // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnCapturedTeam_Event(); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.OnCapturedTeam_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnIsCapture_Event(); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.OnIsCapture_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_ControlPointMarker(int32_t EntryPoint); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.ExecuteUbergraph_UI_ControlPointMarker // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
	void SelectAsSpawnPointDelegate__DelegateSignature(enum class EControlPoint Point); // Function UI_ControlPointMarker.UI_ControlPointMarker_C.SelectAsSpawnPointDelegate__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

