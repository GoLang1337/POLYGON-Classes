// BlueprintGeneratedClass BP_SupportBox_Ammo.BP_SupportBox_Ammo_C
// Size: 0x248 (Inherited: 0x248)
struct ABP_SupportBox_Ammo_C : ASupportBox_Ammo {
};

