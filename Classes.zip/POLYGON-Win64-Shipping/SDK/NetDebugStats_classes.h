// Class NetDebugStats.NetDebugStatsFunctions
// Size: 0x28 (Inherited: 0x28)
struct UNetDebugStatsFunctions : UBlueprintFunctionLibrary {

	bool GetTotalPackets(struct UObject* WorldContextObject, struct FNetDebugStatPackets OutPackets); // Function NetDebugStats.NetDebugStatsFunctions.GetTotalPackets // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xee0600
	bool GetTotalBytes(struct UObject* WorldContextObject, struct FNetDebugStatBytes OutBytes, bool bConvertToKB); // Function NetDebugStats.NetDebugStatsFunctions.GetTotalBytes // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xee04d0
	bool GetTotalAcks(struct UObject* WorldContextObject, int32_t OutTotalAcks); // Function NetDebugStats.NetDebugStatsFunctions.GetTotalAcks // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xee03f0
	bool GetPacketsPerSecond(struct UObject* WorldContextObject, struct FNetDebugStatPackets OutPackets); // Function NetDebugStats.NetDebugStatsFunctions.GetPacketsPerSecond // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xee0310
	bool GetPackets(struct UObject* WorldContextObject, struct FNetDebugStatPackets OutPackets); // Function NetDebugStats.NetDebugStatsFunctions.GetPackets // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xee0230
	bool GetPacketLostPercentage(struct UObject* WorldContextObject, float InPercentage, float OutPercentage, bool bGetAverage); // Function NetDebugStats.NetDebugStatsFunctions.GetPacketLostPercentage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xee00c0
	bool GetPacketLost(struct UObject* WorldContextObject, struct FNetDebugStatPackets OutPackets); // Function NetDebugStats.NetDebugStatsFunctions.GetPacketLost // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xedffe0
	bool GetMaxPacket(struct UObject* WorldContextObject, int32_t OutMaxPacket); // Function NetDebugStats.NetDebugStatsFunctions.GetMaxPacket // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xedff00
	enum class ENetDebugStatConnectionState GetConnectionState(struct UObject* WorldContextObject); // Function NetDebugStats.NetDebugStatsFunctions.GetConnectionState // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xedfe70
	bool GetBytesPerSecond(struct UObject* WorldContextObject, struct FNetDebugStatBytes OutBytes, bool bConvertToKB); // Function NetDebugStats.NetDebugStatsFunctions.GetBytesPerSecond // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xedfd40
	bool GetBytes(struct UObject* WorldContextObject, struct FNetDebugStatBytes OutBytes, bool bConvertToKB); // Function NetDebugStats.NetDebugStatsFunctions.GetBytes // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xedfc10
	bool GetAverageLag(struct UObject* WorldContextObject, float OutAverageLag); // Function NetDebugStats.NetDebugStatsFunctions.GetAverageLag // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xedfb30
};

