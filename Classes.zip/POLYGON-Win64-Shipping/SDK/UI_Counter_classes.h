// WidgetBlueprintGeneratedClass UI_Counter.UI_Counter_C
// Size: 0x2b0 (Inherited: 0x260)
struct UUI_Counter_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button; // 0x268(0x08)
	struct UImage* Image_Hovered; // 0x270(0x08)
	struct UImage* Image_Icon; // 0x278(0x08)
	struct UImage* Image_Plus; // 0x280(0x08)
	struct UTextBlock* TextBlock_Counter; // 0x288(0x08)
	struct UTexture2D* Icon; // 0x290(0x08)
	bool IsPremium; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)
	struct FMulticastInlineDelegate OnClickDelegate; // 0x2a0(0x10)

	void PreConstruct(bool IsDesignTime); // Function UI_Counter.UI_Counter_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_Counter.UI_Counter_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_Counter.UI_Counter_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function UI_Counter.UI_Counter_C.BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Counter(int32_t EntryPoint); // Function UI_Counter.UI_Counter_C.ExecuteUbergraph_UI_Counter // (Final|UbergraphFunction) // @ game+0x1847880
	void OnClickDelegate__DelegateSignature(struct UUI_Counter_C* Counter); // Function UI_Counter.UI_Counter_C.OnClickDelegate__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

