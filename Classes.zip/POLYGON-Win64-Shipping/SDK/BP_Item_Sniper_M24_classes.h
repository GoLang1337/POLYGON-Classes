// BlueprintGeneratedClass BP_Item_Sniper_M24.BP_Item_Sniper_M24_C
// Size: 0x418 (Inherited: 0x410)
struct ABP_Item_Sniper_M24_C : AItem_Weapon_Sniper {
	struct UStaticMeshComponent* IronSight; // 0x410(0x08)

	void UserConstructionScript(); // Function BP_Item_Sniper_M24.BP_Item_Sniper_M24_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

