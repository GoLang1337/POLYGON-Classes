// WidgetBlueprintGeneratedClass UI_GameScreen.UI_GameScreen_C
// Size: 0x290 (Inherited: 0x260)
struct UUI_GameScreen_C : UUserWidget {
	struct UUI_Compass_C* UI_Compass; // 0x260(0x08)
	struct UUI_CountdownTimer_C* UI_CountdownTimer; // 0x268(0x08)
	struct UUI_Crosshair_C* UI_Crosshair; // 0x270(0x08)
	struct UUI_Indicators_C* UI_Indicators; // 0x278(0x08)
	struct UUI_Minimap_C* UI_Minimap; // 0x280(0x08)
	struct UUI_Weapons_C* UI_Weapons; // 0x288(0x08)
};

