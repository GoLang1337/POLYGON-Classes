// WidgetBlueprintGeneratedClass UI_Interaction.UI_Interaction_C
// Size: 0x260 (Inherited: 0x260)
struct UUI_Interaction_C : UUserWidget {
};

