// WidgetBlueprintGeneratedClass UI_InteractionTime.UI_InteractionTime_C
// Size: 0x278 (Inherited: 0x260)
struct UUI_InteractionTime_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* Image_InteractionProgress; // 0x268(0x08)
	float interactionTime; // 0x270(0x04)
	float CurrentTime; // 0x274(0x04)

	void Construct(); // Function UI_InteractionTime.UI_InteractionTime_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Timer_InteractionTime(); // Function UI_InteractionTime.UI_InteractionTime_C.Timer_InteractionTime // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_InteractionTime.UI_InteractionTime_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_InteractionTime(int32_t EntryPoint); // Function UI_InteractionTime.UI_InteractionTime_C.ExecuteUbergraph_UI_InteractionTime // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

