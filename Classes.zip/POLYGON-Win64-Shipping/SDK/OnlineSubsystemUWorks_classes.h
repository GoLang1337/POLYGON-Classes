// Class OnlineSubsystemUWorks.IpConnectionUWorks
// Size: 0x1b90 (Inherited: 0x1b90)
struct UIpConnectionUWorks : UIpConnection {
};

// Class OnlineSubsystemUWorks.IpNetDriverUWorks
// Size: 0x7f0 (Inherited: 0x7b8)
struct UIpNetDriverUWorks : UIpNetDriver {
	char pad_7B8[0x38]; // 0x7b8(0x38)
};

