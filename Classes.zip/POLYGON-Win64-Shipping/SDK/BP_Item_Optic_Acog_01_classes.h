// BlueprintGeneratedClass BP_Item_Optic_Acog_01.BP_Item_Optic_Acog_01_C
// Size: 0x2b0 (Inherited: 0x2a0)
struct ABP_Item_Optic_Acog_01_C : AItem_Module_Optic {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a0(0x08)
	struct FTimerHandle Timer_SetAimingMesh; // 0x2a8(0x08)

	void SetAimingMesh(); // Function BP_Item_Optic_Acog_01.BP_Item_Optic_Acog_01_C.SetAimingMesh // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ToggleAiming(bool IsAiming); // Function BP_Item_Optic_Acog_01.BP_Item_Optic_Acog_01_C.ToggleAiming // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_Item_Optic_Acog_01(int32_t EntryPoint); // Function BP_Item_Optic_Acog_01.BP_Item_Optic_Acog_01_C.ExecuteUbergraph_BP_Item_Optic_Acog_01 // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

