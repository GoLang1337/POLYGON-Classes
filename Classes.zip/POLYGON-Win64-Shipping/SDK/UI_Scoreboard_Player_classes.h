// WidgetBlueprintGeneratedClass UI_Scoreboard_Player.UI_Scoreboard_Player_C
// Size: 0x2d0 (Inherited: 0x260)
struct UUI_Scoreboard_Player_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border_Illumination; // 0x268(0x08)
	struct UBorder* Border_MyPlayer; // 0x270(0x08)
	struct UImage* Image_LevelIcon; // 0x278(0x08)
	struct UTextBlock* TextBlock_LevelNumber; // 0x280(0x08)
	struct UTextBlock* TextBlock_PlayerDeath; // 0x288(0x08)
	struct UTextBlock* TextBlock_PlayerKills; // 0x290(0x08)
	struct UTextBlock* TextBlock_PlayerName; // 0x298(0x08)
	struct UTextBlock* TextBlock_PlayerNumber; // 0x2a0(0x08)
	struct UTextBlock* TextBlock_PlayerPing; // 0x2a8(0x08)
	struct UTextBlock* TextBlock_PlayerScore; // 0x2b0(0x08)
	struct APG_PlayerState_Game* Player; // 0x2b8(0x08)
	int32_t PlayerNumber; // 0x2c0(0x04)
	char pad_2C4[0x4]; // 0x2c4(0x04)
	struct UUI_Scoreboard_C* ParentWidget; // 0x2c8(0x08)

	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetPlayerNumber(int32_t NewNumber); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.SetPlayerNumber // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SortPlayers(struct UGridPanel* GridTeam); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.SortPlayers // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetPlayerName(); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.SetPlayerName // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetPlayerDeaths(); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.SetPlayerDeaths // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetKillsOfPlayer(); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.SetKillsOfPlayer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetPlayerGameScore(); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.SetPlayerGameScore // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetPlayerLevel(); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.SetPlayerLevel // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnNewLevelReceived_Event(); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.OnNewLevelReceived_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnChangeNumberKills_Event(); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.OnChangeNumberKills_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnChangeNumberDeaths_Event(); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.OnChangeNumberDeaths_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayerNameChanged_Event(); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.OnPlayerNameChanged_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnSetTotalProgress_Event(); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.OnSetTotalProgress_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Scoreboard_Player(int32_t EntryPoint); // Function UI_Scoreboard_Player.UI_Scoreboard_Player_C.ExecuteUbergraph_UI_Scoreboard_Player // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

