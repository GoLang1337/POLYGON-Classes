// BlueprintGeneratedClass BP_PG_GameState_Game.BP_PG_GameState_Game_C
// Size: 0x380 (Inherited: 0x378)
struct ABP_PG_GameState_Game_C : APG_GameState_Game {
	struct USceneComponent* DefaultSceneRoot; // 0x378(0x08)
};

