// WidgetBlueprintGeneratedClass UI_GameMenu_Map_SpawnSelect.UI_GameMenu_Map_SpawnSelect_C
// Size: 0x270 (Inherited: 0x260)
struct UUI_GameMenu_Map_SpawnSelect_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct FVector2D NewPosition; // 0x268(0x08)

	void SetNewPosition(struct FVector2D NewPosition); // Function UI_GameMenu_Map_SpawnSelect.UI_GameMenu_Map_SpawnSelect_C.SetNewPosition // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function UI_GameMenu_Map_SpawnSelect.UI_GameMenu_Map_SpawnSelect_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_GameMenu_Map_SpawnSelect(int32_t EntryPoint); // Function UI_GameMenu_Map_SpawnSelect.UI_GameMenu_Map_SpawnSelect_C.ExecuteUbergraph_UI_GameMenu_Map_SpawnSelect // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

