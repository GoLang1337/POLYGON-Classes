// WidgetBlueprintGeneratedClass UI_Shop_WeaponModules.UI_Shop_WeaponModules_C
// Size: 0x2b0 (Inherited: 0x260)
struct UUI_Shop_WeaponModules_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UHorizontalBox* HorizontalBox_Header; // 0x268(0x08)
	struct UUI_Button_C* UI_Button_Accessory; // 0x270(0x08)
	struct UUI_Button_C* UI_Button_Barrel; // 0x278(0x08)
	struct UUI_Button_C* UI_Button_Optic; // 0x280(0x08)
	struct UUI_Button_C* UI_Button_Skin; // 0x288(0x08)
	struct UUI_Button_C* UI_Button_Underbarrel; // 0x290(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_ModuleClass; // 0x298(0x08)
	struct UWrapBox* WrapBox_Optic; // 0x2a0(0x08)
	struct UWrapBox* WrapBox_Skin; // 0x2a8(0x08)

	void SetActivePage(int32_t Index, struct UUI_Button_C* Button); // Function UI_Shop_WeaponModules.UI_Shop_WeaponModules_C.SetActivePage // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void AddNewModuleItem(struct AItem_Module_General* ModuleID, struct UUI_ShopItem_C* CreatedItem); // Function UI_Shop_WeaponModules.UI_Shop_WeaponModules_C.AddNewModuleItem // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Shop_WeaponModules.UI_Shop_WeaponModules_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void IsHoveredDelegate_Event(struct UUI_ShopItem_C* Item, bool IsHovered); // Function UI_Shop_WeaponModules.UI_Shop_WeaponModules_C.IsHoveredDelegate_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Optic_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Shop_WeaponModules.UI_Shop_WeaponModules_C.BndEvt__UI_Button_Optic_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Paint_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Shop_WeaponModules.UI_Shop_WeaponModules_C.BndEvt__UI_Button_Paint_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Shop_WeaponModules(int32_t EntryPoint); // Function UI_Shop_WeaponModules.UI_Shop_WeaponModules_C.ExecuteUbergraph_UI_Shop_WeaponModules // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

