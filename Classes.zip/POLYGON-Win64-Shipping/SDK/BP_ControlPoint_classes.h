// BlueprintGeneratedClass BP_ControlPoint.BP_ControlPoint_C
// Size: 0x2a8 (Inherited: 0x290)
struct ABP_ControlPoint_C : AControlPoint {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UBillboardComponent* Billboard; // 0x298(0x08)
	struct UWidgetComponent* Widget; // 0x2a0(0x08)

	void SetVisibleFromDistance(); // Function BP_ControlPoint.BP_ControlPoint_C.SetVisibleFromDistance // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ReceiveBeginPlay(); // Function BP_ControlPoint.BP_ControlPoint_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void BndEvt__CaptureArea_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BP_ControlPoint.BP_ControlPoint_C.BndEvt__CaptureArea_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x1847880
	void BndEvt__CaptureArea_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_ControlPoint.BP_ControlPoint_C.BndEvt__CaptureArea_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_ControlPoint(int32_t EntryPoint); // Function BP_ControlPoint.BP_ControlPoint_C.ExecuteUbergraph_BP_ControlPoint // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

