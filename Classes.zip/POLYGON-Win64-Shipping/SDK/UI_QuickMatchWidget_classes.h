// WidgetBlueprintGeneratedClass UI_QuickMatchWidget.UI_QuickMatchWidget_C
// Size: 0x30c (Inherited: 0x260)
struct UUI_QuickMatchWidget_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Hovered; // 0x268(0x08)
	struct UBorder* Border; // 0x270(0x08)
	struct UBorder* Border_Create; // 0x278(0x08)
	struct UBorder* Border_Footer; // 0x280(0x08)
	struct UBorder* Border_Hovered; // 0x288(0x08)
	struct UBorder* Border_Play; // 0x290(0x08)
	struct UButton* Button; // 0x298(0x08)
	struct UButton* Button_Create; // 0x2a0(0x08)
	struct UButton* Button_Play; // 0x2a8(0x08)
	struct UImage* Image_MapPreview; // 0x2b0(0x08)
	struct UImage* Image_MatchmakingTimer; // 0x2b8(0x08)
	struct UTextBlock* TextBlock_Create; // 0x2c0(0x08)
	struct UTextBlock* TextBlock_MapName; // 0x2c8(0x08)
	struct UTextBlock* TextBlock_Play; // 0x2d0(0x08)
	struct UTextBlock* TextBlock_ServerSearchTime; // 0x2d8(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Play; // 0x2e0(0x08)
	struct FName MapID; // 0x2e8(0x08)
	struct FTimerHandle TimerGetMatchmakingTicket; // 0x2f0(0x08)
	struct FTimerHandle TimerSearchServer; // 0x2f8(0x08)
	struct FTimerHandle TimerCalculateServerSearchTime; // 0x300(0x08)
	int32_t SearchTime; // 0x308(0x04)

	void GetServerWithMinPing(struct TArray<struct UUI_ServerInfo_C*> ServersInfo, struct UUI_ServerInfo_C* ServerInfo); // Function UI_QuickMatchWidget.UI_QuickMatchWidget_C.GetServerWithMinPing // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_QuickMatchWidget.UI_QuickMatchWidget_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_QuickMatchWidget.UI_QuickMatchWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function UI_QuickMatchWidget.UI_QuickMatchWidget_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_QuickMatchWidget.UI_QuickMatchWidget_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Play_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function UI_QuickMatchWidget.UI_QuickMatchWidget_C.BndEvt__Button_Play_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Play_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function UI_QuickMatchWidget.UI_QuickMatchWidget_C.BndEvt__Button_Play_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Create_K2Node_ComponentBoundEvent_5_OnButtonHoverEvent__DelegateSignature(); // Function UI_QuickMatchWidget.UI_QuickMatchWidget_C.BndEvt__Button_Create_K2Node_ComponentBoundEvent_5_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Create_K2Node_ComponentBoundEvent_6_OnButtonHoverEvent__DelegateSignature(); // Function UI_QuickMatchWidget.UI_QuickMatchWidget_C.BndEvt__Button_Create_K2Node_ComponentBoundEvent_6_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Create_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature(); // Function UI_QuickMatchWidget.UI_QuickMatchWidget_C.BndEvt__Button_Create_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Play_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature(); // Function UI_QuickMatchWidget.UI_QuickMatchWidget_C.BndEvt__Button_Play_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_QuickMatchWidget(int32_t EntryPoint); // Function UI_QuickMatchWidget.UI_QuickMatchWidget_C.ExecuteUbergraph_UI_QuickMatchWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

