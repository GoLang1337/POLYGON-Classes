// WidgetBlueprintGeneratedClass DefaultBindCaptureButton.DefaultBindCaptureButton_C
// Size: 0x2a8 (Inherited: 0x290)
struct UDefaultBindCaptureButton_C : UBindCaptureButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UButton* Button_1; // 0x298(0x08)
	struct UNamedSlot* Content; // 0x2a0(0x08)

	void BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function DefaultBindCaptureButton.DefaultBindCaptureButton_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_DefaultBindCaptureButton(int32_t EntryPoint); // Function DefaultBindCaptureButton.DefaultBindCaptureButton_C.ExecuteUbergraph_DefaultBindCaptureButton // (Final|UbergraphFunction) // @ game+0x1847880
};

