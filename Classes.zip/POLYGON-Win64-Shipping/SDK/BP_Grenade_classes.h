// BlueprintGeneratedClass BP_Grenade.BP_Grenade_C
// Size: 0x2b8 (Inherited: 0x2b8)
struct ABP_Grenade_C : AItem_Weapon_Grenade {
};

