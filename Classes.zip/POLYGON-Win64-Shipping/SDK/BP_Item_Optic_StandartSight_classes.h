// BlueprintGeneratedClass BP_Item_Optic_StandartSight.BP_Item_Optic_StandartSight_C
// Size: 0x2a0 (Inherited: 0x2a0)
struct ABP_Item_Optic_StandartSight_C : AItem_Module_Optic {
};

