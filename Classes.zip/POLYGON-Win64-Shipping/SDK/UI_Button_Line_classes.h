// WidgetBlueprintGeneratedClass UI_Button_Line.UI_Button_Line_C
// Size: 0x310 (Inherited: 0x260)
struct UUI_Button_Line_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* CornerAnimation; // 0x268(0x08)
	struct UBorder* Border; // 0x270(0x08)
	struct UButton* Button; // 0x278(0x08)
	struct UImage* Image_Corner; // 0x280(0x08)
	struct UImage* Image_Selected; // 0x288(0x08)
	struct UImage* Image_Triangle; // 0x290(0x08)
	struct UTextBlock* TextBlock_Name; // 0x298(0x08)
	struct FText Name; // 0x2a0(0x18)
	struct FMulticastInlineDelegate OnPressed; // 0x2b8(0x10)
	int32_t FontSize; // 0x2c8(0x04)
	bool IsSelected; // 0x2cc(0x01)
	char pad_2CD[0x3]; // 0x2cd(0x03)
	struct FName GeneralColorID; // 0x2d0(0x08)
	struct FName SelectColorID; // 0x2d8(0x08)
	struct FName DisableColorID; // 0x2e0(0x08)
	struct FName HoveredColorID; // 0x2e8(0x08)
	struct FLinearColor SelectColor; // 0x2f0(0x10)
	struct FLinearColor DisableColor; // 0x300(0x10)

	void SetButtonColor(); // Function UI_Button_Line.UI_Button_Line_C.SetButtonColor // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetSelectButton(bool Selected); // Function UI_Button_Line.UI_Button_Line_C.SetSelectButton // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Button_Line.UI_Button_Line_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function UI_Button_Line.UI_Button_Line_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_Button_Line.UI_Button_Line_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature(); // Function UI_Button_Line.UI_Button_Line_C.BndEvt__Button_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void Pressed(); // Function UI_Button_Line.UI_Button_Line_C.Pressed // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Button_Line(int32_t EntryPoint); // Function UI_Button_Line.UI_Button_Line_C.ExecuteUbergraph_UI_Button_Line // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
	void OnPressed__DelegateSignature(struct UUI_Button_Line_C* Button); // Function UI_Button_Line.UI_Button_Line_C.OnPressed__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

