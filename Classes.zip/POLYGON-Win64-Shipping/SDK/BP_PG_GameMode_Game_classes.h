// BlueprintGeneratedClass BP_PG_GameMode_Game.BP_PG_GameMode_Game_C
// Size: 0x350 (Inherited: 0x348)
struct ABP_PG_GameMode_Game_C : APG_GameMode_Game {
	struct USceneComponent* DefaultSceneRoot; // 0x348(0x08)
};

