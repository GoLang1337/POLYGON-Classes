// WidgetBlueprintGeneratedClass UI_Map_TeamBaseMarker.UI_Map_TeamBaseMarker_C
// Size: 0x274 (Inherited: 0x260)
struct UUI_Map_TeamBaseMarker_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct ATeamBase* TeamBaseReference; // 0x268(0x08)
	float MapSize; // 0x270(0x04)

	void SetTeamName(); // Function UI_Map_TeamBaseMarker.UI_Map_TeamBaseMarker_C.SetTeamName // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void FindCoord(float Distance, float Degrees, struct FVector2D NewVector); // Function UI_Map_TeamBaseMarker.UI_Map_TeamBaseMarker_C.FindCoord // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void FindAngle(struct FVector2D A, float Degrees); // Function UI_Map_TeamBaseMarker.UI_Map_TeamBaseMarker_C.FindAngle // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void Construct(); // Function UI_Map_TeamBaseMarker.UI_Map_TeamBaseMarker_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void CalculatePosition(); // Function UI_Map_TeamBaseMarker.UI_Map_TeamBaseMarker_C.CalculatePosition // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Map_TeamBaseMarker(int32_t EntryPoint); // Function UI_Map_TeamBaseMarker.UI_Map_TeamBaseMarker_C.ExecuteUbergraph_UI_Map_TeamBaseMarker // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

