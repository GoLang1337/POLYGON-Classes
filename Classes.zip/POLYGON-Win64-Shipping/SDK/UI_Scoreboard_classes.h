// WidgetBlueprintGeneratedClass UI_Scoreboard.UI_Scoreboard_C
// Size: 0x2a8 (Inherited: 0x260)
struct UUI_Scoreboard_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* LinesBackground; // 0x268(0x08)
	struct UOverlay* Overlay_Main; // 0x270(0x08)
	struct UTextBlock* TextBlock_BlueScore; // 0x278(0x08)
	struct UTextBlock* TextBlock_RedScore; // 0x280(0x08)
	struct UVerticalBox* VerticalBox_BlueTeam; // 0x288(0x08)
	struct UVerticalBox* VerticalBox_RedTeam; // 0x290(0x08)
	struct FTimerHandle Timer_UpdatePlayersTab; // 0x298(0x08)
	struct UUI_Scoreboard_Player_Menu_C* UI_PlayerMenu; // 0x2a0(0x08)

	struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function UI_Scoreboard.UI_Scoreboard_C.OnKeyUp // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SortPlayers(struct UUI_Scoreboard_Player_C* Player, struct UGridPanel* Tab); // Function UI_Scoreboard.UI_Scoreboard_C.SortPlayers // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void AddPlayersToTab(enum class ETeam Team); // Function UI_Scoreboard.UI_Scoreboard_C.AddPlayersToTab // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Scoreboard.UI_Scoreboard_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Scoreboard.UI_Scoreboard_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void StartUpdatePlayersTab(); // Function UI_Scoreboard.UI_Scoreboard_C.StartUpdatePlayersTab // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void UpdatePlayeysTabEvent(); // Function UI_Scoreboard.UI_Scoreboard_C.UpdatePlayeysTabEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnChangeTotalScore_Event(); // Function UI_Scoreboard.UI_Scoreboard_C.OnChangeTotalScore_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnVisibilityChanged_Event(enum class ESlateVisibility InVisibility); // Function UI_Scoreboard.UI_Scoreboard_C.OnVisibilityChanged_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Scoreboard(int32_t EntryPoint); // Function UI_Scoreboard.UI_Scoreboard_C.ExecuteUbergraph_UI_Scoreboard // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

