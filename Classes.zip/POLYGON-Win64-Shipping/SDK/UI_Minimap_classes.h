// WidgetBlueprintGeneratedClass UI_Minimap.UI_Minimap_C
// Size: 0x340 (Inherited: 0x260)
struct UUI_Minimap_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border_Background_Blue; // 0x268(0x08)
	struct UBorder* Border_Background_Red; // 0x270(0x08)
	struct UHorizontalBox* HorizontalBox_AlphaMarker; // 0x278(0x08)
	struct UHorizontalBox* HorizontalBox_BravoMarker; // 0x280(0x08)
	struct UHorizontalBox* HorizontalBox_CharlieMarker; // 0x288(0x08)
	struct UHorizontalBox* HorizontalBox_ControlPoints; // 0x290(0x08)
	struct UHorizontalBox* HorizontalBox_DeltaMarker; // 0x298(0x08)
	struct UHorizontalBox* HorizontalBox_EchoMarker; // 0x2a0(0x08)
	struct UHorizontalBox* HorizontalBox_FoxtrotMarker; // 0x2a8(0x08)
	struct UImage* Lines; // 0x2b0(0x08)
	struct UImage* LinesRainbow; // 0x2b8(0x08)
	struct UProgressBar* ProgressBar_CaptureProcessBlueTeam; // 0x2c0(0x08)
	struct UProgressBar* ProgressBar_CaptureProcessRedTeam; // 0x2c8(0x08)
	struct USizeBox* SizeBox_Map; // 0x2d0(0x08)
	struct UTextBlock* TextBlock_CapturePointsBlueTeam; // 0x2d8(0x08)
	struct UTextBlock* TextBlock_CapturePointsRedTeam; // 0x2e0(0x08)
	struct UTextBlock* TextBlock_GameTimer; // 0x2e8(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_A; // 0x2f0(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_B; // 0x2f8(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_C; // 0x300(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_D; // 0x308(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_E; // 0x310(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_F; // 0x318(0x08)
	struct UUI_Map_C* UI_Map; // 0x320(0x08)
	struct ABP_PG_GameState_Game_C* GameState; // 0x328(0x08)
	struct UObject* PlayerController; // 0x330(0x08)
	struct UObject* PlayerState; // 0x338(0x08)

	void GetControlPointMarkerFromType(enum class EControlPoint ControlPointType, struct UHorizontalBox* Marker); // Function UI_Minimap.UI_Minimap_C.GetControlPointMarkerFromType // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void Construct(); // Function UI_Minimap.UI_Minimap_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Minimap.UI_Minimap_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnGameTimer_Event(); // Function UI_Minimap.UI_Minimap_C.OnGameTimer_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnSetTeam_Event(); // Function UI_Minimap.UI_Minimap_C.OnSetTeam_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnChangeTotalScore_Event(); // Function UI_Minimap.UI_Minimap_C.OnChangeTotalScore_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Minimap(int32_t EntryPoint); // Function UI_Minimap.UI_Minimap_C.ExecuteUbergraph_UI_Minimap // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

