// BlueprintGeneratedClass CameraShake_RifleShot.CameraShake_RifleShot_C
// Size: 0x180 (Inherited: 0x180)
struct UCameraShake_RifleShot_C : UMatineeCameraShake {
};

