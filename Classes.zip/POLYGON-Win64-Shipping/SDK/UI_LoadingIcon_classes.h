// WidgetBlueprintGeneratedClass UI_LoadingIcon.UI_LoadingIcon_C
// Size: 0x270 (Inherited: 0x260)
struct UUI_LoadingIcon_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Animation; // 0x268(0x08)

	void Construct(); // Function UI_LoadingIcon.UI_LoadingIcon_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_LoadingIcon(int32_t EntryPoint); // Function UI_LoadingIcon.UI_LoadingIcon_C.ExecuteUbergraph_UI_LoadingIcon // (Final|UbergraphFunction) // @ game+0x1847880
};

