// WidgetBlueprintGeneratedClass DefaultKeyLabel.DefaultKeyLabel_C
// Size: 0x2e0 (Inherited: 0x2c8)
struct UDefaultKeyLabel_C : UKeyLabel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)
	struct UImage* IconImage; // 0x2d0(0x08)
	struct UTextBlock* LabelText; // 0x2d8(0x08)

	void UpdateKeyLabel(); // Function DefaultKeyLabel.DefaultKeyLabel_C.UpdateKeyLabel // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_DefaultKeyLabel(int32_t EntryPoint); // Function DefaultKeyLabel.DefaultKeyLabel_C.ExecuteUbergraph_DefaultKeyLabel // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

