// Class UWorks.UWorks
// Size: 0x28 (Inherited: 0x28)
struct UUWorks : UObject {
};

// Class UWorks.UWorksInterface
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterface : UUWorks {
};

// Class UWorks.UWorksRequest
// Size: 0x28 (Inherited: 0x28)
struct UUWorksRequest : UUWorks {
};

