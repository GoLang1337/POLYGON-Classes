// WidgetBlueprintGeneratedClass UI_Solder_Customization_Slot.UI_Solder_Customization_Slot_C
// Size: 0x338 (Inherited: 0x260)
struct UUI_Solder_Customization_Slot_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Hover; // 0x268(0x08)
	struct UBorder* Border; // 0x270(0x08)
	struct UButton* Button; // 0x278(0x08)
	struct UButton* Button_CustomizationSlot; // 0x280(0x08)
	struct UHorizontalBox* HorizontalBox_Condition; // 0x288(0x08)
	struct UImage* Image_Corner; // 0x290(0x08)
	struct UImage* Image_ItemIcon; // 0x298(0x08)
	struct UOverlay* Overlay_Loading; // 0x2a0(0x08)
	struct UProgressBar* ProgressBar_Condition; // 0x2a8(0x08)
	struct USizeBox* SizeBox; // 0x2b0(0x08)
	struct UTextBlock* TextBlock_Condition; // 0x2b8(0x08)
	struct UTextBlock* TextBlock_ItemName; // 0x2c0(0x08)
	struct UTextBlock* TextBlock_ItemType; // 0x2c8(0x08)
	struct UUI_LoadingIcon_C* UI_LoadingIcon; // 0x2d0(0x08)
	struct AItem_General* ItemClass; // 0x2d8(0x08)
	struct FText ItemClass_Name; // 0x2e0(0x18)
	bool IsSelected; // 0x2f8(0x01)
	char pad_2F9[0x7]; // 0x2f9(0x07)
	struct FMulticastInlineDelegate SelectDelegate; // 0x300(0x10)
	bool IsCustomizable; // 0x310(0x01)
	bool HasCondition; // 0x311(0x01)
	char pad_312[0x6]; // 0x312(0x06)
	struct UPlayFabJsonObject* ItemJson; // 0x318(0x08)
	struct FMulticastInlineDelegate HoveredDelegate; // 0x320(0x10)
	struct UUI_Solder_Customization_C* UI_Customization; // 0x330(0x08)

	void SetSlotInfo(struct AItem_General* ItemClass, struct UPlayFabJsonObject* ItemJson); // Function UI_Solder_Customization_Slot.UI_Solder_Customization_Slot_C.SetSlotInfo // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetIsSelected(bool IsSelected); // Function UI_Solder_Customization_Slot.UI_Solder_Customization_Slot_C.SetIsSelected // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Solder_Customization_Slot.UI_Solder_Customization_Slot_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function UI_Solder_Customization_Slot.UI_Solder_Customization_Slot_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_Solder_Customization_Slot.UI_Solder_Customization_Slot_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonPressedEvent__DelegateSignature(); // Function UI_Solder_Customization_Slot.UI_Solder_Customization_Slot_C.BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_WeaponCustomization_K2Node_ComponentBoundEvent_4_OnButtonClickedEvent__DelegateSignature(); // Function UI_Solder_Customization_Slot.UI_Solder_Customization_Slot_C.BndEvt__Button_WeaponCustomization_K2Node_ComponentBoundEvent_4_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Solder_Customization_Slot.UI_Solder_Customization_Slot_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Solder_Customization_Slot(int32_t EntryPoint); // Function UI_Solder_Customization_Slot.UI_Solder_Customization_Slot_C.ExecuteUbergraph_UI_Solder_Customization_Slot // (Final|UbergraphFunction) // @ game+0x1847880
	void HoveredDelegate__DelegateSignature(struct UUI_Solder_Customization_Slot_C* Slot, bool IsHover); // Function UI_Solder_Customization_Slot.UI_Solder_Customization_Slot_C.HoveredDelegate__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SelectDelegate__DelegateSignature(struct UUI_Solder_Customization_Slot_C* Slot); // Function UI_Solder_Customization_Slot.UI_Solder_Customization_Slot_C.SelectDelegate__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

