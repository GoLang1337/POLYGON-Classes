// BlueprintGeneratedClass BP_Item_Optic_HolographicSight_01.BP_Item_Optic_HolographicSight_01_C
// Size: 0x2a0 (Inherited: 0x2a0)
struct ABP_Item_Optic_HolographicSight_01_C : AItem_Module_Optic {
};

