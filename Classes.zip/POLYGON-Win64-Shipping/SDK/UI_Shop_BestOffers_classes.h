// WidgetBlueprintGeneratedClass UI_Shop_BestOffers.UI_Shop_BestOffers_C
// Size: 0x2d0 (Inherited: 0x260)
struct UUI_Shop_BestOffers_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* CrownsHovered; // 0x268(0x08)
	struct UWidgetAnimation* VIPHovered; // 0x270(0x08)
	struct UWidgetAnimation* BattlePassHovered; // 0x278(0x08)
	struct UBorder* Border_BattlePass_Border; // 0x280(0x08)
	struct UBorder* Border_Crowns_Border; // 0x288(0x08)
	struct UBorder* Border_VIP_Border; // 0x290(0x08)
	struct UBorder* Border_VIP_Lines_01; // 0x298(0x08)
	struct UBorder* Border_VIP_Lines_02; // 0x2a0(0x08)
	struct UButton* Button_BattlePass; // 0x2a8(0x08)
	struct UButton* Button_Crowns; // 0x2b0(0x08)
	struct UButton* Button_VIP; // 0x2b8(0x08)
	struct UImage* Image_BattlePass_Background; // 0x2c0(0x08)
	struct UUI_Shop_C* UI_Shop; // 0x2c8(0x08)

	void Construct(); // Function UI_Shop_BestOffers.UI_Shop_BestOffers_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BestOffers_Button_BattlePass_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function UI_Shop_BestOffers.UI_Shop_BestOffers_C.BndEvt__UI_Shop_BestOffers_Button_BattlePass_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BestOffers_Button_BattlePass_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_Shop_BestOffers.UI_Shop_BestOffers_C.BndEvt__UI_Shop_BestOffers_Button_BattlePass_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BestOffers_Button_BattlePass_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function UI_Shop_BestOffers.UI_Shop_BestOffers_C.BndEvt__UI_Shop_BestOffers_Button_BattlePass_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BestOffers_Button_VIP_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function UI_Shop_BestOffers.UI_Shop_BestOffers_C.BndEvt__UI_Shop_BestOffers_Button_VIP_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BestOffers_Button_VIP_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function UI_Shop_BestOffers.UI_Shop_BestOffers_C.BndEvt__UI_Shop_BestOffers_Button_VIP_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BestOffers_Button_VIP_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature(); // Function UI_Shop_BestOffers.UI_Shop_BestOffers_C.BndEvt__UI_Shop_BestOffers_Button_VIP_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BestOffers_Button_Crowns_K2Node_ComponentBoundEvent_6_OnButtonHoverEvent__DelegateSignature(); // Function UI_Shop_BestOffers.UI_Shop_BestOffers_C.BndEvt__UI_Shop_BestOffers_Button_Crowns_K2Node_ComponentBoundEvent_6_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BestOffers_Button_Crowns_K2Node_ComponentBoundEvent_7_OnButtonHoverEvent__DelegateSignature(); // Function UI_Shop_BestOffers.UI_Shop_BestOffers_C.BndEvt__UI_Shop_BestOffers_Button_Crowns_K2Node_ComponentBoundEvent_7_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BestOffers_Button_Crowns_K2Node_ComponentBoundEvent_8_OnButtonClickedEvent__DelegateSignature(); // Function UI_Shop_BestOffers.UI_Shop_BestOffers_C.BndEvt__UI_Shop_BestOffers_Button_Crowns_K2Node_ComponentBoundEvent_8_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Shop_BestOffers(int32_t EntryPoint); // Function UI_Shop_BestOffers.UI_Shop_BestOffers_C.ExecuteUbergraph_UI_Shop_BestOffers // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

