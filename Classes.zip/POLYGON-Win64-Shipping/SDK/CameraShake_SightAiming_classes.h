// BlueprintGeneratedClass CameraShake_SightAiming.CameraShake_SightAiming_C
// Size: 0x180 (Inherited: 0x180)
struct UCameraShake_SightAiming_C : UMatineeCameraShake {
};

