// BlueprintGeneratedClass BP_PG_Character_Red.BP_PG_Character_Red_C
// Size: 0x638 (Inherited: 0x630)
struct ABP_PG_Character_Red_C : ABP_PG_Character_General_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x630(0x08)

	void ReceiveBeginPlay(); // Function BP_PG_Character_Red.BP_PG_Character_Red_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void OnSetTeam_Event(); // Function BP_PG_Character_Red.BP_PG_Character_Red_C.OnSetTeam_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnSetPlayerState_Event(); // Function BP_PG_Character_Red.BP_PG_Character_Red_C.OnSetPlayerState_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_PG_Character_Red(int32_t EntryPoint); // Function BP_PG_Character_Red.BP_PG_Character_Red_C.ExecuteUbergraph_BP_PG_Character_Red // (Final|UbergraphFunction) // @ game+0x1847880
};

