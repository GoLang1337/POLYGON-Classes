// BlueprintGeneratedClass BP_PG_PlayerState_Game.BP_PG_PlayerState_Game_C
// Size: 0x3b0 (Inherited: 0x3a8)
struct ABP_PG_PlayerState_Game_C : APG_PlayerState_Game {
	struct USceneComponent* DefaultSceneRoot; // 0x3a8(0x08)
};

