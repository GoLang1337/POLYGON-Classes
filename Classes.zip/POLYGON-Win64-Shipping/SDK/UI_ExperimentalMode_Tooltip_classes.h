// WidgetBlueprintGeneratedClass UI_ExperimentalMode_Tooltip.UI_ExperimentalMode_Tooltip_C
// Size: 0x260 (Inherited: 0x260)
struct UUI_ExperimentalMode_Tooltip_C : UUserWidget {
};

