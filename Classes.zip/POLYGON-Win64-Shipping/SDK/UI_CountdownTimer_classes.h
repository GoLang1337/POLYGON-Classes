// WidgetBlueprintGeneratedClass UI_CountdownTimer.UI_CountdownTimer_C
// Size: 0x280 (Inherited: 0x260)
struct UUI_CountdownTimer_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UTextBlock* TextBlock_TextInfo; // 0x268(0x08)
	struct UTextBlock* TextBlock_Timer; // 0x270(0x08)
	struct ABP_PG_GameState_Game_C* GameState; // 0x278(0x08)

	void Construct(); // Function UI_CountdownTimer.UI_CountdownTimer_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnChangeGameState_Event(); // Function UI_CountdownTimer.UI_CountdownTimer_C.OnChangeGameState_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnGameTimer_Event(); // Function UI_CountdownTimer.UI_CountdownTimer_C.OnGameTimer_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_CountdownTimer(int32_t EntryPoint); // Function UI_CountdownTimer.UI_CountdownTimer_C.ExecuteUbergraph_UI_CountdownTimer // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

