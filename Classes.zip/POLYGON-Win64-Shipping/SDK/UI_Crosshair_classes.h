// WidgetBlueprintGeneratedClass UI_Crosshair.UI_Crosshair_C
// Size: 0x2c0 (Inherited: 0x260)
struct UUI_Crosshair_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* HeadshotAnimation; // 0x268(0x08)
	struct UWidgetAnimation* KillAnimation; // 0x270(0x08)
	struct UWidgetAnimation* HitAnimation; // 0x278(0x08)
	struct UBorder* Border_OnApplyDamage; // 0x280(0x08)
	struct UCanvasPanel* CanvasPanel_Main; // 0x288(0x08)
	struct UOverlay* Overlay_Bottom; // 0x290(0x08)
	struct UOverlay* Overlay_Center; // 0x298(0x08)
	struct UOverlay* Overlay_Left; // 0x2a0(0x08)
	struct UOverlay* Overlay_Right; // 0x2a8(0x08)
	struct UOverlay* Overlay_Top; // 0x2b0(0x08)
	struct APG_Character* Character; // 0x2b8(0x08)

	void SetCrosshairPosition(struct FVector2D InPosition); // Function UI_Crosshair.UI_Crosshair_C.SetCrosshairPosition // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Crosshair.UI_Crosshair_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function UI_Crosshair.UI_Crosshair_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnSetPawn_Event(); // Function UI_Crosshair.UI_Crosshair_C.OnSetPawn_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnSetCurrentWeapon_Event(); // Function UI_Crosshair.UI_Crosshair_C.OnSetCurrentWeapon_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnApplyWeaponDamage_Event(bool bHeadshot); // Function UI_Crosshair.UI_Crosshair_C.OnApplyWeaponDamage_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Crosshair(int32_t EntryPoint); // Function UI_Crosshair.UI_Crosshair_C.ExecuteUbergraph_UI_Crosshair // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

