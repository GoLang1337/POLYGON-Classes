// WidgetBlueprintGeneratedClass UI_ConfirmPurchases.UI_ConfirmPurchases_C
// Size: 0x2bc (Inherited: 0x260)
struct UUI_ConfirmPurchases_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button_No; // 0x268(0x08)
	struct UButton* Button_Yes; // 0x270(0x08)
	struct UTextBlock* TextBlock_ItemName; // 0x278(0x08)
	struct FText DisplayName; // 0x280(0x18)
	struct FString Catalog; // 0x298(0x10)
	struct FString ItemId; // 0x2a8(0x10)
	int32_t Price; // 0x2b8(0x04)

	void OnPlayFabResponse_162DFB834B563E89615F53A447FEB99E(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_ConfirmPurchases.UI_ConfirmPurchases_C.OnPlayFabResponse_162DFB834B563E89615F53A447FEB99E // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PurchaseItem_Success(struct FClientPurchaseItemResult Result, struct UObject* customData); // Function UI_ConfirmPurchases.UI_ConfirmPurchases_C.PurchaseItem_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PurchaseItem_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_ConfirmPurchases.UI_ConfirmPurchases_C.PurchaseItem_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Yes_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_ConfirmPurchases.UI_ConfirmPurchases_C.BndEvt__Button_Yes_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_No_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function UI_ConfirmPurchases.UI_ConfirmPurchases_C.BndEvt__Button_No_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_ConfirmPurchases.UI_ConfirmPurchases_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_ConfirmPurchases(int32_t EntryPoint); // Function UI_ConfirmPurchases.UI_ConfirmPurchases_C.ExecuteUbergraph_UI_ConfirmPurchases // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

