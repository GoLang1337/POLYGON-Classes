// WidgetBlueprintGeneratedClass UI_HomeScreen_BattlePass.UI_HomeScreen_BattlePass_C
// Size: 0x2a0 (Inherited: 0x260)
struct UUI_HomeScreen_BattlePass_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* NewRewardsAvailable; // 0x268(0x08)
	struct UWidgetAnimation* Hovered; // 0x270(0x08)
	struct UButton* Button_BattlePass; // 0x278(0x08)
	struct UOverlay* Overlay_NewRewardsAvailable; // 0x280(0x08)
	struct UProgressBar* ProgressBar_BattlePass; // 0x288(0x08)
	struct UTextBlock* TextBlock_BattlePassLevel; // 0x290(0x08)
	struct ABP_PG_PlayerController_Menu_C* PlayerController; // 0x298(0x08)

	void BndEvt__UI_HomeScreen_Button_BattlePass_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function UI_HomeScreen_BattlePass.UI_HomeScreen_BattlePass_C.BndEvt__UI_HomeScreen_Button_BattlePass_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_HomeScreen_Button_BattlePass_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_HomeScreen_BattlePass.UI_HomeScreen_BattlePass_C.BndEvt__UI_HomeScreen_Button_BattlePass_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_HomeScreen_Button_BattlePass_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature(); // Function UI_HomeScreen_BattlePass.UI_HomeScreen_BattlePass_C.BndEvt__UI_HomeScreen_Button_BattlePass_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_HomeScreen_BattlePass(int32_t EntryPoint); // Function UI_HomeScreen_BattlePass.UI_HomeScreen_BattlePass_C.ExecuteUbergraph_UI_HomeScreen_BattlePass // (Final|UbergraphFunction) // @ game+0x1847880
};

