// BlueprintGeneratedClass BP_Item_Pistol_Anaconda.BP_Item_Pistol_Anaconda_C
// Size: 0x418 (Inherited: 0x418)
struct ABP_Item_Pistol_Anaconda_C : AItem_Weapon_Pistol {
};

