// WidgetBlueprintGeneratedClass UI_Options.UI_Options_C
// Size: 0x570 (Inherited: 0x260)
struct UUI_Options_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UComboBoxString* ComboBoxString_Language; // 0x268(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping; // 0x270(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_2; // 0x278(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_3; // 0x280(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_4; // 0x288(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_5; // 0x290(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_6; // 0x298(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_7; // 0x2a0(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_8; // 0x2a8(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_9; // 0x2b0(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_10; // 0x2b8(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_11; // 0x2c0(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_12; // 0x2c8(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_13; // 0x2d0(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_14; // 0x2d8(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_15; // 0x2e0(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_16; // 0x2e8(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_17; // 0x2f0(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_18; // 0x2f8(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_19; // 0x300(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_20; // 0x308(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_21; // 0x310(0x08)
	struct UDefaultActionMapping_C* DefaultActionMapping_22; // 0x318(0x08)
	struct UDefaultAxisMapping_C* DefaultAxisMapping; // 0x320(0x08)
	struct UDefaultAxisMapping_C* DefaultAxisMapping_2; // 0x328(0x08)
	struct UDefaultAxisMapping_C* DefaultAxisMapping_3; // 0x330(0x08)
	struct UDefaultAxisMapping_C* DefaultAxisMapping_4; // 0x338(0x08)
	struct UDefaultCheckBoxSetting_C* DefaultCheckBoxSetting_VolumetricFog; // 0x340(0x08)
	struct UDefaultComboBoxSetting_C* DefaultComboBoxSetting_AntiAliasingMethod; // 0x348(0x08)
	struct UDefaultComboBoxSetting_C* DefaultComboBoxSetting_Resolution; // 0x350(0x08)
	struct UDefaultComboBoxSetting_C* DefaultComboBoxSetting_ScreenMode; // 0x358(0x08)
	struct UImage* Image_182; // 0x360(0x08)
	struct UTextBlock* TextBlock_EffectsVolume; // 0x368(0x08)
	struct UTextBlock* TextBlock_FOV; // 0x370(0x08)
	struct UTextBlock* TextBlock_MasterVolume; // 0x378(0x08)
	struct UTextBlock* TextBlock_MouseSensitivity; // 0x380(0x08)
	struct UTextBlock* TextBlock_MouseSensitivityScoped; // 0x388(0x08)
	struct UTextBlock* TextBlock_MusicVolume; // 0x390(0x08)
	struct UTextBlock* TextBlock_ResolutionScale; // 0x398(0x08)
	struct UUI_Button_C* UI_Button_Apply; // 0x3a0(0x08)
	struct UUI_Button_C* UI_Button_Audio; // 0x3a8(0x08)
	struct UUI_Button_C* UI_Button_Back; // 0x3b0(0x08)
	struct UUI_Button_C* UI_Button_Controls; // 0x3b8(0x08)
	struct UUI_Button_C* UI_Button_Custom; // 0x3c0(0x08)
	struct UUI_Button_C* UI_Button_High; // 0x3c8(0x08)
	struct UUI_Button_C* UI_Button_Low; // 0x3d0(0x08)
	struct UUI_Button_C* UI_Button_Medium; // 0x3d8(0x08)
	struct UUI_Button_C* UI_Button_Reset; // 0x3e0(0x08)
	struct UUI_Button_C* UI_Button_Ultra; // 0x3e8(0x08)
	struct UUI_Button_C* UI_Button_Video; // 0x3f0(0x08)
	struct UUI_Options_Spinner_C* UI_Options_AntialiasingQuality; // 0x3f8(0x08)
	struct UUI_Options_Spinner_C* UI_Options_EffectsQuality; // 0x400(0x08)
	struct UUI_Options_Slider_C* UI_Options_EffectsVolume; // 0x408(0x08)
	struct UUI_Options_Slider_C* UI_Options_FOV; // 0x410(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow; // 0x418(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_2; // 0x420(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_3; // 0x428(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_4; // 0x430(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_5; // 0x438(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_6; // 0x440(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_7; // 0x448(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_8; // 0x450(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_9; // 0x458(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_10; // 0x460(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_11; // 0x468(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_12; // 0x470(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_13; // 0x478(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_14; // 0x480(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_15; // 0x488(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_16; // 0x490(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_17; // 0x498(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_18; // 0x4a0(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_19; // 0x4a8(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_20; // 0x4b0(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_21; // 0x4b8(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_22; // 0x4c0(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_23; // 0x4c8(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_24; // 0x4d0(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_25; // 0x4d8(0x08)
	struct UUI_Options_InputRow_C* UI_Options_InputRow_26; // 0x4e0(0x08)
	struct UUI_Options_Slider_C* UI_Options_MasterVolume; // 0x4e8(0x08)
	struct UUI_Options_Slider_C* UI_Options_MusicVolume; // 0x4f0(0x08)
	struct UUI_Options_Spinner_C* UI_Options_PostProcessQuality; // 0x4f8(0x08)
	struct UUI_Options_Slider_C* UI_Options_ResolutionScale; // 0x500(0x08)
	struct UUI_Options_Spinner_C* UI_Options_ShadersQuality; // 0x508(0x08)
	struct UUI_Options_Spinner_C* UI_Options_ShadowQuality; // 0x510(0x08)
	struct UUI_Options_Slider_C* UI_Options_Slider_MouseSensitivity; // 0x518(0x08)
	struct UUI_Options_Slider_C* UI_Options_Slider_MouseSensitivity_Scoped; // 0x520(0x08)
	struct UUI_Options_Spinner_C* UI_Options_TerrainQuality; // 0x528(0x08)
	struct UUI_Options_Spinner_C* UI_Options_TextureQuality; // 0x530(0x08)
	struct UUI_Options_Spinner_C* UI_Options_VerticalSync; // 0x538(0x08)
	struct UUI_Options_Spinner_C* UI_Options_ViewDistance; // 0x540(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Main; // 0x548(0x08)
	int32_t GeneralGraphicsQuality; // 0x550(0x04)
	char pad_554[0x4]; // 0x554(0x04)
	struct APG_PlayerController_Base* PlayerController; // 0x558(0x08)
	struct FMulticastInlineDelegate ClickBackDelegate; // 0x560(0x10)

	void SetCurrentLanguageOption(); // Function UI_Options.UI_Options_C.SetCurrentLanguageOption // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SelectLanguage(struct FString Selection); // Function UI_Options.UI_Options_C.SelectLanguage // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetActiveOptionsMenu(int32_t Index); // Function UI_Options.UI_Options_C.SetActiveOptionsMenu // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetGraphicsQuality(int32_t GeneralGraphicsQuality); // Function UI_Options.UI_Options_C.SetGraphicsQuality // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Options.UI_Options_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Back_K2Node_ComponentBoundEvent_3_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Options.UI_Options_C.BndEvt__UI_Button_Back_K2Node_ComponentBoundEvent_3_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void VerticalSyncEvent(int32_t NewValue); // Function UI_Options.UI_Options_C.VerticalSyncEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ApplyChanges(); // Function UI_Options.UI_Options_C.ApplyChanges // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Apply_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Options.UI_Options_C.BndEvt__UI_Button_Apply_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Low_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Options.UI_Options_C.BndEvt__UI_Button_Low_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Medium_K2Node_ComponentBoundEvent_0_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Options.UI_Options_C.BndEvt__UI_Button_Medium_K2Node_ComponentBoundEvent_0_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_HIGH_K2Node_ComponentBoundEvent_4_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Options.UI_Options_C.BndEvt__UI_Button_HIGH_K2Node_ComponentBoundEvent_4_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Ultra_K2Node_ComponentBoundEvent_5_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Options.UI_Options_C.BndEvt__UI_Button_Ultra_K2Node_ComponentBoundEvent_5_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void OnChangedValue_Event(struct FString Value); // Function UI_Options.UI_Options_C.OnChangedValue_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Audio_K2Node_ComponentBoundEvent_8_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Options.UI_Options_C.BndEvt__UI_Button_Audio_K2Node_ComponentBoundEvent_8_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Video_K2Node_ComponentBoundEvent_9_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Options.UI_Options_C.BndEvt__UI_Button_Video_K2Node_ComponentBoundEvent_9_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Controls_K2Node_ComponentBoundEvent_10_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Options.UI_Options_C.BndEvt__UI_Button_Controls_K2Node_ComponentBoundEvent_10_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ChangeMasterVolume(float NewValue); // Function UI_Options.UI_Options_C.ChangeMasterVolume // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ChangeMusicVolume(float NewValue); // Function UI_Options.UI_Options_C.ChangeMusicVolume // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ChangeEffectsVolume(float NewValue); // Function UI_Options.UI_Options_C.ChangeEffectsVolume // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Options_MasterVolume_K2Node_ComponentBoundEvent_7_OnValueChanged__DelegateSignature(float Value); // Function UI_Options.UI_Options_C.BndEvt__UI_Options_MasterVolume_K2Node_ComponentBoundEvent_7_OnValueChanged__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Options_EffectsVolume_K2Node_ComponentBoundEvent_13_OnValueChanged__DelegateSignature(float Value); // Function UI_Options.UI_Options_C.BndEvt__UI_Options_EffectsVolume_K2Node_ComponentBoundEvent_13_OnValueChanged__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Options_MusicVolume_K2Node_ComponentBoundEvent_14_OnValueChanged__DelegateSignature(float Value); // Function UI_Options.UI_Options_C.BndEvt__UI_Options_MusicVolume_K2Node_ComponentBoundEvent_14_OnValueChanged__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ChangeGeneralQuality(int32_t NewValue); // Function UI_Options.UI_Options_C.ChangeGeneralQuality // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ChangeMouseSensitivity(float NewValue); // Function UI_Options.UI_Options_C.ChangeMouseSensitivity // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Options_Slider_K2Node_ComponentBoundEvent_15_OnValueChanged__DelegateSignature(float Value); // Function UI_Options.UI_Options_C.BndEvt__UI_Options_Slider_K2Node_ComponentBoundEvent_15_OnValueChanged__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ChangeInvertMouse(int32_t NewValue); // Function UI_Options.UI_Options_C.ChangeInvertMouse // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__ComboBoxString_255_K2Node_ComponentBoundEvent_11_OnSelectionChangedEvent__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType); // Function UI_Options.UI_Options_C.BndEvt__ComboBoxString_255_K2Node_ComponentBoundEvent_11_OnSelectionChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ChangeInputVolumetricFog(int32_t NewValue); // Function UI_Options.UI_Options_C.ChangeInputVolumetricFog // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ChangeFOVEvent(float NewValue); // Function UI_Options.UI_Options_C.ChangeFOVEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Options_FOV_K2Node_ComponentBoundEvent_16_OnValueChanged__DelegateSignature(float Value); // Function UI_Options.UI_Options_C.BndEvt__UI_Options_FOV_K2Node_ComponentBoundEvent_16_OnValueChanged__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Options_UI_Button_Reset_K2Node_ComponentBoundEvent_17_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Options.UI_Options_C.BndEvt__UI_Options_UI_Button_Reset_K2Node_ComponentBoundEvent_17_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ChangeResolutionQuality(int32_t NewValue); // Function UI_Options.UI_Options_C.ChangeResolutionQuality // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ChangeMouseSensitivityScoped(float NewValue); // Function UI_Options.UI_Options_C.ChangeMouseSensitivityScoped // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Options_UI_Options_Slider_MouseSensitivity_Scoped_K2Node_ComponentBoundEvent_6_OnValueChanged__DelegateSignature(float Value); // Function UI_Options.UI_Options_C.BndEvt__UI_Options_UI_Options_Slider_MouseSensitivity_Scoped_K2Node_ComponentBoundEvent_6_OnValueChanged__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Options(int32_t EntryPoint); // Function UI_Options.UI_Options_C.ExecuteUbergraph_UI_Options // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
	void ClickBackDelegate__DelegateSignature(); // Function UI_Options.UI_Options_C.ClickBackDelegate__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

