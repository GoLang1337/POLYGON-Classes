// WidgetBlueprintGeneratedClass DefaultAxisLabel.DefaultAxisLabel_C
// Size: 0x2a8 (Inherited: 0x2a8)
struct UDefaultAxisLabel_C : UAxisLabel {
};

