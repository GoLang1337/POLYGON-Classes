// Enum UWorksCore.EUWorksResult
enum class EUWorksResult : uint8 {
	Unknown = 0,
	OK = 1,
	Fail = 2,
	NoConnection = 3,
	InvalidPassword = 5,
	LoggedInElsewhere = 6,
	InvalidProtocolVer = 7,
	InvalidParam = 8,
	FileNotFound = 9,
	Busy = 10,
	InvalidState = 11,
	InvalidName = 12,
	InvalidEmail = 13,
	DuplicateName = 14,
	AccessDenied = 15,
	Timeout = 16,
	Banned = 17,
	AccountNotFound = 18,
	InvalidSteamID = 19,
	ServiceUnavailable = 20,
	NotLoggedOn = 21,
	Pending = 22,
	EncryptionFailure = 23,
	InsufficientPrivilege = 24,
	LimitExceeded = 25,
	Revoked = 26,
	Expired = 27,
	AlreadyRedeemed = 28,
	DuplicateRequest = 29,
	AlreadyOwned = 30,
	IPNotFound = 31,
	PersistFailed = 32,
	LockingFailed = 33,
	LogonSessionReplaced = 34,
	ConnectFailed = 35,
	HandshakeFailed = 36,
	IOFailure = 37,
	RemoteDisconnect = 38,
	ShoppingCartNotFound = 39,
	Blocked = 40,
	Ignored = 41,
	NoMatch = 42,
	AccountDisabled = 43,
	ServiceReadOnly = 44,
	AccountNotFeatured = 45,
	AdministratorOK = 46,
	ContentVersion = 47,
	TryAnotherCM = 48,
	PasswordRequiredToKickSession = 49,
	AlreadyLoggedInElsewhere = 50,
	Suspended = 51,
	Cancelled = 52,
	DataCorruption = 53,
	DiskFull = 54,
	RemoteCallFailed = 55,
	PasswordUnset = 56,
	ExternalAccountUnlinked = 57,
	PSNTicketInvalid = 58,
	ExternalAccountAlreadyLinked = 59,
	RemoteFileConflict = 60,
	IllegalPassword = 61,
	SameAsPreviousValue = 62,
	AccountLogonDenied = 63,
	CannotUseOldPassword = 64,
	InvalidLoginAuthCode = 65,
	AccountLogonDeniedNoMail = 66,
	HardwareNotCapableOfIPT = 67,
	IPTInitError = 68,
	ParentalControlRestricted = 69,
	FacebookQueryError = 70,
	ExpiredLoginAuthCode = 71,
	IPLoginRestrictionFailed = 72,
	AccountLockedDown = 73,
	AccountLogonDeniedVerifiedEmailRequired = 74,
	NoMatchingURL = 75,
	BadResponse = 76,
	RequirePasswordReEntry = 77,
	ValueOutOfRange = 78,
	UnexpectedError = 79,
	Disabled = 80,
	InvalidCEGSubmission = 81,
	RestrictedDevice = 82,
	RegionLocked = 83,
	RateLimitExceeded = 84,
	AccountLoginDeniedNeedTwoFactor = 85,
	ItemDeleted = 86,
	AccountLoginDeniedThrottle = 87,
	TwoFactorCodeMismatch = 88,
	TwoFactorActivationCodeMismatch = 89,
	AccountAssociatedToMultiplePartners = 90,
	NotModified = 91,
	NoMobileDevice = 92,
	TimeNotSynced = 93,
	SmsCodeFailed = 94,
	AccountLimitExceeded = 95,
	AccountActivityLimitExceeded = 96,
	PhoneActivityLimitExceeded = 97,
	RefundToWallet = 98,
	EmailSendFailure = 99,
	NotSettled = 100,
	NeedCaptcha = 101,
	GSLTDenied = 102,
	GSOwnerDenied = 103,
	InvalidItemType = 104,
	IPBanned = 105,
	GSLTExpired = 106,
	EUWorksResult_MAX = 107
};

// Enum UWorksCore.EUWorksChatRoomEnterResponse
enum class EUWorksChatRoomEnterResponse : uint8 {
	Unknown = 0,
	Success = 1,
	DoesntExist = 2,
	NotAllowed = 3,
	Full = 4,
	Error = 5,
	Banned = 6,
	Limited = 7,
	ClanDisabled = 8,
	CommunityBan = 9,
	MemberBlockedYou = 10,
	YouBlockedMember = 11,
	EUWorksChatRoomEnterResponse_MAX = 12
};

// Enum UWorksCore.EUWorksPersonaChange
enum class EUWorksPersonaChange : uint8 {
	Name = 0,
	Status = 1,
	ComeOnline = 2,
	GoneOffline = 3,
	GamePlayed = 4,
	GameServer = 5,
	Avatar = 6,
	JoinedSource = 7,
	LeftSource = 8,
	RelationshipChanged = 9,
	NameFirstSet = 10,
	FacebookInfo = 11,
	Nickname = 12,
	SteamLevel = 13,
	EUWorksPersonaChange_MAX = 14
};

// Enum UWorksCore.EUWorksAuthSessionResponse
enum class EUWorksAuthSessionResponse : uint8 {
	OK = 0,
	UserNotConnectedToSteam = 1,
	NoLicenseOrExpired = 2,
	VACBanned = 3,
	LoggedInElseWhere = 4,
	VACCheckTimedOut = 5,
	AuthTicketCanceled = 6,
	AuthTicketInvalidAlreadyUsed = 7,
	AuthTicketInvalid = 8,
	PublisherIssuedBan = 9,
	EUWorksAuthSessionResponse_MAX = 10
};

// Enum UWorksCore.EUWorksFavoriteFlags
enum class EUWorksFavoriteFlags : uint8 {
	Unknown = 0,
	Favorite = 1,
	History = 2,
	EUWorksFavoriteFlags_MAX = 3
};

// Enum UWorksCore.EUWorksChatMemberStateChange
enum class EUWorksChatMemberStateChange : uint8 {
	Entered = 0,
	Left = 1,
	Disconnected = 2,
	Kicked = 3,
	Banned = 4,
	EUWorksChatMemberStateChange_MAX = 5
};

// Enum UWorksCore.EUWorksChatEntryType
enum class EUWorksChatEntryType : uint8 {
	Invalid = 0,
	ChatMessage = 1,
	Typing = 2,
	InviteGame = 3,
	Emote = 4,
	LeftConversation = 6,
	Entered = 7,
	WasKicked = 8,
	WasBanned = 9,
	Disconnected = 10,
	HistoricalChat = 11,
	LinkBlocked = 14,
	EUWorksChatEntryType_MAX = 15
};

// Enum UWorksCore.EUWorksP2PSessionError
enum class EUWorksP2PSessionError : uint8 {
	None = 0,
	NotRunningApp = 1,
	NoRightsToApp = 2,
	DestinationNotLoggedIn = 3,
	Timeout = 4,
	Max = 5
};

// Enum UWorksCore.EUWorksDenyReason
enum class EUWorksDenyReason : uint8 {
	Invalid = 0,
	InvalidVersion = 1,
	Generic = 2,
	NotLoggedOn = 3,
	NoLicense = 4,
	Cheater = 5,
	LoggedInElseWhere = 6,
	UnknownText = 7,
	IncompatibleAnticheat = 8,
	MemoryCorruption = 9,
	IncompatibleSoftware = 10,
	SteamConnectionLost = 11,
	SteamConnectionError = 12,
	SteamResponseTimedOut = 13,
	SteamValidationStalled = 14,
	SteamOwnerLeftGuestUser = 15,
	EUWorksDenyReason_MAX = 16
};

// Enum UWorksCore.EUWorksFailureType
enum class EUWorksFailureType : uint8 {
	FlushedCallbackQueue = 0,
	PipeFail = 1,
	EUWorksFailureType_MAX = 2
};

// Enum UWorksCore.EUWorksSteamControllerPad
enum class EUWorksSteamControllerPad : uint8 {
	Left = 0,
	Right = 1,
	EUWorksSteamControllerPad_MAX = 2
};

// Enum UWorksCore.EUWorksSteamControllerLEDFlag
enum class EUWorksSteamControllerLEDFlag : uint8 {
	SetColor = 0,
	RestoreUserDefault = 1,
	EUWorksSteamControllerLEDFlag_MAX = 2
};

// Enum UWorksCore.EUWorksControllerSourceMode
enum class EUWorksControllerSourceMode : uint8 {
	None = 0,
	Dpad = 1,
	Buttons = 2,
	FourButtons = 3,
	AbsoluteMouse = 4,
	RelativeMouse = 5,
	JoystickMove = 6,
	JoystickMouse = 7,
	JoystickCamera = 8,
	ScrollWheel = 9,
	Trigger = 10,
	TouchMenu = 11,
	MouseJoystick = 12,
	MouseRegion = 13,
	RadialMenu = 14,
	Switches = 15,
	EUWorksControllerSourceMode_MAX = 16
};

// Enum UWorksCore.EUWorksControllerSource
enum class EUWorksControllerSource : uint8 {
	None = 0,
	LeftTrackpad = 1,
	RightTrackpad = 2,
	Joystick = 3,
	ABXY = 4,
	Switch = 5,
	LeftTrigger = 6,
	RightTrigger = 7,
	Gyro = 8,
	CenterTrackpad = 9,
	RightJoystick = 10,
	DPad = 11,
	Count = 12,
	EUWorksControllerSource_MAX = 13
};

// Enum UWorksCore.EUWorksControllerActionOrigin
enum class EUWorksControllerActionOrigin : uint8 {
	None = 0,
	A = 1,
	B = 2,
	X = 3,
	Y = 4,
	LeftBumper = 5,
	RightBumper = 6,
	LeftGrip = 7,
	RightGrip = 8,
	Start = 9,
	Back = 10,
	LeftPad_Touch = 11,
	LeftPad_Swipe = 12,
	LeftPad_Click = 13,
	LeftPad_DPadNorth = 14,
	LeftPad_DPadSouth = 15,
	LeftPad_DPadWest = 16,
	LeftPad_DPadEast = 17,
	RightPad_Touch = 18,
	RightPad_Swipe = 19,
	RightPad_Click = 20,
	RightPad_DPadNorth = 21,
	RightPad_DPadSouth = 22,
	RightPad_DPadWest = 23,
	RightPad_DPadEast = 24,
	LeftTrigger_Pull = 25,
	LeftTrigger_Click = 26,
	RightTrigger_Pull = 27,
	RightTrigger_Click = 28,
	LeftStick_Move = 29,
	LeftStick_Click = 30,
	LeftStick_DPadNorth = 31,
	LeftStick_DPadSouth = 32,
	LeftStick_DPadWest = 33,
	LeftStick_DPadEast = 34,
	Gyro_Move = 35,
	Gyro_Pitch = 36,
	Gyro_Yaw = 37,
	Gyro_Roll = 38,
	PS4_X = 39,
	PS4_Circle = 40,
	PS4_Triangle = 41,
	PS4_Square = 42,
	PS4_LeftBumper = 43,
	PS4_RightBumper = 44,
	PS4_Options = 45,
	PS4_Share = 46,
	PS4_LeftPad_Touch = 47,
	PS4_LeftPad_Swipe = 48,
	PS4_LeftPad_Click = 49,
	PS4_LeftPad_DPadNorth = 50,
	PS4_LeftPad_DPadSouth = 51,
	PS4_LeftPad_DPadWest = 52,
	PS4_LeftPad_DPadEast = 53,
	PS4_RightPad_Touch = 54,
	PS4_RightPad_Swipe = 55,
	PS4_RightPad_Click = 56,
	PS4_RightPad_DPadNorth = 57,
	PS4_RightPad_DPadSouth = 58,
	PS4_RightPad_DPadWest = 59,
	PS4_RightPad_DPadEast = 60,
	PS4_CenterPad_Touch = 61,
	PS4_CenterPad_Swipe = 62,
	PS4_CenterPad_Click = 63,
	PS4_CenterPad_DPadNorth = 64,
	PS4_CenterPad_DPadSouth = 65,
	PS4_CenterPad_DPadWest = 66,
	PS4_CenterPad_DPadEast = 67,
	PS4_LeftTrigger_Pull = 68,
	PS4_LeftTrigger_Click = 69,
	PS4_RightTrigger_Pull = 70,
	PS4_RightTrigger_Click = 71,
	PS4_LeftStick_Move = 72,
	PS4_LeftStick_Click = 73,
	PS4_LeftStick_DPadNorth = 74,
	PS4_LeftStick_DPadSouth = 75,
	PS4_LeftStick_DPadWest = 76,
	PS4_LeftStick_DPadEast = 77,
	PS4_RightStick_Move = 78,
	PS4_RightStick_Click = 79,
	PS4_RightStick_DPadNorth = 80,
	PS4_RightStick_DPadSouth = 81,
	PS4_RightStick_DPadWest = 82,
	PS4_RightStick_DPadEast = 83,
	PS4_DPad_North = 84,
	PS4_DPad_South = 85,
	PS4_DPad_West = 86,
	PS4_DPad_East = 87,
	PS4_Gyro_Move = 88,
	PS4_Gyro_Pitch = 89,
	PS4_Gyro_Yaw = 90,
	PS4_Gyro_Roll = 91,
	XBoxOne_A = 92,
	XBoxOne_B = 93,
	XBoxOne_X = 94,
	XBoxOne_Y = 95,
	XBoxOne_LeftBumper = 96,
	XBoxOne_RightBumper = 97,
	XBoxOne_Menu = 98,
	XBoxOne_View = 99,
	XBoxOne_LeftTrigger_Pull = 100,
	XBoxOne_LeftTrigger_Click = 101,
	XBoxOne_RightTrigger_Pull = 102,
	XBoxOne_RightTrigger_Click = 103,
	XBoxOne_LeftStick_Move = 104,
	XBoxOne_LeftStick_Click = 105,
	XBoxOne_LeftStick_DPadNorth = 106,
	XBoxOne_LeftStick_DPadSouth = 107,
	XBoxOne_LeftStick_DPadWest = 108,
	XBoxOne_LeftStick_DPadEast = 109,
	XBoxOne_RightStick_Move = 110,
	XBoxOne_RightStick_Click = 111,
	XBoxOne_RightStick_DPadNorth = 112,
	XBoxOne_RightStick_DPadSouth = 113,
	XBoxOne_RightStick_DPadWest = 114,
	XBoxOne_RightStick_DPadEast = 115,
	XBoxOne_DPad_North = 116,
	XBoxOne_DPad_South = 117,
	XBoxOne_DPad_West = 118,
	XBoxOne_DPad_East = 119,
	XBox360_A = 120,
	XBox360_B = 121,
	XBox360_X = 122,
	XBox360_Y = 123,
	XBox360_LeftBumper = 124,
	XBox360_RightBumper = 125,
	XBox360_Start = 126,
	XBox360_Back = 127,
	XBox360_LeftTrigger_Pull = 128,
	XBox360_LeftTrigger_Click = 129,
	XBox360_RightTrigger_Pull = 130,
	XBox360_RightTrigger_Click = 131,
	XBox360_LeftStick_Move = 132,
	XBox360_LeftStick_Click = 133,
	XBox360_LeftStick_DPadNorth = 134,
	XBox360_LeftStick_DPadSouth = 135,
	XBox360_LeftStick_DPadWest = 136,
	XBox360_LeftStick_DPadEast = 137,
	XBox360_RightStick_Move = 138,
	XBox360_RightStick_Click = 139,
	XBox360_RightStick_DPadNorth = 140,
	XBox360_RightStick_DPadSouth = 141,
	XBox360_RightStick_DPadWest = 142,
	XBox360_RightStick_DPadEast = 143,
	XBox360_DPad_North = 144,
	XBox360_DPad_South = 145,
	XBox360_DPad_West = 146,
	XBox360_DPad_East = 147,
	SteamV2_A = 148,
	SteamV2_B = 149,
	SteamV2_X = 150,
	SteamV2_Y = 151,
	SteamV2_LeftBumper = 152,
	SteamV2_RightBumper = 153,
	SteamV2_LeftGrip = 154,
	SteamV2_RightGrip = 155,
	SteamV2_Start = 156,
	SteamV2_Back = 157,
	SteamV2_LeftPad_Touch = 158,
	SteamV2_LeftPad_Swipe = 159,
	SteamV2_LeftPad_Click = 160,
	SteamV2_LeftPad_DPadNorth = 161,
	SteamV2_LeftPad_DPadSouth = 162,
	SteamV2_LeftPad_DPadWest = 163,
	SteamV2_LeftPad_DPadEast = 164,
	SteamV2_RightPad_Touch = 165,
	SteamV2_RightPad_Swipe = 166,
	SteamV2_RightPad_Click = 167,
	SteamV2_RightPad_DPadNorth = 168,
	SteamV2_RightPad_DPadSouth = 169,
	SteamV2_RightPad_DPadWest = 170,
	SteamV2_RightPad_DPadEast = 171,
	SteamV2_LeftTrigger_Pull = 172,
	SteamV2_LeftTrigger_Click = 173,
	SteamV2_RightTrigger_Pull = 174,
	SteamV2_RightTrigger_Click = 175,
	SteamV2_LeftStick_Move = 176,
	SteamV2_LeftStick_Click = 177,
	SteamV2_LeftStick_DPadNorth = 178,
	SteamV2_LeftStick_DPadSouth = 179,
	SteamV2_LeftStick_DPadWest = 180,
	SteamV2_LeftStick_DPadEast = 181,
	SteamV2_Gyro_Move = 182,
	SteamV2_Gyro_Pitch = 183,
	SteamV2_Gyro_Yaw = 184,
	SteamV2_Gyro_Roll = 185,
	Count = 186,
	EUWorksControllerActionOrigin_MAX = 187
};

// Enum UWorksCore.EUWorksUserRestriction
enum class EUWorksUserRestriction : uint8 {
	Unknown = 0,
	AnyChat = 1,
	VoiceChat = 2,
	GroupChat = 3,
	Rating = 4,
	GameInvites = 5,
	Trading = 6,
	EUWorksUserRestriction_MAX = 7
};

// Enum UWorksCore.EUWorksOverlaySpecific
enum class EUWorksOverlaySpecific : uint8 {
	SteamID = 0,
	Chat = 1,
	JoinTrade = 2,
	Stats = 3,
	Achievements = 4,
	FriendAdd = 5,
	FriendRemove = 6,
	FriendRequestAccept = 7,
	FriendRequestIgnore = 8,
	EUWorksOverlaySpecific_MAX = 9
};

// Enum UWorksCore.EUWorksOverlayGeneric
enum class EUWorksOverlayGeneric : uint8 {
	Friends = 0,
	Community = 1,
	Players = 2,
	Settings = 3,
	OfficialGameGroup = 4,
	Stats = 5,
	Achievements = 6,
	EUWorksOverlayGeneric_MAX = 7
};

// Enum UWorksCore.EUWorksPersonaState
enum class EUWorksPersonaState : uint8 {
	Offline = 0,
	Online = 1,
	Busy = 2,
	Away = 3,
	Snooze = 4,
	LookingToTrade = 5,
	LookingToPlay = 6,
	Max = 7
};

// Enum UWorksCore.EUWorksOverlayToStoreFlag
enum class EUWorksOverlayToStoreFlag : uint8 {
	None = 0,
	AddToCart = 1,
	AddToCartAndShow = 2,
	EUWorksOverlayToStoreFlag_MAX = 3
};

// Enum UWorksCore.EUWorksFriendRelationship
enum class EUWorksFriendRelationship : uint8 {
	None = 0,
	Blocked = 1,
	RequestRecipient = 2,
	Friend = 3,
	RequestInitiator = 4,
	Ignored = 5,
	IgnoredFriend = 6,
	Max = 8
};

// Enum UWorksCore.EUWorksFriendFlags
enum class EUWorksFriendFlags : uint8 {
	Blocked = 0,
	FriendshipRequested = 1,
	Immediate = 2,
	ClanMember = 3,
	OnGameServer = 4,
	HasPlayedWith = 5,
	FriendOfFriend = 6,
	RequestingFriendship = 7,
	RequestingInfo = 8,
	Ignored = 9,
	IgnoredFriend = 10,
	Suggested = 11,
	ChatMember = 12,
	All = 13,
	EUWorksFriendFlags_MAX = 14
};

// Enum UWorksCore.EUWorksSteamItemFlags
enum class EUWorksSteamItemFlags : uint8 {
	NoTrade = 0,
	Removed = 8,
	Consumed = 9,
	EUWorksSteamItemFlags_MAX = 10
};

// Enum UWorksCore.EUWorksLobbyType
enum class EUWorksLobbyType : uint8 {
	Private = 0,
	FriendsOnly = 1,
	Public = 2,
	Invisible = 3,
	EUWorksLobbyType_MAX = 4
};

// Enum UWorksCore.EUWorksLobbyDistanceFilter
enum class EUWorksLobbyDistanceFilter : uint8 {
	Close = 0,
	Default = 1,
	Far = 2,
	Worldwide = 3,
	EUWorksLobbyDistanceFilter_MAX = 4
};

// Enum UWorksCore.EUWorksLobbyComparison
enum class EUWorksLobbyComparison : uint8 {
	EqualToOrLessThan = 0,
	LessThan = 1,
	Equal = 2,
	GreaterThan = 3,
	EqualToOrGreaterThan = 4,
	NotEqual = 5,
	EUWorksLobbyComparison_MAX = 6
};

// Enum UWorksCore.EUWorksServerQueryType
enum class EUWorksServerQueryType : uint8 {
	Internet = 0,
	LAN = 1,
	Friends = 2,
	Favorites = 3,
	History = 4,
	Spectator = 5,
	EUWorksServerQueryType_MAX = 6
};

// Enum UWorksCore.EUWorksAudioPlaybackStatus
enum class EUWorksAudioPlaybackStatus : uint8 {
	Undefined = 0,
	Playing = 1,
	Paused = 2,
	Idle = 3,
	EUWorksAudioPlaybackStatus_MAX = 4
};

// Enum UWorksCore.EUWorksP2PSend
enum class EUWorksP2PSend : uint8 {
	Unreliable = 0,
	UnreliableNoDelay = 1,
	Reliable = 2,
	ReliableWithBuffering = 3,
	EUWorksP2PSend_MAX = 4
};

// Enum UWorksCore.EUWorksRemoteStoragePlatform
enum class EUWorksRemoteStoragePlatform : uint8 {
	Windows = 0,
	OSX = 1,
	PS3 = 2,
	Linux = 3,
	Reserved = 4,
	All = 5,
	EUWorksRemoteStoragePlatform_MAX = 6
};

// Enum UWorksCore.EUWorksVRScreenshotType
enum class EUWorksVRScreenshotType : uint8 {
	None = 0,
	Mono = 1,
	Stereo = 2,
	MonoCubemap = 3,
	MonoPanorama = 4,
	StereoPanorama = 5,
	EUWorksVRScreenshotType_MAX = 6
};

// Enum UWorksCore.EUWorksWorkshopFileType
enum class EUWorksWorkshopFileType : uint8 {
	Community = 0,
	Microtransaction = 1,
	Collection = 2,
	Art = 3,
	Video = 4,
	Screenshot = 5,
	Game = 6,
	Software = 7,
	Concept = 8,
	WebGuide = 9,
	IntegratedGuide = 10,
	Merch = 11,
	ControllerBinding = 12,
	SteamworksAccessInvite = 13,
	SteamVideo = 14,
	GameManagedItem = 15,
	Max = 16
};

// Enum UWorksCore.EUWorksRemoteStoragePublishedFileVisibility
enum class EUWorksRemoteStoragePublishedFileVisibility : uint8 {
	Public = 0,
	FriendsOnly = 1,
	Private = 2,
	EUWorksRemoteStoragePublishedFileVisibility_MAX = 3
};

// Enum UWorksCore.EUWorksUserUGCListSortOrder
enum class EUWorksUserUGCListSortOrder : uint8 {
	CreationOrderDesc = 0,
	CreationOrderAsc = 1,
	TitleAsc = 2,
	LastUpdatedDesc = 3,
	SubscriptionDateDesc = 4,
	VoteScoreDesc = 5,
	ForModeration = 6,
	EUWorksUserUGCListSortOrder_MAX = 7
};

// Enum UWorksCore.EUWorksUserUGCList
enum class EUWorksUserUGCList : uint8 {
	Published = 0,
	VotedOn = 1,
	VotedUp = 2,
	VotedDown = 3,
	WillVoteLater = 4,
	Favorited = 5,
	Subscribed = 6,
	UsedOrPlayed = 7,
	Followed = 8,
	EUWorksUserUGCList_MAX = 9
};

// Enum UWorksCore.EUWorksUGCQuery
enum class EUWorksUGCQuery : uint8 {
	RankedByVote = 0,
	RankedByPublicationDate = 1,
	AcceptedForGameRankedByAcceptanceDate = 2,
	RankedByTrend = 3,
	FavoritedByFriendsRankedByPublicationDate = 4,
	CreatedByFriendsRankedByPublicationDate = 5,
	RankedByNumTimesReported = 6,
	CreatedByFollowedUsersRankedByPublicationDate = 7,
	NotYetRated = 8,
	RankedByTotalVotesAsc = 9,
	RankedByVotesUp = 10,
	RankedByTextSearch = 11,
	RankedByTotalUniqueSubscriptions = 12,
	RankedByPlaytimeTrend = 13,
	RankedByTotalPlaytime = 14,
	RankedByAveragePlaytimeTrend = 15,
	RankedByLifetimeAveragePlaytime = 16,
	RankedByPlaytimeSessionsTrend = 17,
	RankedByLifetimePlaytimeSessions = 18,
	EUWorksUGCQuery_MAX = 19
};

// Enum UWorksCore.EUWorksUGCMatchingUGCType
enum class EUWorksUGCMatchingUGCType : uint8 {
	Items = 0,
	Items_Mtx = 1,
	Items_ReadyToUse = 2,
	Collections = 3,
	Artwork = 4,
	Videos = 5,
	Screenshots = 6,
	AllGuides = 7,
	WebGuides = 8,
	IntegratedGuides = 9,
	UsableInGame = 10,
	ControllerBindings = 11,
	GameManagedItems = 12,
	All = 254,
	EUWorksUGCMatchingUGCType_MAX = 255
};

// Enum UWorksCore.EUWorksItemUpdateStatus
enum class EUWorksItemUpdateStatus : uint8 {
	Invalid = 0,
	PreparingConfig = 1,
	PreparingContent = 2,
	UploadingContent = 3,
	UploadingPreviewFile = 4,
	CommittingChanges = 5,
	EUWorksItemUpdateStatus_MAX = 6
};

// Enum UWorksCore.EUWorksItemStatistic
enum class EUWorksItemStatistic : uint8 {
	NumSubscriptions = 0,
	NumFavorites = 1,
	NumFollowers = 2,
	NumUniqueSubscriptions = 3,
	NumUniqueFavorites = 4,
	NumUniqueFollowers = 5,
	NumUniqueWebsiteViews = 6,
	ReportScore = 7,
	NumSecondsPlayed = 8,
	NumPlaytimeSessions = 9,
	NumComments = 10,
	EUWorksItemStatistic_MAX = 11
};

// Enum UWorksCore.EUWorksItemState
enum class EUWorksItemState : uint8 {
	None = 0,
	Subscribed = 1,
	LegacyItem = 2,
	Installed = 3,
	NeedsUpdate = 4,
	Downloading = 5,
	DownloadPending = 6,
	EUWorksItemState_MAX = 7
};

// Enum UWorksCore.EUWorksItemPreviewType
enum class EUWorksItemPreviewType : uint8 {
	Image = 0,
	YouTubeVideo = 1,
	Sketchfab = 2,
	EnvironmentMap_HorizontalCross = 3,
	EnvironmentMap_LatLong = 4,
	ReservedMax = 254,
	EUWorksItemPreviewType_MAX = 255
};

// Enum UWorksCore.EUWorksVoiceResult
enum class EUWorksVoiceResult : uint8 {
	OK = 0,
	NotInitialized = 1,
	NotRecording = 2,
	NoData = 3,
	BufferTooSmall = 4,
	DataCorrupted = 5,
	Restricted = 6,
	UnsupportedCodec = 7,
	ReceiverOutOfDate = 8,
	ReceiverDidNotAnswer = 9,
	EUWorksVoiceResult_MAX = 10
};

// Enum UWorksCore.EUWorksLeaderboardUploadScoreMethod
enum class EUWorksLeaderboardUploadScoreMethod : uint8 {
	None = 0,
	KeepBest = 1,
	ForceUpdate = 2,
	EUWorksLeaderboardUploadScoreMethod_MAX = 3
};

// Enum UWorksCore.EUWorksLeaderboardSortMethod
enum class EUWorksLeaderboardSortMethod : uint8 {
	None = 0,
	Ascending = 1,
	Descending = 2,
	EUWorksLeaderboardSortMethod_MAX = 3
};

// Enum UWorksCore.EUWorksLeaderboardDisplayType
enum class EUWorksLeaderboardDisplayType : uint8 {
	None = 0,
	Numeric = 1,
	TimeSeconds = 2,
	TimeMilliSeconds = 3,
	EUWorksLeaderboardDisplayType_MAX = 4
};

// Enum UWorksCore.EUWorksLeaderboardDataRequest
enum class EUWorksLeaderboardDataRequest : uint8 {
	Global = 0,
	GlobalAroundUser = 1,
	Friends = 2,
	Users = 3,
	EUWorksLeaderboardDataRequest_MAX = 4
};

// Enum UWorksCore.EUWorksNotificationPosition
enum class EUWorksNotificationPosition : uint8 {
	TopLeft = 0,
	TopRight = 1,
	BottomLeft = 2,
	BottomRight = 3,
	EUWorksNotificationPosition_MAX = 4
};

// Enum UWorksCore.EUWorksUniverse
enum class EUWorksUniverse : uint8 {
	Invalid = 0,
	Public = 1,
	Beta = 2,
	Internal = 3,
	Dev = 4,
	Max = 5
};

// Enum UWorksCore.EUWorksGamepadTextInputMode
enum class EUWorksGamepadTextInputMode : uint8 {
	Normal = 0,
	Password = 1,
	EUWorksGamepadTextInputMode_MAX = 2
};

// Enum UWorksCore.EUWorksGamepadTextInputLineMode
enum class EUWorksGamepadTextInputLineMode : uint8 {
	SingleLine = 0,
	MultipleLines = 1,
	EUWorksGamepadTextInputLineMode_MAX = 2
};

// Enum UWorksCore.EUWorksCheckFileSignature
enum class EUWorksCheckFileSignature : uint8 {
	InvalidSignature = 0,
	ValidSignature = 1,
	FileNotFound = 2,
	NoSignaturesFoundForThisApp = 3,
	NoSignaturesFoundForThisFile = 4,
	EUWorksCheckFileSignature_MAX = 5
};

// Enum UWorksCore.EUWorksUserHasLicenseForAppResult
enum class EUWorksUserHasLicenseForAppResult : uint8 {
	HasLicense = 0,
	DoesNotHaveLicense = 1,
	NoAuth = 2,
	EUWorksUserHasLicenseForAppResult_MAX = 3
};

// Enum UWorksCore.EUWorksBeginAuthSessionResult
enum class EUWorksBeginAuthSessionResult : uint8 {
	OK = 0,
	InvalidTicket = 1,
	DuplicateRequest = 2,
	InvalidVersion = 3,
	GameMismatch = 4,
	ExpiredTicket = 5,
	EUWorksBeginAuthSessionResult_MAX = 6
};

// Enum UWorksCore.EUWorksAccountType
enum class EUWorksAccountType : uint8 {
	Invalid = 0,
	Individual = 1,
	Multiseat = 2,
	GameServer = 3,
	AnonGameServer = 4,
	Pending = 5,
	ContentServer = 6,
	Clan = 7,
	Chat = 8,
	ConsoleUser = 9,
	AnonUser = 10,
	Max = 11
};

// ScriptStruct UWorksCore.UWorksSteamInventoryResult
// Size: 0x04 (Inherited: 0x00)
struct FUWorksSteamInventoryResult {
	char pad_0[0x4]; // 0x00(0x04)
};

// ScriptStruct UWorksCore.UWorksServerInfo
// Size: 0x98 (Inherited: 0x00)
struct FUWorksServerInfo {
	struct FString Name; // 0x00(0x10)
	struct FString IP; // 0x10(0x10)
	int32_t QueryPort; // 0x20(0x04)
	int32_t ConnectionPort; // 0x24(0x04)
	int32_t Ping; // 0x28(0x04)
	bool bHadSuccessfulResponse; // 0x2c(0x01)
	bool bDoNotRefresh; // 0x2d(0x01)
	char pad_2E[0x2]; // 0x2e(0x02)
	struct FString GameDir; // 0x30(0x10)
	struct FString Map; // 0x40(0x10)
	struct FString GameDescription; // 0x50(0x10)
	int32_t AppID; // 0x60(0x04)
	int32_t Players; // 0x64(0x04)
	int32_t MaxPlayers; // 0x68(0x04)
	int32_t BotPlayers; // 0x6c(0x04)
	bool bPassword; // 0x70(0x01)
	bool BSecure; // 0x71(0x01)
	char pad_72[0x2]; // 0x72(0x02)
	int32_t TimeLastPlayed; // 0x74(0x04)
	int32_t ServerVersion; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct FString GameTags; // 0x80(0x10)
	struct FUWorksSteamID SteamID; // 0x90(0x08)
};

// ScriptStruct UWorksCore.UWorksPlayerInfo
// Size: 0x18 (Inherited: 0x00)
struct FUWorksPlayerInfo {
	struct FString Name; // 0x00(0x10)
	int32_t Score; // 0x10(0x04)
	float TimePlayed; // 0x14(0x04)
};

// ScriptStruct UWorksCore.UWorksRuleInfo
// Size: 0x20 (Inherited: 0x00)
struct FUWorksRuleInfo {
	struct FString Name; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

// ScriptStruct UWorksCore.UWorksScreenshotHandle
// Size: 0x04 (Inherited: 0x00)
struct FUWorksScreenshotHandle {
	char pad_0[0x4]; // 0x00(0x04)
};

// ScriptStruct UWorksCore.UWorksUGCQueryHandle
// Size: 0x08 (Inherited: 0x00)
struct FUWorksUGCQueryHandle {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorksCore.UWorksTicketHandle
// Size: 0x04 (Inherited: 0x00)
struct FUWorksTicketHandle {
	char pad_0[0x4]; // 0x00(0x04)
};

// ScriptStruct UWorksCore.UWorksSteamLeaderboard
// Size: 0x08 (Inherited: 0x00)
struct FUWorksSteamLeaderboard {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorksCore.UWorksSteamLeaderboardEntries
// Size: 0x08 (Inherited: 0x00)
struct FUWorksSteamLeaderboardEntries {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreAppList
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreAppList {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreApps
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreApps {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksControllerHandle
// Size: 0x08 (Inherited: 0x00)
struct FUWorksControllerHandle {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorksCore.UWorksControllerDigitalActionHandle
// Size: 0x08 (Inherited: 0x00)
struct FUWorksControllerDigitalActionHandle {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorksCore.UWorksControllerAnalogActionHandle
// Size: 0x08 (Inherited: 0x00)
struct FUWorksControllerAnalogActionHandle {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorksCore.UWorksControllerActionSetHandle
// Size: 0x08 (Inherited: 0x00)
struct FUWorksControllerActionSetHandle {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorksCore.UWorksControllerMotionData
// Size: 0x28 (Inherited: 0x00)
struct FUWorksControllerMotionData {
	float RotQuatX; // 0x00(0x04)
	float RotQuatY; // 0x04(0x04)
	float RotQuatZ; // 0x08(0x04)
	float RotQuatW; // 0x0c(0x04)
	float PosAccelX; // 0x10(0x04)
	float PosAccelY; // 0x14(0x04)
	float PosAccelZ; // 0x18(0x04)
	float RotVelX; // 0x1c(0x04)
	float RotVelY; // 0x20(0x04)
	float RotVelZ; // 0x24(0x04)
};

// ScriptStruct UWorksCore.UWorksControllerDigitalActionData
// Size: 0x02 (Inherited: 0x00)
struct FUWorksControllerDigitalActionData {
	bool bState; // 0x00(0x01)
	bool bActive; // 0x01(0x01)
};

// ScriptStruct UWorksCore.UWorksControllerAnalogActionData
// Size: 0x10 (Inherited: 0x00)
struct FUWorksControllerAnalogActionData {
	enum class EUWorksControllerSourceMode Mode; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float X; // 0x04(0x04)
	float Y; // 0x08(0x04)
	bool bActive; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreController
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreController {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksFriendsGroupID
// Size: 0x02 (Inherited: 0x00)
struct FUWorksFriendsGroupID {
	char pad_0[0x2]; // 0x00(0x02)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreFriends
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreFriends {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreGameServer
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreGameServer {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreGameServerStats
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreGameServerStats {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksSteamItemDetails
// Size: 0x20 (Inherited: 0x00)
struct FUWorksSteamItemDetails {
	struct FUWorksSteamItemInstanceID InstanceID; // 0x00(0x08)
	struct FUWorksSteamItemDef Definition; // 0x08(0x04)
	int32_t Quantity; // 0x0c(0x04)
	struct TArray<enum class EUWorksSteamItemFlags> Flags; // 0x10(0x10)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreInventory
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreInventory {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreMatchmaking
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreMatchmaking {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreMatchmakingServers
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreMatchmakingServers {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreMusic
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreMusic {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksP2PSessionState
// Size: 0x0c (Inherited: 0x00)
struct FUWorksP2PSessionState {
	bool bConnectionActive; // 0x00(0x01)
	bool bConnecting; // 0x01(0x01)
	enum class EUWorksP2PSessionError P2PSessionError; // 0x02(0x01)
	bool bUsingRelay; // 0x03(0x01)
	int32_t BytesQueuedForSend; // 0x04(0x04)
	int32_t PacketsQueuedForSend; // 0x08(0x04)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreNetworking
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreNetworking {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksUGCFileWriteStreamHandle
// Size: 0x08 (Inherited: 0x00)
struct FUWorksUGCFileWriteStreamHandle {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreRemoteStorage
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreRemoteStorage {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreScreenshots
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreScreenshots {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksSteamUGCDetails
// Size: 0xa8 (Inherited: 0x00)
struct FUWorksSteamUGCDetails {
	struct FUWorksPublishedFileID PublishedFileID; // 0x00(0x08)
	enum class EUWorksResult Result; // 0x08(0x01)
	enum class EUWorksWorkshopFileType FileType; // 0x09(0x01)
	char pad_A[0x2]; // 0x0a(0x02)
	int32_t CreatorAppID; // 0x0c(0x04)
	int32_t ConsumerAppID; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString Title; // 0x18(0x10)
	struct FString Description; // 0x28(0x10)
	struct FUWorksSteamID SteamIDOwner; // 0x38(0x08)
	int32_t TimeCreated; // 0x40(0x04)
	int32_t TimeUpdated; // 0x44(0x04)
	int32_t TimeAddedToUserList; // 0x48(0x04)
	enum class EUWorksRemoteStoragePublishedFileVisibility Visibility; // 0x4c(0x01)
	bool bBanned; // 0x4d(0x01)
	bool bAcceptedForUse; // 0x4e(0x01)
	bool bTagsTruncated; // 0x4f(0x01)
	struct TArray<struct FString> Tags; // 0x50(0x10)
	struct FUWorksUGCHandle File; // 0x60(0x08)
	struct FUWorksUGCHandle PreviewFile; // 0x68(0x08)
	struct FString Filename; // 0x70(0x10)
	int32_t FileSize; // 0x80(0x04)
	int32_t PreviewFileSize; // 0x84(0x04)
	struct FString URL; // 0x88(0x10)
	int32_t VotesUp; // 0x98(0x04)
	int32_t VotesDown; // 0x9c(0x04)
	float Score; // 0xa0(0x04)
	int32_t NumChildren; // 0xa4(0x04)
};

// ScriptStruct UWorksCore.UWorksUGCHandle
// Size: 0x08 (Inherited: 0x00)
struct FUWorksUGCHandle {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorksCore.UWorksUGCUpdateHandle
// Size: 0x08 (Inherited: 0x00)
struct FUWorksUGCUpdateHandle {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreUGC
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreUGC {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreUser
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreUser {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksLeaderboardEntry
// Size: 0x20 (Inherited: 0x00)
struct FUWorksLeaderboardEntry {
	struct FUWorksSteamID SteamID; // 0x00(0x08)
	int32_t GlobalRank; // 0x08(0x04)
	int32_t Score; // 0x0c(0x04)
	int32_t Details; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FUWorksUGCHandle UGCHandle; // 0x18(0x08)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreUserStats
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreUserStats {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksAnnexCoreUtils
// Size: 0x01 (Inherited: 0x00)
struct FUWorksAnnexCoreUtils {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct UWorksCore.UWorksSteamPipe
// Size: 0x04 (Inherited: 0x00)
struct FUWorksSteamPipe {
	char pad_0[0x4]; // 0x00(0x04)
};

// ScriptStruct UWorksCore.UWorksSteamUser
// Size: 0x04 (Inherited: 0x00)
struct FUWorksSteamUser {
	char pad_0[0x4]; // 0x00(0x04)
};

