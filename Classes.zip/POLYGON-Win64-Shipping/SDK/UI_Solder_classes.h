// WidgetBlueprintGeneratedClass UI_Solder.UI_Solder_C
// Size: 0x298 (Inherited: 0x260)
struct UUI_Solder_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UHorizontalBox* HorizontalBox_Header; // 0x268(0x08)
	struct UUI_Button_C* UI_Button_Customization; // 0x270(0x08)
	struct UUI_Button_C* UI_Button_Statistics; // 0x278(0x08)
	struct UUI_Solder_Customization_C* UI_Solder_Customization; // 0x280(0x08)
	struct UUI_Solder_Statistic_C* UI_Solder_Statistic; // 0x288(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Main; // 0x290(0x08)

	void Construct(); // Function UI_Solder.UI_Solder_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnPressed_Event(struct UUI_Button_C* Button); // Function UI_Solder.UI_Solder_C.OnPressed_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Customization_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Solder.UI_Solder_C.BndEvt__UI_Button_Customization_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Statistics_K2Node_ComponentBoundEvent_3_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Solder.UI_Solder_C.BndEvt__UI_Button_Statistics_K2Node_ComponentBoundEvent_3_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Solder(int32_t EntryPoint); // Function UI_Solder.UI_Solder_C.ExecuteUbergraph_UI_Solder // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

