// WidgetBlueprintGeneratedClass UI_Map_OtherPlayerIcon.UI_Map_OtherPlayerIcon_C
// Size: 0x288 (Inherited: 0x260)
struct UUI_Map_OtherPlayerIcon_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UOverlay* MainOverlay; // 0x268(0x08)
	struct UImage* PlayerIcon; // 0x270(0x08)
	float TargetOpacity; // 0x278(0x04)
	float MapSize; // 0x27c(0x04)
	struct APawn* PlayerCharacter; // 0x280(0x08)

	void FindCoord(float Distance, float Degrees, struct FVector2D NewVector); // Function UI_Map_OtherPlayerIcon.UI_Map_OtherPlayerIcon_C.FindCoord // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void FindAngle(struct FVector2D In, float Degrees); // Function UI_Map_OtherPlayerIcon.UI_Map_OtherPlayerIcon_C.FindAngle // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void Construct(); // Function UI_Map_OtherPlayerIcon.UI_Map_OtherPlayerIcon_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void CalculatePosition(); // Function UI_Map_OtherPlayerIcon.UI_Map_OtherPlayerIcon_C.CalculatePosition // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Map_OtherPlayerIcon(int32_t EntryPoint); // Function UI_Map_OtherPlayerIcon.UI_Map_OtherPlayerIcon_C.ExecuteUbergraph_UI_Map_OtherPlayerIcon // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

