// WidgetBlueprintGeneratedClass UI_PremiumShop_Skin.UI_PremiumShop_Skin_C
// Size: 0x270 (Inherited: 0x260)
struct UUI_PremiumShop_Skin_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWrapBox* WrapBox; // 0x268(0x08)

	void PreConstruct(bool IsDesignTime); // Function UI_PremiumShop_Skin.UI_PremiumShop_Skin_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_PremiumShop_Skin(int32_t EntryPoint); // Function UI_PremiumShop_Skin.UI_PremiumShop_Skin_C.ExecuteUbergraph_UI_PremiumShop_Skin // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

