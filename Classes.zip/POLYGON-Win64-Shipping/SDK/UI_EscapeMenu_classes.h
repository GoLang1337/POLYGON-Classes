// WidgetBlueprintGeneratedClass UI_EscapeMenu.UI_EscapeMenu_C
// Size: 0x2a8 (Inherited: 0x260)
struct UUI_EscapeMenu_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* LinesBackground; // 0x268(0x08)
	struct UUI_Button_C* UI_Button_Options; // 0x270(0x08)
	struct UUI_Button_C* UI_Button_Quit; // 0x278(0x08)
	struct UUI_Button_C* UI_Button_Resume; // 0x280(0x08)
	struct UUI_Button_C* UI_Button_TeamSetup; // 0x288(0x08)
	struct UUI_Options_C* UI_Options; // 0x290(0x08)
	struct UVerticalBox* VerticalBox_Buttons; // 0x298(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Main; // 0x2a0(0x08)

	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function UI_EscapeMenu.UI_EscapeMenu_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_EscapeMenu.UI_EscapeMenu_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Back(); // Function UI_EscapeMenu.UI_EscapeMenu_C.Back // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Settings_K2Node_ComponentBoundEvent_3_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_EscapeMenu.UI_EscapeMenu_C.BndEvt__UI_Button_Settings_K2Node_ComponentBoundEvent_3_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Resume_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_EscapeMenu.UI_EscapeMenu_C.BndEvt__UI_Button_Resume_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Quit_K2Node_ComponentBoundEvent_4_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_EscapeMenu.UI_EscapeMenu_C.BndEvt__UI_Button_Quit_K2Node_ComponentBoundEvent_4_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Options_K2Node_ComponentBoundEvent_0_ClickBackDelegate__DelegateSignature(); // Function UI_EscapeMenu.UI_EscapeMenu_C.BndEvt__UI_Options_K2Node_ComponentBoundEvent_0_ClickBackDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_EscapeMenu(int32_t EntryPoint); // Function UI_EscapeMenu.UI_EscapeMenu_C.ExecuteUbergraph_UI_EscapeMenu // (Final|UbergraphFunction) // @ game+0x1847880
};

