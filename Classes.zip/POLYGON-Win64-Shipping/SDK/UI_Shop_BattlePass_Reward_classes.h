// WidgetBlueprintGeneratedClass UI_Shop_BattlePass_Reward.UI_Shop_BattlePass_Reward_C
// Size: 0x388 (Inherited: 0x260)
struct UUI_Shop_BattlePass_Reward_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* AllowGetReward_Premium; // 0x268(0x08)
	struct UWidgetAnimation* AllowGetReward_Free; // 0x270(0x08)
	struct UWidgetAnimation* GetReward_Premium; // 0x278(0x08)
	struct UWidgetAnimation* GetReward_Free; // 0x280(0x08)
	struct UBorder* Border_IsReceivedFree; // 0x288(0x08)
	struct UBorder* Border_IsReceivedPremium; // 0x290(0x08)
	struct UBorder* Border_Selected_Free; // 0x298(0x08)
	struct UBorder* Border_Selected_Premium; // 0x2a0(0x08)
	struct UButton* Button_FreeInfo; // 0x2a8(0x08)
	struct UButton* Button_PremiumInfo; // 0x2b0(0x08)
	struct UImage* Image_Free_Background; // 0x2b8(0x08)
	struct UImage* Image_FreeLock; // 0x2c0(0x08)
	struct UImage* Image_Icon_Free; // 0x2c8(0x08)
	struct UImage* Image_Icon_Premium; // 0x2d0(0x08)
	struct UImage* Image_Premium_Background; // 0x2d8(0x08)
	struct UImage* Image_PremiumLock; // 0x2e0(0x08)
	struct UProgressBar* ProgressBar_Progress; // 0x2e8(0x08)
	struct UTextBlock* TextBlock_Level; // 0x2f0(0x08)
	struct UTexture2D* FreeIcon; // 0x2f8(0x08)
	struct UTexture2D* FreeRewardImage; // 0x300(0x08)
	struct UTexture2D* PremiumIcon; // 0x308(0x08)
	struct UTexture2D* PremiumRewardImage; // 0x310(0x08)
	int32_t Level; // 0x318(0x04)
	bool FreeIsReceived; // 0x31c(0x01)
	bool PremiumIsReceived; // 0x31d(0x01)
	char pad_31E[0x2]; // 0x31e(0x02)
	struct UUI_Shop_BattlePass_C* UI Shop Battle Pass; // 0x320(0x08)
	struct FText FreeTitle; // 0x328(0x18)
	struct FText FreeDescription; // 0x340(0x18)
	struct FText PremiumTitle; // 0x358(0x18)
	struct FText PremiumDescription; // 0x370(0x18)

	void SetProgress(float Progress); // Function UI_Shop_BattlePass_Reward.UI_Shop_BattlePass_Reward_C.SetProgress // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetSelected(bool IsPremium); // Function UI_Shop_BattlePass_Reward.UI_Shop_BattlePass_Reward_C.SetSelected // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetPremiumIsReceived(); // Function UI_Shop_BattlePass_Reward.UI_Shop_BattlePass_Reward_C.SetPremiumIsReceived // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetFreeIsReceived(); // Function UI_Shop_BattlePass_Reward.UI_Shop_BattlePass_Reward_C.SetFreeIsReceived // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Shop_BattlePass_Reward.UI_Shop_BattlePass_Reward_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Shop_BattlePass_Reward.UI_Shop_BattlePass_Reward_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BattlePass_Reward_Button_PremiumInfo_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature(); // Function UI_Shop_BattlePass_Reward.UI_Shop_BattlePass_Reward_C.BndEvt__UI_Shop_BattlePass_Reward_Button_PremiumInfo_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BattlePass_Reward_Button_FreeInfo_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature(); // Function UI_Shop_BattlePass_Reward.UI_Shop_BattlePass_Reward_C.BndEvt__UI_Shop_BattlePass_Reward_Button_FreeInfo_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void PlayGetRewardAnimation(); // Function UI_Shop_BattlePass_Reward.UI_Shop_BattlePass_Reward_C.PlayGetRewardAnimation // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Shop_BattlePass_Reward(int32_t EntryPoint); // Function UI_Shop_BattlePass_Reward.UI_Shop_BattlePass_Reward_C.ExecuteUbergraph_UI_Shop_BattlePass_Reward // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

