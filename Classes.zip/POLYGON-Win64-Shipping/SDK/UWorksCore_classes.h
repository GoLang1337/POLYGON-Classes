// Class UWorksCore.UWorksInterfaceCore
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceCore : UUWorksInterface {
};

// Class UWorksCore.UWorksRequestCore
// Size: 0x38 (Inherited: 0x28)
struct UUWorksRequestCore : UUWorksRequest {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class UWorksCore.UWorksInterfaceCoreAppList
// Size: 0x48 (Inherited: 0x28)
struct UUWorksInterfaceCoreAppList : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate SteamAppInstalled; // 0x28(0x10)
	struct FMulticastInlineDelegate SteamAppUninstalled; // 0x38(0x10)

	int32_t GetNumInstalledApps(); // Function UWorksCore.UWorksInterfaceCoreAppList.GetNumInstalledApps // (Final|Native|Public|BlueprintCallable) // @ game+0x8d2080
	int32_t GetInstalledApps(struct TArray<int32_t> AppIDs, int32_t MaxAppIDs); // Function UWorksCore.UWorksInterfaceCoreAppList.GetInstalledApps // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d1c70
	int32_t GetAppName(int32_t AppID, struct FString Name, int32_t NameMaxLength); // Function UWorksCore.UWorksInterfaceCoreAppList.GetAppName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d1070
	struct UUWorksInterfaceCoreAppList* GetAppList(); // Function UWorksCore.UWorksInterfaceCoreAppList.GetAppList // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8d1040
	int32_t GetAppInstallDir(int32_t AppID, struct FString Directory, int32_t DirectoryMaxLength); // Function UWorksCore.UWorksInterfaceCoreAppList.GetAppInstallDir // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d0dc0
	int32_t GetAppBuildId(int32_t AppID); // Function UWorksCore.UWorksInterfaceCoreAppList.GetAppBuildId // (Final|Native|Public|BlueprintCallable) // @ game+0x8d0cf0
};

// Class UWorksCore.UWorksInterfaceCoreApps
// Size: 0x48 (Inherited: 0x28)
struct UUWorksInterfaceCoreApps : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate DlcInstalled; // 0x28(0x10)
	struct FMulticastInlineDelegate NewUrlLaunchParameters; // 0x38(0x10)

	void UninstallDLC(int32_t AppID); // Function UWorksCore.UWorksInterfaceCoreApps.UninstallDLC // (Final|Native|Public|BlueprintCallable) // @ game+0x8d2a70
	bool MarkContentCorrupt(bool bMissingFilesOnly); // Function UWorksCore.UWorksInterfaceCoreApps.MarkContentCorrupt // (Final|Native|Public|BlueprintCallable) // @ game+0x8d2220
	void InstallDLC(int32_t AppID); // Function UWorksCore.UWorksInterfaceCoreApps.InstallDLC // (Final|Native|Public|BlueprintCallable) // @ game+0x8d2190
	struct FString GetLaunchQueryParam(struct FString Key); // Function UWorksCore.UWorksInterfaceCoreApps.GetLaunchQueryParam // (Final|Native|Public|BlueprintCallable) // @ game+0x8d1eb0
	int32_t GetInstalledDepots(int32_t AppID, struct TArray<int32_t> Depots, int32_t MaxDepots); // Function UWorksCore.UWorksInterfaceCoreApps.GetInstalledDepots // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d1d70
	void GetFileDetailsMinimal(struct FDelegate Completed, struct FString Filename); // Function UWorksCore.UWorksInterfaceCoreApps.GetFileDetailsMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d19d0
	struct UUWorksRequestCoreGetFileDetails* GetFileDetails(); // Function UWorksCore.UWorksInterfaceCoreApps.GetFileDetails // (Final|Native|Public|BlueprintCallable) // @ game+0x8d19a0
	int32_t GetEarliestPurchaseUnixTime(int32_t AppID); // Function UWorksCore.UWorksInterfaceCoreApps.GetEarliestPurchaseUnixTime // (Final|Native|Public|BlueprintCallable) // @ game+0x8d1900
	bool GetDlcDownloadProgress(int32_t AppID, int32_t BytesDownloaded, int32_t BytesTotal); // Function UWorksCore.UWorksInterfaceCoreApps.GetDlcDownloadProgress // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d17e0
	int32_t GetDLCCount(); // Function UWorksCore.UWorksInterfaceCoreApps.GetDLCCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8d15e0
	struct FString GetCurrentGameLanguage(); // Function UWorksCore.UWorksInterfaceCoreApps.GetCurrentGameLanguage // (Final|Native|Public|BlueprintCallable) // @ game+0x8d1590
	bool GetCurrentBetaName(struct FString Name, int32_t NameMaxLength); // Function UWorksCore.UWorksInterfaceCoreApps.GetCurrentBetaName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d1490
	struct FString GetAvailableGameLanguages(); // Function UWorksCore.UWorksInterfaceCoreApps.GetAvailableGameLanguages // (Final|Native|Public|BlueprintCallable) // @ game+0x8d1220
	struct UUWorksInterfaceCoreApps* GetApps(); // Function UWorksCore.UWorksInterfaceCoreApps.GetApps // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8d11f0
	struct FUWorksSteamID GetAppOwner(); // Function UWorksCore.UWorksInterfaceCoreApps.GetAppOwner // (Final|Native|Public|BlueprintCallable) // @ game+0x8d11b0
	int32_t GetAppInstallDir(int32_t AppID, struct FString Path, int32_t PathMaxLength); // Function UWorksCore.UWorksInterfaceCoreApps.GetAppInstallDir // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d0f00
	int32_t GetAppBuildId(); // Function UWorksCore.UWorksInterfaceCoreApps.GetAppBuildId // (Final|Native|Public|BlueprintCallable) // @ game+0x8d0d90
	bool BIsVACBanned(); // Function UWorksCore.UWorksInterfaceCoreApps.BIsVACBanned // (Final|Native|Public|BlueprintCallable) // @ game+0x8d0860
	bool BIsSubscribedFromFreeWeekend(); // Function UWorksCore.UWorksInterfaceCoreApps.BIsSubscribedFromFreeWeekend // (Final|Native|Public|BlueprintCallable) // @ game+0x8d0830
	bool BIsSubscribedApp(int32_t AppID); // Function UWorksCore.UWorksInterfaceCoreApps.BIsSubscribedApp // (Final|Native|Public|BlueprintCallable) // @ game+0x8d0790
	bool BIsSubscribed(); // Function UWorksCore.UWorksInterfaceCoreApps.BIsSubscribed // (Final|Native|Public|BlueprintCallable) // @ game+0x8d0760
	bool BIsLowViolence(); // Function UWorksCore.UWorksInterfaceCoreApps.BIsLowViolence // (Final|Native|Public|BlueprintCallable) // @ game+0x8d0730
	bool BIsDlcInstalled(int32_t AppID); // Function UWorksCore.UWorksInterfaceCoreApps.BIsDlcInstalled // (Final|Native|Public|BlueprintCallable) // @ game+0x8d0690
	bool BIsCybercafe(); // Function UWorksCore.UWorksInterfaceCoreApps.BIsCybercafe // (Final|Native|Public|BlueprintCallable) // @ game+0x8d0660
	bool BIsAppInstalled(int32_t AppID); // Function UWorksCore.UWorksInterfaceCoreApps.BIsAppInstalled // (Final|Native|Public|BlueprintCallable) // @ game+0x8d05c0
	bool BGetDLCDataByIndex(int32_t DLC, int32_t AppID, bool bAvailable, struct FString Name, int32_t NameMaxLength); // Function UWorksCore.UWorksInterfaceCoreApps.BGetDLCDataByIndex // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d03c0
};

// Class UWorksCore.UWorksInterfaceCoreController
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceCoreController : UUWorksInterfaceCore {

	void TriggerVibration(struct FUWorksControllerHandle ControllerHandle, int32_t LeftSpeed, int32_t RightSpeed); // Function UWorksCore.UWorksInterfaceCoreController.TriggerVibration // (Final|Native|Public|BlueprintCallable) // @ game+0x8d2950
	void TriggerRepeatedHapticPulse(struct FUWorksControllerHandle ControllerHandle, enum class EUWorksSteamControllerPad TargetPad, int32_t DurationMicroSec, int32_t OffMicroSec, int32_t Repeat, int32_t Flags); // Function UWorksCore.UWorksInterfaceCoreController.TriggerRepeatedHapticPulse // (Final|Native|Public|BlueprintCallable) // @ game+0x8d2780
	void TriggerHapticPulse(struct FUWorksControllerHandle ControllerHandle, enum class EUWorksSteamControllerPad TargetPad, int32_t DurationMicroSec); // Function UWorksCore.UWorksInterfaceCoreController.TriggerHapticPulse // (Final|Native|Public|BlueprintCallable) // @ game+0x8d2660
	void StopAnalogActionMomentum(struct FUWorksControllerHandle ControllerHandle, struct FUWorksControllerAnalogActionHandle Action); // Function UWorksCore.UWorksInterfaceCoreController.StopAnalogActionMomentum // (Final|Native|Public|BlueprintCallable) // @ game+0x8d2590
	bool Shutdown(); // Function UWorksCore.UWorksInterfaceCoreController.Shutdown // (Final|Native|Public|BlueprintCallable) // @ game+0x8d2560
	bool ShowBindingPanel(struct FUWorksControllerHandle ControllerHandle); // Function UWorksCore.UWorksInterfaceCoreController.ShowBindingPanel // (Final|Native|Public|BlueprintCallable) // @ game+0x8d24d0
	void SetLEDColor(struct FUWorksControllerHandle ControllerHandle, char ColorR, char ColorG, char ColorB, struct TArray<enum class EUWorksSteamControllerLEDFlag> Flags); // Function UWorksCore.UWorksInterfaceCoreController.SetLEDColor // (Final|Native|Public|BlueprintCallable) // @ game+0x8d22e0
	void RunFrame(); // Function UWorksCore.UWorksInterfaceCoreController.RunFrame // (Final|Native|Public|BlueprintCallable) // @ game+0x8d22c0
	bool Init(); // Function UWorksCore.UWorksInterfaceCoreController.Init // (Final|Native|Public|BlueprintCallable) // @ game+0x8d2160
	struct FString GetStringForActionOrigin(enum class EUWorksControllerActionOrigin Origin); // Function UWorksCore.UWorksInterfaceCoreController.GetStringForActionOrigin // (Final|Native|Public|BlueprintCallable) // @ game+0x8d20b0
	struct FUWorksControllerMotionData GetMotionData(struct FUWorksControllerHandle ControllerHandle); // Function UWorksCore.UWorksInterfaceCoreController.GetMotionData // (Final|Native|Public|BlueprintCallable) // @ game+0x8d1fd0
	struct FString GetGlyphForActionOrigin(enum class EUWorksControllerActionOrigin Origin); // Function UWorksCore.UWorksInterfaceCoreController.GetGlyphForActionOrigin // (Final|Native|Public|BlueprintCallable) // @ game+0x8d1bc0
	int32_t GetGamepadIndexForController(struct FUWorksControllerHandle ControllerHandle); // Function UWorksCore.UWorksInterfaceCoreController.GetGamepadIndexForController // (Final|Native|Public|BlueprintCallable) // @ game+0x8d1b30
	int32_t GetDigitalActionOrigins(struct FUWorksControllerHandle ControllerHandle, struct FUWorksControllerActionSetHandle ActionSetHandle, struct FUWorksControllerDigitalActionHandle DigitalActionHandle, struct TArray<enum class EUWorksControllerActionOrigin> OriginsOut); // Function UWorksCore.UWorksInterfaceCoreController.GetDigitalActionOrigins // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d0b60
	struct FUWorksControllerDigitalActionHandle GetDigitalActionHandle(struct FString ActionName); // Function UWorksCore.UWorksInterfaceCoreController.GetDigitalActionHandle // (Final|Native|Public|BlueprintCallable) // @ game+0x8d16f0
	struct FUWorksControllerDigitalActionData GetDigitalActionData(struct FUWorksControllerHandle ControllerHandle, struct FUWorksControllerDigitalActionHandle DigitalActionHandle); // Function UWorksCore.UWorksInterfaceCoreController.GetDigitalActionData // (Final|Native|Public|BlueprintCallable) // @ game+0x8d1610
	struct FUWorksControllerActionSetHandle GetCurrentActionSet(struct FUWorksControllerHandle ControllerHandle); // Function UWorksCore.UWorksInterfaceCoreController.GetCurrentActionSet // (Final|Native|Public|BlueprintCallable) // @ game+0x8d13f0
	struct FUWorksControllerHandle GetControllerForGamepadIndex(int32_t Index); // Function UWorksCore.UWorksInterfaceCoreController.GetControllerForGamepadIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8d1360
	struct UUWorksInterfaceCoreController* GetController(); // Function UWorksCore.UWorksInterfaceCoreController.GetController // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8d1330
	int32_t GetConnectedControllers(struct TArray<struct FUWorksControllerHandle> HandlesOut); // Function UWorksCore.UWorksInterfaceCoreController.GetConnectedControllers // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d1270
	int32_t GetAnalogActionOrigins(struct FUWorksControllerHandle ControllerHandle, struct FUWorksControllerActionSetHandle ActionSetHandle, struct FUWorksControllerAnalogActionHandle AnalogActionHandle, struct TArray<enum class EUWorksControllerActionOrigin> OriginsOut); // Function UWorksCore.UWorksInterfaceCoreController.GetAnalogActionOrigins // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d0b60
	struct FUWorksControllerAnalogActionHandle GetAnalogActionHandle(struct FString ActionName); // Function UWorksCore.UWorksInterfaceCoreController.GetAnalogActionHandle // (Final|Native|Public|BlueprintCallable) // @ game+0x8d0a70
	struct FUWorksControllerAnalogActionData GetAnalogActionData(struct FUWorksControllerHandle ControllerHandle, struct FUWorksControllerAnalogActionHandle AnalogActionHandle); // Function UWorksCore.UWorksInterfaceCoreController.GetAnalogActionData // (Final|Native|Public|BlueprintCallable) // @ game+0x8d0980
	struct FUWorksControllerActionSetHandle GetActionSetHandle(struct FString ActionSetName); // Function UWorksCore.UWorksInterfaceCoreController.GetActionSetHandle // (Final|Native|Public|BlueprintCallable) // @ game+0x8d0890
	void ActivateActionSet(struct FUWorksControllerHandle ControllerHandle, struct FUWorksControllerActionSetHandle ActionSetHandle); // Function UWorksCore.UWorksInterfaceCoreController.ActivateActionSet // (Final|Native|Public|BlueprintCallable) // @ game+0x8d02f0
};

// Class UWorksCore.UWorksInterfaceCoreFriends
// Size: 0xd8 (Inherited: 0x28)
struct UUWorksInterfaceCoreFriends : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate PersonaStateChange; // 0x28(0x10)
	struct FMulticastInlineDelegate GameOverlayActivated; // 0x38(0x10)
	struct FMulticastInlineDelegate GameServerChangeRequested; // 0x48(0x10)
	struct FMulticastInlineDelegate GameLobbyJoinRequested; // 0x58(0x10)
	struct FMulticastInlineDelegate AvatarImageLoaded; // 0x68(0x10)
	struct FMulticastInlineDelegate FriendRichPresenceUpdate; // 0x78(0x10)
	struct FMulticastInlineDelegate GameRichPresenceJoinRequested; // 0x88(0x10)
	struct FMulticastInlineDelegate GameConnectedClanChatMsg; // 0x98(0x10)
	struct FMulticastInlineDelegate GameConnectedChatJoin; // 0xa8(0x10)
	struct FMulticastInlineDelegate GameConnectedChatLeave; // 0xb8(0x10)
	struct FMulticastInlineDelegate GameConnectedFriendChatMsg; // 0xc8(0x10)

	bool SetRichPresence(struct FString Key, struct FString Value); // Function UWorksCore.UWorksInterfaceCoreFriends.SetRichPresence // (Final|Native|Public|BlueprintCallable) // @ game+0x8d74b0
	void SetPlayedWith(struct FUWorksSteamID SteamIDUserPlayedWith); // Function UWorksCore.UWorksInterfaceCoreFriends.SetPlayedWith // (Final|Native|Public|BlueprintCallable) // @ game+0x8d7420
	void SetPersonaNameMinimal(struct FDelegate Completed, struct FString Name); // Function UWorksCore.UWorksInterfaceCoreFriends.SetPersonaNameMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d72c0
	struct UUWorksRequestCoreSetPersonaName* SetPersonaName(); // Function UWorksCore.UWorksInterfaceCoreFriends.SetPersonaName // (Final|Native|Public|BlueprintCallable) // @ game+0x8d7290
	bool SetListenForFriendsMessages(bool bInterceptEnabled); // Function UWorksCore.UWorksInterfaceCoreFriends.SetListenForFriendsMessages // (Final|Native|Public|BlueprintCallable) // @ game+0x8d71f0
	void SetInGameVoiceSpeaking(struct FUWorksSteamID SteamIDUser, bool bSpeaking); // Function UWorksCore.UWorksInterfaceCoreFriends.SetInGameVoiceSpeaking // (Final|Native|Public|BlueprintCallable) // @ game+0x8d7120
	bool SendClanChatMessage(struct FUWorksSteamID SteamIDClanChat, struct FString Text); // Function UWorksCore.UWorksInterfaceCoreFriends.SendClanChatMessage // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6ff0
	bool RequestUserInformation(struct FUWorksSteamID SteamIDUser, bool bRequireNameOnly); // Function UWorksCore.UWorksInterfaceCoreFriends.RequestUserInformation // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6f20
	void RequestFriendRichPresence(struct FUWorksSteamID SteamIDFriend); // Function UWorksCore.UWorksInterfaceCoreFriends.RequestFriendRichPresence // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6e90
	void RequestClanOfficerListMinimal(struct FDelegate Completed, struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksInterfaceCoreFriends.RequestClanOfficerListMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d6d90
	struct UUWorksRequestCoreRequestClanOfficerList* RequestClanOfficerList(); // Function UWorksCore.UWorksInterfaceCoreFriends.RequestClanOfficerList // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6d60
	bool ReplyToFriendMessage(struct FUWorksSteamID SteamIDFriend, struct FString MessageToSend); // Function UWorksCore.UWorksInterfaceCoreFriends.ReplyToFriendMessage // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6c30
	bool OpenClanChatWindowInSteam(struct FUWorksSteamID SteamIDClanChat); // Function UWorksCore.UWorksInterfaceCoreFriends.OpenClanChatWindowInSteam // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6b90
	bool LeaveClanChatRoom(struct FUWorksSteamID SteamIDClan); // Function UWorksCore.UWorksInterfaceCoreFriends.LeaveClanChatRoom // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6af0
	void JoinClanChatRoomMinimal(struct FDelegate Completed, struct FUWorksSteamID SteamIDClan); // Function UWorksCore.UWorksInterfaceCoreFriends.JoinClanChatRoomMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d69f0
	struct UUWorksRequestCoreJoinClanChatRoom* JoinClanChatRoom(); // Function UWorksCore.UWorksInterfaceCoreFriends.JoinClanChatRoom // (Final|Native|Public|BlueprintCallable) // @ game+0x8d69c0
	bool IsUserInSource(struct FUWorksSteamID SteamIDUser, struct FUWorksSteamID SteamIDSource); // Function UWorksCore.UWorksInterfaceCoreFriends.IsUserInSource // (Final|Native|Public|BlueprintCallable) // @ game+0x8d68f0
	void IsFollowingMinimal(struct FDelegate Completed, struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksInterfaceCoreFriends.IsFollowingMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d67f0
	struct UUWorksRequestCoreIsFollowing* IsFollowing(); // Function UWorksCore.UWorksInterfaceCoreFriends.IsFollowing // (Final|Native|Public|BlueprintCallable) // @ game+0x8d67c0
	bool IsClanChatWindowOpenInSteam(struct FUWorksSteamID SteamIDClanChat); // Function UWorksCore.UWorksInterfaceCoreFriends.IsClanChatWindowOpenInSteam // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6720
	bool IsClanChatAdmin(struct FUWorksSteamID SteamIDClanChat, struct FUWorksSteamID SteamIDUser); // Function UWorksCore.UWorksInterfaceCoreFriends.IsClanChatAdmin // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6650
	bool InviteUserToGame(struct FUWorksSteamID SteamIDFriend, struct FString ConnectString); // Function UWorksCore.UWorksInterfaceCoreFriends.InviteUserToGame // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6520
	bool HasFriend(struct FUWorksSteamID SteamIDFriend, struct TArray<enum class EUWorksFriendFlags> FriendFlags); // Function UWorksCore.UWorksInterfaceCoreFriends.HasFriend // (Final|Native|Public|BlueprintCallable) // @ game+0x8d63f0
	struct TArray<enum class EUWorksUserRestriction> GetUserRestrictions(); // Function UWorksCore.UWorksInterfaceCoreFriends.GetUserRestrictions // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6350
	struct UTexture2D* GetSmallFriendAvatar(struct FUWorksSteamID SteamIDFriend); // Function UWorksCore.UWorksInterfaceCoreFriends.GetSmallFriendAvatar // (Final|Native|Public|BlueprintCallable) // @ game+0x8d62b0
	struct FString GetPlayerNickname(struct FUWorksSteamID SteamIDPlayer); // Function UWorksCore.UWorksInterfaceCoreFriends.GetPlayerNickname // (Final|Native|Public|BlueprintCallable) // @ game+0x8d61f0
	enum class EUWorksPersonaState GetPersonaState(); // Function UWorksCore.UWorksInterfaceCoreFriends.GetPersonaState // (Final|Native|Public|BlueprintCallable) // @ game+0x8d61c0
	struct FString GetPersonaName(); // Function UWorksCore.UWorksInterfaceCoreFriends.GetPersonaName // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6170
	struct UTexture2D* GetMediumFriendAvatar(struct FUWorksSteamID SteamIDFriend); // Function UWorksCore.UWorksInterfaceCoreFriends.GetMediumFriendAvatar // (Final|Native|Public|BlueprintCallable) // @ game+0x8d60d0
	struct UTexture2D* GetLargeFriendAvatar(struct FUWorksSteamID SteamIDFriend); // Function UWorksCore.UWorksInterfaceCoreFriends.GetLargeFriendAvatar // (Final|Native|Public|BlueprintCallable) // @ game+0x8d6030
	int32_t GetFriendSteamLevel(struct FUWorksSteamID SteamIDFriend); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendSteamLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x8d5c30
	struct FString GetFriendsGroupName(struct FUWorksFriendsGroupID FriendsGroupID); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendsGroupName // (Final|Native|Public|BlueprintCallable) // @ game+0x8d5f80
	void GetFriendsGroupMembersList(struct FUWorksFriendsGroupID FriendsGroupID, struct TArray<struct FUWorksSteamID> SteamIDMembers, int32_t MembersCount); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendsGroupMembersList // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d5e50
	int32_t GetFriendsGroupMembersCount(struct FUWorksFriendsGroupID FriendsGroupID); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendsGroupMembersCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8d5dc0
	struct FUWorksFriendsGroupID GetFriendsGroupIDByIndex(int32_t FriendGroup); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendsGroupIDByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8d5d30
	int32_t GetFriendsGroupCount(); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendsGroupCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8d5d00
	struct UUWorksInterfaceCoreFriends* GetFriends(); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriends // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8d5cd0
	int32_t GetFriendRichPresenceKeyCount(struct FUWorksSteamID SteamIDFriend); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendRichPresenceKeyCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8d5b90
	struct FString GetFriendRichPresenceKeyByIndex(struct FUWorksSteamID SteamIDFriend, int32_t Key); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendRichPresenceKeyByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8d5aa0
	struct FString GetFriendRichPresence(struct FUWorksSteamID SteamIDFriend, struct FString Key); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendRichPresence // (Final|Native|Public|BlueprintCallable) // @ game+0x8d5950
	enum class EUWorksFriendRelationship GetFriendRelationship(struct FUWorksSteamID SteamIDFriend); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendRelationship // (Final|Native|Public|BlueprintCallable) // @ game+0x8d58b0
	enum class EUWorksPersonaState GetFriendPersonaState(struct FUWorksSteamID SteamIDFriend); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendPersonaState // (Final|Native|Public|BlueprintCallable) // @ game+0x8d5810
	struct FString GetFriendPersonaNameHistory(struct FUWorksSteamID SteamIDFriend, int32_t PersonaName); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendPersonaNameHistory // (Final|Native|Public|BlueprintCallable) // @ game+0x8d5720
	struct FString GetFriendPersonaName(struct FUWorksSteamID SteamIDFriend); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendPersonaName // (Final|Native|Public|BlueprintCallable) // @ game+0x8d5660
	int32_t GetFriendMessage(struct FUWorksSteamID SteamIDFriend, int32_t MessageID, struct FString Text, int32_t TextMaxLength, enum class EUWorksChatEntryType ChatEntryType); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendMessage // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d5470
	bool GetFriendGamePlayed(struct FUWorksSteamID SteamIDFriend, struct FUWorksGameID GameID, struct FString GameIP, int32_t ConnectionPort, int32_t QueryPort, struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendGamePlayed // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d5240
	struct FUWorksSteamID GetFriendFromSourceByIndex(struct FUWorksSteamID SteamIDSource, int32_t Friend); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendFromSourceByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8d5170
	int32_t GetFriendCountFromSource(struct FUWorksSteamID SteamIDSource); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendCountFromSource // (Final|Native|Public|BlueprintCallable) // @ game+0x8d50d0
	int32_t GetFriendCount(struct TArray<enum class EUWorksFriendFlags> FriendFlags); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4fd0
	int32_t GetFriendCoplayTime(struct FUWorksSteamID SteamIDFriend); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendCoplayTime // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4f30
	int32_t GetFriendCoplayGame(struct FUWorksSteamID SteamIDFriend); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendCoplayGame // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4e90
	struct FUWorksSteamID GetFriendByIndex(int32_t Friend, struct TArray<enum class EUWorksFriendFlags> FriendFlags); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFriendByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4d50
	void GetFollowerCountMinimal(struct FDelegate Completed, struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFollowerCountMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d4c50
	struct UUWorksRequestCoreGetFollowerCount* GetFollowerCount(); // Function UWorksCore.UWorksInterfaceCoreFriends.GetFollowerCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4c20
	int32_t GetCoplayFriendCount(); // Function UWorksCore.UWorksInterfaceCoreFriends.GetCoplayFriendCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4bf0
	struct FUWorksSteamID GetCoplayFriend(int32_t CoplayFriend); // Function UWorksCore.UWorksInterfaceCoreFriends.GetCoplayFriend // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4b60
	struct FString GetClanTag(struct FUWorksSteamID SteamIDClan); // Function UWorksCore.UWorksInterfaceCoreFriends.GetClanTag // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4aa0
	struct FUWorksSteamID GetClanOwner(struct FUWorksSteamID SteamIDClan); // Function UWorksCore.UWorksInterfaceCoreFriends.GetClanOwner // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4a10
	int32_t GetClanOfficerCount(struct FUWorksSteamID SteamIDClan); // Function UWorksCore.UWorksInterfaceCoreFriends.GetClanOfficerCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4970
	struct FUWorksSteamID GetClanOfficerByIndex(struct FUWorksSteamID SteamIDClan, int32_t Officer); // Function UWorksCore.UWorksInterfaceCoreFriends.GetClanOfficerByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8d48a0
	struct FString GetClanName(struct FUWorksSteamID SteamIDClan); // Function UWorksCore.UWorksInterfaceCoreFriends.GetClanName // (Final|Native|Public|BlueprintCallable) // @ game+0x8d47e0
	int32_t GetClanCount(); // Function UWorksCore.UWorksInterfaceCoreFriends.GetClanCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8d47b0
	int32_t GetClanChatMessage(struct FUWorksSteamID SteamIDClanChat, int32_t MessageID, struct FString Text, int32_t TextMax, enum class EUWorksChatEntryType ChatEntryType, struct FUWorksSteamID SteamIDChatter); // Function UWorksCore.UWorksInterfaceCoreFriends.GetClanChatMessage // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d45a0
	int32_t GetClanChatMemberCount(struct FUWorksSteamID SteamIDClan); // Function UWorksCore.UWorksInterfaceCoreFriends.GetClanChatMemberCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4500
	struct FUWorksSteamID GetClanByIndex(int32_t Clan); // Function UWorksCore.UWorksInterfaceCoreFriends.GetClanByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4470
	bool GetClanActivityCounts(struct FUWorksSteamID SteamIDClan, int32_t Online, int32_t InGame, int32_t Chatting); // Function UWorksCore.UWorksInterfaceCoreFriends.GetClanActivityCounts // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d42d0
	struct FUWorksSteamID GetChatMemberByIndex(struct FUWorksSteamID SteamIDClan, int32_t User); // Function UWorksCore.UWorksInterfaceCoreFriends.GetChatMemberByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8d4200
	void EnumerateFollowingListMinimal(struct FDelegate Completed, int32_t StartIndex); // Function UWorksCore.UWorksInterfaceCoreFriends.EnumerateFollowingListMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d4100
	struct UUWorksRequestCoreEnumerateFollowingList* EnumerateFollowingList(); // Function UWorksCore.UWorksInterfaceCoreFriends.EnumerateFollowingList // (Final|Native|Public|BlueprintCallable) // @ game+0x8d40d0
	void DownloadClanActivityCountsMinimal(struct FDelegate Completed, struct TArray<struct FUWorksSteamID> SteamIDClans); // Function UWorksCore.UWorksInterfaceCoreFriends.DownloadClanActivityCountsMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d3f70
	struct UUWorksRequestCoreDownloadClanActivityCounts* DownloadClanActivityCounts(); // Function UWorksCore.UWorksInterfaceCoreFriends.DownloadClanActivityCounts // (Final|Native|Public|BlueprintCallable) // @ game+0x8d3f40
	bool CloseClanChatWindowInSteam(struct FUWorksSteamID SteamIDClanChat); // Function UWorksCore.UWorksInterfaceCoreFriends.CloseClanChatWindowInSteam // (Final|Native|Public|BlueprintCallable) // @ game+0x8d3ea0
	void ClearRichPresence(); // Function UWorksCore.UWorksInterfaceCoreFriends.ClearRichPresence // (Final|Native|Public|BlueprintCallable) // @ game+0x8d3e80
	void ActivateGameOverlayToWebPage(struct FString URL); // Function UWorksCore.UWorksInterfaceCoreFriends.ActivateGameOverlayToWebPage // (Final|Native|Public|BlueprintCallable) // @ game+0x8d3d90
	void ActivateGameOverlayToUser(enum class EUWorksOverlaySpecific Dialog, struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksInterfaceCoreFriends.ActivateGameOverlayToUser // (Final|Native|Public|BlueprintCallable) // @ game+0x8d3cc0
	void ActivateGameOverlayToStore(int32_t AppID, enum class EUWorksOverlayToStoreFlag Flag); // Function UWorksCore.UWorksInterfaceCoreFriends.ActivateGameOverlayToStore // (Final|Native|Public|BlueprintCallable) // @ game+0x8d3bf0
	void ActivateGameOverlayInviteDialog(struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.UWorksInterfaceCoreFriends.ActivateGameOverlayInviteDialog // (Final|Native|Public|BlueprintCallable) // @ game+0x8d3b60
	void ActivateGameOverlay(enum class EUWorksOverlayGeneric Dialog); // Function UWorksCore.UWorksInterfaceCoreFriends.ActivateGameOverlay // (Final|Native|Public|BlueprintCallable) // @ game+0x8d3ae0
};

// Class UWorksCore.UWorksInterfaceCoreGameServer
// Size: 0x58 (Inherited: 0x28)
struct UUWorksInterfaceCoreGameServer : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate GSPolicyResponse; // 0x28(0x10)
	struct FMulticastInlineDelegate GSClientGroupStatus; // 0x38(0x10)
	struct FMulticastInlineDelegate GSValidateAuthTicketResponse; // 0x48(0x10)

	bool WasRestartRequested(); // Function UWorksCore.UWorksInterfaceCoreGameServer.WasRestartRequested // (Final|Native|Public|BlueprintCallable) // @ game+0x8dc2c0
	enum class EUWorksUserHasLicenseForAppResult UserHasLicenseForApp(struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksCore.UWorksInterfaceCoreGameServer.UserHasLicenseForApp // (Final|Native|Public|BlueprintCallable) // @ game+0x8dc1f0
	void SetServerName(struct FString ServerName); // Function UWorksCore.UWorksInterfaceCoreGameServer.SetServerName // (Final|Native|Public|BlueprintCallable) // @ game+0x8db450
	void SetRegion(struct FString Region); // Function UWorksCore.UWorksInterfaceCoreGameServer.SetRegion // (Final|Native|Public|BlueprintCallable) // @ game+0x8db360
	void SetPasswordProtected(bool bPasswordProtected); // Function UWorksCore.UWorksInterfaceCoreGameServer.SetPasswordProtected // (Final|Native|Public|BlueprintCallable) // @ game+0x8db2d0
	void SetMaxPlayerCount(int32_t PlayersMax); // Function UWorksCore.UWorksInterfaceCoreGameServer.SetMaxPlayerCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8db240
	void SetMapName(struct FString MapName); // Function UWorksCore.UWorksInterfaceCoreGameServer.SetMapName // (Final|Native|Public|BlueprintCallable) // @ game+0x8db150
	void SetKeyValue(struct FString Key, struct FString Value); // Function UWorksCore.UWorksInterfaceCoreGameServer.SetKeyValue // (Final|Native|Public|BlueprintCallable) // @ game+0x8dafd0
	void SetHeartbeatInterval(int32_t HeartbeatInterval); // Function UWorksCore.UWorksInterfaceCoreGameServer.SetHeartbeatInterval // (Final|Native|Public|BlueprintCallable) // @ game+0x8daf40
	void SetGameTags(struct FString GameTags); // Function UWorksCore.UWorksInterfaceCoreGameServer.SetGameTags // (Final|Native|Public|BlueprintCallable) // @ game+0x8dae50
	void SetGameData(struct FString GameData); // Function UWorksCore.UWorksInterfaceCoreGameServer.SetGameData // (Final|Native|Public|BlueprintCallable) // @ game+0x8dad60
	void SetBotPlayerCount(int32_t BotPlayers); // Function UWorksCore.UWorksInterfaceCoreGameServer.SetBotPlayerCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8dacd0
	bool RequestUserGroupStatus(struct FUWorksSteamID SteamIDUser, struct FUWorksSteamID SteamIDGroup); // Function UWorksCore.UWorksInterfaceCoreGameServer.RequestUserGroupStatus // (Final|Native|Public|BlueprintCallable) // @ game+0x8da9d0
	struct FUWorksSteamID GetSteamID(); // Function UWorksCore.UWorksInterfaceCoreGameServer.GetSteamID // (Final|Native|Public|BlueprintCallable) // @ game+0x8da2d0
	struct UUWorksInterfaceCoreGameServer* GetGameServer(); // Function UWorksCore.UWorksInterfaceCoreGameServer.GetGameServer // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8d9b30
	struct FUWorksTicketHandle GetAuthSessionTicket(struct TArray<char> Ticket); // Function UWorksCore.UWorksInterfaceCoreGameServer.GetAuthSessionTicket // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d9970
	void ForceHeartbeat(); // Function UWorksCore.UWorksInterfaceCoreGameServer.ForceHeartbeat // (Final|Native|Public|BlueprintCallable) // @ game+0x8d96d0
	void EndAuthSession(struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksInterfaceCoreGameServer.EndAuthSession // (Final|Native|Public|BlueprintCallable) // @ game+0x8d9340
	void EnableHeartbeats(bool bActive); // Function UWorksCore.UWorksInterfaceCoreGameServer.EnableHeartbeats // (Final|Native|Public|BlueprintCallable) // @ game+0x8d92b0
	void ComputeNewPlayerCompatibilityMinimal(struct FDelegate Completed, struct FUWorksSteamID SteamIDNewPlayer); // Function UWorksCore.UWorksInterfaceCoreGameServer.ComputeNewPlayerCompatibilityMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d8e70
	struct UUWorksRequestCoreComputeNewPlayerCompatibility* ComputeNewPlayerCompatibility(); // Function UWorksCore.UWorksInterfaceCoreGameServer.ComputeNewPlayerCompatibility // (Final|Native|Public|BlueprintCallable) // @ game+0x8d8e40
	void ClearAllKeyValues(); // Function UWorksCore.UWorksInterfaceCoreGameServer.ClearAllKeyValues // (Final|Native|Public|BlueprintCallable) // @ game+0x8d8cf0
	void CancelAuthTicket(struct FUWorksTicketHandle TicketHandle); // Function UWorksCore.UWorksInterfaceCoreGameServer.CancelAuthTicket // (Final|Native|Public|BlueprintCallable) // @ game+0x8d8ba0
	bool BSecure(); // Function UWorksCore.UWorksInterfaceCoreGameServer.BSecure // (Final|Native|Public|BlueprintCallable) // @ game+0x8d8a40
	bool BLoggedOn(); // Function UWorksCore.UWorksInterfaceCoreGameServer.BLoggedOn // (Final|Native|Public|BlueprintCallable) // @ game+0x8d8a10
	enum class EUWorksBeginAuthSessionResult BeginAuthSession(struct TArray<char> Ticket, struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksInterfaceCoreGameServer.BeginAuthSession // (Final|Native|Public|BlueprintCallable) // @ game+0x8d8a70
	void AssociateWithClanMinimal(struct FDelegate Completed, struct FUWorksSteamID SteamIDClan); // Function UWorksCore.UWorksInterfaceCoreGameServer.AssociateWithClanMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d8910
	struct UUWorksRequestCoreAssociateWithClan* AssociateWithClan(); // Function UWorksCore.UWorksInterfaceCoreGameServer.AssociateWithClan // (Final|Native|Public|BlueprintCallable) // @ game+0x8d88e0
};

// Class UWorksCore.UWorksInterfaceCoreGameServerStats
// Size: 0x38 (Inherited: 0x28)
struct UUWorksInterfaceCoreGameServerStats : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate GSStatsUnloaded; // 0x28(0x10)

	bool UpdateUserAvgRateStat(struct FUWorksSteamID SteamIDUser, struct FString Name, float CountThisSession, float SessionLength); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.UpdateUserAvgRateStat // (Final|Native|Public|BlueprintCallable) // @ game+0x8dc040
	void StoreUserStatsMinimal(struct FDelegate Completed, struct FUWorksSteamID SteamIDUser); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.StoreUserStatsMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8db990
	struct UUWorksRequestCoreStoreUserStats* StoreUserStats(); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.StoreUserStats // (Final|Native|Public|BlueprintCallable) // @ game+0x8db960
	bool SetUserStatFromInteger(struct FUWorksSteamID SteamIDUser, struct FString Name, int32_t Data); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.SetUserStatFromInteger // (Final|Native|Public|BlueprintCallable) // @ game+0x8db7f0
	bool SetUserStatFromFloat(struct FUWorksSteamID SteamIDUser, struct FString Name, float Data); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.SetUserStatFromFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x8db670
	bool SetUserAchievement(struct FUWorksSteamID SteamIDUser, struct FString Name); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.SetUserAchievement // (Final|Native|Public|BlueprintCallable) // @ game+0x8db540
	void RequestUserStatsMinimal(struct FDelegate Completed, struct FUWorksSteamID SteamIDUser); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.RequestUserStatsMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8daad0
	struct UUWorksRequestCoreRequestUserStatsGS* RequestUserStats(); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.RequestUserStats // (Final|Native|Public|BlueprintCallable) // @ game+0x8daaa0
	bool GetUserStatAsInteger(struct FUWorksSteamID SteamIDUser, struct FString Name, int32_t Data); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.GetUserStatAsInteger // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8da630
	bool GetUserStatAsFloat(struct FUWorksSteamID SteamIDUser, struct FString Name, float Data); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.GetUserStatAsFloat // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8da4a0
	bool GetUserAchievement(struct FUWorksSteamID SteamIDUser, struct FString Name, bool bAchieved); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.GetUserAchievement // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8da310
	struct UUWorksInterfaceCoreGameServerStats* GetGameServerStats(); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.GetGameServerStats // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8d9b60
	bool ClearUserAchievement(struct FUWorksSteamID SteamIDUser, struct FString Name); // Function UWorksCore.UWorksInterfaceCoreGameServerStats.ClearUserAchievement // (Final|Native|Public|BlueprintCallable) // @ game+0x8d8d10
};

// Class UWorksCore.UWorksInterfaceCoreInventory
// Size: 0x58 (Inherited: 0x28)
struct UUWorksInterfaceCoreInventory : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate SteamInventoryResultReady; // 0x28(0x10)
	struct FMulticastInlineDelegate SteamInventoryFullUpdate; // 0x38(0x10)
	struct FMulticastInlineDelegate SteamInventoryDefinitionUpdate; // 0x48(0x10)

	bool TriggerItemDrop(struct FUWorksSteamInventoryResult Handle, struct FUWorksSteamItemDef ItemDefinition); // Function UWorksCore.UWorksInterfaceCoreInventory.TriggerItemDrop // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8dbf50
	bool TransferItemQuantity(struct FUWorksSteamInventoryResult Handle, struct FUWorksSteamItemInstanceID ItemSourceInstanceID, int32_t ItemSourceQuantity, struct FUWorksSteamItemInstanceID ItemDestinationInstanceID); // Function UWorksCore.UWorksInterfaceCoreInventory.TransferItemQuantity // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8dbdd0
	bool TradeItems(struct FUWorksSteamInventoryResult Handle, struct FUWorksSteamID SteamIDTradePartner, struct TArray<struct FUWorksSteamItemInstanceID> ItemsGiven, struct TArray<int32_t> ItemsGivenQuantities, struct TArray<struct FUWorksSteamItemInstanceID> ItemsReceived, struct TArray<int32_t> ItemsReceivedQuantities); // Function UWorksCore.UWorksInterfaceCoreInventory.TradeItems // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8dba90
	bool SerializeResult(struct FUWorksSteamInventoryResult Handle, struct TArray<char> Buffer); // Function UWorksCore.UWorksInterfaceCoreInventory.SerializeResult // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8dabd0
	void RequestEligiblePromoItemDefinitionsIDsMinimal(struct FDelegate Completed, struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksInterfaceCoreInventory.RequestEligiblePromoItemDefinitionsIDsMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8da8d0
	struct UUWorksRequestCoreRequestEligiblePromoItemDefinitionsIDs* RequestEligiblePromoItemDefinitionsIDs(); // Function UWorksCore.UWorksInterfaceCoreInventory.RequestEligiblePromoItemDefinitionsIDs // (Final|Native|Public|BlueprintCallable) // @ game+0x8da8a0
	bool LoadItemDefinitions(); // Function UWorksCore.UWorksInterfaceCoreInventory.LoadItemDefinitions // (Final|Native|Public|BlueprintCallable) // @ game+0x8da870
	bool GrantPromoItems(struct FUWorksSteamInventoryResult Handle); // Function UWorksCore.UWorksInterfaceCoreInventory.GrantPromoItems // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8da7c0
	int32_t GetResultTimestamp(struct FUWorksSteamInventoryResult Handle); // Function UWorksCore.UWorksInterfaceCoreInventory.GetResultTimestamp // (Final|Native|Public|BlueprintCallable) // @ game+0x8da240
	enum class EUWorksResult GetResultStatus(struct FUWorksSteamInventoryResult Handle); // Function UWorksCore.UWorksInterfaceCoreInventory.GetResultStatus // (Final|Native|Public|BlueprintCallable) // @ game+0x8da1b0
	bool GetResultItems(struct FUWorksSteamInventoryResult Handle, struct TArray<struct FUWorksSteamItemDetails> Items); // Function UWorksCore.UWorksInterfaceCoreInventory.GetResultItems // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8da080
	bool GetItemsByID(struct FUWorksSteamInventoryResult Handle, struct TArray<struct FUWorksSteamItemInstanceID> InstanceIDs); // Function UWorksCore.UWorksInterfaceCoreInventory.GetItemsByID // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d9f30
	bool GetItemDefinitionPropertyValue(struct FUWorksSteamItemDef ItemDefinition, struct FString PropertyName, struct FString PropertyValue); // Function UWorksCore.UWorksInterfaceCoreInventory.GetItemDefinitionPropertyValue // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d9da0
	bool GetItemDefinitionPropertiesNames(struct FUWorksSteamItemDef ItemDefinition, struct TArray<struct FString> PropertiesNames); // Function UWorksCore.UWorksInterfaceCoreInventory.GetItemDefinitionPropertiesNames // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d9c80
	bool GetItemDefinitionIDs(struct TArray<struct FUWorksSteamItemDef> ItemDefinitions); // Function UWorksCore.UWorksInterfaceCoreInventory.GetItemDefinitionIDs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d9bc0
	struct UUWorksInterfaceCoreInventory* GetInventory(); // Function UWorksCore.UWorksInterfaceCoreInventory.GetInventory // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8d9b90
	bool GetEligiblePromoItemDefinitionIDs(struct FUWorksSteamID SteamID, struct TArray<struct FUWorksSteamItemDef> ItemDefinitions); // Function UWorksCore.UWorksInterfaceCoreInventory.GetEligiblePromoItemDefinitionIDs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d9a30
	bool GetAllItems(struct FUWorksSteamInventoryResult Handle); // Function UWorksCore.UWorksInterfaceCoreInventory.GetAllItems // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d98c0
	bool GenerateItems(struct FUWorksSteamInventoryResult Handle, struct TArray<struct FUWorksSteamItemDef> ItemDefinitions, struct TArray<int32_t> ItemQuantities); // Function UWorksCore.UWorksInterfaceCoreInventory.GenerateItems // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d96f0
	bool ExchangeItems(struct FUWorksSteamInventoryResult Handle, struct TArray<struct FUWorksSteamItemDef> ItemsGenerated, struct TArray<int32_t> ItemsGeneratedQuantities, struct TArray<struct FUWorksSteamItemInstanceID> ItemsDestroyed, struct TArray<int32_t> ItemsDestroyedQuantities); // Function UWorksCore.UWorksInterfaceCoreInventory.ExchangeItems // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d93d0
	void DestroyResult(struct FUWorksSteamInventoryResult Handle); // Function UWorksCore.UWorksInterfaceCoreInventory.DestroyResult // (Final|Native|Public|BlueprintCallable) // @ game+0x8d9230
	bool DeserializeResult(struct FUWorksSteamInventoryResult Handle, struct TArray<char> Buffer, bool bReservedMustBeFalse); // Function UWorksCore.UWorksInterfaceCoreInventory.DeserializeResult // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d9090
	bool ConsumeItem(struct FUWorksSteamInventoryResult Handle, struct FUWorksSteamItemInstanceID ItemInstanceId, int32_t ItemQuantity); // Function UWorksCore.UWorksInterfaceCoreInventory.ConsumeItem // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d8f70
	bool CheckResultSteamID(struct FUWorksSteamInventoryResult Handle, struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksInterfaceCoreInventory.CheckResultSteamID // (Final|Native|Public|BlueprintCallable) // @ game+0x8d8c20
	bool AddPromoItems(struct FUWorksSteamInventoryResult Handle, struct TArray<struct FUWorksSteamItemDef> ItemDefinitions); // Function UWorksCore.UWorksInterfaceCoreInventory.AddPromoItems // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d8790
	bool AddPromoItem(struct FUWorksSteamInventoryResult Handle, struct FUWorksSteamItemDef ItemDefinition); // Function UWorksCore.UWorksInterfaceCoreInventory.AddPromoItem // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d86a0
};

// Class UWorksCore.UWorksInterfaceCoreMatchmaking
// Size: 0xb8 (Inherited: 0x28)
struct UUWorksInterfaceCoreMatchmaking : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate FavoritesListChanged; // 0x28(0x10)
	struct FMulticastInlineDelegate LobbyInvite; // 0x38(0x10)
	struct FMulticastInlineDelegate LobbyDataUpdate; // 0x48(0x10)
	struct FMulticastInlineDelegate LobbyEnter; // 0x58(0x10)
	struct FMulticastInlineDelegate LobbyChatUpdate; // 0x68(0x10)
	struct FMulticastInlineDelegate LobbyChatMsg; // 0x78(0x10)
	struct FMulticastInlineDelegate LobbyGameCreated; // 0x88(0x10)
	struct FMulticastInlineDelegate LobbyKicked; // 0x98(0x10)
	struct FMulticastInlineDelegate FavoritesListAccountsUpdated; // 0xa8(0x10)

	bool SetLobbyType(struct FUWorksSteamID SteamIDLobby, enum class EUWorksLobbyType LobbyType); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.SetLobbyType // (Final|Native|Public|BlueprintCallable) // @ game+0x8e14a0
	bool SetLobbyOwner(struct FUWorksSteamID SteamIDLobby, struct FUWorksSteamID SteamIDNewOwner); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.SetLobbyOwner // (Final|Native|Public|BlueprintCallable) // @ game+0x8e13d0
	bool SetLobbyMemberLimit(struct FUWorksSteamID SteamIDLobby, int32_t MaxMembers); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.SetLobbyMemberLimit // (Final|Native|Public|BlueprintCallable) // @ game+0x8e1300
	void SetLobbyMemberData(struct FUWorksSteamID SteamIDLobby, struct FString Key, struct FString Value); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.SetLobbyMemberData // (Final|Native|Public|BlueprintCallable) // @ game+0x8e1150
	bool SetLobbyJoinable(struct FUWorksSteamID SteamIDLobby, bool bLobbyJoinable); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.SetLobbyJoinable // (Final|Native|Public|BlueprintCallable) // @ game+0x8e1080
	void SetLobbyGameServer(struct FUWorksSteamID SteamIDLobby, struct FString GameServerIP, int32_t GameServerPort, struct FUWorksSteamID SteamIDGameServer); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.SetLobbyGameServer // (Final|Native|Public|BlueprintCallable) // @ game+0x8e0ee0
	bool SetLobbyData(struct FUWorksSteamID SteamIDLobby, struct FString Key, struct FString Value); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.SetLobbyData // (Final|Native|Public|BlueprintCallable) // @ game+0x8e0d20
	bool SetLinkedLobby(struct FUWorksSteamID SteamIDLobby, struct FUWorksSteamID SteamIDLobbyDependent); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.SetLinkedLobby // (Final|Native|Public|BlueprintCallable) // @ game+0x8e0c50
	bool SendLobbyChatMsg(struct FUWorksSteamID SteamIDLobby, struct FString Message); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.SendLobbyChatMsg // (Final|Native|Public|BlueprintCallable) // @ game+0x8e0620
	void RequestLobbyListMinimal(struct FDelegate Completed); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.RequestLobbyListMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e0350
	struct UUWorksRequestCoreRequestLobbyList* RequestLobbyList(); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.RequestLobbyList // (Final|Native|Public|BlueprintCallable) // @ game+0x8e0320
	bool RequestLobbyData(struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.RequestLobbyData // (Final|Native|Public|BlueprintCallable) // @ game+0x8e0280
	bool RemoveFavoriteGame(int32_t AppID, struct FString IP, int32_t ConnectionPort, int32_t QueryPort, struct TArray<enum class EUWorksFavoriteFlags> Flags); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.RemoveFavoriteGame // (Final|Native|Public|BlueprintCallable) // @ game+0x8e0050
	void LeaveLobby(struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.LeaveLobby // (Final|Native|Public|BlueprintCallable) // @ game+0x8df820
	void JoinLobbyMinimal(struct FDelegate Completed, struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.JoinLobbyMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8df720
	struct UUWorksRequestCoreJoinLobby* JoinLobby(); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.JoinLobby // (Final|Native|Public|BlueprintCallable) // @ game+0x8df6f0
	bool InviteUserToLobby(struct FUWorksSteamID SteamIDLobby, struct FUWorksSteamID SteamIDInvitee); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.InviteUserToLobby // (Final|Native|Public|BlueprintCallable) // @ game+0x8df540
	int32_t GetNumLobbyMembers(struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetNumLobbyMembers // (Final|Native|Public|BlueprintCallable) // @ game+0x8df350
	struct UUWorksInterfaceCoreMatchmaking* GetMatchmaking(); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetMatchmaking // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8df290
	struct FUWorksSteamID GetLobbyOwner(struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetLobbyOwner // (Final|Native|Public|BlueprintCallable) // @ game+0x8df200
	int32_t GetLobbyMemberLimit(struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetLobbyMemberLimit // (Final|Native|Public|BlueprintCallable) // @ game+0x8df160
	struct FString GetLobbyMemberData(struct FUWorksSteamID SteamIDLobby, struct FUWorksSteamID SteamIDUser, struct FString Key); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetLobbyMemberData // (Final|Native|Public|BlueprintCallable) // @ game+0x8defe0
	struct FUWorksSteamID GetLobbyMemberByIndex(struct FUWorksSteamID SteamIDLobby, int32_t Member); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetLobbyMemberByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8def10
	bool GetLobbyGameServer(struct FUWorksSteamID SteamIDLobby, struct FString GameServerIP, int32_t GameServerPort, struct FUWorksSteamID SteamIDGameServer); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetLobbyGameServer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ded60
	int32_t GetLobbyDataCount(struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetLobbyDataCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8decc0
	bool GetLobbyDataByIndex(struct FUWorksSteamID SteamIDLobby, int32_t LobbyData, struct FString Key, int32_t KeyMaxLength, struct FString Value, int32_t ValueMaxLength); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetLobbyDataByIndex // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8deab0
	struct FString GetLobbyData(struct FUWorksSteamID SteamIDLobby, struct FString Key); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetLobbyData // (Final|Native|Public|BlueprintCallable) // @ game+0x8de960
	int32_t GetLobbyChatEntry(struct FUWorksSteamID SteamIDLobby, int32_t MessageID, struct FUWorksSteamID SteamIDUser, struct FString Message, int32_t MessageMaxLength, enum class EUWorksChatEntryType ChatEntryType); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetLobbyChatEntry // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8de750
	struct FUWorksSteamID GetLobbyByIndex(int32_t Lobby); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetLobbyByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8de6c0
	int32_t GetFavoriteGameCount(); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetFavoriteGameCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8de690
	bool GetFavoriteGame(int32_t Game, int32_t AppID, struct FString IP, int32_t ConnectionPort, int32_t QueryPort, struct TArray<enum class EUWorksFavoriteFlags> Flags, int32_t TimeLastPlayedOnServer); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.GetFavoriteGame // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8de400
	bool DeleteLobbyData(struct FUWorksSteamID SteamIDLobby, struct FString Key); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.DeleteLobbyData // (Final|Native|Public|BlueprintCallable) // @ game+0x8de2d0
	void CreateLobbyMinimal(struct FDelegate Completed, enum class EUWorksLobbyType LobbyType, int32_t MaxMembers); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.CreateLobbyMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8de1a0
	struct UUWorksRequestCoreCreateLobby* CreateLobby(); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.CreateLobby // (Final|Native|Public|BlueprintCallable) // @ game+0x8de170
	void AddRequestLobbyListStringFilter(struct FString KeyToMatch, struct FString ValueToMatch, enum class EUWorksLobbyComparison ComparisonType); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.AddRequestLobbyListStringFilter // (Final|Native|Public|BlueprintCallable) // @ game+0x8ddd50
	void AddRequestLobbyListResultCountFilter(int32_t MaxResults); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.AddRequestLobbyListResultCountFilter // (Final|Native|Public|BlueprintCallable) // @ game+0x8ddcc0
	void AddRequestLobbyListNumericalFilter(struct FString KeyToMatch, int32_t ValueToMatch, enum class EUWorksLobbyComparison ComparisonType); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.AddRequestLobbyListNumericalFilter // (Final|Native|Public|BlueprintCallable) // @ game+0x8ddb60
	void AddRequestLobbyListNearValueFilter(struct FString KeyToMatch, int32_t ValueToBeCloseTo); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.AddRequestLobbyListNearValueFilter // (Final|Native|Public|BlueprintCallable) // @ game+0x8dda30
	void AddRequestLobbyListFilterSlotsAvailable(int32_t SlotsAvailable); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.AddRequestLobbyListFilterSlotsAvailable // (Final|Native|Public|BlueprintCallable) // @ game+0x8dd9a0
	void AddRequestLobbyListDistanceFilter(enum class EUWorksLobbyDistanceFilter LobbyDistanceFilter); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.AddRequestLobbyListDistanceFilter // (Final|Native|Public|BlueprintCallable) // @ game+0x8dd920
	void AddRequestLobbyListCompatibleMembersFilter(struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.AddRequestLobbyListCompatibleMembersFilter // (Final|Native|Public|BlueprintCallable) // @ game+0x8dd890
	int32_t AddFavoriteGame(int32_t AppID, struct FString IP, int32_t ConnectionPort, int32_t QueryPort, struct TArray<enum class EUWorksFavoriteFlags> Flags, int32_t TimeLastPlayedOnServer); // Function UWorksCore.UWorksInterfaceCoreMatchmaking.AddFavoriteGame // (Final|Native|Public|BlueprintCallable) // @ game+0x8dd610
};

// Class UWorksCore.UWorksInterfaceCoreMatchmakingServers
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceCoreMatchmakingServers : UUWorksInterfaceCore {

	void ServerListMinimal(struct FDelegate Completed, struct FDelegate Updated, int32_t AppID, enum class EUWorksServerQueryType QueryType); // Function UWorksCore.UWorksInterfaceCoreMatchmakingServers.ServerListMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e0ac0
	struct UUWorksRequestCoreServerList* ServerList(); // Function UWorksCore.UWorksInterfaceCoreMatchmakingServers.ServerList // (Final|Native|Public|BlueprintCallable) // @ game+0x8e0a90
	void RulesMinimal(struct FDelegate Completed, struct FDelegate Updated, struct FString IP, int32_t Port); // Function UWorksCore.UWorksInterfaceCoreMatchmakingServers.RulesMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e0430
	struct UUWorksRequestCoreRules* Rules(); // Function UWorksCore.UWorksInterfaceCoreMatchmakingServers.Rules // (Final|Native|Public|BlueprintCallable) // @ game+0x8e0400
	void PlayersMinimal(struct FDelegate Completed, struct FDelegate Updated, struct FString IP, int32_t Port); // Function UWorksCore.UWorksInterfaceCoreMatchmakingServers.PlayersMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8dfb20
	struct UUWorksRequestCorePlayers* Players(); // Function UWorksCore.UWorksInterfaceCoreMatchmakingServers.Players // (Final|Native|Public|BlueprintCallable) // @ game+0x8dfaf0
	void PingMinimal(struct FDelegate Completed, struct FString IP, int32_t Port); // Function UWorksCore.UWorksInterfaceCoreMatchmakingServers.PingMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8df900
	struct UUWorksRequestCorePing* Ping(); // Function UWorksCore.UWorksInterfaceCoreMatchmakingServers.Ping // (Final|Native|Public|BlueprintCallable) // @ game+0x8df8d0
	struct UUWorksInterfaceCoreMatchmakingServers* GetMatchmakingServers(); // Function UWorksCore.UWorksInterfaceCoreMatchmakingServers.GetMatchmakingServers // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8df2c0
};

// Class UWorksCore.UWorksInterfaceCoreMusic
// Size: 0x48 (Inherited: 0x28)
struct UUWorksInterfaceCoreMusic : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate PlaybackStatusHasChanged; // 0x28(0x10)
	struct FMulticastInlineDelegate VolumeHasChanged; // 0x38(0x10)

	void SetVolume(float Volume); // Function UWorksCore.UWorksInterfaceCoreMusic.SetVolume // (Final|Native|Public|BlueprintCallable) // @ game+0x8e1570
	void PlayPrevious(); // Function UWorksCore.UWorksInterfaceCoreMusic.PlayPrevious // (Final|Native|Public|BlueprintCallable) // @ game+0x8dfad0
	void PlayNext(); // Function UWorksCore.UWorksInterfaceCoreMusic.PlayNext // (Final|Native|Public|BlueprintCallable) // @ game+0x8dfab0
	void Play(); // Function UWorksCore.UWorksInterfaceCoreMusic.Play // (Final|Native|Public|BlueprintCallable) // @ game+0x8dfa90
	void Pause(); // Function UWorksCore.UWorksInterfaceCoreMusic.Pause // (Final|Native|Public|BlueprintCallable) // @ game+0x8df8b0
	float GetVolume(); // Function UWorksCore.UWorksInterfaceCoreMusic.GetVolume // (Final|Native|Public|BlueprintCallable) // @ game+0x8df510
	enum class EUWorksAudioPlaybackStatus GetPlaybackStatus(); // Function UWorksCore.UWorksInterfaceCoreMusic.GetPlaybackStatus // (Final|Native|Public|BlueprintCallable) // @ game+0x8df4e0
	struct UUWorksInterfaceCoreMusic* GetMusic(); // Function UWorksCore.UWorksInterfaceCoreMusic.GetMusic // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8df2f0
	bool BIsPlaying(); // Function UWorksCore.UWorksInterfaceCoreMusic.BIsPlaying // (Final|Native|Public|BlueprintCallable) // @ game+0x8ddfd0
	bool BIsEnabled(); // Function UWorksCore.UWorksInterfaceCoreMusic.BIsEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x8ddfa0
};

// Class UWorksCore.UWorksInterfaceCoreNetworking
// Size: 0x48 (Inherited: 0x28)
struct UUWorksInterfaceCoreNetworking : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate P2PSessionRequest; // 0x28(0x10)
	struct FMulticastInlineDelegate P2PSessionConnectFail; // 0x38(0x10)

	bool SendP2PPacket(struct FUWorksSteamID SteamIDRemote, struct TArray<char> Data, enum class EUWorksP2PSend P2PSendType, int32_t Channel); // Function UWorksCore.UWorksInterfaceCoreNetworking.SendP2PPacket // (Final|Native|Public|BlueprintCallable) // @ game+0x8e08f0
	bool SendP2PMessage(struct FUWorksSteamID SteamIDRemote, struct FString Data, enum class EUWorksP2PSend P2PSendType, int32_t Channel); // Function UWorksCore.UWorksInterfaceCoreNetworking.SendP2PMessage // (Final|Native|Public|BlueprintCallable) // @ game+0x8e0750
	bool ReadP2PPacket(struct TArray<char> Data, int32_t DataMax, struct FUWorksSteamID SteamIDRemote, int32_t Channel); // Function UWorksCore.UWorksInterfaceCoreNetworking.ReadP2PPacket // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8dfeb0
	bool ReadP2PMessage(struct FString Data, int32_t DataMax, struct FUWorksSteamID SteamIDRemote, int32_t Channel); // Function UWorksCore.UWorksInterfaceCoreNetworking.ReadP2PMessage // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8dfd10
	bool IsP2PPacketAvailable(int32_t DataSize, int32_t Channel); // Function UWorksCore.UWorksInterfaceCoreNetworking.IsP2PPacketAvailable // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8df610
	bool GetP2PSessionState(struct FUWorksSteamID SteamIDRemote, struct FUWorksP2PSessionState ConnectionState); // Function UWorksCore.UWorksInterfaceCoreNetworking.GetP2PSessionState // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8df3f0
	struct UUWorksInterfaceCoreNetworking* GetNetworking(); // Function UWorksCore.UWorksInterfaceCoreNetworking.GetNetworking // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8df320
	bool CloseP2PSessionWithUser(struct FUWorksSteamID SteamIDRemote); // Function UWorksCore.UWorksInterfaceCoreNetworking.CloseP2PSessionWithUser // (Final|Native|Public|BlueprintCallable) // @ game+0x8de0d0
	bool CloseP2PChannelWithUser(struct FUWorksSteamID SteamIDRemote, int32_t Channel); // Function UWorksCore.UWorksInterfaceCoreNetworking.CloseP2PChannelWithUser // (Final|Native|Public|BlueprintCallable) // @ game+0x8de000
	bool AllowP2PPacketRelay(bool bAllow); // Function UWorksCore.UWorksInterfaceCoreNetworking.AllowP2PPacketRelay // (Final|Native|Public|BlueprintCallable) // @ game+0x8ddf00
	bool AcceptP2PSessionWithUser(struct FUWorksSteamID SteamIDRemote); // Function UWorksCore.UWorksInterfaceCoreNetworking.AcceptP2PSessionWithUser // (Final|Native|Public|BlueprintCallable) // @ game+0x8dd570
};

// Class UWorksCore.UWorksInterfaceCoreRemoteStorage
// Size: 0x28 (Inherited: 0x28)
struct UUWorksInterfaceCoreRemoteStorage : UUWorksInterfaceCore {

	bool SetSyncPlatforms(struct FString File, enum class EUWorksRemoteStoragePlatform RemoteStoragePlatform); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.SetSyncPlatforms // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8e40
	void SetCloudEnabledForApp(bool bEnabled); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.SetCloudEnabledForApp // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7740
	bool IsCloudEnabledForApp(); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.IsCloudEnabledForApp // (Final|Native|Public|BlueprintCallable) // @ game+0x8e70e0
	bool IsCloudEnabledForAccount(); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.IsCloudEnabledForAccount // (Final|Native|Public|BlueprintCallable) // @ game+0x8e70b0
	enum class EUWorksRemoteStoragePlatform GetSyncPlatforms(struct FString File); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.GetSyncPlatforms // (Final|Native|Public|BlueprintCallable) // @ game+0x8e6dc0
	struct UUWorksInterfaceCoreRemoteStorage* GetRemoteStorage(); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.GetRemoteStorage // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8e6c60
	bool GetQuota(struct FString TotalBytes, struct FString AvailableBytes); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.GetQuota // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e6b40
	int32_t GetFileTimestamp(struct FString File); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.GetFileTimestamp // (Final|Native|Public|BlueprintCallable) // @ game+0x8e5630
	int32_t GetFileSize(struct FString File); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.GetFileSize // (Final|Native|Public|BlueprintCallable) // @ game+0x8e5530
	struct FString GetFileNameAndSize(int32_t File, int32_t FileSizeInBytes); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.GetFileNameAndSize // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e5400
	int32_t GetFileCount(); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.GetFileCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8e53d0
	bool FileWriteStreamWriteChunk(struct FUWorksUGCFileWriteStreamHandle Handle, struct TArray<char> Buffer); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileWriteStreamWriteChunk // (Final|Native|Public|BlueprintCallable) // @ game+0x8e52a0
	struct FUWorksUGCFileWriteStreamHandle FileWriteStreamOpen(struct FString File); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileWriteStreamOpen // (Final|Native|Public|BlueprintCallable) // @ game+0x8e51b0
	bool FileWriteStreamClose(struct FUWorksUGCFileWriteStreamHandle Handle); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileWriteStreamClose // (Final|Native|Public|BlueprintCallable) // @ game+0x8e5120
	bool FileWriteStreamCancel(struct FUWorksUGCFileWriteStreamHandle Handle); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileWriteStreamCancel // (Final|Native|Public|BlueprintCallable) // @ game+0x8e5090
	void FileWriteAsyncMinimal(struct FDelegate Completed, struct FString File, struct TArray<char> Buffer); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileWriteAsyncMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e4eb0
	struct UUWorksRequestCoreFileWriteAsync* FileWriteAsync(); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileWriteAsync // (Final|Native|Public|BlueprintCallable) // @ game+0x8e4e80
	bool FileWrite(struct FString File, struct TArray<char> Buffer); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileWrite // (Final|Native|Public|BlueprintCallable) // @ game+0x8e4d00
	void FileReadAsyncMinimal(struct FDelegate Completed, struct FString File, int32_t Offset, int32_t BytesToRead); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileReadAsyncMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e4b40
	struct UUWorksRequestCoreFileReadAsync* FileReadAsync(); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileReadAsync // (Final|Native|Public|BlueprintCallable) // @ game+0x8e4b10
	int32_t FileRead(struct FString File, struct TArray<char> Buffer, int32_t BufferSize); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileRead // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e4980
	bool FilePersisted(struct FString File); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FilePersisted // (Final|Native|Public|BlueprintCallable) // @ game+0x8e4880
	bool FileForget(struct FString File); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileForget // (Final|Native|Public|BlueprintCallable) // @ game+0x8e4780
	bool FileExists(struct FString File); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileExists // (Final|Native|Public|BlueprintCallable) // @ game+0x8e4680
	bool FileDelete(struct FString File); // Function UWorksCore.UWorksInterfaceCoreRemoteStorage.FileDelete // (Final|Native|Public|BlueprintCallable) // @ game+0x8e4580
};

// Class UWorksCore.UWorksInterfaceCoreScreenshots
// Size: 0x48 (Inherited: 0x28)
struct UUWorksInterfaceCoreScreenshots : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate ScreenshotReady; // 0x28(0x10)
	struct FMulticastInlineDelegate ScreenshotRequested; // 0x38(0x10)

	struct FUWorksScreenshotHandle WriteScreenshot(struct UTexture2D* Image); // Function UWorksCore.UWorksInterfaceCoreScreenshots.WriteScreenshot // (Final|Native|Public|BlueprintCallable) // @ game+0x8e9f10
	void TriggerScreenshot(); // Function UWorksCore.UWorksInterfaceCoreScreenshots.TriggerScreenshot // (Final|Native|Public|BlueprintCallable) // @ game+0x8e9ac0
	bool TagUser(struct FUWorksScreenshotHandle Screenshot, struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksInterfaceCoreScreenshots.TagUser // (Final|Native|Public|BlueprintCallable) // @ game+0x8e99f0
	bool TagPublishedFile(struct FUWorksScreenshotHandle Screenshot, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksInterfaceCoreScreenshots.TagPublishedFile // (Final|Native|Public|BlueprintCallable) // @ game+0x8e9920
	bool SetLocation(struct FUWorksScreenshotHandle Screenshot, struct FString Location); // Function UWorksCore.UWorksInterfaceCoreScreenshots.SetLocation // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8480
	bool IsScreenshotsHooked(); // Function UWorksCore.UWorksInterfaceCoreScreenshots.IsScreenshotsHooked // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7110
	void HookScreenshots(bool bHook); // Function UWorksCore.UWorksInterfaceCoreScreenshots.HookScreenshots // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7020
	struct UUWorksInterfaceCoreScreenshots* GetScreenshots(); // Function UWorksCore.UWorksInterfaceCoreScreenshots.GetScreenshots // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8e6c90
	struct FUWorksScreenshotHandle AddVRScreenshotToLibrary(enum class EUWorksVRScreenshotType Type, struct FString Filename, struct FString VRFileName); // Function UWorksCore.UWorksInterfaceCoreScreenshots.AddVRScreenshotToLibrary // (Final|Native|Public|BlueprintCallable) // @ game+0x8e3b40
	struct FUWorksScreenshotHandle AddScreenshotToLibrary(struct FString FileMame, struct FString ThumbnailFileName, int32_t Width, int32_t Height); // Function UWorksCore.UWorksInterfaceCoreScreenshots.AddScreenshotToLibrary // (Final|Native|Public|BlueprintCallable) // @ game+0x8e3940
};

// Class UWorksCore.UWorksInterfaceCoreUGC
// Size: 0x48 (Inherited: 0x28)
struct UUWorksInterfaceCoreUGC : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate ItemInstalled; // 0x28(0x10)
	struct FMulticastInlineDelegate DownloadItemResult; // 0x38(0x10)

	bool UpdateItemPreviewVideo(struct FUWorksUGCUpdateHandle Handle, int32_t Index, struct FString PreviewVideo); // Function UWorksCore.UWorksInterfaceCoreUGC.UpdateItemPreviewVideo // (Final|Native|Public|BlueprintCallable) // @ game+0x8e9d90
	bool UpdateItemPreviewFile(struct FUWorksUGCUpdateHandle Handle, int32_t Index, struct FString PreviewFile); // Function UWorksCore.UWorksInterfaceCoreUGC.UpdateItemPreviewFile // (Final|Native|Public|BlueprintCallable) // @ game+0x8e9c10
	void UnsubscribeItemMinimal(struct FDelegate Completed, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksInterfaceCoreUGC.UnsubscribeItemMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e9b10
	struct UUWorksRequestCoreUnsubscribeItem* UnsubscribeItem(); // Function UWorksCore.UWorksInterfaceCoreUGC.UnsubscribeItem // (Final|Native|Public|BlueprintCallable) // @ game+0x8e9ae0
	void SuspendDownloads(bool bSuspend); // Function UWorksCore.UWorksInterfaceCoreUGC.SuspendDownloads // (Final|Native|Public|BlueprintCallable) // @ game+0x8e9890
	void SubscribeItemMinimal(struct FDelegate Completed, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksInterfaceCoreUGC.SubscribeItemMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e9790
	struct UUWorksRequestCoreSubscribeItem* SubscribeItem(); // Function UWorksCore.UWorksInterfaceCoreUGC.SubscribeItem // (Final|Native|Public|BlueprintCallable) // @ game+0x8e9760
	void SubmitItemUpdateMinimal(struct FDelegate Completed, struct FUWorksUGCUpdateHandle UGCUpdateHandle, struct FString ChangeNote); // Function UWorksCore.UWorksInterfaceCoreUGC.SubmitItemUpdateMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e95d0
	struct UUWorksRequestCoreSubmitItemUpdate* SubmitItemUpdate(); // Function UWorksCore.UWorksInterfaceCoreUGC.SubmitItemUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x8e95a0
	void StopPlaytimeTrackingMinimal(struct FDelegate Completed, struct TArray<struct FUWorksPublishedFileID> PublishedFileIDs); // Function UWorksCore.UWorksInterfaceCoreUGC.StopPlaytimeTrackingMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e9440
	void StopPlaytimeTrackingForAllItemsMinimal(struct FDelegate Completed); // Function UWorksCore.UWorksInterfaceCoreUGC.StopPlaytimeTrackingForAllItemsMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e9390
	struct UUWorksRequestCoreStopPlaytimeTrackingForAllItems* StopPlaytimeTrackingForAllItems(); // Function UWorksCore.UWorksInterfaceCoreUGC.StopPlaytimeTrackingForAllItems // (Final|Native|Public|BlueprintCallable) // @ game+0x8e9360
	struct UUWorksRequestCoreStopPlaytimeTracking* StopPlaytimeTracking(); // Function UWorksCore.UWorksInterfaceCoreUGC.StopPlaytimeTracking // (Final|Native|Public|BlueprintCallable) // @ game+0x8e9330
	void StartPlaytimeTrackingMinimal(struct FDelegate Completed, struct TArray<struct FUWorksPublishedFileID> PublishedFileID); // Function UWorksCore.UWorksInterfaceCoreUGC.StartPlaytimeTrackingMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e91d0
	struct UUWorksRequestCoreStartPlaytimeTracking* StartPlaytimeTracking(); // Function UWorksCore.UWorksInterfaceCoreUGC.StartPlaytimeTracking // (Final|Native|Public|BlueprintCallable) // @ game+0x8e91a0
	struct FUWorksUGCUpdateHandle StartItemUpdate(int32_t ConsumerAppID, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksInterfaceCoreUGC.StartItemUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x8e90d0
	void SetUserItemVoteMinimal(struct FDelegate Completed, struct FUWorksPublishedFileID PublishedFileID, bool bVoteUp); // Function UWorksCore.UWorksInterfaceCoreUGC.SetUserItemVoteMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e8fa0
	struct UUWorksRequestCoreSetUserItemVote* SetUserItemVote(); // Function UWorksCore.UWorksInterfaceCoreUGC.SetUserItemVote // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8f70
	bool SetSearchText(struct FUWorksUGCQueryHandle Handle, struct FString SearchText); // Function UWorksCore.UWorksInterfaceCoreUGC.SetSearchText // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8d00
	bool SetReturnTotalOnly(struct FUWorksUGCQueryHandle Handle, bool bReturnTotalOnly); // Function UWorksCore.UWorksInterfaceCoreUGC.SetReturnTotalOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8c30
	bool SetReturnOnlyIDs(struct FUWorksUGCQueryHandle Handle, bool bReturnOnlyIDs); // Function UWorksCore.UWorksInterfaceCoreUGC.SetReturnOnlyIDs // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8b60
	bool SetReturnMetadata(struct FUWorksUGCQueryHandle Handle, bool bReturnMetadata); // Function UWorksCore.UWorksInterfaceCoreUGC.SetReturnMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8a90
	bool SetReturnLongDescription(struct FUWorksUGCQueryHandle Handle, bool bReturnLongDescription); // Function UWorksCore.UWorksInterfaceCoreUGC.SetReturnLongDescription // (Final|Native|Public|BlueprintCallable) // @ game+0x8e89c0
	bool SetReturnKeyValueTags(struct FUWorksUGCQueryHandle Handle, bool bReturnKeyValueTags); // Function UWorksCore.UWorksInterfaceCoreUGC.SetReturnKeyValueTags // (Final|Native|Public|BlueprintCallable) // @ game+0x8e88f0
	bool SetReturnChildren(struct FUWorksUGCQueryHandle Handle, bool bReturnChildren); // Function UWorksCore.UWorksInterfaceCoreUGC.SetReturnChildren // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8820
	bool SetReturnAdditionalPreviews(struct FUWorksUGCQueryHandle Handle, bool bReturnAdditionalPreviews); // Function UWorksCore.UWorksInterfaceCoreUGC.SetReturnAdditionalPreviews // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8750
	bool SetRankedByTrendDays(struct FUWorksUGCQueryHandle Handle, int32_t Days); // Function UWorksCore.UWorksInterfaceCoreUGC.SetRankedByTrendDays // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8680
	bool SetMatchAnyTag(struct FUWorksUGCQueryHandle Handle, bool bMatchAnyTag); // Function UWorksCore.UWorksInterfaceCoreUGC.SetMatchAnyTag // (Final|Native|Public|BlueprintCallable) // @ game+0x8e85b0
	bool SetLanguage(struct FUWorksUGCQueryHandle Handle, struct FString Language); // Function UWorksCore.UWorksInterfaceCoreUGC.SetLanguage // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8340
	bool SetItemVisibility(struct FUWorksUGCUpdateHandle Handle, enum class EUWorksRemoteStoragePublishedFileVisibility Visibility); // Function UWorksCore.UWorksInterfaceCoreUGC.SetItemVisibility // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8260
	bool SetItemUpdateLanguage(struct FUWorksUGCUpdateHandle Handle, struct FString Language); // Function UWorksCore.UWorksInterfaceCoreUGC.SetItemUpdateLanguage // (Final|Native|Public|BlueprintCallable) // @ game+0x8e8120
	bool SetItemTitle(struct FUWorksUGCUpdateHandle Handle, struct FString Title); // Function UWorksCore.UWorksInterfaceCoreUGC.SetItemTitle // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7fe0
	bool SetItemTags(struct FUWorksUGCUpdateHandle Handle, struct TArray<struct FString> Tags); // Function UWorksCore.UWorksInterfaceCoreUGC.SetItemTags // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7e10
	bool SetItemPreview(struct FUWorksUGCUpdateHandle Handle, struct FString PreviewFile); // Function UWorksCore.UWorksInterfaceCoreUGC.SetItemPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7cd0
	bool SetItemMetadata(struct FUWorksUGCUpdateHandle Handle, struct FString MetaData); // Function UWorksCore.UWorksInterfaceCoreUGC.SetItemMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7b90
	bool SetItemDescription(struct FUWorksUGCUpdateHandle Handle, struct FString Description); // Function UWorksCore.UWorksInterfaceCoreUGC.SetItemDescription // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7a50
	bool SetItemContent(struct FUWorksUGCUpdateHandle Handle, struct FString ContentFolder); // Function UWorksCore.UWorksInterfaceCoreUGC.SetItemContent // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7910
	bool SetCloudFileNameFilter(struct FUWorksUGCQueryHandle Handle, struct FString MatchCloudFileName); // Function UWorksCore.UWorksInterfaceCoreUGC.SetCloudFileNameFilter // (Final|Native|Public|BlueprintCallable) // @ game+0x8e77d0
	bool SetAllowCachedResponse(struct FUWorksUGCQueryHandle Handle, int32_t MaxAgeSeconds); // Function UWorksCore.UWorksInterfaceCoreUGC.SetAllowCachedResponse // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7670
	void SendQueryUGCRequestMinimal(struct FDelegate Completed, struct FUWorksUGCQueryHandle UGCQueryHandle); // Function UWorksCore.UWorksInterfaceCoreUGC.SendQueryUGCRequestMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e7570
	struct UUWorksRequestCoreSendQueryUGCRequest* SendQueryUGCRequest(); // Function UWorksCore.UWorksInterfaceCoreUGC.SendQueryUGCRequest // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7540
	bool RemoveItemPreview(struct FUWorksUGCUpdateHandle Handle, int32_t Index); // Function UWorksCore.UWorksInterfaceCoreUGC.RemoveItemPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7470
	bool RemoveItemKeyValueTags(struct FUWorksUGCUpdateHandle Handle, struct FString Key); // Function UWorksCore.UWorksInterfaceCoreUGC.RemoveItemKeyValueTags // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7330
	void RemoveItemFromFavoritesMinimal(struct FDelegate Completed, int32_t AppID, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksInterfaceCoreUGC.RemoveItemFromFavoritesMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e7200
	struct UUWorksRequestCoreRemoveItemFromFavorites* RemoveItemFromFavorites(); // Function UWorksCore.UWorksInterfaceCoreUGC.RemoveItemFromFavorites // (Final|Native|Public|BlueprintCallable) // @ game+0x8e71d0
	bool ReleaseQueryUGCRequest(struct FUWorksUGCQueryHandle Handle); // Function UWorksCore.UWorksInterfaceCoreUGC.ReleaseQueryUGCRequest // (Final|Native|Public|BlueprintCallable) // @ game+0x8e7140
	void GetUserItemVoteMinimal(struct FDelegate Completed, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksInterfaceCoreUGC.GetUserItemVoteMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e6f20
	struct UUWorksRequestCoreGetUserItemVote* GetUserItemVote(); // Function UWorksCore.UWorksInterfaceCoreUGC.GetUserItemVote // (Final|Native|Public|BlueprintCallable) // @ game+0x8e6ef0
	struct UUWorksInterfaceCoreUGC* GetUGC(); // Function UWorksCore.UWorksInterfaceCoreUGC.GetUGC // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8e6ec0
	int32_t GetSubscribedItems(struct TArray<struct FUWorksPublishedFileID> PublishedFileIDs, int32_t MaxEntries); // Function UWorksCore.UWorksInterfaceCoreUGC.GetSubscribedItems // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e6cc0
	bool GetQueryUGCStatistic(struct FUWorksUGCQueryHandle Handle, int32_t Index, enum class EUWorksItemStatistic StatType, struct FString StatValue); // Function UWorksCore.UWorksInterfaceCoreUGC.GetQueryUGCStatistic // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e69c0
	bool GetQueryUGCResult(struct FUWorksUGCQueryHandle Handle, int32_t Index, struct FUWorksSteamUGCDetails Details); // Function UWorksCore.UWorksInterfaceCoreUGC.GetQueryUGCResult // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e6800
	bool GetQueryUGCPreviewURL(struct FUWorksUGCQueryHandle Handle, int32_t Index, struct FString URL, int32_t URLMaxLength); // Function UWorksCore.UWorksInterfaceCoreUGC.GetQueryUGCPreviewURL // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e6670
	int32_t GetQueryUGCNumKeyValueTags(struct FUWorksUGCQueryHandle Handle, int32_t Index); // Function UWorksCore.UWorksInterfaceCoreUGC.GetQueryUGCNumKeyValueTags // (Final|Native|Public|BlueprintCallable) // @ game+0x8e65a0
	int32_t GetQueryUGCNumAdditionalPreviews(struct FUWorksUGCQueryHandle Handle, int32_t Index); // Function UWorksCore.UWorksInterfaceCoreUGC.GetQueryUGCNumAdditionalPreviews // (Final|Native|Public|BlueprintCallable) // @ game+0x8e64d0
	bool GetQueryUGCMetadata(struct FUWorksUGCQueryHandle Handle, int32_t Index, struct FString MetaData, int32_t MetadataMaxLength); // Function UWorksCore.UWorksInterfaceCoreUGC.GetQueryUGCMetadata // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e6340
	bool GetQueryUGCKeyValueTag(struct FUWorksUGCQueryHandle Handle, int32_t Index, int32_t KeyValueTagIndex, struct FString Key, int32_t KeyMaxLength, struct FString Value, int32_t ValueMaxLength); // Function UWorksCore.UWorksInterfaceCoreUGC.GetQueryUGCKeyValueTag // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e60e0
	bool GetQueryUGCChildren(struct FUWorksUGCQueryHandle Handle, int32_t Index, struct TArray<struct FUWorksPublishedFileID> PublishedFileIDs, int32_t MaxEntries); // Function UWorksCore.UWorksInterfaceCoreUGC.GetQueryUGCChildren // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e5f50
	bool GetQueryUGCAdditionalPreview(struct FUWorksUGCQueryHandle Handle, int32_t Index, int32_t PreviewIndex, struct FString URLOrVideoID, int32_t URLOrVideoIDMaxLength, struct FString OriginalFileName, int32_t OriginalFileNameMaxLength, enum class EUWorksItemPreviewType PreviewType); // Function UWorksCore.UWorksInterfaceCoreUGC.GetQueryUGCAdditionalPreview // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e5ca0
	int32_t GetNumSubscribedItems(); // Function UWorksCore.UWorksInterfaceCoreUGC.GetNumSubscribedItems // (Final|Native|Public|BlueprintCallable) // @ game+0x8e5c70
	enum class EUWorksItemUpdateStatus GetItemUpdateProgress(struct FUWorksUGCUpdateHandle Handle, struct FString BytesProcessed, struct FString BytesTotal); // Function UWorksCore.UWorksInterfaceCoreUGC.GetItemUpdateProgress // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e5b10
	int32_t GetItemState(struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksInterfaceCoreUGC.GetItemState // (Final|Native|Public|BlueprintCallable) // @ game+0x8e5a70
	bool GetItemInstallInfo(struct FUWorksPublishedFileID PublishedFileID, struct FString SizeOnDisk, struct FString Path, int32_t PathMaxLength, int32_t Timestamp); // Function UWorksCore.UWorksInterfaceCoreUGC.GetItemInstallInfo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e5890
	bool GetItemDownloadInfo(struct FUWorksPublishedFileID PublishedFileID, struct FString BytesDownloaded, struct FString BytesTotal); // Function UWorksCore.UWorksInterfaceCoreUGC.GetItemDownloadInfo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e5730
	bool DownloadItem(struct FUWorksPublishedFileID PublishedFileID, bool bHighPriority); // Function UWorksCore.UWorksInterfaceCoreUGC.DownloadItem // (Final|Native|Public|BlueprintCallable) // @ game+0x8e44b0
	struct FUWorksUGCQueryHandle CreateQueryUserUGCRequest(struct FUWorksSteamID SteamID, enum class EUWorksUserUGCList ListType, enum class EUWorksUGCMatchingUGCType MatchingUGCType, enum class EUWorksUserUGCListSortOrder SortOrder, int32_t CreatorAppID, int32_t ConsumerAppID, int32_t Page); // Function UWorksCore.UWorksInterfaceCoreUGC.CreateQueryUserUGCRequest // (Final|Native|Public|BlueprintCallable) // @ game+0x8e4290
	struct FUWorksUGCQueryHandle CreateQueryUGCDetailsRequest(struct TArray<struct FUWorksPublishedFileID> PublishedFileIDs, int32_t NumPublishedFileIDs); // Function UWorksCore.UWorksInterfaceCoreUGC.CreateQueryUGCDetailsRequest // (Final|Native|Public|BlueprintCallable) // @ game+0x8e4150
	struct FUWorksUGCQueryHandle CreateQueryAllUGCRequest(enum class EUWorksUGCQuery QueryType, enum class EUWorksUGCMatchingUGCType MatchingUGCTypeFileType, int32_t CreatorAppID, int32_t ConsumerAppID, int32_t Page); // Function UWorksCore.UWorksInterfaceCoreUGC.CreateQueryAllUGCRequest // (Final|Native|Public|BlueprintCallable) // @ game+0x8e3f90
	void CreateItemMinimal(struct FDelegate Completed, int32_t ConsumerAppID, enum class EUWorksWorkshopFileType FileType); // Function UWorksCore.UWorksInterfaceCoreUGC.CreateItemMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e3e60
	struct UUWorksRequestCoreCreateItem* CreateItem(); // Function UWorksCore.UWorksInterfaceCoreUGC.CreateItem // (Final|Native|Public|BlueprintCallable) // @ game+0x8e3e30
	bool BInitWorkshopForGameServer(int32_t WorkshopDepotID, struct FString Folder); // Function UWorksCore.UWorksInterfaceCoreUGC.BInitWorkshopForGameServer // (Final|Native|Public|BlueprintCallable) // @ game+0x8e3d00
	bool AddRequiredTag(struct FUWorksUGCQueryHandle Handle, struct FString TagName); // Function UWorksCore.UWorksInterfaceCoreUGC.AddRequiredTag // (Final|Native|Public|BlueprintCallable) // @ game+0x8e3800
	bool AddRequiredKeyValueTag(struct FUWorksUGCQueryHandle Handle, struct FString Key, struct FString Value); // Function UWorksCore.UWorksInterfaceCoreUGC.AddRequiredKeyValueTag // (Final|Native|Public|BlueprintCallable) // @ game+0x8e3640
	void AddItemToFavoritesMinimal(struct FDelegate Completed, int32_t AppID, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksInterfaceCoreUGC.AddItemToFavoritesMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8e3510
	struct UUWorksRequestCoreAddItemToFavorites* AddItemToFavorites(); // Function UWorksCore.UWorksInterfaceCoreUGC.AddItemToFavorites // (Final|Native|Public|BlueprintCallable) // @ game+0x8e34e0
	bool AddItemPreviewVideo(struct FUWorksUGCUpdateHandle Handle, struct FString VideoID); // Function UWorksCore.UWorksInterfaceCoreUGC.AddItemPreviewVideo // (Final|Native|Public|BlueprintCallable) // @ game+0x8e33a0
	bool AddItemPreviewFile(struct FUWorksUGCUpdateHandle Handle, struct FString PreviewFile, enum class EUWorksItemPreviewType Type); // Function UWorksCore.UWorksInterfaceCoreUGC.AddItemPreviewFile // (Final|Native|Public|BlueprintCallable) // @ game+0x8e3220
	bool AddItemKeyValueTag(struct FUWorksUGCUpdateHandle Handle, struct FString Key, struct FString Value); // Function UWorksCore.UWorksInterfaceCoreUGC.AddItemKeyValueTag // (Final|Native|Public|BlueprintCallable) // @ game+0x8e3060
	bool AddExcludedTag(struct FUWorksUGCQueryHandle Handle, struct FString TagName); // Function UWorksCore.UWorksInterfaceCoreUGC.AddExcludedTag // (Final|Native|Public|BlueprintCallable) // @ game+0x8e2f20
};

// Class UWorksCore.UWorksInterfaceCoreUser
// Size: 0xd8 (Inherited: 0x28)
struct UUWorksInterfaceCoreUser : UUWorksInterfaceCore {
	char pad_28[0x10]; // 0x28(0x10)
	struct FMulticastInlineDelegate SteamServersConnected; // 0x38(0x10)
	struct FMulticastInlineDelegate SteamServerConnectFailure; // 0x48(0x10)
	struct FMulticastInlineDelegate SteamServersDisconnected; // 0x58(0x10)
	struct FMulticastInlineDelegate ClientGameServerDeny; // 0x68(0x10)
	struct FMulticastInlineDelegate IPCFailure; // 0x78(0x10)
	struct FMulticastInlineDelegate LicensesUpdated; // 0x88(0x10)
	struct FMulticastInlineDelegate ValidateAuthTicketResponse; // 0x98(0x10)
	struct FMulticastInlineDelegate MicroTxnAuthorizationResponse; // 0xa8(0x10)
	struct FMulticastInlineDelegate GetAuthSessionTicketResponse; // 0xb8(0x10)
	struct FMulticastInlineDelegate GameWebCallback; // 0xc8(0x10)

	enum class EUWorksUserHasLicenseForAppResult UserHasLicenseForApp(struct FUWorksSteamID SteamID, int32_t AppID); // Function UWorksCore.UWorksInterfaceCoreUser.UserHasLicenseForApp // (Final|Native|Public|BlueprintCallable) // @ game+0x8ef780
	void StopVoiceRecording(); // Function UWorksCore.UWorksInterfaceCoreUser.StopVoiceRecording // (Final|Native|Public|BlueprintCallable) // @ game+0x8ef370
	void StartVoiceRecording(); // Function UWorksCore.UWorksInterfaceCoreUser.StartVoiceRecording // (Final|Native|Public|BlueprintCallable) // @ game+0x8ef350
	void RequestStoreAuthURLMinimal(struct FDelegate Completed, struct FString URL); // Function UWorksCore.UWorksInterfaceCoreUser.RequestStoreAuthURLMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8eecc0
	struct UUWorksRequestCoreRequestStoreAuthURL* RequestStoreAuthURL(); // Function UWorksCore.UWorksInterfaceCoreUser.RequestStoreAuthURL // (Final|Native|Public|BlueprintCallable) // @ game+0x8eec90
	void RequestEncryptedAppTicketMinimal(struct FDelegate Completed, struct TArray<char> Buffer); // Function UWorksCore.UWorksInterfaceCoreUser.RequestEncryptedAppTicketMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ee920
	struct UUWorksRequestCoreRequestEncryptedAppTicket* RequestEncryptedAppTicket(); // Function UWorksCore.UWorksInterfaceCoreUser.RequestEncryptedAppTicket // (Final|Native|Public|BlueprintCallable) // @ game+0x8ee8f0
	struct UAudioComponent* GetVoiceChannel(int32_t Index); // Function UWorksCore.UWorksInterfaceCoreUser.GetVoiceChannel // (Final|Native|Public|BlueprintCallable) // @ game+0x8ee6b0
	enum class EUWorksVoiceResult GetVoice(struct TArray<char> Data); // Function UWorksCore.UWorksInterfaceCoreUser.GetVoice // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ee5f0
	struct UUWorksInterfaceCoreUser* GetUser(); // Function UWorksCore.UWorksInterfaceCoreUser.GetUser // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8edf10
	struct FUWorksSteamID GetSteamID(); // Function UWorksCore.UWorksInterfaceCoreUser.GetSteamID // (Final|Native|Public|BlueprintCallable) // @ game+0x8eded0
	int32_t GetPlayerSteamLevel(); // Function UWorksCore.UWorksInterfaceCoreUser.GetPlayerSteamLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x8edc00
	struct FUWorksSteamUser GetHSteamUser(); // Function UWorksCore.UWorksInterfaceCoreUser.GetHSteamUser // (Final|Native|Public|BlueprintCallable) // @ game+0x8ed480
	int32_t GetGameBadgeLevel(int32_t Series, bool bFoil); // Function UWorksCore.UWorksInterfaceCoreUser.GetGameBadgeLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x8ecd90
	bool GetEncryptedAppTicket(struct TArray<char> Ticket); // Function UWorksCore.UWorksInterfaceCoreUser.GetEncryptedAppTicket // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8eccd0
	struct FUWorksTicketHandle GetAuthSessionTicket(struct TArray<char> Ticket); // Function UWorksCore.UWorksInterfaceCoreUser.GetAuthSessionTicket // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8eca10
	void EndAuthSession(struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksInterfaceCoreUser.EndAuthSession // (Final|Native|Public|BlueprintCallable) // @ game+0x8ebe70
	enum class EUWorksVoiceResult DecompressVoice(struct TArray<char> CompressedBuffer, struct TArray<char> UncompressedBuffer); // Function UWorksCore.UWorksInterfaceCoreUser.DecompressVoice // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8eb960
	void CancelAuthTicket(struct FUWorksTicketHandle TicketHandle); // Function UWorksCore.UWorksInterfaceCoreUser.CancelAuthTicket // (Final|Native|Public|BlueprintCallable) // @ game+0x8eb7e0
	bool BLoggedOn(); // Function UWorksCore.UWorksInterfaceCoreUser.BLoggedOn // (Final|Native|Public|BlueprintCallable) // @ game+0x8eb680
	bool BIsTwoFactorEnabled(); // Function UWorksCore.UWorksInterfaceCoreUser.BIsTwoFactorEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x8eb650
	bool BIsPhoneVerified(); // Function UWorksCore.UWorksInterfaceCoreUser.BIsPhoneVerified // (Final|Native|Public|BlueprintCallable) // @ game+0x8eb620
	bool BIsPhoneRequiringVerification(); // Function UWorksCore.UWorksInterfaceCoreUser.BIsPhoneRequiringVerification // (Final|Native|Public|BlueprintCallable) // @ game+0x8eb5f0
	bool BIsPhoneIdentifying(); // Function UWorksCore.UWorksInterfaceCoreUser.BIsPhoneIdentifying // (Final|Native|Public|BlueprintCallable) // @ game+0x8eb5c0
	bool BIsBehindNAT(); // Function UWorksCore.UWorksInterfaceCoreUser.BIsBehindNAT // (Final|Native|Public|BlueprintCallable) // @ game+0x8eb590
	enum class EUWorksBeginAuthSessionResult BeginAuthSession(struct TArray<char> Ticket, struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksInterfaceCoreUser.BeginAuthSession // (Final|Native|Public|BlueprintCallable) // @ game+0x8eb6b0
	void AdvertiseGame(struct FUWorksSteamID SteamIDGameServer, struct FString ServerIP, int32_t ServerPort); // Function UWorksCore.UWorksInterfaceCoreUser.AdvertiseGame // (Final|Native|Public|BlueprintCallable) // @ game+0x8eb2c0
	struct UAudioComponent* AddBufferToVoiceChannel(struct TArray<char> Buffer, int32_t Index); // Function UWorksCore.UWorksInterfaceCoreUser.AddBufferToVoiceChannel // (Final|Native|Public|BlueprintCallable) // @ game+0x8eb190
};

// Class UWorksCore.UWorksInterfaceCoreUserStats
// Size: 0x78 (Inherited: 0x28)
struct UUWorksInterfaceCoreUserStats : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate UserStatsReceived; // 0x28(0x10)
	struct FMulticastInlineDelegate UserStatsStored; // 0x38(0x10)
	struct FMulticastInlineDelegate UserAchievementStored; // 0x48(0x10)
	struct FMulticastInlineDelegate UserStatsUnloaded; // 0x58(0x10)
	struct FMulticastInlineDelegate UserAchievementIconFetched; // 0x68(0x10)

	void UploadLeaderboardScoreMinimal(struct FDelegate Completed, struct FUWorksSteamLeaderboard SteamLeaderboard, enum class EUWorksLeaderboardUploadScoreMethod LeaderboardUploadScoreMethod, int32_t Score, struct TArray<int32_t> ScoreDetails); // Function UWorksCore.UWorksInterfaceCoreUserStats.UploadLeaderboardScoreMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ef570
	struct UUWorksRequestCoreUploadLeaderboardScore* UploadLeaderboardScore(); // Function UWorksCore.UWorksInterfaceCoreUserStats.UploadLeaderboardScore // (Final|Native|Public|BlueprintCallable) // @ game+0x8ef540
	bool UpdateAvgRateStat(struct FString Name, float CountThisSession, float SessionLength); // Function UWorksCore.UWorksInterfaceCoreUserStats.UpdateAvgRateStat // (Final|Native|Public|BlueprintCallable) // @ game+0x8ef3c0
	bool StoreStats(); // Function UWorksCore.UWorksInterfaceCoreUserStats.StoreStats // (Final|Native|Public|BlueprintCallable) // @ game+0x8ef390
	bool SetStatAsInteger(struct FString Name, int32_t Data); // Function UWorksCore.UWorksInterfaceCoreUserStats.SetStatAsInteger // (Final|Native|Public|BlueprintCallable) // @ game+0x8ef220
	bool SetStatAsFloat(struct FString Name, float Data); // Function UWorksCore.UWorksInterfaceCoreUserStats.SetStatAsFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x8ef0f0
	bool SetAchievement(struct FString Name); // Function UWorksCore.UWorksInterfaceCoreUserStats.SetAchievement // (Final|Native|Public|BlueprintCallable) // @ game+0x8eeff0
	bool ResetAllStats(bool bAchievementsToo); // Function UWorksCore.UWorksInterfaceCoreUserStats.ResetAllStats // (Final|Native|Public|BlueprintCallable) // @ game+0x8eef50
	void RequestUserStatsMinimal(struct FDelegate Completed, struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksInterfaceCoreUserStats.RequestUserStatsMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8eee50
	struct UUWorksRequestCoreRequestUserStats* RequestUserStats(); // Function UWorksCore.UWorksInterfaceCoreUserStats.RequestUserStats // (Final|Native|Public|BlueprintCallable) // @ game+0x8eee20
	void RequestGlobalStatsMinimal(struct FDelegate Completed, int32_t HistoryDays); // Function UWorksCore.UWorksInterfaceCoreUserStats.RequestGlobalStatsMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8eeb90
	struct UUWorksRequestCoreRequestGlobalStats* RequestGlobalStats(); // Function UWorksCore.UWorksInterfaceCoreUserStats.RequestGlobalStats // (Final|Native|Public|BlueprintCallable) // @ game+0x8eeb60
	void RequestGlobalAchievementPercentagesMinimal(struct FDelegate Completed); // Function UWorksCore.UWorksInterfaceCoreUserStats.RequestGlobalAchievementPercentagesMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8eeab0
	struct UUWorksRequestCoreRequestGlobalAchievementPercentages* RequestGlobalAchievementPercentages(); // Function UWorksCore.UWorksInterfaceCoreUserStats.RequestGlobalAchievementPercentages // (Final|Native|Public|BlueprintCallable) // @ game+0x8eea80
	bool RequestCurrentStats(); // Function UWorksCore.UWorksInterfaceCoreUserStats.RequestCurrentStats // (Final|Native|Public|BlueprintCallable) // @ game+0x8ee8c0
	bool IndicateAchievementProgress(struct FString Name, int32_t CurrentProgress, int32_t MaxProgress); // Function UWorksCore.UWorksInterfaceCoreUserStats.IndicateAchievementProgress // (Final|Native|Public|BlueprintCallable) // @ game+0x8ee750
	struct UUWorksInterfaceCoreUserStats* GetUserStats(); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetUserStats // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8ee5c0
	bool GetUserStatInteger(struct FUWorksSteamID SteamIDUser, struct FString Name, int32_t Data); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetUserStatInteger // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ee430
	bool GetUserStatFloat(struct FUWorksSteamID SteamIDUser, struct FString Name, float Data); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetUserStatFloat // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ee2a0
	bool GetUserAchievementAndUnlockTime(struct FUWorksSteamID SteamIDUser, struct FString Name, bool bAchieved, int32_t UnlockTime); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetUserAchievementAndUnlockTime // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ee0d0
	bool GetUserAchievement(struct FUWorksSteamID SteamIDUser, struct FString Name, bool bAchieved); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetUserAchievement // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8edf40
	bool GetStatAsInteger(struct FString Name, int32_t Data); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetStatAsInteger // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8edd80
	bool GetStatAsFloat(struct FString Name, float Data); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetStatAsFloat // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8edc30
	void GetNumberOfCurrentPlayersMinimal(struct FDelegate Completed); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetNumberOfCurrentPlayersMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8edb50
	struct UUWorksRequestCoreGetNumberOfCurrentPlayers* GetNumberOfCurrentPlayers(); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetNumberOfCurrentPlayers // (Final|Native|Public|BlueprintCallable) // @ game+0x8edb20
	int32_t GetNumAchievements(); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetNumAchievements // (Final|Native|Public|BlueprintCallable) // @ game+0x8edaf0
	int32_t GetNextMostAchievedAchievementInfo(int32_t IteratorPrevious, struct FString Name, int32_t NameBufferLength, float Percent, bool bAchieved); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetNextMostAchievedAchievementInfo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ed8e0
	int32_t GetMostAchievedAchievementInfo(struct FString Name, int32_t NameBufferLength, float Percent, bool bAchieved); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetMostAchievedAchievementInfo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ed720
	enum class EUWorksLeaderboardSortMethod GetLeaderboardSortMethod(struct FUWorksSteamLeaderboard SteamLeaderboard); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetLeaderboardSortMethod // (Final|Native|Public|BlueprintCallable) // @ game+0x8ed690
	struct FString GetLeaderboardName(struct FUWorksSteamLeaderboard SteamLeaderboard); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetLeaderboardName // (Final|Native|Public|BlueprintCallable) // @ game+0x8ed5e0
	int32_t GetLeaderboardEntryCount(struct FUWorksSteamLeaderboard SteamLeaderboard); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetLeaderboardEntryCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8ed550
	enum class EUWorksLeaderboardDisplayType GetLeaderboardDisplayType(struct FUWorksSteamLeaderboard SteamLeaderboard); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetLeaderboardDisplayType // (Final|Native|Public|BlueprintCallable) // @ game+0x8ed4c0
	int32_t GetGlobalStatHistoryFromIntegers(struct FString StatName, struct TArray<struct FString> Data, int32_t HistoryDays); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetGlobalStatHistoryFromIntegers // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ed2d0
	int32_t GetGlobalStatHistoryFromFloats(struct FString StatName, struct TArray<struct FString> Data, int32_t HistoryDays); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetGlobalStatHistoryFromFloats // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ed120
	bool GetGlobalStatFromInteger(struct FString StatName, struct FString Data); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetGlobalStatFromInteger // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ecfc0
	bool GetGlobalStatFromFloat(struct FString StatName, struct FString Data); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetGlobalStatFromFloat // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ece60
	bool GetDownloadedLeaderboardEntry(struct FUWorksSteamLeaderboardEntries SteamLeaderboardEntries, int32_t Index, struct FUWorksLeaderboardEntry LeaderboardEntry, struct TArray<int32_t> Details, int32_t DetailsMax); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetDownloadedLeaderboardEntry // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ecad0
	struct FString GetAchievementName(int32_t Achievement); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetAchievementName // (Final|Native|Public|BlueprintCallable) // @ game+0x8ec960
	struct UTexture2D* GetAchievementIcon(struct FString Name); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetAchievementIcon // (Final|Native|Public|BlueprintCallable) // @ game+0x8ec860
	struct FString GetAchievementDisplayAttribute(struct FString Name, struct FString Key); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetAchievementDisplayAttribute // (Final|Native|Public|BlueprintCallable) // @ game+0x8ec6d0
	bool GetAchievementAndUnlockTime(struct FString Name, bool bAchieved, int32_t UnlockTime); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetAchievementAndUnlockTime // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ec520
	bool GetAchievementAchievedPercent(struct FString Name, float Percent); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetAchievementAchievedPercent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ec3d0
	bool GetAchievement(struct FString Name, bool bAchieved); // Function UWorksCore.UWorksInterfaceCoreUserStats.GetAchievement // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ec280
	void FindOrCreateLeaderboardMinimal(struct FDelegate Completed, struct FString LeaderboardName, enum class EUWorksLeaderboardSortMethod LeaderboardSortMethod, enum class EUWorksLeaderboardDisplayType LeaderboardDisplayType); // Function UWorksCore.UWorksInterfaceCoreUserStats.FindOrCreateLeaderboardMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ec0c0
	struct UUWorksRequestCoreFindOrCreateLeaderboard* FindOrCreateLeaderboard(); // Function UWorksCore.UWorksInterfaceCoreUserStats.FindOrCreateLeaderboard // (Final|Native|Public|BlueprintCallable) // @ game+0x8ec090
	void FindLeaderboardMinimal(struct FDelegate Completed, struct FString LeaderboardName); // Function UWorksCore.UWorksInterfaceCoreUserStats.FindLeaderboardMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ebf30
	struct UUWorksRequestCoreFindLeaderboard* FindLeaderboard(); // Function UWorksCore.UWorksInterfaceCoreUserStats.FindLeaderboard // (Final|Native|Public|BlueprintCallable) // @ game+0x8ebf00
	void DownloadLeaderboardEntriesMinimal(struct FDelegate Completed, struct FUWorksSteamLeaderboard SteamLeaderboard, enum class EUWorksLeaderboardDataRequest LeaderboardDataRequest, int32_t RangeStart, int32_t RangeEnd); // Function UWorksCore.UWorksInterfaceCoreUserStats.DownloadLeaderboardEntriesMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ebcb0
	void DownloadLeaderboardEntriesForUsersMinimal(struct FDelegate Completed, struct FUWorksSteamLeaderboard SteamLeaderboard, struct TArray<struct FUWorksSteamID> Users); // Function UWorksCore.UWorksInterfaceCoreUserStats.DownloadLeaderboardEntriesForUsersMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8ebb20
	struct UUWorksRequestCoreDownloadLeaderboardEntriesForUsers* DownloadLeaderboardEntriesForUsers(); // Function UWorksCore.UWorksInterfaceCoreUserStats.DownloadLeaderboardEntriesForUsers // (Final|Native|Public|BlueprintCallable) // @ game+0x8ebaf0
	struct UUWorksRequestCoreDownloadLeaderboardEntries* DownloadLeaderboardEntries(); // Function UWorksCore.UWorksInterfaceCoreUserStats.DownloadLeaderboardEntries // (Final|Native|Public|BlueprintCallable) // @ game+0x8ebac0
	bool ClearAchievement(struct FString Name); // Function UWorksCore.UWorksInterfaceCoreUserStats.ClearAchievement // (Final|Native|Public|BlueprintCallable) // @ game+0x8eb860
	void AttachLeaderboardUGCMinimal(struct FDelegate Completed, struct FUWorksSteamLeaderboard SteamLeaderboard, struct FUWorksUGCHandle UGCHandle); // Function UWorksCore.UWorksInterfaceCoreUserStats.AttachLeaderboardUGCMinimal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8eb450
	struct UUWorksRequestCoreAttachLeaderboardUGC* AttachLeaderboardUGC(); // Function UWorksCore.UWorksInterfaceCoreUserStats.AttachLeaderboardUGC // (Final|Native|Public|BlueprintCallable) // @ game+0x8eb420
};

// Class UWorksCore.UWorksInterfaceCoreUtils
// Size: 0x68 (Inherited: 0x28)
struct UUWorksInterfaceCoreUtils : UUWorksInterfaceCore {
	struct FMulticastInlineDelegate IPCountry; // 0x28(0x10)
	struct FMulticastInlineDelegate LowBatteryPower; // 0x38(0x10)
	struct FMulticastInlineDelegate SteamShutdown; // 0x48(0x10)
	struct FMulticastInlineDelegate GamepadTextInputDismissed; // 0x58(0x10)

	void StartVRDashboard(); // Function UWorksCore.UWorksInterfaceCoreUtils.StartVRDashboard // (Final|Native|Public|BlueprintCallable) // @ game+0x8f3340
	bool ShowGamepadTextInput(enum class EUWorksGamepadTextInputMode InputMode, enum class EUWorksGamepadTextInputLineMode LineInputMode, struct FString Description, int32_t CharMax, struct FString ExistingText); // Function UWorksCore.UWorksInterfaceCoreUtils.ShowGamepadTextInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f3100
	void SetOverlayNotificationPosition(enum class EUWorksNotificationPosition NotificationPosition); // Function UWorksCore.UWorksInterfaceCoreUtils.SetOverlayNotificationPosition // (Final|Native|Public|BlueprintCallable) // @ game+0x8f3080
	void SetOverlayNotificationInset(int32_t HorizontalInset, int32_t VerticalInset); // Function UWorksCore.UWorksInterfaceCoreUtils.SetOverlayNotificationInset // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2fb0
	bool IsSteamRunningInVR(); // Function UWorksCore.UWorksInterfaceCoreUtils.IsSteamRunningInVR // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d10
	bool IsSteamInBigPictureMode(); // Function UWorksCore.UWorksInterfaceCoreUtils.IsSteamInBigPictureMode // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2ce0
	bool IsOverlayEnabled(); // Function UWorksCore.UWorksInterfaceCoreUtils.IsOverlayEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2cb0
	struct UUWorksInterfaceCoreUtils* GetUtils(); // Function UWorksCore.UWorksInterfaceCoreUtils.GetUtils // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8f2c50
	struct FString GetSteamUILanguage(); // Function UWorksCore.UWorksInterfaceCoreUtils.GetSteamUILanguage // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2c00
	int32_t GetServerRealTime(); // Function UWorksCore.UWorksInterfaceCoreUtils.GetServerRealTime // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2bd0
	int32_t GetSecondsSinceComputerActive(); // Function UWorksCore.UWorksInterfaceCoreUtils.GetSecondsSinceComputerActive // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2ba0
	int32_t GetSecondsSinceAppActive(); // Function UWorksCore.UWorksInterfaceCoreUtils.GetSecondsSinceAppActive // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2b70
	struct FString GetIPCountry(); // Function UWorksCore.UWorksInterfaceCoreUtils.GetIPCountry // (Final|Native|Public|BlueprintCallable) // @ game+0x8f1c20
	int32_t GetIPCCallCount(); // Function UWorksCore.UWorksInterfaceCoreUtils.GetIPCCallCount // (Final|Native|Public|BlueprintCallable) // @ game+0x8f1bf0
	int32_t GetEnteredGamepadTextLength(); // Function UWorksCore.UWorksInterfaceCoreUtils.GetEnteredGamepadTextLength // (Final|Native|Public|BlueprintCallable) // @ game+0x8f1bc0
	bool GetEnteredGamepadTextInput(struct FString Text, int32_t TextMaxLength); // Function UWorksCore.UWorksInterfaceCoreUtils.GetEnteredGamepadTextInput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8f1ac0
	char GetCurrentBatteryPower(); // Function UWorksCore.UWorksInterfaceCoreUtils.GetCurrentBatteryPower // (Final|Native|Public|BlueprintCallable) // @ game+0x8f1a90
	enum class EUWorksUniverse GetConnectedUniverse(); // Function UWorksCore.UWorksInterfaceCoreUtils.GetConnectedUniverse // (Final|Native|Public|BlueprintCallable) // @ game+0x8f1a60
	int32_t GetAppID(); // Function UWorksCore.UWorksInterfaceCoreUtils.GetAppID // (Final|Native|Public|BlueprintCallable) // @ game+0x8f1a30
	bool BOverlayNeedsPresent(); // Function UWorksCore.UWorksInterfaceCoreUtils.BOverlayNeedsPresent // (Final|Native|Public|BlueprintCallable) // @ game+0x8f19e0
};

// Class UWorksCore.UWorksRequestCoreGetFileDetails
// Size: 0x90 (Inherited: 0x38)
struct UUWorksRequestCoreGetFileDetails : UUWorksRequestCore {
	char pad_38[0x38]; // 0x38(0x38)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x70(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x80(0x10)

	void SetInput(struct FString Filename); // Function UWorksCore.UWorksRequestCoreGetFileDetails.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2ec0
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreGetFileDetails.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, int32_t FileSize, struct FString FileSHA, struct TArray<int32_t> FileFlags); // Function UWorksCore.UWorksRequestCoreGetFileDetails.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f2140
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreGetFileDetails.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreGetFileDetails.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreSetPersonaName
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreSetPersonaName : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(struct FString Name); // Function UWorksCore.UWorksRequestCoreSetPersonaName.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2ec0
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreSetPersonaName.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(bool bSuccess, bool bLocalSuccess, enum class EUWorksResult Result); // Function UWorksCore.UWorksRequestCoreSetPersonaName.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f2a30
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreSetPersonaName.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreSetPersonaName.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreDownloadClanActivityCounts
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreDownloadClanActivityCounts : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(struct TArray<struct FUWorksSteamID> SteamIDClans); // Function UWorksCore.UWorksRequestCoreDownloadClanActivityCounts.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2dd0
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreDownloadClanActivityCounts.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(bool bSuccess); // Function UWorksCore.UWorksRequestCoreDownloadClanActivityCounts.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f1f00
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreDownloadClanActivityCounts.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreDownloadClanActivityCounts.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreRequestClanOfficerList
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreRequestClanOfficerList : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksRequestCoreRequestClanOfficerList.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreRequestClanOfficerList.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksSteamID SteamIDClan, int32_t Officers, bool bSuccess); // Function UWorksCore.UWorksRequestCoreRequestClanOfficerList.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f2670
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreRequestClanOfficerList.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreRequestClanOfficerList.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreJoinClanChatRoom
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreJoinClanChatRoom : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(struct FUWorksSteamID SteamIDClan); // Function UWorksCore.UWorksRequestCoreJoinClanChatRoom.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreJoinClanChatRoom.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksSteamID SteamIDClanChat, enum class EUWorksChatRoomEnterResponse ChatRoomEnterResponse); // Function UWorksCore.UWorksRequestCoreJoinClanChatRoom.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f2590
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreJoinClanChatRoom.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreJoinClanChatRoom.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreGetFollowerCount
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreGetFollowerCount : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksRequestCoreGetFollowerCount.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreGetFollowerCount.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, struct FUWorksSteamID SteamID, int32_t Count); // Function UWorksCore.UWorksRequestCoreGetFollowerCount.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f2310
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreGetFollowerCount.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreGetFollowerCount.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreIsFollowing
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreIsFollowing : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksRequestCoreIsFollowing.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreIsFollowing.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, struct FUWorksSteamID SteamID, bool bIsFollowing); // Function UWorksCore.UWorksRequestCoreIsFollowing.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f2450
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreIsFollowing.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreIsFollowing.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreEnumerateFollowingList
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreEnumerateFollowingList : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(int32_t StartIndex); // Function UWorksCore.UWorksRequestCoreEnumerateFollowingList.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x875d80
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreEnumerateFollowingList.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, struct TArray<struct FUWorksSteamID> SteamIDs, int32_t ResultsReturned, int32_t TotalResultCount); // Function UWorksCore.UWorksRequestCoreEnumerateFollowingList.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f1f90
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreEnumerateFollowingList.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreEnumerateFollowingList.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreAssociateWithClan
// Size: 0x68 (Inherited: 0x38)
struct UUWorksRequestCoreAssociateWithClan : UUWorksRequestCore {
	char pad_38[0x10]; // 0x38(0x10)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x48(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x58(0x10)

	void SetInput(struct FUWorksSteamID SteamIDClan); // Function UWorksCore.UWorksRequestCoreAssociateWithClan.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreAssociateWithClan.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result); // Function UWorksCore.UWorksRequestCoreAssociateWithClan.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f1c70
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreAssociateWithClan.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreAssociateWithClan.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreComputeNewPlayerCompatibility
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreComputeNewPlayerCompatibility : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(struct FUWorksSteamID SteamIDNewPlayer); // Function UWorksCore.UWorksRequestCoreComputeNewPlayerCompatibility.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreComputeNewPlayerCompatibility.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, int32_t PlayersThatDontLikeCandidate, int32_t PlayersThatCandidateDoesntLike, int32_t ClanPlayersThatDontLikeCandidate, struct FUWorksSteamID SteamIDCandidate); // Function UWorksCore.UWorksRequestCoreComputeNewPlayerCompatibility.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f1d00
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreComputeNewPlayerCompatibility.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreComputeNewPlayerCompatibility.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreRequestUserStatsGS
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreRequestUserStatsGS : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(struct FUWorksSteamID SteamIDUser); // Function UWorksCore.UWorksRequestCoreRequestUserStatsGS.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreRequestUserStatsGS.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, struct FUWorksSteamID SteamIDUser); // Function UWorksCore.UWorksRequestCoreRequestUserStatsGS.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f2950
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreRequestUserStatsGS.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreRequestUserStatsGS.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreStoreUserStats
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreStoreUserStats : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(struct FUWorksSteamID SteamIDUser); // Function UWorksCore.UWorksRequestCoreStoreUserStats.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreStoreUserStats.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, struct FUWorksSteamID SteamIDUser); // Function UWorksCore.UWorksRequestCoreStoreUserStats.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f2950
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreStoreUserStats.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreStoreUserStats.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreRequestEligiblePromoItemDefinitionsIDs
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreRequestEligiblePromoItemDefinitionsIDs : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksRequestCoreRequestEligiblePromoItemDefinitionsIDs.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreRequestEligiblePromoItemDefinitionsIDs.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, struct FUWorksSteamID SteamID, int32_t NumEligiblePromoItemsDefinitionsIDs, bool bCachedData); // Function UWorksCore.UWorksRequestCoreRequestEligiblePromoItemDefinitionsIDs.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f27b0
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreRequestEligiblePromoItemDefinitionsIDs.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreRequestEligiblePromoItemDefinitionsIDs.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreRequestLobbyList
// Size: 0x60 (Inherited: 0x38)
struct UUWorksRequestCoreRequestLobbyList : UUWorksRequestCore {
	char pad_38[0x8]; // 0x38(0x08)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x40(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x50(0x10)

	bool IsActive(); // Function UWorksCore.UWorksRequestCoreRequestLobbyList.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(int32_t LobbiesMatching); // Function UWorksCore.UWorksRequestCoreRequestLobbyList.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f7950
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreRequestLobbyList.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreRequestLobbyList.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreCreateLobby
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreCreateLobby : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(enum class EUWorksLobbyType LobbyType, int32_t MaxMembers); // Function UWorksCore.UWorksRequestCoreCreateLobby.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f8230
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreCreateLobby.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.UWorksRequestCoreCreateLobby.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f2950
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreCreateLobby.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreCreateLobby.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreJoinLobby
// Size: 0x80 (Inherited: 0x38)
struct UUWorksRequestCoreJoinLobby : UUWorksRequestCore {
	char pad_38[0x28]; // 0x38(0x28)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x60(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x70(0x10)

	void SetInput(struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.UWorksRequestCoreJoinLobby.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreJoinLobby.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksSteamID SteamIDLobby, struct TArray<char> ChatPermissions, bool bLocked, enum class EUWorksChatRoomEnterResponse ChatRoomEnterResponse); // Function UWorksCore.UWorksRequestCoreJoinLobby.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f7550
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreJoinLobby.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreJoinLobby.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreServerList
// Size: 0x150 (Inherited: 0x38)
struct UUWorksRequestCoreServerList : UUWorksRequestCore {
	char pad_38[0xd8]; // 0x38(0xd8)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x110(0x10)
	struct FMulticastInlineDelegate OnRequestUpdated; // 0x120(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x130(0x10)
	struct FDelegate OnRequestUpdatedMinimal; // 0x140(0x10)

	void SetInput(int32_t AppID, enum class EUWorksServerQueryType QueryType); // Function UWorksCore.UWorksRequestCoreServerList.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f8780
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreServerList.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksServerInfo UpdatedServer, struct TArray<struct FUWorksServerInfo> Servers); // Function UWorksCore.UWorksRequestCoreServerList.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f7d40
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreServerList.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void AddFilterSecure(); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterSecure // (Native|Public|BlueprintCallable) // @ game+0x8f6ed0
	void AddFilterOr(int32_t Value); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterOr // (Native|Public|BlueprintCallable) // @ game+0x8f6e40
	void AddFilterNotFull(); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterNotFull // (Native|Public|BlueprintCallable) // @ game+0x8f6e20
	void AddFilterNor(int32_t Value); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterNor // (Native|Public|BlueprintCallable) // @ game+0x8f6d90
	void AddFilterNoPlayers(); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterNoPlayers // (Native|Public|BlueprintCallable) // @ game+0x8f6d70
	void AddFilterNand(int32_t Value); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterNand // (Native|Public|BlueprintCallable) // @ game+0x8f6ce0
	void AddFilterMap(struct FString Value); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterMap // (Native|Public|BlueprintCallable) // @ game+0x8f6bf0
	void AddFilterLinux(); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterLinux // (Native|Public|BlueprintCallable) // @ game+0x8f6bd0
	void AddFilterHasPlayers(); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterHasPlayers // (Native|Public|BlueprintCallable) // @ game+0x8f6bb0
	void AddFilterGameTagsNor(struct FString Value); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterGameTagsNor // (Native|Public|BlueprintCallable) // @ game+0x8f6ac0
	void AddFilterGameTagsAnd(struct FString Value); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterGameTagsAnd // (Native|Public|BlueprintCallable) // @ game+0x8f69d0
	void AddFilterGameDataOr(struct FString Value); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterGameDataOr // (Native|Public|BlueprintCallable) // @ game+0x8f68e0
	void AddFilterGameDataNor(struct FString Value); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterGameDataNor // (Native|Public|BlueprintCallable) // @ game+0x8f67f0
	void AddFilterGameDataAnd(struct FString Value); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterGameDataAnd // (Native|Public|BlueprintCallable) // @ game+0x8f6700
	void AddFilterGameAddr(struct FString Value); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterGameAddr // (Native|Public|BlueprintCallable) // @ game+0x8f6610
	void AddFilterDedicated(); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterDedicated // (Native|Public|BlueprintCallable) // @ game+0x8f65f0
	void AddFilterAnd(int32_t Value); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterAnd // (Native|Public|BlueprintCallable) // @ game+0x8f6560
	void AddFilterAddr(struct FString Value); // Function UWorksCore.UWorksRequestCoreServerList.AddFilterAddr // (Native|Public|BlueprintCallable) // @ game+0x8f6470
	void Activate(); // Function UWorksCore.UWorksRequestCoreServerList.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCorePing
// Size: 0x100 (Inherited: 0x38)
struct UUWorksRequestCorePing : UUWorksRequestCore {
	char pad_38[0xa8]; // 0x38(0xa8)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0xe0(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0xf0(0x10)

	void SetInput(struct FString IP, int32_t Port); // Function UWorksCore.UWorksRequestCorePing.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f85d0
	bool IsActive(); // Function UWorksCore.UWorksRequestCorePing.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksServerInfo Server); // Function UWorksCore.UWorksRequestCorePing.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f7710
	void Deactivate(); // Function UWorksCore.UWorksRequestCorePing.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCorePing.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCorePlayers
// Size: 0xb0 (Inherited: 0x38)
struct UUWorksRequestCorePlayers : UUWorksRequestCore {
	char pad_38[0x38]; // 0x38(0x38)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x70(0x10)
	struct FMulticastInlineDelegate OnRequestUpdated; // 0x80(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x90(0x10)
	struct FDelegate OnRequestUpdatedMinimal; // 0xa0(0x10)

	void SetInput(struct FString IP, int32_t Port); // Function UWorksCore.UWorksRequestCorePlayers.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f85d0
	bool IsActive(); // Function UWorksCore.UWorksRequestCorePlayers.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksPlayerInfo UpdatedPlayer, struct TArray<struct FUWorksPlayerInfo> Players); // Function UWorksCore.UWorksRequestCorePlayers.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f7810
	void Deactivate(); // Function UWorksCore.UWorksRequestCorePlayers.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCorePlayers.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreRules
// Size: 0xb8 (Inherited: 0x38)
struct UUWorksRequestCoreRules : UUWorksRequestCore {
	char pad_38[0x40]; // 0x38(0x40)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x78(0x10)
	struct FMulticastInlineDelegate OnRequestUpdated; // 0x88(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x98(0x10)
	struct FDelegate OnRequestUpdatedMinimal; // 0xa8(0x10)

	void SetInput(struct FString IP, int32_t Port); // Function UWorksCore.UWorksRequestCoreRules.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f85d0
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreRules.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksRuleInfo UpdatedRule, struct TArray<struct FUWorksRuleInfo> Rules); // Function UWorksCore.UWorksRequestCoreRules.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f79e0
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreRules.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreRules.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreFileWriteAsync
// Size: 0x80 (Inherited: 0x38)
struct UUWorksRequestCoreFileWriteAsync : UUWorksRequestCore {
	char pad_38[0x28]; // 0x38(0x28)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x60(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x70(0x10)

	void SetInput(struct FString File, struct TArray<char> Buffer); // Function UWorksCore.UWorksRequestCoreFileWriteAsync.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f8460
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreFileWriteAsync.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result); // Function UWorksCore.UWorksRequestCoreFileWriteAsync.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f72c0
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreFileWriteAsync.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreFileWriteAsync.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreFileReadAsync
// Size: 0x88 (Inherited: 0x38)
struct UUWorksRequestCoreFileReadAsync : UUWorksRequestCore {
	char pad_38[0x30]; // 0x38(0x30)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x68(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x78(0x10)

	void SetInput(struct FString File, int32_t Offset, int32_t BytesToRead); // Function UWorksCore.UWorksRequestCoreFileReadAsync.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f8300
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreFileReadAsync.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, int32_t Offset, struct TArray<char> Buffer); // Function UWorksCore.UWorksRequestCoreFileReadAsync.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f7170
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreFileReadAsync.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreFileReadAsync.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreSendQueryUGCRequest
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreSendQueryUGCRequest : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(struct FUWorksUGCQueryHandle UGCQueryHandle); // Function UWorksCore.UWorksRequestCoreSendQueryUGCRequest.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f8700
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreSendQueryUGCRequest.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksUGCQueryHandle UGCQueryHandle, enum class EUWorksResult Result, int32_t NumResultsReturned, int32_t TotalMatchingResults, bool bCachedData); // Function UWorksCore.UWorksRequestCoreSendQueryUGCRequest.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f7b40
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreSendQueryUGCRequest.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreSendQueryUGCRequest.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreCreateItem
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreCreateItem : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(int32_t ConsumerAppID, enum class EUWorksWorkshopFileType FileType); // Function UWorksCore.UWorksRequestCoreCreateItem.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f8160
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreCreateItem.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, struct FUWorksPublishedFileID PublishedFileID, bool bUserNeedsToAcceptWorkshopLegalAgreement); // Function UWorksCore.UWorksRequestCoreCreateItem.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f7030
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreCreateItem.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreCreateItem.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreSubmitItemUpdate
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreSubmitItemUpdate : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(struct FUWorksUGCUpdateHandle UGCUpdateHandle, struct FString ChangeNote); // Function UWorksCore.UWorksRequestCoreSubmitItemUpdate.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f8920
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreSubmitItemUpdate.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, bool bUserNeedsToAcceptWorkshopLegalAgreement); // Function UWorksCore.UWorksRequestCoreSubmitItemUpdate.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f7fb0
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreSubmitItemUpdate.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreSubmitItemUpdate.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreSetUserItemVote
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreSetUserItemVote : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(struct FUWorksPublishedFileID PublishedFileID, bool bVoteUp); // Function UWorksCore.UWorksRequestCoreSetUserItemVote.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f8850
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreSetUserItemVote.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksPublishedFileID PublishedFileID, enum class EUWorksResult Result, bool bVoteUp); // Function UWorksCore.UWorksRequestCoreSetUserItemVote.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f6ef0
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreSetUserItemVote.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreSetUserItemVote.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreGetUserItemVote
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreGetUserItemVote : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksRequestCoreGetUserItemVote.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreGetUserItemVote.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksPublishedFileID PublishedFileID, enum class EUWorksResult Result, bool bVotedUp, bool bVotedDown, bool bVoteSkipped); // Function UWorksCore.UWorksRequestCoreGetUserItemVote.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f7350
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreGetUserItemVote.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreGetUserItemVote.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreAddItemToFavorites
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreAddItemToFavorites : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(int32_t AppID, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksRequestCoreAddItemToFavorites.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f8090
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreAddItemToFavorites.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksPublishedFileID PublishedFileID, enum class EUWorksResult Result, bool bWasAddRequest); // Function UWorksCore.UWorksRequestCoreAddItemToFavorites.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f6ef0
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreAddItemToFavorites.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreAddItemToFavorites.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreRemoveItemFromFavorites
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreRemoveItemFromFavorites : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(int32_t AppID, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksRequestCoreRemoveItemFromFavorites.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f8090
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreRemoveItemFromFavorites.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksPublishedFileID PublishedFileID, enum class EUWorksResult Result, bool bWasAddRequest); // Function UWorksCore.UWorksRequestCoreRemoveItemFromFavorites.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f6ef0
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreRemoveItemFromFavorites.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreRemoveItemFromFavorites.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreSubscribeItem
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreSubscribeItem : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksRequestCoreSubscribeItem.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreSubscribeItem.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksRequestCoreSubscribeItem.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f2950
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreSubscribeItem.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreSubscribeItem.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreUnsubscribeItem
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreUnsubscribeItem : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksRequestCoreUnsubscribeItem.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreUnsubscribeItem.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.UWorksRequestCoreUnsubscribeItem.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f2950
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreUnsubscribeItem.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreUnsubscribeItem.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreStartPlaytimeTracking
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreStartPlaytimeTracking : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(struct TArray<struct FUWorksPublishedFileID> PublishedFileID); // Function UWorksCore.UWorksRequestCoreStartPlaytimeTracking.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2dd0
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreStartPlaytimeTracking.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result); // Function UWorksCore.UWorksRequestCoreStartPlaytimeTracking.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f1f00
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreStartPlaytimeTracking.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreStartPlaytimeTracking.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreStopPlaytimeTracking
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreStopPlaytimeTracking : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(struct TArray<struct FUWorksPublishedFileID> PublishedFileIDs); // Function UWorksCore.UWorksRequestCoreStopPlaytimeTracking.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2dd0
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreStopPlaytimeTracking.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result); // Function UWorksCore.UWorksRequestCoreStopPlaytimeTracking.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f1f00
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreStopPlaytimeTracking.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreStopPlaytimeTracking.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreStopPlaytimeTrackingForAllItems
// Size: 0x60 (Inherited: 0x38)
struct UUWorksRequestCoreStopPlaytimeTrackingForAllItems : UUWorksRequestCore {
	char pad_38[0x8]; // 0x38(0x08)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x40(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x50(0x10)

	bool IsActive(); // Function UWorksCore.UWorksRequestCoreStopPlaytimeTrackingForAllItems.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result); // Function UWorksCore.UWorksRequestCoreStopPlaytimeTrackingForAllItems.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f7f20
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreStopPlaytimeTrackingForAllItems.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreStopPlaytimeTrackingForAllItems.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreRequestEncryptedAppTicket
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreRequestEncryptedAppTicket : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(struct TArray<char> Buffer); // Function UWorksCore.UWorksRequestCoreRequestEncryptedAppTicket.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8fd000
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreRequestEncryptedAppTicket.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result); // Function UWorksCore.UWorksRequestCoreRequestEncryptedAppTicket.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f1f00
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreRequestEncryptedAppTicket.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreRequestEncryptedAppTicket.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreRequestStoreAuthURL
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreRequestStoreAuthURL : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(struct FString URL); // Function UWorksCore.UWorksRequestCoreRequestStoreAuthURL.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2ec0
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreRequestStoreAuthURL.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FString URL); // Function UWorksCore.UWorksRequestCoreRequestStoreAuthURL.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8fb9f0
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreRequestStoreAuthURL.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreRequestStoreAuthURL.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreRequestUserStats
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreRequestUserStats : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksRequestCoreRequestUserStats.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2d40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreRequestUserStats.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksGameID GameID, enum class EUWorksResult Result, struct FUWorksSteamID SteamID); // Function UWorksCore.UWorksRequestCoreRequestUserStats.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8fbaa0
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreRequestUserStats.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreRequestUserStats.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreFindOrCreateLeaderboard
// Size: 0x80 (Inherited: 0x38)
struct UUWorksRequestCoreFindOrCreateLeaderboard : UUWorksRequestCore {
	char pad_38[0x28]; // 0x38(0x28)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x60(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x70(0x10)

	void SetInput(struct FString LeaderboardName, enum class EUWorksLeaderboardSortMethod LeaderboardSortMethod, enum class EUWorksLeaderboardDisplayType LeaderboardDisplayType); // Function UWorksCore.UWorksRequestCoreFindOrCreateLeaderboard.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8fcea0
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreFindOrCreateLeaderboard.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksSteamLeaderboard SteamLeaderboard, bool bLeaderboardFound); // Function UWorksCore.UWorksRequestCoreFindOrCreateLeaderboard.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8fb750
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreFindOrCreateLeaderboard.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreFindOrCreateLeaderboard.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreFindLeaderboard
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreFindLeaderboard : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(struct FString LeaderboardName); // Function UWorksCore.UWorksRequestCoreFindLeaderboard.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8f2ec0
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreFindLeaderboard.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksSteamLeaderboard SteamLeaderboard, bool bLeaderboardFound); // Function UWorksCore.UWorksRequestCoreFindLeaderboard.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8fb670
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreFindLeaderboard.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreFindLeaderboard.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreDownloadLeaderboardEntries
// Size: 0x88 (Inherited: 0x38)
struct UUWorksRequestCoreDownloadLeaderboardEntries : UUWorksRequestCore {
	char pad_38[0x30]; // 0x38(0x30)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x68(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x78(0x10)

	void SetInput(struct FUWorksSteamLeaderboard SteamLeaderboard, enum class EUWorksLeaderboardDataRequest LeaderboardDataRequest, int32_t RangeStart, int32_t RangeEnd); // Function UWorksCore.UWorksRequestCoreDownloadLeaderboardEntries.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8fcc10
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreDownloadLeaderboardEntries.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksSteamLeaderboard SteamLeaderboard, struct FUWorksSteamLeaderboardEntries SteamLeaderboardEntries, int32_t EntryCount); // Function UWorksCore.UWorksRequestCoreDownloadLeaderboardEntries.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8fb530
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreDownloadLeaderboardEntries.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreDownloadLeaderboardEntries.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreDownloadLeaderboardEntriesForUsers
// Size: 0x88 (Inherited: 0x38)
struct UUWorksRequestCoreDownloadLeaderboardEntriesForUsers : UUWorksRequestCore {
	char pad_38[0x30]; // 0x38(0x30)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x68(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x78(0x10)

	void SetInput(struct FUWorksSteamLeaderboard SteamLeaderboard, struct TArray<struct FUWorksSteamID> Users); // Function UWorksCore.UWorksRequestCoreDownloadLeaderboardEntriesForUsers.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8fcd70
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreDownloadLeaderboardEntriesForUsers.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksSteamLeaderboard SteamLeaderboard, struct FUWorksSteamLeaderboardEntries SteamLeaderboardEntries, int32_t EntryCount); // Function UWorksCore.UWorksRequestCoreDownloadLeaderboardEntriesForUsers.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8fb530
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreDownloadLeaderboardEntriesForUsers.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreDownloadLeaderboardEntriesForUsers.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreUploadLeaderboardScore
// Size: 0x98 (Inherited: 0x38)
struct UUWorksRequestCoreUploadLeaderboardScore : UUWorksRequestCore {
	char pad_38[0x40]; // 0x38(0x40)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x78(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x88(0x10)

	void SetInput(struct FUWorksSteamLeaderboard SteamLeaderboard, enum class EUWorksLeaderboardUploadScoreMethod LeaderboardUploadScoreMethod, int32_t Score, struct TArray<int32_t> ScoreDetails); // Function UWorksCore.UWorksRequestCoreUploadLeaderboardScore.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8fd0f0
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreUploadLeaderboardScore.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(bool bSuccess, struct FUWorksSteamLeaderboard SteamLeaderboard, int32_t Score, bool bScoreChanged, int32_t GlobalRankNew, int32_t GlobalRankPrevious); // Function UWorksCore.UWorksRequestCoreUploadLeaderboardScore.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8fbbe0
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreUploadLeaderboardScore.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreUploadLeaderboardScore.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreAttachLeaderboardUGC
// Size: 0x78 (Inherited: 0x38)
struct UUWorksRequestCoreAttachLeaderboardUGC : UUWorksRequestCore {
	char pad_38[0x20]; // 0x38(0x20)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x58(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x68(0x10)

	void SetInput(struct FUWorksSteamLeaderboard SteamLeaderboard, struct FUWorksUGCHandle UGCHandle); // Function UWorksCore.UWorksRequestCoreAttachLeaderboardUGC.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x8fcb40
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreAttachLeaderboardUGC.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(enum class EUWorksResult Result, struct FUWorksSteamLeaderboard SteamLeaderboard); // Function UWorksCore.UWorksRequestCoreAttachLeaderboardUGC.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8fb450
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreAttachLeaderboardUGC.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreAttachLeaderboardUGC.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreGetNumberOfCurrentPlayers
// Size: 0x60 (Inherited: 0x38)
struct UUWorksRequestCoreGetNumberOfCurrentPlayers : UUWorksRequestCore {
	char pad_38[0x8]; // 0x38(0x08)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x40(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x50(0x10)

	bool IsActive(); // Function UWorksCore.UWorksRequestCoreGetNumberOfCurrentPlayers.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(bool bSuccess, int32_t Players); // Function UWorksCore.UWorksRequestCoreGetNumberOfCurrentPlayers.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8fb830
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreGetNumberOfCurrentPlayers.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreGetNumberOfCurrentPlayers.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreRequestGlobalAchievementPercentages
// Size: 0x68 (Inherited: 0x38)
struct UUWorksRequestCoreRequestGlobalAchievementPercentages : UUWorksRequestCore {
	char pad_38[0x10]; // 0x38(0x10)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x48(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x58(0x10)

	bool IsActive(); // Function UWorksCore.UWorksRequestCoreRequestGlobalAchievementPercentages.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksGameID GameID, enum class EUWorksResult Result); // Function UWorksCore.UWorksRequestCoreRequestGlobalAchievementPercentages.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8fb910
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreRequestGlobalAchievementPercentages.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreRequestGlobalAchievementPercentages.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.UWorksRequestCoreRequestGlobalStats
// Size: 0x70 (Inherited: 0x38)
struct UUWorksRequestCoreRequestGlobalStats : UUWorksRequestCore {
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnRequestCompleted; // 0x50(0x10)
	struct FDelegate OnRequestCompletedMinimal; // 0x60(0x10)

	void SetInput(int32_t HistoryDays); // Function UWorksCore.UWorksRequestCoreRequestGlobalStats.SetInput // (Final|Native|Public|BlueprintCallable) // @ game+0x875d80
	bool IsActive(); // Function UWorksCore.UWorksRequestCoreRequestGlobalStats.IsActive // (Native|Public|BlueprintCallable) // @ game+0x8f2c80
	void GetOutput(struct FUWorksGameID GameID, enum class EUWorksResult Result); // Function UWorksCore.UWorksRequestCoreRequestGlobalStats.GetOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8f2590
	void Deactivate(); // Function UWorksCore.UWorksRequestCoreRequestGlobalStats.Deactivate // (Native|Public|BlueprintCallable) // @ game+0x8f1a10
	void Activate(); // Function UWorksCore.UWorksRequestCoreRequestGlobalStats.Activate // (Native|Public|BlueprintCallable) // @ game+0x8f19c0
};

// Class UWorksCore.CoreGetFileDetailsNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreGetFileDetailsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, int32_t FileSize, struct FString FileSHA, struct TArray<int32_t> FileFlags); // Function UWorksCore.CoreGetFileDetailsNode.OnRequestCompleted // (Final|Native|Public|HasOutParms) // @ game+0x8fc1e0
	struct UCoreGetFileDetailsNode* GetFileDetailsNode(struct FString Filename); // Function UWorksCore.CoreGetFileDetailsNode.GetFileDetailsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8fb2d0
};

// Class UWorksCore.CoreSetPersonaNameNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreSetPersonaNameNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreSetPersonaNameNode* SetPersonaNameNode(struct FString Name); // Function UWorksCore.CoreSetPersonaNameNode.SetPersonaNameNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8fd2a0
	void OnRequestCompleted(bool bSuccessful, bool bSuccess, bool bLocalSuccess, enum class EUWorksResult Result); // Function UWorksCore.CoreSetPersonaNameNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x8fc930
};

// Class UWorksCore.CoreDownloadClanActivityCountsNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreDownloadClanActivityCountsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, bool bSuccess); // Function UWorksCore.CoreDownloadClanActivityCountsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x8fbf30
	struct UCoreDownloadClanActivityCountsNode* DownloadClanActivityCountsNode(struct TArray<struct FUWorksSteamID> SteamIDClans); // Function UWorksCore.CoreDownloadClanActivityCountsNode.DownloadClanActivityCountsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8fb150
};

// Class UWorksCore.CoreRequestClanOfficerListNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreRequestClanOfficerListNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreRequestClanOfficerListNode* RequestClanOfficerListNode(struct FUWorksSteamID SteamID); // Function UWorksCore.CoreRequestClanOfficerListNode.RequestClanOfficerListNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8fcab0
	void OnRequestCompleted(bool bSuccessful, struct FUWorksSteamID SteamIDClan, int32_t Officers, bool bSuccess); // Function UWorksCore.CoreRequestClanOfficerListNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x8fc7d0
};

// Class UWorksCore.CoreJoinClanChatRoomNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreJoinClanChatRoomNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FUWorksSteamID SteamIDClanChat, enum class EUWorksChatRoomEnterResponse ChatRoomEnterResponse); // Function UWorksCore.CoreJoinClanChatRoomNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x8fc6c0
	struct UCoreJoinClanChatRoomNode* JoinClanChatRoomNode(struct FUWorksSteamID SteamIDClan); // Function UWorksCore.CoreJoinClanChatRoomNode.JoinClanChatRoomNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8fbea0
};

// Class UWorksCore.CoreGetFollowerCountNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreGetFollowerCountNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, struct FUWorksSteamID SteamID, int32_t Count); // Function UWorksCore.CoreGetFollowerCountNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x8fc400
	struct UCoreGetFollowerCountNode* GetFollowerCountNode(struct FUWorksSteamID SteamID); // Function UWorksCore.CoreGetFollowerCountNode.GetFollowerCountNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8fb3c0
};

// Class UWorksCore.CoreIsFollowingNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreIsFollowingNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, struct FUWorksSteamID SteamID, bool bIsFollowing); // Function UWorksCore.CoreIsFollowingNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x8fc560
	struct UCoreIsFollowingNode* IsFollowingNode(struct FUWorksSteamID SteamID); // Function UWorksCore.CoreIsFollowingNode.IsFollowingNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8fbe10
};

// Class UWorksCore.CoreEnumerateFollowingListNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreEnumerateFollowingListNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, struct TArray<struct FUWorksSteamID> SteamIDs, int32_t ResultsReturned, int32_t TotalResultCount); // Function UWorksCore.CoreEnumerateFollowingListNode.OnRequestCompleted // (Final|Native|Public|HasOutParms) // @ game+0x8fc000
	struct UCoreEnumerateFollowingListNode* EnumerateFollowingListNode(int32_t StartIndex); // Function UWorksCore.CoreEnumerateFollowingListNode.EnumerateFollowingListNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8fb240
};

// Class UWorksCore.CoreAssociateWithClanNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreAssociateWithClanNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result); // Function UWorksCore.CoreAssociateWithClanNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900560
	struct UCoreAssociateWithClanNode* AssociateWithClanNode(struct FUWorksSteamID SteamIDClan); // Function UWorksCore.CoreAssociateWithClanNode.AssociateWithClanNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ffd50
};

// Class UWorksCore.CoreComputeNewPlayerCompatibilityNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreComputeNewPlayerCompatibilityNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, int32_t PlayersThatDontLikeCandidate, int32_t PlayersThatCandidateDoesntLike, int32_t ClanPlayersThatDontLikeCandidate, struct FUWorksSteamID SteamIDCandidate); // Function UWorksCore.CoreComputeNewPlayerCompatibilityNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900630
	struct UCoreComputeNewPlayerCompatibilityNode* ComputeNewPlayerCompatibilityNode(struct FUWorksSteamID SteamIDNewPlayer); // Function UWorksCore.CoreComputeNewPlayerCompatibilityNode.ComputeNewPlayerCompatibilityNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ffde0
};

// Class UWorksCore.CoreRequestUserStatsGSNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreRequestUserStatsGSNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreRequestUserStatsGSNode* RequestUserStatsGSNode(struct FUWorksSteamID SteamIDUser); // Function UWorksCore.CoreRequestUserStatsGSNode.RequestUserStatsGSNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x901d10
	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, struct FUWorksSteamID SteamIDUser); // Function UWorksCore.CoreRequestUserStatsGSNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900810
};

// Class UWorksCore.CoreStoreUserStatsNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreStoreUserStatsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreStoreUserStatsNode* StoreUserStatsNode(struct FUWorksSteamID SteamIDUser); // Function UWorksCore.CoreStoreUserStatsNode.StoreUserStatsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x902360
	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, struct FUWorksSteamID SteamIDUser); // Function UWorksCore.CoreStoreUserStatsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900810
};

// Class UWorksCore.CoreRequestEligiblePromoItemDefinitionsIDsNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreRequestEligiblePromoItemDefinitionsIDsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreRequestEligiblePromoItemDefinitionsIDsNode* RequestEligiblePromoItemDefinitionsIDsNode(struct FUWorksSteamID SteamID); // Function UWorksCore.CoreRequestEligiblePromoItemDefinitionsIDsNode.RequestEligiblePromoItemDefinitionsIDsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x901c50
	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, struct FUWorksSteamID SteamID, int32_t NumEligiblePromoItemsDefinitionsIDs, bool bCachedData); // Function UWorksCore.CoreRequestEligiblePromoItemDefinitionsIDsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900fe0
};

// Class UWorksCore.CoreRequestLobbyListNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreRequestLobbyListNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreRequestLobbyListNode* RequestLobbyListNode(); // Function UWorksCore.CoreRequestLobbyListNode.RequestLobbyListNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x901ce0
	void OnRequestCompleted(bool bSuccessful, int32_t LobbiesMatching); // Function UWorksCore.CoreRequestLobbyListNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x901180
};

// Class UWorksCore.CoreCreateLobbyNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreCreateLobbyNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.CoreCreateLobbyNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900810
	struct UCoreCreateLobbyNode* CreateLobbyNode(enum class EUWorksLobbyType LobbyType, int32_t MaxMembers); // Function UWorksCore.CoreCreateLobbyNode.CreateLobbyNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8fff40
};

// Class UWorksCore.CoreJoinLobbyNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreJoinLobbyNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FUWorksSteamID SteamIDLobby, struct TArray<char> ChatPermissions, bool bLocked, enum class EUWorksChatRoomEnterResponse ChatRoomEnterResponse); // Function UWorksCore.CoreJoinLobbyNode.OnRequestCompleted // (Final|Native|Public|HasOutParms) // @ game+0x900c90
	struct UCoreJoinLobbyNode* JoinLobbyNode(struct FUWorksSteamID SteamIDLobby); // Function UWorksCore.CoreJoinLobbyNode.JoinLobbyNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x900370
};

// Class UWorksCore.CoreServerListNode
// Size: 0x50 (Inherited: 0x30)
struct UCoreServerListNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Updated; // 0x30(0x10)
	char pad_40[0x10]; // 0x40(0x10)

	struct UCoreServerListNode* ServerListNode(int32_t AppID, enum class EUWorksServerQueryType QueryType, int32_t MaxUpdates); // Function UWorksCore.CoreServerListNode.ServerListNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x901f80
	void OnRequestUpdated(bool bSuccessful, struct FUWorksServerInfo Server); // Function UWorksCore.CoreServerListNode.OnRequestUpdated // (Final|Native|Public) // @ game+0x901790
};

// Class UWorksCore.CorePingNode
// Size: 0x40 (Inherited: 0x30)
struct UCorePingNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCorePingNode* PingNode(struct FString IP, int32_t Port); // Function UWorksCore.CorePingNode.PingNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9018f0
	void OnRequestCompleted(bool bSuccessful, struct FUWorksServerInfo Server); // Function UWorksCore.CorePingNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900e80
};

// Class UWorksCore.CorePlayersNode
// Size: 0x50 (Inherited: 0x30)
struct UCorePlayersNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Updated; // 0x30(0x10)
	char pad_40[0x10]; // 0x40(0x10)

	struct UCorePlayersNode* PlayersNode(struct FString IP, int32_t Port, int32_t MaxUpdates); // Function UWorksCore.CorePlayersNode.PlayersNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x901a20
	void OnRequestUpdated(bool bSuccessful, struct FUWorksPlayerInfo Player); // Function UWorksCore.CorePlayersNode.OnRequestUpdated // (Final|Native|Public) // @ game+0x901560
};

// Class UWorksCore.CoreRulesNode
// Size: 0x50 (Inherited: 0x30)
struct UCoreRulesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Updated; // 0x30(0x10)
	char pad_40[0x10]; // 0x40(0x10)

	struct UCoreRulesNode* RulesNode(struct FString IP, int32_t Port, int32_t MaxUpdates); // Function UWorksCore.CoreRulesNode.RulesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x901da0
	void OnRequestUpdated(bool bSuccessful, struct FUWorksRuleInfo Rule); // Function UWorksCore.CoreRulesNode.OnRequestUpdated // (Final|Native|Public) // @ game+0x901670
};

// Class UWorksCore.CoreFileWriteAsyncNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreFileWriteAsyncNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result); // Function UWorksCore.CoreFileWriteAsyncNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900560
	struct UCoreFileWriteAsyncNode* FileWriteAsyncNode(struct FString File, struct TArray<char> Buffer); // Function UWorksCore.CoreFileWriteAsyncNode.FileWriteAsyncNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x900170
};

// Class UWorksCore.CoreFileReadAsyncNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreFileReadAsyncNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, int32_t Offset, struct TArray<char> Buffer); // Function UWorksCore.CoreFileReadAsyncNode.OnRequestCompleted // (Final|Native|Public|HasOutParms) // @ game+0x900920
	struct UCoreFileReadAsyncNode* FileReadAsyncNode(struct FString File, int32_t Offset, int32_t BytesToRead); // Function UWorksCore.CoreFileReadAsyncNode.FileReadAsyncNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x900010
};

// Class UWorksCore.CoreSendQueryUGCRequestNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreSendQueryUGCRequestNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreSendQueryUGCRequestNode* SendQueryUGCRequestNode(struct FUWorksUGCQueryHandle UGCQueryHandle); // Function UWorksCore.CoreSendQueryUGCRequestNode.SendQueryUGCRequestNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x901f00
	void OnRequestCompleted(bool bSuccessful, struct FUWorksUGCQueryHandle UGCQueryHandle, enum class EUWorksResult Result, int32_t NumResultsReturned, int32_t TotalMatchingResults, bool bCachedData); // Function UWorksCore.CoreSendQueryUGCRequestNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x901250
};

// Class UWorksCore.CoreCreateItemNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreCreateItemNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, struct FUWorksPublishedFileID PublishedFileID, bool bUserNeedsToAcceptWorkshopLegalAgreement); // Function UWorksCore.CoreCreateItemNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x8fc560
	struct UCoreCreateItemNode* CreateItemNode(int32_t ConsumerAppID, enum class EUWorksWorkshopFileType FileType); // Function UWorksCore.CoreCreateItemNode.CreateItemNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ffe70
};

// Class UWorksCore.CoreSubmitItemUpdateNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreSubmitItemUpdateNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreSubmitItemUpdateNode* SubmitItemUpdateNode(struct FUWorksUGCUpdateHandle UGCUpdateHandle, struct FString ChangeNote); // Function UWorksCore.CoreSubmitItemUpdateNode.SubmitItemUpdateNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9023f0
	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, bool bUserNeedsToAcceptWorkshopLegalAgreement); // Function UWorksCore.CoreSubmitItemUpdateNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x901440
};

// Class UWorksCore.CoreSetUserItemVoteNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreSetUserItemVoteNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreSetUserItemVoteNode* SetUserItemVoteNode(struct FUWorksPublishedFileID PublishedFileID, bool bVoteUp); // Function UWorksCore.CoreSetUserItemVoteNode.SetUserItemVoteNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x902080
	void OnRequestCompleted(bool bSuccessful, struct FUWorksPublishedFileID PublishedFileID, enum class EUWorksResult Result, bool bVoteUp); // Function UWorksCore.CoreSetUserItemVoteNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900400
};

// Class UWorksCore.CoreGetUserItemVoteNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreGetUserItemVoteNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FUWorksPublishedFileID PublishedFileID, enum class EUWorksResult Result, bool bVotedUp, bool bVotedDown, bool bVoteSkipped); // Function UWorksCore.CoreGetUserItemVoteNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900aa0
	struct UCoreGetUserItemVoteNode* GetUserItemVoteNode(struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.CoreGetUserItemVoteNode.GetUserItemVoteNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9002e0
};

// Class UWorksCore.CoreAddItemToFavoritesNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreAddItemToFavoritesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FUWorksPublishedFileID PublishedFileID, enum class EUWorksResult Result, bool bWasAddRequest); // Function UWorksCore.CoreAddItemToFavoritesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900400
	struct UCoreAddItemToFavoritesNode* AddItemToFavoritesNode(int32_t AppID, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.CoreAddItemToFavoritesNode.AddItemToFavoritesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8ffc80
};

// Class UWorksCore.CoreRemoveItemFromFavoritesNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreRemoveItemFromFavoritesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreRemoveItemFromFavoritesNode* RemoveItemFromFavoritesNode(int32_t AppID, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.CoreRemoveItemFromFavoritesNode.RemoveItemFromFavoritesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x901b80
	void OnRequestCompleted(bool bSuccessful, struct FUWorksPublishedFileID PublishedFileID, enum class EUWorksResult Result, bool bWasAddRequest); // Function UWorksCore.CoreRemoveItemFromFavoritesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900400
};

// Class UWorksCore.CoreSubscribeItemNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreSubscribeItemNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreSubscribeItemNode* SubscribeItemNode(struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.CoreSubscribeItemNode.SubscribeItemNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x902520
	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.CoreSubscribeItemNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900810
};

// Class UWorksCore.CoreUnsubscribeItemNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreUnsubscribeItemNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreUnsubscribeItemNode* UnsubscribeItemNode(struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.CoreUnsubscribeItemNode.UnsubscribeItemNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9025b0
	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, struct FUWorksPublishedFileID PublishedFileID); // Function UWorksCore.CoreUnsubscribeItemNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900810
};

// Class UWorksCore.CoreStartPlaytimeTrackingNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreStartPlaytimeTrackingNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreStartPlaytimeTrackingNode* StartPlaytimeTrackingNode(struct TArray<struct FUWorksPublishedFileID> PublishedFileID); // Function UWorksCore.CoreStartPlaytimeTrackingNode.StartPlaytimeTrackingNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x902150
	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result); // Function UWorksCore.CoreStartPlaytimeTrackingNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900560
};

// Class UWorksCore.CoreStopPlaytimeTrackingNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreStopPlaytimeTrackingNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreStopPlaytimeTrackingNode* StopPlaytimeTrackingNode(struct TArray<struct FUWorksPublishedFileID> PublishedFileID); // Function UWorksCore.CoreStopPlaytimeTrackingNode.StopPlaytimeTrackingNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x902270
	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result); // Function UWorksCore.CoreStopPlaytimeTrackingNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900560
};

// Class UWorksCore.CoreStopPlaytimeTrackingForAllItemsNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreStopPlaytimeTrackingForAllItemsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreStopPlaytimeTrackingForAllItemsNode* StopPlaytimeTrackingForAllItemsNode(); // Function UWorksCore.CoreStopPlaytimeTrackingForAllItemsNode.StopPlaytimeTrackingForAllItemsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x902240
	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result); // Function UWorksCore.CoreStopPlaytimeTrackingForAllItemsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900560
};

// Class UWorksCore.CoreRequestEncryptedAppTicketNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreRequestEncryptedAppTicketNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreRequestEncryptedAppTicketNode* RequestEncryptedAppTicketNode(struct TArray<char> Buffer); // Function UWorksCore.CoreRequestEncryptedAppTicketNode.RequestEncryptedAppTicketNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x904860
	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result); // Function UWorksCore.CoreRequestEncryptedAppTicketNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x900560
};

// Class UWorksCore.CoreRequestStoreAuthURLNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreRequestStoreAuthURLNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreRequestStoreAuthURLNode* RequestStoreAuthURLNode(struct FString URL); // Function UWorksCore.CoreRequestStoreAuthURLNode.RequestStoreAuthURLNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x904a10
	void OnRequestCompleted(bool bSuccessful, struct FString URL); // Function UWorksCore.CoreRequestStoreAuthURLNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904390
};

// Class UWorksCore.CoreRequestUserStatsNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreRequestUserStatsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreRequestUserStatsNode* RequestUserStatsNode(struct FUWorksSteamID SteamID); // Function UWorksCore.CoreRequestUserStatsNode.RequestUserStatsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x904b00
	void OnRequestCompleted(bool bSuccessful, struct FUWorksGameID GameID, enum class EUWorksResult Result, struct FUWorksSteamID SteamID); // Function UWorksCore.CoreRequestUserStatsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x9044c0
};

// Class UWorksCore.CoreFindOrCreateLeaderboardNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreFindOrCreateLeaderboardNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FUWorksSteamLeaderboard SteamLeaderboard, bool bLeaderboardFound); // Function UWorksCore.CoreFindOrCreateLeaderboardNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904150
	struct UCoreFindOrCreateLeaderboardNode* FindOrCreateLeaderboardNode(struct FString LeaderboardName, enum class EUWorksLeaderboardSortMethod LeaderboardSortMethod, enum class EUWorksLeaderboardDisplayType LeaderboardDisplayType); // Function UWorksCore.CoreFindOrCreateLeaderboardNode.FindOrCreateLeaderboardNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x903d40
};

// Class UWorksCore.CoreFindLeaderboardNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreFindLeaderboardNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FUWorksSteamLeaderboard SteamLeaderboard, bool bLeaderboardFound); // Function UWorksCore.CoreFindLeaderboardNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904150
	struct UCoreFindLeaderboardNode* FindLeaderboardNode(struct FString LeaderboardName); // Function UWorksCore.CoreFindLeaderboardNode.FindLeaderboardNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x903c50
};

// Class UWorksCore.CoreDownloadLeaderboardEntriesNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreDownloadLeaderboardEntriesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FUWorksSteamLeaderboard SteamLeaderboard, struct FUWorksSteamLeaderboardEntries SteamLeaderboardEntries, int32_t EntryCount); // Function UWorksCore.CoreDownloadLeaderboardEntriesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x903ff0
	struct UCoreDownloadLeaderboardEntriesNode* DownloadLeaderboardEntriesNode(struct FUWorksSteamLeaderboard SteamLeaderboard, enum class EUWorksLeaderboardDataRequest LeaderboardDataRequest, int32_t RangeStart, int32_t RangeEnd); // Function UWorksCore.CoreDownloadLeaderboardEntriesNode.DownloadLeaderboardEntriesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x903b00
};

// Class UWorksCore.CoreDownloadLeaderboardEntriesForUsersNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreDownloadLeaderboardEntriesForUsersNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, struct FUWorksSteamLeaderboard SteamLeaderboard, struct FUWorksSteamLeaderboardEntries SteamLeaderboardEntries, int32_t EntryCount); // Function UWorksCore.CoreDownloadLeaderboardEntriesForUsersNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x903ff0
	struct UCoreDownloadLeaderboardEntriesForUsersNode* DownloadLeaderboardEntriesForUsersNode(struct FUWorksSteamLeaderboard SteamLeaderboard, struct TArray<struct FUWorksSteamID> Users); // Function UWorksCore.CoreDownloadLeaderboardEntriesForUsersNode.DownloadLeaderboardEntriesForUsersNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9039d0
};

// Class UWorksCore.CoreUploadLeaderboardScoreNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreUploadLeaderboardScoreNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreUploadLeaderboardScoreNode* UploadLeaderboardScoreNode(struct FUWorksSteamLeaderboard SteamLeaderboard, enum class EUWorksLeaderboardUploadScoreMethod LeaderboardUploadScoreMethod, int32_t Score, struct TArray<int32_t> ScoreDetails); // Function UWorksCore.CoreUploadLeaderboardScoreNode.UploadLeaderboardScoreNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x904b90
	void OnRequestCompleted(bool bSuccessful, bool bSuccess, struct FUWorksSteamLeaderboard SteamLeaderboard, int32_t Score, bool bScoreChanged, int32_t GlobalRankNew, int32_t GlobalRankPrevious); // Function UWorksCore.CoreUploadLeaderboardScoreNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904620
};

// Class UWorksCore.CoreAttachLeaderboardUGCNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreAttachLeaderboardUGCNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, enum class EUWorksResult Result, struct FUWorksSteamLeaderboard SteamLeaderboard); // Function UWorksCore.CoreAttachLeaderboardUGCNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x903ed0
	struct UCoreAttachLeaderboardUGCNode* AttachLeaderboardUGCNode(struct FUWorksSteamLeaderboard SteamLeaderboard, struct FUWorksUGCHandle UGCHandle); // Function UWorksCore.CoreAttachLeaderboardUGCNode.AttachLeaderboardUGCNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x903900
};

// Class UWorksCore.CoreGetNumberOfCurrentPlayersNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreGetNumberOfCurrentPlayersNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	void OnRequestCompleted(bool bSuccessful, bool bSuccess, int32_t Players); // Function UWorksCore.CoreGetNumberOfCurrentPlayersNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x904270
	struct UCoreGetNumberOfCurrentPlayersNode* GetNumberOfCurrentPlayersNode(); // Function UWorksCore.CoreGetNumberOfCurrentPlayersNode.GetNumberOfCurrentPlayersNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x903ea0
};

// Class UWorksCore.CoreRequestGlobalAchievementPercentagesNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreRequestGlobalAchievementPercentagesNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreRequestGlobalAchievementPercentagesNode* RequestGlobalAchievementPercentagesNode(); // Function UWorksCore.CoreRequestGlobalAchievementPercentagesNode.RequestGlobalAchievementPercentagesNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x904950
	void OnRequestCompleted(bool bSuccessful, struct FUWorksGameID GameID, enum class EUWorksResult Result); // Function UWorksCore.CoreRequestGlobalAchievementPercentagesNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x8fc6c0
};

// Class UWorksCore.CoreRequestGlobalStatsNode
// Size: 0x40 (Inherited: 0x30)
struct UCoreRequestGlobalStatsNode : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)

	struct UCoreRequestGlobalStatsNode* RequestGlobalStatsNode(int32_t HistoryDays); // Function UWorksCore.CoreRequestGlobalStatsNode.RequestGlobalStatsNode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x904980
	void OnRequestCompleted(bool bSuccessful, struct FUWorksGameID GameID, enum class EUWorksResult Result); // Function UWorksCore.CoreRequestGlobalStatsNode.OnRequestCompleted // (Final|Native|Public) // @ game+0x8fc6c0
};

