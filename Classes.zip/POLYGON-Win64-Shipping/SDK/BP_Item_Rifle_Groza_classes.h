// BlueprintGeneratedClass BP_Item_Rifle_Groza.BP_Item_Rifle_Groza_C
// Size: 0x410 (Inherited: 0x410)
struct ABP_Item_Rifle_Groza_C : AItem_Weapon_Rifle {
};

