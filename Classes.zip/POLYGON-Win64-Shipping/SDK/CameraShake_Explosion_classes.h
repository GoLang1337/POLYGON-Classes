// BlueprintGeneratedClass CameraShake_Explosion.CameraShake_Explosion_C
// Size: 0x180 (Inherited: 0x180)
struct UCameraShake_Explosion_C : UMatineeCameraShake {
};

