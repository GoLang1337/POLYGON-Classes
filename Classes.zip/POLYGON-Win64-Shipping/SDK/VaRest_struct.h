// Enum VaRest.EVaJson
enum class EVaJson : uint8 {
	None = 0,
	Null = 1,
	String = 2,
	Number = 3,
	Boolean = 4,
	Array = 5,
	Object = 6,
	EVaJson_MAX = 7
};

// Enum VaRest.EVaRestHttpStatusCode
enum class EVaRestHttpStatusCode : int32 {
	Unknown = 0,
	Continue = 100,
	SwitchProtocol = 101,
	Ok = 200,
	Created = 201,
	Accepted = 202,
	Partial = 203,
	NoContent = 204,
	ResetContent = 205,
	PartialContent = 206,
	Ambiguous = 300,
	Moved = 301,
	Redirect = 302,
	RedirectMethod = 303,
	NotModified = 304,
	UseProxy = 305,
	RedirectKeepVerb = 307,
	BadRequest = 400,
	Denied = 401,
	PaymentReq = 402,
	Forbidden = 403,
	NotFound = 404,
	BadMethod = 405,
	NoneAcceptable = 406,
	ProxyAuthReq = 407,
	RequestTimeout = 408,
	Conflict = 409,
	Gone = 410,
	LengthRequired = 411,
	PrecondFailed = 412,
	RequestTooLarge = 413,
	UriTooLong = 414,
	UnsupportedMedia = 415,
	TooManyRequests = 429,
	RetryWith = 449,
	ServerError = 500,
	NotSupported = 501,
	BadGateway = 502,
	ServiceUnavail = 503,
	GatewayTimeout = 504,
	VersionNotSup = 505,
	EVaRestHttpStatusCode_MAX = 506
};

// Enum VaRest.EVaRestRequestStatus
enum class EVaRestRequestStatus : uint8 {
	NotStarted = 0,
	Processing = 1,
	Failed = 2,
	Failed_ConnectionError = 3,
	Succeeded = 4,
	EVaRestRequestStatus_MAX = 5
};

// Enum VaRest.EVaRestRequestContentType
enum class EVaRestRequestContentType : uint8 {
	x_www_form_urlencoded_url = 0,
	x_www_form_urlencoded_body = 1,
	json = 2,
	binary = 3,
	EVaRestRequestContentType_MAX = 4
};

// Enum VaRest.EVaRestRequestVerb
enum class EVaRestRequestVerb : uint8 {
	GET = 0,
	POST = 1,
	PUT = 2,
	DEL = 3,
	CUSTOM = 4,
	EVaRestRequestVerb_MAX = 5
};

// ScriptStruct VaRest.VaRestCallResponse
// Size: 0x28 (Inherited: 0x00)
struct FVaRestCallResponse {
	struct UVaRestRequestJSON* Request; // 0x00(0x08)
	struct FDelegate Callback; // 0x08(0x10)
	char pad_18[0x10]; // 0x18(0x10)
};

// ScriptStruct VaRest.VaRestURL
// Size: 0x68 (Inherited: 0x00)
struct FVaRestURL {
	struct FString Protocol; // 0x00(0x10)
	struct FString Host; // 0x10(0x10)
	int32_t Port; // 0x20(0x04)
	int32_t Valid; // 0x24(0x04)
	struct FString Map; // 0x28(0x10)
	struct FString RedirectURL; // 0x38(0x10)
	struct TArray<struct FString> Op; // 0x48(0x10)
	struct FString Portal; // 0x58(0x10)
};

