// WidgetBlueprintGeneratedClass UI_Squad_PlayerSlot.UI_Squad_PlayerSlot_C
// Size: 0x2a9 (Inherited: 0x260)
struct UUI_Squad_PlayerSlot_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button; // 0x268(0x08)
	struct UImage* Image_Ready_2; // 0x270(0x08)
	struct UImage* Image_Ready_3; // 0x278(0x08)
	struct UTextBlock* TextBlock_NumberSlot; // 0x280(0x08)
	struct UTextBlock* TextBlock_PlayerName; // 0x288(0x08)
	int32_t NumberSlot; // 0x290(0x04)
	char pad_294[0x4]; // 0x294(0x04)
	struct FMulticastInlineDelegate OnClickDelegate; // 0x298(0x10)
	bool IsFree; // 0x2a8(0x01)

	void SetPlayerName(struct FString PlayerName); // Function UI_Squad_PlayerSlot.UI_Squad_PlayerSlot_C.SetPlayerName // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Squad_PlayerSlot.UI_Squad_PlayerSlot_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_Squad_PlayerSlot.UI_Squad_PlayerSlot_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Squad_PlayerSlot(int32_t EntryPoint); // Function UI_Squad_PlayerSlot.UI_Squad_PlayerSlot_C.ExecuteUbergraph_UI_Squad_PlayerSlot // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
	void OnClickDelegate__DelegateSignature(struct UUI_Squad_PlayerSlot_C* Slot); // Function UI_Squad_PlayerSlot.UI_Squad_PlayerSlot_C.OnClickDelegate__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

