// BlueprintGeneratedClass BP_Item_Barrel_StandartBarrel.BP_Item_Barrel_StandartBarrel_C
// Size: 0x288 (Inherited: 0x280)
struct ABP_Item_Barrel_StandartBarrel_C : AItem_Module_General {
	struct USceneComponent* DefaultSceneRoot; // 0x280(0x08)
};

