// BlueprintGeneratedClass BP_MenuCharacter.BP_MenuCharacter_C
// Size: 0x2c0 (Inherited: 0x260)
struct ABP_MenuCharacter_C : AMenuCharacter {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UStaticMeshComponent* Clips_01; // 0x268(0x08)
	struct UStaticMeshComponent* Clips_02; // 0x270(0x08)
	struct UStaticMeshComponent* Pistol; // 0x278(0x08)
	struct UStaticMeshComponent* Grenade_02; // 0x280(0x08)
	struct UStaticMeshComponent* Grenade_01; // 0x288(0x08)
	struct UStaticMeshComponent* Pouch_03; // 0x290(0x08)
	struct UStaticMeshComponent* Pouch_02; // 0x298(0x08)
	struct UStaticMeshComponent* Pouch_01; // 0x2a0(0x08)
	struct UStaticMeshComponent* Glowstick; // 0x2a8(0x08)
	struct UStaticMeshComponent* Tool; // 0x2b0(0x08)
	struct UStaticMeshComponent* Radio; // 0x2b8(0x08)

	void OnNotifyEnd_A7E365CD41E88B50E1CF3A8FFEC592C3(struct FName NotifyName); // Function BP_MenuCharacter.BP_MenuCharacter_C.OnNotifyEnd_A7E365CD41E88B50E1CF3A8FFEC592C3 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnNotifyBegin_A7E365CD41E88B50E1CF3A8FFEC592C3(struct FName NotifyName); // Function BP_MenuCharacter.BP_MenuCharacter_C.OnNotifyBegin_A7E365CD41E88B50E1CF3A8FFEC592C3 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnInterrupted_A7E365CD41E88B50E1CF3A8FFEC592C3(struct FName NotifyName); // Function BP_MenuCharacter.BP_MenuCharacter_C.OnInterrupted_A7E365CD41E88B50E1CF3A8FFEC592C3 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnBlendOut_A7E365CD41E88B50E1CF3A8FFEC592C3(struct FName NotifyName); // Function BP_MenuCharacter.BP_MenuCharacter_C.OnBlendOut_A7E365CD41E88B50E1CF3A8FFEC592C3 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnCompleted_A7E365CD41E88B50E1CF3A8FFEC592C3(struct FName NotifyName); // Function BP_MenuCharacter.BP_MenuCharacter_C.OnCompleted_A7E365CD41E88B50E1CF3A8FFEC592C3 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ReceiveBeginPlay(); // Function BP_MenuCharacter.BP_MenuCharacter_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void PlayAnimation(); // Function BP_MenuCharacter.BP_MenuCharacter_C.PlayAnimation // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_MenuCharacter(int32_t EntryPoint); // Function BP_MenuCharacter.BP_MenuCharacter_C.ExecuteUbergraph_BP_MenuCharacter // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

