// WidgetBlueprintGeneratedClass UI_NetworkStats.UI_NetworkStats_C
// Size: 0x268 (Inherited: 0x260)
struct UUI_NetworkStats_C : UUserWidget {
	struct UWBP_NetDebugStats_C* WBP_NetDebugStats; // 0x260(0x08)
};

