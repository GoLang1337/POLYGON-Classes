// ScriptStruct StaticMeshDescription.UVMapSettings
// Size: 0x38 (Inherited: 0x00)
struct FUVMapSettings {
	struct FVector Size; // 0x00(0x0c)
	struct FVector2D UVTile; // 0x0c(0x08)
	struct FVector Position; // 0x14(0x0c)
	struct FRotator Rotation; // 0x20(0x0c)
	struct FVector Scale; // 0x2c(0x0c)
};

