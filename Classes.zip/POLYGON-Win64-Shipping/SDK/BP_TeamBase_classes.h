// BlueprintGeneratedClass BP_TeamBase.BP_TeamBase_C
// Size: 0x240 (Inherited: 0x228)
struct ABP_TeamBase_C : ATeamBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x228(0x08)
	struct UWidgetComponent* Widget; // 0x230(0x08)
	struct UBillboardComponent* Billboard; // 0x238(0x08)

	void SetVisibleFromDistance(); // Function BP_TeamBase.BP_TeamBase_C.SetVisibleFromDistance // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ReceiveBeginPlay(); // Function BP_TeamBase.BP_TeamBase_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_TeamBase(int32_t EntryPoint); // Function BP_TeamBase.BP_TeamBase_C.ExecuteUbergraph_BP_TeamBase // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

