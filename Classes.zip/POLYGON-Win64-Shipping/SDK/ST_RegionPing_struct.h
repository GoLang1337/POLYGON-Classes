// UserDefinedStruct ST_RegionPing.ST_RegionPing
// Size: 0x20 (Inherited: 0x00)
struct FST_RegionPing {
	enum class ERegion Region_16_64CCDF4949B4F0CFEE5545AD78C9252D; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString PingUrl_13_C6E17C0845B839B33CC93086A0FA43FA; // 0x08(0x10)
	float Stopwatch_9_D06431374A9CC7D48EEBA4A44B376E32; // 0x18(0x04)
	int32_t Ping_7_B068B96D41F1B0EEF2B1A59E23F88095; // 0x1c(0x04)
};

