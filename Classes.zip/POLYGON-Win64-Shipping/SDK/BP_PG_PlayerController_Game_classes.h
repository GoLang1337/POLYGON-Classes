// BlueprintGeneratedClass BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C
// Size: 0x5d0 (Inherited: 0x5a8)
struct ABP_PG_PlayerController_Game_C : APG_PlayerController_Game {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5a8(0x08)
	struct UUI_GeneralGameScreen_C* UI_GeneralGameScreen; // 0x5b0(0x08)
	struct UUI_InteractionTime_C* UI_InteractionTime; // 0x5b8(0x08)
	struct UUI_DarkenScreen_C* UI_DarkenScreen; // 0x5c0(0x08)
	struct UUI_CaptureProcess_C* UI_CaptureProcess; // 0x5c8(0x08)

	void HideInterface(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.HideInterface // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void InpActEvt_Escape_K2Node_InputKeyEvent_3(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_Escape_K2Node_InputKeyEvent_3 // (BlueprintEvent) // @ game+0x1847880
	void InpActEvt_Scoreboard_K2Node_InputActionEvent_5(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_Scoreboard_K2Node_InputActionEvent_5 // (BlueprintEvent) // @ game+0x1847880
	void InpActEvt_Scoreboard_K2Node_InputActionEvent_4(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_Scoreboard_K2Node_InputActionEvent_4 // (BlueprintEvent) // @ game+0x1847880
	void InpActEvt_ChatAll_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_ChatAll_K2Node_InputActionEvent_3 // (BlueprintEvent) // @ game+0x1847880
	void InpActEvt_ChatTeam_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_ChatTeam_K2Node_InputActionEvent_2 // (BlueprintEvent) // @ game+0x1847880
	void InpActEvt_HideInterface_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_HideInterface_K2Node_InputActionEvent_1 // (BlueprintEvent) // @ game+0x1847880
	void InpActEvt_N_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_N_K2Node_InputKeyEvent_2 // (BlueprintEvent) // @ game+0x1847880
	void InpActEvt_MiddleMouseButton_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.InpActEvt_MiddleMouseButton_K2Node_InputKeyEvent_1 // (BlueprintEvent) // @ game+0x1847880
	void OpenScoreboard(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.OpenScoreboard // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void CloseScoreboard(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.CloseScoreboard // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ReceiveBeginPlay(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void DisplayMessageToChatEvent(struct FChatMessage Message); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.DisplayMessageToChatEvent // (Event|Public|BlueprintEvent) // @ game+0x1847880
	void StartInteractionEvent(float interactionTime); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.StartInteractionEvent // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void StopInteractionEvent(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.StopInteractionEvent // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void NotifyPlayerKilledEvent(struct APG_PlayerState_Game* killed, struct APG_PlayerState_Game* killer, bool isHeadshot, bool isGrenade); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.NotifyPlayerKilledEvent // (Event|Public|BlueprintEvent) // @ game+0x1847880
	void NotifyAddedGameScoreEvent(int32_t addedScore, enum class EAccrualTypeGameScore addGameScoreType, struct FString customString); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.NotifyAddedGameScoreEvent // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void SetPlayerState(); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.SetPlayerState // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_PG_PlayerController_Game(int32_t EntryPoint); // Function BP_PG_PlayerController_Game.BP_PG_PlayerController_Game_C.ExecuteUbergraph_BP_PG_PlayerController_Game // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

