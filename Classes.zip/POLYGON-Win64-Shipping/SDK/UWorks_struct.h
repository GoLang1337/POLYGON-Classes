// ScriptStruct UWorks.UWorksSteamID
// Size: 0x08 (Inherited: 0x00)
struct FUWorksSteamID {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorks.UWorksGameID
// Size: 0x08 (Inherited: 0x00)
struct FUWorksGameID {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorks.UWorksPublishedFileID
// Size: 0x08 (Inherited: 0x00)
struct FUWorksPublishedFileID {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct UWorks.UWorksSteamItemDef
// Size: 0x04 (Inherited: 0x00)
struct FUWorksSteamItemDef {
	int32_t Value; // 0x00(0x04)
};

// ScriptStruct UWorks.UWorksSteamItemInstanceID
// Size: 0x08 (Inherited: 0x00)
struct FUWorksSteamItemInstanceID {
	char pad_0[0x8]; // 0x00(0x08)
};

