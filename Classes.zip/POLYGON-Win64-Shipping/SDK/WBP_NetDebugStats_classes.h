// WidgetBlueprintGeneratedClass WBP_NetDebugStats.WBP_NetDebugStats_C
// Size: 0x300 (Inherited: 0x260)
struct UWBP_NetDebugStats_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UTextBlock* AverageLagText; // 0x268(0x08)
	struct UTextBlock* ConnectionStateText; // 0x270(0x08)
	struct UTextBlock* InBytesPerSecondText; // 0x278(0x08)
	struct UTextBlock* InBytesText; // 0x280(0x08)
	struct UTextBlock* InPacketLostText; // 0x288(0x08)
	struct UTextBlock* InPacketsPerSecondText; // 0x290(0x08)
	struct UTextBlock* InPacketsText; // 0x298(0x08)
	struct UTextBlock* InTotalBytesText; // 0x2a0(0x08)
	struct UTextBlock* InTotalPacketsText; // 0x2a8(0x08)
	struct UTextBlock* MaxPacketsText; // 0x2b0(0x08)
	struct UTextBlock* OutBytesPerSecondText; // 0x2b8(0x08)
	struct UTextBlock* OutBytesText; // 0x2c0(0x08)
	struct UTextBlock* OutPacketLostText; // 0x2c8(0x08)
	struct UTextBlock* OutPacketsPerSecondText; // 0x2d0(0x08)
	struct UTextBlock* OutPacketsText; // 0x2d8(0x08)
	struct UTextBlock* OutTotalBytesText; // 0x2e0(0x08)
	struct UTextBlock* OutTotalPacketsText; // 0x2e8(0x08)
	struct UTextBlock* TotalAcksText; // 0x2f0(0x08)
	struct FTimerHandle TimerHandle_FetchDetails; // 0x2f8(0x08)

	void Internal_CalculatePackets(); // Function WBP_NetDebugStats.WBP_NetDebugStats_C.Internal_CalculatePackets // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Internal_CalculateBytes(); // Function WBP_NetDebugStats.WBP_NetDebugStats_C.Internal_CalculateBytes // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function WBP_NetDebugStats.WBP_NetDebugStats_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Destruct(); // Function WBP_NetDebugStats.WBP_NetDebugStats_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void FetchDetails(); // Function WBP_NetDebugStats.WBP_NetDebugStats_C.FetchDetails // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_WBP_NetDebugStats(int32_t EntryPoint); // Function WBP_NetDebugStats.WBP_NetDebugStats_C.ExecuteUbergraph_WBP_NetDebugStats // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

