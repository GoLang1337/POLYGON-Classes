// WidgetBlueprintGeneratedClass UI_UpgradeLevelOfPlayer.UI_UpgradeLevelOfPlayer_C
// Size: 0x290 (Inherited: 0x260)
struct UUI_UpgradeLevelOfPlayer_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* DisplayNewLevel; // 0x268(0x08)
	struct UImage* Image_NewLevelIcon; // 0x270(0x08)
	struct UImage* Lines; // 0x278(0x08)
	struct UImage* LinesRainbow; // 0x280(0x08)
	struct UTextBlock* TextBlock_NewLevel; // 0x288(0x08)

	void Construct(); // Function UI_UpgradeLevelOfPlayer.UI_UpgradeLevelOfPlayer_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_UpgradeLevelOfPlayer.UI_UpgradeLevelOfPlayer_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_UpgradeLevelOfPlayer(int32_t EntryPoint); // Function UI_UpgradeLevelOfPlayer.UI_UpgradeLevelOfPlayer_C.ExecuteUbergraph_UI_UpgradeLevelOfPlayer // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

