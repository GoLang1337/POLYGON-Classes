// WidgetBlueprintGeneratedClass UI_ShopItem.UI_ShopItem_C
// Size: 0x330 (Inherited: 0x260)
struct UUI_ShopItem_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border; // 0x268(0x08)
	struct UBorder* Border_Purchased; // 0x270(0x08)
	struct UBorder* Border_RequiredLevel; // 0x278(0x08)
	struct UBorder* Border_Soon; // 0x280(0x08)
	struct UButton* Button; // 0x288(0x08)
	struct UButton* Button_Unavailable; // 0x290(0x08)
	struct UHorizontalBox* HorizontalBox_Price; // 0x298(0x08)
	struct UHorizontalBox* HorizontalBox_RequiredLevel; // 0x2a0(0x08)
	struct UImage* Image_Coin; // 0x2a8(0x08)
	struct UImage* Image_Corner; // 0x2b0(0x08)
	struct UImage* Image_Crowns; // 0x2b8(0x08)
	struct UImage* Image_ItemIcon; // 0x2c0(0x08)
	struct UOverlay* Overlay_Base; // 0x2c8(0x08)
	struct UOverlay* Overlay_Loading; // 0x2d0(0x08)
	struct UTextBlock* TextBlock_Buy; // 0x2d8(0x08)
	struct UTextBlock* TextBlock_ItemName; // 0x2e0(0x08)
	struct UTextBlock* TextBlock_Price; // 0x2e8(0x08)
	struct UTextBlock* TextBlock_Purchased; // 0x2f0(0x08)
	struct UTextBlock* TextBlock_RequiredLevel; // 0x2f8(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_PriceType; // 0x300(0x08)
	struct AItem_General* ItemClass; // 0x308(0x08)
	struct FMulticastInlineDelegate IsHoveredDelegate; // 0x310(0x10)
	bool IsPurchased; // 0x320(0x01)
	bool IsAvailable; // 0x321(0x01)
	bool IsPremium; // 0x322(0x01)
	char pad_323[0x1]; // 0x323(0x01)
	int32_t LevelRequired; // 0x324(0x04)
	struct ABP_PG_PlayerController_Menu_C* PlayerController; // 0x328(0x08)

	void SetIsEnabled_Override(bool bInIsEnabled); // Function UI_ShopItem.UI_ShopItem_C.SetIsEnabled_Override // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetIsPurchased(bool IsPurchased); // Function UI_ShopItem.UI_ShopItem_C.SetIsPurchased // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void GetCatalogVersionByItemType(struct FString Catalog); // Function UI_ShopItem.UI_ShopItem_C.GetCatalogVersionByItemType // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void SetItemInfo(); // Function UI_ShopItem.UI_ShopItem_C.SetItemInfo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_09710F9A4237AB46170B1D960A630947(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_ShopItem.UI_ShopItem_C.OnPlayFabResponse_09710F9A4237AB46170B1D960A630947 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_ShopItem.UI_ShopItem_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function UI_ShopItem.UI_ShopItem_C.OnMouseEnter // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1847880
	void OnMouseLeave(struct FPointerEvent MouseEvent); // Function UI_ShopItem.UI_ShopItem_C.OnMouseLeave // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1847880
	void PurchaseItemSuccess(struct FClientExecuteCloudScriptResult Result, struct UObject* customData); // Function UI_ShopItem.UI_ShopItem_C.PurchaseItemSuccess // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PurchaseItemFailure(struct FPlayFabError Error, struct UObject* customData); // Function UI_ShopItem.UI_ShopItem_C.PurchaseItemFailure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function UI_ShopItem.UI_ShopItem_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_ShopItem.UI_ShopItem_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnUpdatePlayerCombinedInfo_Event(); // Function UI_ShopItem.UI_ShopItem_C.OnUpdatePlayerCombinedInfo_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnClicked_Event(); // Function UI_ShopItem.UI_ShopItem_C.OnClicked_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_ShopItem(int32_t EntryPoint); // Function UI_ShopItem.UI_ShopItem_C.ExecuteUbergraph_UI_ShopItem // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
	void IsHoveredDelegate__DelegateSignature(struct UUI_ShopItem_C* Item, bool IsHovered); // Function UI_ShopItem.UI_ShopItem_C.IsHoveredDelegate__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

