// UserDefinedStruct ST_Option.ST_Option
// Size: 0x28 (Inherited: 0x00)
struct FST_Option {
	struct FText Label_3_C8817C974AD087B6ABEF9D91A826B4D1; // 0x00(0x18)
	struct FString Value_6_570477F044A4BD292888D9820D5EC764; // 0x18(0x10)
};

