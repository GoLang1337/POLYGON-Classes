// WidgetBlueprintGeneratedClass UI_SupportBox_Ammo.UI_SupportBox_Ammo_C
// Size: 0x260 (Inherited: 0x260)
struct UUI_SupportBox_Ammo_C : UUserWidget {
};

