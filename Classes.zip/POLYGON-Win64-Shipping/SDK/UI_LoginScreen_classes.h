// WidgetBlueprintGeneratedClass UI_LoginScreen.UI_LoginScreen_C
// Size: 0x280 (Inherited: 0x260)
struct UUI_LoginScreen_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UUI_LoadingIcon_C* UI_LoadingIcon; // 0x268(0x08)
	struct ABP_PG_PlayerController_Menu_C* PlayerController; // 0x270(0x08)
	struct ABP_PG_PlayerState_Menu_C* PlayerState; // 0x278(0x08)

	void ConstructRequestPlayerCombinedInfo(struct UPlayFabJsonObject* Request); // Function UI_LoginScreen.UI_LoginScreen_C.ConstructRequestPlayerCombinedInfo // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void ShowErrorMessage(struct FPlayFabError PlayFabError); // Function UI_LoginScreen.UI_LoginScreen_C.ShowErrorMessage // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_C212664541185E46F64DD1B5C3B4F97F(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_LoginScreen.UI_LoginScreen_C.OnPlayFabResponse_C212664541185E46F64DD1B5C3B4F97F // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_65C9D32C43B0E62996B765AC298DBA20(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_LoginScreen.UI_LoginScreen_C.OnPlayFabResponse_65C9D32C43B0E62996B765AC298DBA20 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_9D53D0BB48321AF2818524814BD8FB06(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_LoginScreen.UI_LoginScreen_C.OnPlayFabResponse_9D53D0BB48321AF2818524814BD8FB06 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_DA74F5AB45E383FF5D542A96BD744E9E(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_LoginScreen.UI_LoginScreen_C.OnPlayFabResponse_DA74F5AB45E383FF5D542A96BD744E9E // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void LoginWithSteam_Success(struct FClientLoginResult Result, struct UObject* customData); // Function UI_LoginScreen.UI_LoginScreen_C.LoginWithSteam_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void LoginWithSteam_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_LoginScreen.UI_LoginScreen_C.LoginWithSteam_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_LoginScreen.UI_LoginScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void LoginWithSteam(); // Function UI_LoginScreen.UI_LoginScreen_C.LoginWithSteam // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void LoginWithCustomID(); // Function UI_LoginScreen.UI_LoginScreen_C.LoginWithCustomID // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void LoginWithCustomID_Success(struct FClientLoginResult Result, struct UObject* customData); // Function UI_LoginScreen.UI_LoginScreen_C.LoginWithCustomID_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void LoginWithCustomID_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_LoginScreen.UI_LoginScreen_C.LoginWithCustomID_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void RequestPlayerCombinedInfo(); // Function UI_LoginScreen.UI_LoginScreen_C.RequestPlayerCombinedInfo // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Login(); // Function UI_LoginScreen.UI_LoginScreen_C.Login // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void GetPlayerCombinedInfo_Success(struct FClientGetPlayerCombinedInfoResult Result, struct UObject* customData); // Function UI_LoginScreen.UI_LoginScreen_C.GetPlayerCombinedInfo_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void GetPlayerCombinedInfo_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_LoginScreen.UI_LoginScreen_C.GetPlayerCombinedInfo_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void UpdateUserTitleDisplayName_Success(struct FClientUpdateUserTitleDisplayNameResult Result, struct UObject* customData); // Function UI_LoginScreen.UI_LoginScreen_C.UpdateUserTitleDisplayName_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void UpdateUserTitleDisplayName_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_LoginScreen.UI_LoginScreen_C.UpdateUserTitleDisplayName_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_LoginScreen(int32_t EntryPoint); // Function UI_LoginScreen.UI_LoginScreen_C.ExecuteUbergraph_UI_LoginScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

