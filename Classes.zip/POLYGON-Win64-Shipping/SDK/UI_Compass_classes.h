// WidgetBlueprintGeneratedClass UI_Compass.UI_Compass_C
// Size: 0x270 (Inherited: 0x260)
struct UUI_Compass_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* Image_Compass; // 0x268(0x08)

	void SetCompassPosition(); // Function UI_Compass.UI_Compass_C.SetCompassPosition // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function UI_Compass.UI_Compass_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Compass(int32_t EntryPoint); // Function UI_Compass.UI_Compass_C.ExecuteUbergraph_UI_Compass // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

