// WidgetBlueprintGeneratedClass UI_Shop_WeaponInfo.UI_Shop_WeaponInfo_C
// Size: 0x2a8 (Inherited: 0x260)
struct UUI_Shop_WeaponInfo_C : UUserWidget {
	struct UImage* Image_WeaponIcon; // 0x260(0x08)
	struct UTextBlock* TextBlock_WeaponName; // 0x268(0x08)
	struct UUI_ItemParameter_C* UI_ItemParameter_AccuracyHip; // 0x270(0x08)
	struct UUI_ItemParameter_C* UI_ItemParameter_AccuracySight; // 0x278(0x08)
	struct UUI_ItemParameter_C* UI_ItemParameter_Damage; // 0x280(0x08)
	struct UUI_ItemParameter_C* UI_ItemParameter_MagazineCapacity; // 0x288(0x08)
	struct UUI_ItemParameter_C* UI_ItemParameter_Range; // 0x290(0x08)
	struct UUI_ItemParameter_C* UI_ItemParameter_RateOfFire; // 0x298(0x08)
	struct AItem_Weapon_General* WeaponClass; // 0x2a0(0x08)

	void SetNewWeaponInfo(struct AItem_Weapon_General* WeaponClass); // Function UI_Shop_WeaponInfo.UI_Shop_WeaponInfo_C.SetNewWeaponInfo // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

