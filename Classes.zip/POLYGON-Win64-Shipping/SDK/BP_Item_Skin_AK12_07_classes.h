// BlueprintGeneratedClass BP_Item_Skin_AK12_07.BP_Item_Skin_AK12_07_C
// Size: 0x290 (Inherited: 0x288)
struct ABP_Item_Skin_AK12_07_C : AItem_Module_Skin {
	struct USceneComponent* DefaultSceneRoot; // 0x288(0x08)
};

