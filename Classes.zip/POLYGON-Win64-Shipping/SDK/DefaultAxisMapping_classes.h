// WidgetBlueprintGeneratedClass DefaultAxisMapping.DefaultAxisMapping_C
// Size: 0x2b0 (Inherited: 0x2b0)
struct UDefaultAxisMapping_C : UAxisMapping {
};

