// WidgetBlueprintGeneratedClass UI_KillLog.UI_KillLog_C
// Size: 0x268 (Inherited: 0x260)
struct UUI_KillLog_C : UUserWidget {
	struct UVerticalBox* VerticalBox_Log; // 0x260(0x08)

	void AddEntryToLog(struct APG_PlayerState_Game* killed, struct APG_PlayerState_Game* killer, bool isHeadshot, bool isGrenade); // Function UI_KillLog.UI_KillLog_C.AddEntryToLog // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

