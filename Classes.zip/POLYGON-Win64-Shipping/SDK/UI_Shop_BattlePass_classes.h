// WidgetBlueprintGeneratedClass UI_Shop_BattlePass.UI_Shop_BattlePass_C
// Size: 0x3d8 (Inherited: 0x260)
struct UUI_Shop_BattlePass_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* PurchaseBattlePassAnimation; // 0x268(0x08)
	struct UWidgetAnimation* GetRewardsButton_Click; // 0x270(0x08)
	struct UWidgetAnimation* GetRewardImage; // 0x278(0x08)
	struct UWidgetAnimation* GetRewardsButton_Flashing; // 0x280(0x08)
	struct UWidgetAnimation* RewardImageAnimation; // 0x288(0x08)
	struct UButton* Button_BuyBattlePass; // 0x290(0x08)
	struct UButton* Button_GetRewards; // 0x298(0x08)
	struct UButton* Button_PurchaseLevel; // 0x2a0(0x08)
	struct UHorizontalBox* HorizontalBox_NextLevel; // 0x2a8(0x08)
	struct UImage* Image_Description_FreeImage; // 0x2b0(0x08)
	struct UImage* Image_Description_PremiumImage; // 0x2b8(0x08)
	struct UImage* Image_RewardImage; // 0x2c0(0x08)
	struct UOverlay* Overlay_BattlePassButton_Loading; // 0x2c8(0x08)
	struct UOverlay* Overlay_GetRewards; // 0x2d0(0x08)
	struct UOverlay* Overlay_PurchaseLevel; // 0x2d8(0x08)
	struct UScrollBox* ScrollBox_Rewards; // 0x2e0(0x08)
	struct UTextBlock* TextBlock_BattlePassPrice; // 0x2e8(0x08)
	struct UTextBlock* TextBlock_CurrentLevel; // 0x2f0(0x08)
	struct UTextBlock* TextBlock_CurrentProgress; // 0x2f8(0x08)
	struct UTextBlock* TextBlock_FreeRewardDescription; // 0x300(0x08)
	struct UTextBlock* TextBlock_FreeRewardTitle; // 0x308(0x08)
	struct UTextBlock* TextBlock_NextLevel; // 0x310(0x08)
	struct UTextBlock* TextBlock_PremiumRewardDescription; // 0x318(0x08)
	struct UTextBlock* TextBlock_PremiumRewardTitle; // 0x320(0x08)
	struct UTextBlock* TextBlock_ProgressForNextLevel; // 0x328(0x08)
	struct UTextBlock* TextBlock_PurchaseLevels_Length; // 0x330(0x08)
	struct UTextBlock* TextBlock_PurchaseLevels_Price; // 0x338(0x08)
	struct UTextBlock* TextBlock_SelectedLevel; // 0x340(0x08)
	struct UUI_LoadingIcon_C* UI_LoadingIcon; // 0x348(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Description; // 0x350(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_IsActive; // 0x358(0x08)
	struct ABP_PG_PlayerController_Menu_C* PlayerController; // 0x360(0x08)
	int32_t TotalCurrentProgress; // 0x368(0x04)
	char pad_36C[0x4]; // 0x36c(0x04)
	struct FBattlePassReward Current Level; // 0x370(0x58)
	bool HasBattlePass; // 0x3c8(0x01)
	char pad_3C9[0x7]; // 0x3c9(0x07)
	struct UUI_Shop_BattlePass_Reward_C* SelectedReward; // 0x3d0(0x08)

	void PlayBlocksAnimation(); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.PlayBlocksAnimation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ParseBlocksOfReward(); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.ParseBlocksOfReward // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void AddRewardsToPlayer(struct UPlayFabJsonObject* Rewards); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.AddRewardsToPlayer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void FillPurchaseLevel(); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.FillPurchaseLevel // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void GetReceivedLevels(int32_t FreeLevel, int32_t PremiumLevel); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.GetReceivedLevels // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ConstructRewardsRequest(struct UPlayFabJsonObject* Value ); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.ConstructRewardsRequest // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void GetBattlePassLevelInfoByProgress(int32_t Progress, struct FBattlePassReward LevelInfo); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.GetBattlePassLevelInfoByProgress // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void OnPlayFabResponse_118A6FC14E6ABFCBF8FABEABFF88B374(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.OnPlayFabResponse_118A6FC14E6ABFCBF8FABEABFF88B374 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_F0366C6D4D73BFA65CEDAFB3CE696588(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.OnPlayFabResponse_F0366C6D4D73BFA65CEDAFB3CE696588 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_D50CB35B48CBDA6D16812099C44207AF(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.OnPlayFabResponse_D50CB35B48CBDA6D16812099C44207AF // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnUpdatePlayerCombinedInfo_Event(); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.OnUpdatePlayerCombinedInfo_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BattlePass_Button_BuyBattlePass_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.BndEvt__UI_Shop_BattlePass_Button_BuyBattlePass_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BattlePass_Button_PurchaseLevel_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.BndEvt__UI_Shop_BattlePass_Button_PurchaseLevel_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_BattlePass_Button_GetRewards_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.BndEvt__UI_Shop_BattlePass_Button_GetRewards_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void RequestBattlePassRewards_Success(struct FClientExecuteCloudScriptResult Result, struct UObject* customData); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.RequestBattlePassRewards_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void RequestBattlePassRewards_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.RequestBattlePassRewards_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PurchaseItemFailure(struct FPlayFabError Error, struct UObject* customData); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.PurchaseItemFailure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PurchaseItemSuccess(struct FClientExecuteCloudScriptResult Result, struct UObject* customData); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.PurchaseItemSuccess // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnClicked_Event(); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.OnClicked_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnClicked_BuyLevels_Event(); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.OnClicked_BuyLevels_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PurchaseBattlePassXP_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.PurchaseBattlePassXP_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PurchaseBattlePassXP_Success(struct FClientExecuteCloudScriptResult Result, struct UObject* customData); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.PurchaseBattlePassXP_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Shop_BattlePass(int32_t EntryPoint); // Function UI_Shop_BattlePass.UI_Shop_BattlePass_C.ExecuteUbergraph_UI_Shop_BattlePass // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

