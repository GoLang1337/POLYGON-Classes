// WidgetBlueprintGeneratedClass UI_GameLoading.UI_GameLoading_C
// Size: 0x288 (Inherited: 0x260)
struct UUI_GameLoading_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* Image_183; // 0x268(0x08)
	struct UImage* Lines_Map; // 0x270(0x08)
	struct UImage* LinesRainbow_Map; // 0x278(0x08)
	struct UUI_LoadingIcon_C* UI_LoadingIcon; // 0x280(0x08)

	void PreConstruct(bool IsDesignTime); // Function UI_GameLoading.UI_GameLoading_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_GameLoading(int32_t EntryPoint); // Function UI_GameLoading.UI_GameLoading_C.ExecuteUbergraph_UI_GameLoading // (Final|UbergraphFunction) // @ game+0x1847880
};

