// WidgetBlueprintGeneratedClass UI_GamePointsWindow.UI_GamePointsWindow_C
// Size: 0x284 (Inherited: 0x260)
struct UUI_GamePointsWindow_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UGridPanel* GridPanel; // 0x268(0x08)
	struct UOverlay* Overlay_AllGamePoints; // 0x270(0x08)
	struct UTextBlock* TextBlock_AllGamePoints; // 0x278(0x08)
	int32_t AllGamePoint; // 0x280(0x04)

	void AddNewPointMessage(int32_t AddPoint, enum class EAccrualTypeGameScore addGameScoreType, struct FString customString); // Function UI_GamePointsWindow.UI_GamePointsWindow_C.AddNewPointMessage // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_GamePointsWindow(int32_t EntryPoint); // Function UI_GamePointsWindow.UI_GamePointsWindow_C.ExecuteUbergraph_UI_GamePointsWindow // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

