// WidgetBlueprintGeneratedClass UI_CaptureProcess.UI_CaptureProcess_C
// Size: 0x290 (Inherited: 0x260)
struct UUI_CaptureProcess_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border_Process; // 0x268(0x08)
	struct UImage* Image_Lines; // 0x270(0x08)
	struct UProgressBar* ProgressBar_Process; // 0x278(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker; // 0x280(0x08)
	struct AControlPoint* ControlPointReference; // 0x288(0x08)

	void Construct(); // Function UI_CaptureProcess.UI_CaptureProcess_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_CaptureProcess.UI_CaptureProcess_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnCapturedTeam_Event(); // Function UI_CaptureProcess.UI_CaptureProcess_C.OnCapturedTeam_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnChangeCapturePoints_Event(); // Function UI_CaptureProcess.UI_CaptureProcess_C.OnChangeCapturePoints_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_CaptureProcess(int32_t EntryPoint); // Function UI_CaptureProcess.UI_CaptureProcess_C.ExecuteUbergraph_UI_CaptureProcess // (Final|UbergraphFunction) // @ game+0x1847880
};

