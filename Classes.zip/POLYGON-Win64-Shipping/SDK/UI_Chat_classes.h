// WidgetBlueprintGeneratedClass UI_Chat.UI_Chat_C
// Size: 0x2da (Inherited: 0x260)
struct UUI_Chat_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Warning; // 0x268(0x08)
	struct UWidgetAnimation* HiddenChat; // 0x270(0x08)
	struct UBorder* Border; // 0x278(0x08)
	struct UButton* Button_CloseChat; // 0x280(0x08)
	struct UButton* Button_MessageType; // 0x288(0x08)
	struct UEditableText* EditableText_Message; // 0x290(0x08)
	struct UScrollBox* ScrollBox_Chat; // 0x298(0x08)
	struct UScrollBox* ScrollBox_Message; // 0x2a0(0x08)
	struct UTextBlock* TextBlock_MessageType; // 0x2a8(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Main; // 0x2b0(0x08)
	struct ABP_PG_PlayerState_Game_C* PlayerState; // 0x2b8(0x08)
	bool ChatIsOpened; // 0x2c0(0x01)
	char pad_2C1[0x7]; // 0x2c1(0x07)
	struct FTimerHandle Timer_PlayAnimation; // 0x2c8(0x08)
	struct FTimerHandle Timer_HiddenChat; // 0x2d0(0x08)
	enum class EMessageType MessageType; // 0x2d8(0x01)
	bool IsShowedMouseCursor; // 0x2d9(0x01)

	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function UI_Chat.UI_Chat_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OpenChat(); // Function UI_Chat.UI_Chat_C.OpenChat // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__EditableText_Message_K2Node_ComponentBoundEvent_0_OnEditableTextCommittedEvent__DelegateSignature(struct FText Text, enum class ETextCommit CommitMethod); // Function UI_Chat.UI_Chat_C.BndEvt__EditableText_Message_K2Node_ComponentBoundEvent_0_OnEditableTextCommittedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Chat.UI_Chat_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void CloseChat(); // Function UI_Chat.UI_Chat_C.CloseChat // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void AddMessage(struct FChatMessage Message); // Function UI_Chat.UI_Chat_C.AddMessage // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void StartPlayAnimationHiddenChat(); // Function UI_Chat.UI_Chat_C.StartPlayAnimationHiddenChat // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PlayAnimationEvent(); // Function UI_Chat.UI_Chat_C.PlayAnimationEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void HiddenChatEvent(); // Function UI_Chat.UI_Chat_C.HiddenChatEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SendMessage(); // Function UI_Chat.UI_Chat_C.SendMessage // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_MessageType_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function UI_Chat.UI_Chat_C.BndEvt__Button_MessageType_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__EditableText_Message_K2Node_ComponentBoundEvent_2_OnEditableTextChangedEvent__DelegateSignature(struct FText Text); // Function UI_Chat.UI_Chat_C.BndEvt__EditableText_Message_K2Node_ComponentBoundEvent_2_OnEditableTextChangedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x1847880
	void SelectMessageType(enum class EMessageType MessageType); // Function UI_Chat.UI_Chat_C.SelectMessageType // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_CloseChat_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature(); // Function UI_Chat.UI_Chat_C.BndEvt__Button_CloseChat_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void OnAddedToFocusPath(struct FFocusEvent InFocusEvent); // Function UI_Chat.UI_Chat_C.OnAddedToFocusPath // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Chat(int32_t EntryPoint); // Function UI_Chat.UI_Chat_C.ExecuteUbergraph_UI_Chat // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

