// WidgetBlueprintGeneratedClass DefaultActionMapping.DefaultActionMapping_C
// Size: 0x2a8 (Inherited: 0x2a8)
struct UDefaultActionMapping_C : UActionMapping {
};

