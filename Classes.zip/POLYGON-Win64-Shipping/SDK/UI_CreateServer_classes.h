// WidgetBlueprintGeneratedClass UI_CreateServer.UI_CreateServer_C
// Size: 0x2e8 (Inherited: 0x260)
struct UUI_CreateServer_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* ServerNameWarning; // 0x268(0x08)
	struct UWidgetAnimation* StartHovered; // 0x270(0x08)
	struct UBorder* Border_116; // 0x278(0x08)
	struct UButton* Button_CreateServer; // 0x280(0x08)
	struct UButton* Button_NextMap; // 0x288(0x08)
	struct UButton* Button_PreviousMap; // 0x290(0x08)
	struct UComboBoxString* ComboBoxString_GameMode; // 0x298(0x08)
	struct UEditableTextBox* EditableTextBox_ServerName; // 0x2a0(0x08)
	struct UImage* Image_ServerMap; // 0x2a8(0x08)
	struct USizeBox* SizeBox_StartBotton; // 0x2b0(0x08)
	struct UTextBlock* TextBlock_MapName; // 0x2b8(0x08)
	int32_t SelectedMapIndex; // 0x2c0(0x04)
	int32_t SelectedMaxPlayers; // 0x2c4(0x04)
	struct ABP_PG_PlayerController_Menu_C* PlayerController; // 0x2c8(0x08)
	bool ServerIsCreated; // 0x2d0(0x01)
	char pad_2D1[0x3]; // 0x2d1(0x03)
	struct FName SelectedMapName; // 0x2d4(0x08)
	char pad_2DC[0x4]; // 0x2dc(0x04)
	struct UUI_ExperimentalMode_Tooltip_C* UI_ExperimentalModeTooltip; // 0x2e0(0x08)

	struct UWidget* GenerateTooltipForExperimentalMode(); // Function UI_CreateServer.UI_CreateServer_C.GenerateTooltipForExperimentalMode // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void ParsePlayerCombinedInfo(); // Function UI_CreateServer.UI_CreateServer_C.ParsePlayerCombinedInfo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnPlayFabResponse_97B0F78B43A4381A61C05E8774387836(struct FPlayFabBaseModel response, struct UObject* customData, bool successful); // Function UI_CreateServer.UI_CreateServer_C.OnPlayFabResponse_97B0F78B43A4381A61C05E8774387836 // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_137_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature(); // Function UI_CreateServer.UI_CreateServer_C.BndEvt__Button_137_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_CreateServer.UI_CreateServer_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_CreateServer.UI_CreateServer_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void CreateServer_Failure(struct FPlayFabError Error, struct UObject* customData); // Function UI_CreateServer.UI_CreateServer_C.CreateServer_Failure // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Play_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function UI_CreateServer.UI_CreateServer_C.BndEvt__Button_Play_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_StartServer_K2Node_ComponentBoundEvent_5_OnButtonHoverEvent__DelegateSignature(); // Function UI_CreateServer.UI_CreateServer_C.BndEvt__Button_StartServer_K2Node_ComponentBoundEvent_5_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void CreateServer_Success(struct FClientStartGameResult Result, struct UObject* customData); // Function UI_CreateServer.UI_CreateServer_C.CreateServer_Success // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_NextMap_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature(); // Function UI_CreateServer.UI_CreateServer_C.BndEvt__Button_NextMap_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_PreviousMap_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature(); // Function UI_CreateServer.UI_CreateServer_C.BndEvt__Button_PreviousMap_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void OnUpdatePlayerCombinedInfo_Event(); // Function UI_CreateServer.UI_CreateServer_C.OnUpdatePlayerCombinedInfo_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void CreateServer(); // Function UI_CreateServer.UI_CreateServer_C.CreateServer // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_CreateServer(int32_t EntryPoint); // Function UI_CreateServer.UI_CreateServer_C.ExecuteUbergraph_UI_CreateServer // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

