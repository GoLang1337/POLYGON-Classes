// WidgetBlueprintGeneratedClass UI_Shop_VIP.UI_Shop_VIP_C
// Size: 0x2a0 (Inherited: 0x260)
struct UUI_Shop_VIP_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UTextBlock* TextBlock_VIPTimer; // 0x268(0x08)
	struct UUI_Shop_VIP_Button_C* UI_Shop_VIP_Button_1Day; // 0x270(0x08)
	struct UUI_Shop_VIP_Button_C* UI_Shop_VIP_Button_30Days; // 0x278(0x08)
	struct UUI_Shop_VIP_Button_C* UI_Shop_VIP_Button_365Days; // 0x280(0x08)
	struct UUI_Shop_VIP_Button_C* UI_Shop_VIP_Button_7Days; // 0x288(0x08)
	struct UUI_Shop_VIP_Button_C* UI_Shop_VIP_Button_90Days; // 0x290(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_ActiveState; // 0x298(0x08)

	void Construct(); // Function UI_Shop_VIP.UI_Shop_VIP_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnUpdatePlayerCombinedInfo_Event(); // Function UI_Shop_VIP.UI_Shop_VIP_C.OnUpdatePlayerCombinedInfo_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Shop_VIP(int32_t EntryPoint); // Function UI_Shop_VIP.UI_Shop_VIP_C.ExecuteUbergraph_UI_Shop_VIP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

