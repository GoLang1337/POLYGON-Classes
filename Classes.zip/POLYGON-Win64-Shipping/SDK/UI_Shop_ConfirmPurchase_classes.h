// WidgetBlueprintGeneratedClass UI_Shop_ConfirmPurchase.UI_Shop_ConfirmPurchase_C
// Size: 0x2a8 (Inherited: 0x260)
struct UUI_Shop_ConfirmPurchase_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border_BattlePass_Border; // 0x268(0x08)
	struct UButton* Button_Buy; // 0x270(0x08)
	struct UButton* Button_Cancel; // 0x278(0x08)
	struct UImage* Image_BattlePass_Background; // 0x280(0x08)
	struct UTextBlock* TextBlock_ItemName; // 0x288(0x08)
	struct FText ItemName; // 0x290(0x18)

	void BndEvt__UI_Shop_ConfirmPurchase_Button_Cancel_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function UI_Shop_ConfirmPurchase.UI_Shop_ConfirmPurchase_C.BndEvt__UI_Shop_ConfirmPurchase_Button_Cancel_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_ConfirmPurchase_Button_Buy_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature(); // Function UI_Shop_ConfirmPurchase.UI_Shop_ConfirmPurchase_C.BndEvt__UI_Shop_ConfirmPurchase_Button_Buy_K2Node_ComponentBoundEvent_3_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Shop_ConfirmPurchase.UI_Shop_ConfirmPurchase_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Shop_ConfirmPurchase(int32_t EntryPoint); // Function UI_Shop_ConfirmPurchase.UI_Shop_ConfirmPurchase_C.ExecuteUbergraph_UI_Shop_ConfirmPurchase // (Final|UbergraphFunction) // @ game+0x1847880
};

