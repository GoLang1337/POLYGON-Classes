// WidgetBlueprintGeneratedClass UI_Solder_Statistic.UI_Solder_Statistic_C
// Size: 0x2a8 (Inherited: 0x260)
struct UUI_Solder_Statistic_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button_VipStatus; // 0x268(0x08)
	struct UImage* Image_Rank; // 0x270(0x08)
	struct UProgressBar* ProgressBar_Progress; // 0x278(0x08)
	struct UTextBlock* TextBlock_CurrentProgress; // 0x280(0x08)
	struct UTextBlock* TextBlock_Level; // 0x288(0x08)
	struct UTextBlock* TextBlock_PlayerName; // 0x290(0x08)
	struct UTextBlock* TextBlock_ProgressToNextLevel; // 0x298(0x08)
	struct UTextBlock* TextBlock_RegistrationDate; // 0x2a0(0x08)

	void ParsePlayerCombinedInfo(); // Function UI_Solder_Statistic.UI_Solder_Statistic_C.ParsePlayerCombinedInfo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Solder_Statistic.UI_Solder_Statistic_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnUpdatePlayerCombinedInfo_Event(); // Function UI_Solder_Statistic.UI_Solder_Statistic_C.OnUpdatePlayerCombinedInfo_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Solder_Statistic(int32_t EntryPoint); // Function UI_Solder_Statistic.UI_Solder_Statistic_C.ExecuteUbergraph_UI_Solder_Statistic // (Final|UbergraphFunction) // @ game+0x1847880
};

