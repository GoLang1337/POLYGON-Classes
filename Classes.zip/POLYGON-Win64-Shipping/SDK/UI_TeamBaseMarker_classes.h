// WidgetBlueprintGeneratedClass UI_TeamBaseMarker.UI_TeamBaseMarker_C
// Size: 0x294 (Inherited: 0x260)
struct UUI_TeamBaseMarker_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button; // 0x268(0x08)
	struct USizeBox* SizeBox; // 0x270(0x08)
	enum class ETeam Team; // 0x278(0x01)
	bool AllowPlayerSpawn; // 0x279(0x01)
	char pad_27A[0x6]; // 0x27a(0x06)
	struct FMulticastInlineDelegate SelectAsSpawnPointDelegate; // 0x280(0x10)
	float Size; // 0x290(0x04)

	void SetBaseColor(); // Function UI_TeamBaseMarker.UI_TeamBaseMarker_C.SetBaseColor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_TeamBaseMarker.UI_TeamBaseMarker_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_TeamBaseMarker.UI_TeamBaseMarker_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_TeamBaseMarker.UI_TeamBaseMarker_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_TeamBaseMarker(int32_t EntryPoint); // Function UI_TeamBaseMarker.UI_TeamBaseMarker_C.ExecuteUbergraph_UI_TeamBaseMarker // (Final|UbergraphFunction) // @ game+0x1847880
	void SelectAsSpawnPointDelegate__DelegateSignature(enum class EControlPoint Point); // Function UI_TeamBaseMarker.UI_TeamBaseMarker_C.SelectAsSpawnPointDelegate__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

