// WidgetBlueprintGeneratedClass UI_GameMenu_Map.UI_GameMenu_Map_C
// Size: 0x340 (Inherited: 0x260)
struct UUI_GameMenu_Map_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* Image_Map; // 0x268(0x08)
	struct UImage* Lines_Map; // 0x270(0x08)
	struct UImage* LinesRainbow_Map; // 0x278(0x08)
	struct UOverlay* MapOverlay; // 0x280(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_A; // 0x288(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_B; // 0x290(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_C; // 0x298(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_D; // 0x2a0(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_E; // 0x2a8(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_F; // 0x2b0(0x08)
	struct UUI_GameMenu_Map_SpawnSelect_C* UI_SpawnSelect; // 0x2b8(0x08)
	struct UUI_TeamBaseMarker_C* UI_TeamBaseMarker_Blue; // 0x2c0(0x08)
	struct UUI_TeamBaseMarker_C* UI_TeamBaseMarker_Red; // 0x2c8(0x08)
	enum class EControlPoint SelectedSpawnPoint; // 0x2d0(0x01)
	char pad_2D1[0x7]; // 0x2d1(0x07)
	struct FMapInfo MapInfo; // 0x2d8(0x68)

	struct FVector2D ConvertWorldPositionToMap(struct AActor* Actor); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.ConvertWorldPositionToMap // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void SetMapInfo(); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.SetMapInfo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SelectNewSpawnPoint(enum class EControlPoint SpawnPoint); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.SelectNewSpawnPoint // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void AddPlayerIcon(struct APawn* PlayerCharacter); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.AddPlayerIcon // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetControlPointsPosition(); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.SetControlPointsPosition // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Get Team Base by Type(enum class ETeam Type, struct UUI_TeamBaseMarker_C* Marker); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.Get Team Base by Type // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void GetControlPointMarkerByType(enum class EControlPoint ControlPointType, struct UUI_ControlPointMarker_C* Marker); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.GetControlPointMarkerByType // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_ControlPointMarker_A_K2Node_ComponentBoundEvent_4_SelectAsSpawnPointDelegate__DelegateSignature(enum class EControlPoint Point); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.BndEvt__UI_ControlPointMarker_A_K2Node_ComponentBoundEvent_4_SelectAsSpawnPointDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_ControlPointMarker_B_K2Node_ComponentBoundEvent_5_SelectAsSpawnPointDelegate__DelegateSignature(enum class EControlPoint Point); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.BndEvt__UI_ControlPointMarker_B_K2Node_ComponentBoundEvent_5_SelectAsSpawnPointDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_ControlPointMarker_C_K2Node_ComponentBoundEvent_6_SelectAsSpawnPointDelegate__DelegateSignature(enum class EControlPoint Point); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.BndEvt__UI_ControlPointMarker_C_K2Node_ComponentBoundEvent_6_SelectAsSpawnPointDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_ControlPointMarker_D_K2Node_ComponentBoundEvent_7_SelectAsSpawnPointDelegate__DelegateSignature(enum class EControlPoint Point); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.BndEvt__UI_ControlPointMarker_D_K2Node_ComponentBoundEvent_7_SelectAsSpawnPointDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_ControlPointMarker_E_K2Node_ComponentBoundEvent_8_SelectAsSpawnPointDelegate__DelegateSignature(enum class EControlPoint Point); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.BndEvt__UI_ControlPointMarker_E_K2Node_ComponentBoundEvent_8_SelectAsSpawnPointDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_ControlPointMarker_F_K2Node_ComponentBoundEvent_9_SelectAsSpawnPointDelegate__DelegateSignature(enum class EControlPoint Point); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.BndEvt__UI_ControlPointMarker_F_K2Node_ComponentBoundEvent_9_SelectAsSpawnPointDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_TeamBaseMarker_Blue_K2Node_ComponentBoundEvent_10_SelectAsSpawnPointDelegate__DelegateSignature(enum class EControlPoint Point); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.BndEvt__UI_TeamBaseMarker_Blue_K2Node_ComponentBoundEvent_10_SelectAsSpawnPointDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_TeamBaseMarker_Red_K2Node_ComponentBoundEvent_11_SelectAsSpawnPointDelegate__DelegateSignature(enum class EControlPoint Point); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.BndEvt__UI_TeamBaseMarker_Red_K2Node_ComponentBoundEvent_11_SelectAsSpawnPointDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void OnSetTeam_Event(); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.OnSetTeam_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_GameMenu_Map(int32_t EntryPoint); // Function UI_GameMenu_Map.UI_GameMenu_Map_C.ExecuteUbergraph_UI_GameMenu_Map // (Final|UbergraphFunction) // @ game+0x1847880
};

