// BlueprintGeneratedClass BP_Item_Optic_8x.BP_Item_Optic_8x_C
// Size: 0x2a0 (Inherited: 0x2a0)
struct ABP_Item_Optic_8x_C : AItem_Module_Optic {
};

