// WidgetBlueprintGeneratedClass UI_PlayerMarker.UI_PlayerMarker_C
// Size: 0x270 (Inherited: 0x260)
struct UUI_PlayerMarker_C : UUserWidget {
	struct UWidgetAnimation* HiddenAnimation; // 0x260(0x08)
	struct UImage* Image; // 0x268(0x08)
};

