// WidgetBlueprintGeneratedClass UI_Map_ControlPoint.UI_Map_ControlPoint_C
// Size: 0x288 (Inherited: 0x260)
struct UUI_Map_ControlPoint_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UImage* ControlPointImage; // 0x268(0x08)
	struct UOverlay* MainOverlay; // 0x270(0x08)
	struct AControlPoint* ControlPointReference; // 0x278(0x08)
	float TargetOpacity; // 0x280(0x04)
	float MapSize; // 0x284(0x04)

	void FindCoord(float Distance, float Degrees, struct FVector2D NewVector); // Function UI_Map_ControlPoint.UI_Map_ControlPoint_C.FindCoord // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void FindAngle(struct FVector2D In, float Degrees); // Function UI_Map_ControlPoint.UI_Map_ControlPoint_C.FindAngle // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void SetName(); // Function UI_Map_ControlPoint.UI_Map_ControlPoint_C.SetName // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Map_ControlPoint.UI_Map_ControlPoint_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function UI_Map_ControlPoint.UI_Map_ControlPoint_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void CalculatePosition(); // Function UI_Map_ControlPoint.UI_Map_ControlPoint_C.CalculatePosition // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnCapturedTeam_Event(); // Function UI_Map_ControlPoint.UI_Map_ControlPoint_C.OnCapturedTeam_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnIsCapture_Event(); // Function UI_Map_ControlPoint.UI_Map_ControlPoint_C.OnIsCapture_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Map_ControlPoint(int32_t EntryPoint); // Function UI_Map_ControlPoint.UI_Map_ControlPoint_C.ExecuteUbergraph_UI_Map_ControlPoint // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

