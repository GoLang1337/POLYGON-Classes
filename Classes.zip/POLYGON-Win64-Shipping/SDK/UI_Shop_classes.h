// WidgetBlueprintGeneratedClass UI_Shop.UI_Shop_C
// Size: 0x2c8 (Inherited: 0x260)
struct UUI_Shop_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button_Back; // 0x268(0x08)
	struct UHorizontalBox* HorizontalBox_Header; // 0x270(0x08)
	struct UUI_Button_C* UI_Button_Best; // 0x278(0x08)
	struct UUI_Button_C* UI_Button_Clothes; // 0x280(0x08)
	struct UUI_Button_C* UI_Button_Premium; // 0x288(0x08)
	struct UUI_Button_C* UI_Button_Weapon; // 0x290(0x08)
	struct UUI_Shop_BestOffers_C* UI_Shop_BestOffers; // 0x298(0x08)
	struct UUI_Shop_Premium_C* UI_Shop_Premium; // 0x2a0(0x08)
	struct UUI_Shop_Weapon_C* UI_Shop_Weapon; // 0x2a8(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Main; // 0x2b0(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_ShopMenu; // 0x2b8(0x08)
	struct ABP_PG_PlayerState_Menu_C* PlayerState; // 0x2c0(0x08)

	void DiselectAllButtonsInHeader(); // Function UI_Shop.UI_Shop_C.DiselectAllButtonsInHeader // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ParsePlayerCombinedInfo(); // Function UI_Shop.UI_Shop_C.ParsePlayerCombinedInfo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Button_Weapon_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Shop.UI_Shop_C.BndEvt__UI_Button_Weapon_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Shop.UI_Shop_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnUpdatePlayerCombinedInfo_Event(); // Function UI_Shop.UI_Shop_C.OnUpdatePlayerCombinedInfo_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_UI_Button_Best_K2Node_ComponentBoundEvent_0_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Shop.UI_Shop_C.BndEvt__UI_Shop_UI_Button_Best_K2Node_ComponentBoundEvent_0_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_UI_Button_Premium_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Shop.UI_Shop_C.BndEvt__UI_Shop_UI_Button_Premium_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Shop(int32_t EntryPoint); // Function UI_Shop.UI_Shop_C.ExecuteUbergraph_UI_Shop // (Final|UbergraphFunction) // @ game+0x1847880
};

