// BlueprintGeneratedClass CameraShake_Damage.CameraShake_Damage_C
// Size: 0x180 (Inherited: 0x180)
struct UCameraShake_Damage_C : UMatineeCameraShake {
};

