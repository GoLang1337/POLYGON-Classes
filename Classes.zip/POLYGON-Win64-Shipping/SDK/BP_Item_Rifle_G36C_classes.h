// BlueprintGeneratedClass BP_Item_Rifle_G36C.BP_Item_Rifle_G36C_C
// Size: 0x420 (Inherited: 0x410)
struct ABP_Item_Rifle_G36C_C : AItem_Weapon_Rifle {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x410(0x08)
	struct UStaticMeshComponent* Sight; // 0x418(0x08)

	void ReceiveBeginPlay(); // Function BP_Item_Rifle_G36C.BP_Item_Rifle_G36C_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_Item_Rifle_G36C(int32_t EntryPoint); // Function BP_Item_Rifle_G36C.BP_Item_Rifle_G36C_C.ExecuteUbergraph_BP_Item_Rifle_G36C // (Final|UbergraphFunction) // @ game+0x1847880
};

