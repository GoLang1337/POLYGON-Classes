// Class POLYGON.ChatSystemComponent
// Size: 0xc0 (Inherited: 0xb0)
struct UChatSystemComponent : UActorComponent {
	struct TArray<struct FChatMessage> ChatHistory; // 0xb0(0x10)

	void SentMessage_Multicast(struct FChatMessage Message); // Function POLYGON.ChatSystemComponent.SentMessage_Multicast // (Final|Net|Native|Event|NetMulticast|Private) // @ game+0x1490c10
	void SendMessage_Server(struct FChatMessage Message); // Function POLYGON.ChatSystemComponent.SendMessage_Server // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0x1490a90
};

// Class POLYGON.GeneralBackendComponent
// Size: 0xf0 (Inherited: 0xb0)
struct UGeneralBackendComponent : UActorComponent {
	char pad_B0[0x40]; // 0xb0(0x40)
};

// Class POLYGON.ClientBackendComponent
// Size: 0x128 (Inherited: 0xf0)
struct UClientBackendComponent : UGeneralBackendComponent {
	struct FMulticastInlineDelegate OnSetPlayerId; // 0xf0(0x10)
	struct FMulticastInlineDelegate OnUpdatePlayerCombinedInfo; // 0x100(0x10)
	struct FString PlayerMasterId; // 0x110(0x10)
	struct UPlayFabJsonObject* PlayerCombinedInfo; // 0x120(0x08)

	void SetPlayerId(struct FString newPlayerMasterId); // Function POLYGON.ClientBackendComponent.SetPlayerId // (Final|Native|Public|BlueprintCallable) // @ game+0x1490e40
	void SetPlayerCombinedInfo(struct UPlayFabJsonObject* newPlayerCombinedInfo); // Function POLYGON.ClientBackendComponent.SetPlayerCombinedInfo // (Final|Native|Public|BlueprintCallable) // @ game+0x1490d20
	bool IsClientLoggedIn(); // Function POLYGON.ClientBackendComponent.IsClientLoggedIn // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x14905e0
	struct UPlayFabJsonObject* GetPlayerCombinedInfo(); // Function POLYGON.ClientBackendComponent.GetPlayerCombinedInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1490260
};

// Class POLYGON.ClientTransfer
// Size: 0x60 (Inherited: 0x28)
struct UClientTransfer : UObject {
	bool bInMenu; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FText KickReason; // 0x30(0x18)
	char pad_48[0x10]; // 0x48(0x10)
	struct UPlayFabJsonObject* PlayerCombinedInfo; // 0x58(0x08)

	void SetPlayerId(struct FString newPlayerMasterId); // Function POLYGON.ClientTransfer.SetPlayerId // (Final|Native|Public|BlueprintCallable) // @ game+0x1490ef0
	void SetPlayerCombinedInfo(struct UPlayFabJsonObject* newPlayerCombinedInfo); // Function POLYGON.ClientTransfer.SetPlayerCombinedInfo // (Final|Native|Public|BlueprintCallable) // @ game+0x1490db0
	void HandleNetworkFailure(struct UWorld* World, struct UNetDriver* NetDriver, enum class ENetworkFailure FailureType, struct FString ErrorString); // Function POLYGON.ClientTransfer.HandleNetworkFailure // (Final|Native|Private) // @ game+0x1490460
	struct FString GetPlayerMasterId(); // Function POLYGON.ClientTransfer.GetPlayerMasterId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x14902a0
	struct UPlayFabJsonObject* GetPlayerCombinedInfo(); // Function POLYGON.ClientTransfer.GetPlayerCombinedInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1490280
};

// Class POLYGON.ControlPoint
// Size: 0x290 (Inherited: 0x220)
struct AControlPoint : AActor {
	struct FMulticastInlineDelegate OnCapturedTeam; // 0x220(0x10)
	struct FMulticastInlineDelegate OnIsCapture; // 0x230(0x10)
	struct FMulticastInlineDelegate OnChangeCapturePoints; // 0x240(0x10)
	enum class EControlPoint ControlPointName; // 0x250(0x01)
	enum class ETeam CapturedTeam; // 0x251(0x01)
	bool bIsCapture; // 0x252(0x01)
	char pad_253[0x1]; // 0x253(0x01)
	int32_t CapturePointsRedTeam; // 0x254(0x04)
	int32_t CapturePointsBlueTeam; // 0x258(0x04)
	char pad_25C[0x2c]; // 0x25c(0x2c)
	struct USphereComponent* CaptureArea; // 0x288(0x08)

	void OnRep_IsCapture(); // Function POLYGON.ControlPoint.OnRep_IsCapture // (Final|Native|Private|Const) // @ game+0x14908b0
	void OnRep_CapturePointsRedTeam(); // Function POLYGON.ControlPoint.OnRep_CapturePointsRedTeam // (Final|Native|Private|Const) // @ game+0x1490810
	void OnRep_CapturePointsBlueTeam(); // Function POLYGON.ControlPoint.OnRep_CapturePointsBlueTeam // (Final|Native|Private|Const) // @ game+0x1490810
	void OnRep_CapturedTeam(); // Function POLYGON.ControlPoint.OnRep_CapturedTeam // (Final|Native|Private|Const) // @ game+0x1490830
	struct FString GetControlPointNameAsString(); // Function POLYGON.ControlPoint.GetControlPointNameAsString // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x14900e0
	struct FString GetControlPointNameAsOneLetter(); // Function POLYGON.ControlPoint.GetControlPointNameAsOneLetter // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1490090
};

// Class POLYGON.DataManagerLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDataManagerLibrary : UBlueprintFunctionLibrary {

	struct UDataTable* GetDataTable_MapsInfo(); // Function POLYGON.DataManagerLibrary.GetDataTable_MapsInfo // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x14901b0
	struct UDataTable* GetDataTable_LevelInfo(); // Function POLYGON.DataManagerLibrary.GetDataTable_LevelInfo // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x1490180
	struct UDataTable* GetDataTable_ItemReferences(); // Function POLYGON.DataManagerLibrary.GetDataTable_ItemReferences // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x1490150
};

// Class POLYGON.HealthStatsComponent
// Size: 0x100 (Inherited: 0xb0)
struct UHealthStatsComponent : UActorComponent {
	struct FMulticastInlineDelegate OnChangeHealth; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnIsAlive; // 0xc0(0x10)
	char Health; // 0xd0(0x01)
	bool bIsAlive; // 0xd1(0x01)
	char pad_D2[0x2]; // 0xd2(0x02)
	float Stamina; // 0xd4(0x04)
	char pad_D8[0x8]; // 0xd8(0x08)
	struct TArray<struct FPlayerAssist> KillAssists; // 0xe0(0x10)
	char pad_F0[0x10]; // 0xf0(0x10)

	void OnRep_Health(); // Function POLYGON.HealthStatsComponent.OnRep_Health // (Final|Native|Private) // @ game+0x1490890
	int32_t GetStamina(); // Function POLYGON.HealthStatsComponent.GetStamina // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1490340
	int32_t GetHealth(); // Function POLYGON.HealthStatsComponent.GetHealth // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1490220
};

// Class POLYGON.InteractInterface
// Size: 0x28 (Inherited: 0x28)
struct UInteractInterface : UInterface {

	void StopInteract(struct APG_Character* Character); // Function POLYGON.InteractInterface.StopInteract // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1491200
	void StartInteract(struct APG_Character* Character); // Function POLYGON.InteractInterface.StartInteract // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x14910e0
	void SetPlayerLooks(bool isLooks); // Function POLYGON.InteractInterface.SetPlayerLooks // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1490fa0
};

// Class POLYGON.Item_General
// Size: 0x270 (Inherited: 0x220)
struct AItem_General : AActor {
	struct FString ItemId; // 0x220(0x10)
	enum class EItemType ItemType; // 0x230(0x01)
	char pad_231[0x7]; // 0x231(0x07)
	struct FText ItemName; // 0x238(0x18)
	struct UTexture2D* ItemIcon; // 0x250(0x08)
	int32_t ItemPrice; // 0x258(0x04)
	char pad_25C[0x4]; // 0x25c(0x04)
	struct FString customData; // 0x260(0x10)
};

// Class POLYGON.Item_Module_General
// Size: 0x280 (Inherited: 0x270)
struct AItem_Module_General : AItem_General {
	enum class EWeaponModuleType WeaponModuleType; // 0x270(0x01)
	char pad_271[0x3]; // 0x271(0x03)
	int32_t LevelRequired; // 0x274(0x04)
	bool bIsPremium; // 0x278(0x01)
	char pad_279[0x7]; // 0x279(0x07)
};

// Class POLYGON.Item_Module_Optic
// Size: 0x2a0 (Inherited: 0x280)
struct AItem_Module_Optic : AItem_Module_General {
	struct FName MountingSocket; // 0x280(0x08)
	float FOV; // 0x288(0x04)
	bool bIsScope; // 0x28c(0x01)
	char pad_28D[0x3]; // 0x28d(0x03)
	struct UMaterialInstance* PostProcessLensMaterial; // 0x290(0x08)
	struct UStaticMeshComponent* ModuleMesh; // 0x298(0x08)

	void ToggleAiming(bool IsAiming); // Function POLYGON.Item_Module_Optic.ToggleAiming // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
};

// Class POLYGON.Item_Module_Skin
// Size: 0x288 (Inherited: 0x280)
struct AItem_Module_Skin : AItem_Module_General {
	struct UMaterialInstance* SkinMaterial; // 0x280(0x08)
};

// Class POLYGON.Item_Weapon_General
// Size: 0x410 (Inherited: 0x270)
struct AItem_Weapon_General : AItem_General {
	struct FMulticastInlineDelegate OnChangeCurrentNumberAmmo; // 0x270(0x10)
	struct FMulticastInlineDelegate OnChangeStockAmmo; // 0x280(0x10)
	struct FMulticastInlineDelegate OnSetWeaponModules; // 0x290(0x10)
	struct FMulticastInlineDelegate OnApplyWeaponDamage; // 0x2a0(0x10)
	char pad_2B0[0x18]; // 0x2b0(0x18)
	enum class EWeaponType WeaponType; // 0x2c8(0x01)
	enum class EWeaponShootingType WeaponShootingType; // 0x2c9(0x01)
	char pad_2CA[0x2]; // 0x2ca(0x02)
	int32_t WeaponDamage; // 0x2cc(0x04)
	struct UCurveFloat* DamageCurve; // 0x2d0(0x08)
	int32_t MaxMagazineAmmo; // 0x2d8(0x04)
	int32_t MaxStockAmmo; // 0x2dc(0x04)
	float TimeBetweenShots; // 0x2e0(0x04)
	float WeaponRecoil; // 0x2e4(0x04)
	float WeaponRecoilAlphaPerShot; // 0x2e8(0x04)
	float AccuracyHip; // 0x2ec(0x04)
	float AccuracySight; // 0x2f0(0x04)
	float SpreadShot; // 0x2f4(0x04)
	struct TArray<struct AItem_Module_General*> RelatedModules; // 0x2f8(0x10)
	struct UTexture2D* WeaponWhileIcon; // 0x308(0x08)
	int32_t LevelRequired; // 0x310(0x04)
	bool bIsPremium; // 0x314(0x01)
	bool bIsAvailable; // 0x315(0x01)
	char pad_316[0x2]; // 0x316(0x02)
	struct UParticleSystem* TrailFX; // 0x318(0x08)
	struct UParticleSystem* SleeveFX; // 0x320(0x08)
	struct UCameraShakeBase* ShotCameraShake; // 0x328(0x08)
	struct UAnimSequence* IdleCharacterAnimation; // 0x330(0x08)
	struct UAnimMontage* ReloadCharacterAnimation; // 0x338(0x08)
	struct UAnimMontage* ReloadFullCharacterAnimation; // 0x340(0x08)
	struct UAnimMontage* ShotCharacterAnimation; // 0x348(0x08)
	struct UAnimMontage* BoltCharacterAnimation; // 0x350(0x08)
	struct UAnimSequence* ShotWeaponAnimation; // 0x358(0x08)
	struct UAnimSequence* BoltWeaponAnimation; // 0x360(0x08)
	struct UAnimSequence* ReloadWeaponAnimation; // 0x368(0x08)
	struct UAnimSequence* ReloadFullWeaponAnimation; // 0x370(0x08)
	struct FVector PositionAdjustment; // 0x378(0x0c)
	char pad_384[0x4]; // 0x384(0x04)
	struct USoundBase* SoundShot; // 0x388(0x08)
	struct USoundBase* SoundBlankShot; // 0x390(0x08)
	struct TArray<struct USoundBase*> CustomSounds; // 0x398(0x10)
	int32_t CurrentMagazineAmmo; // 0x3a8(0x04)
	uint16_t CurrentStockAmmo; // 0x3ac(0x02)
	char pad_3AE[0x2]; // 0x3ae(0x02)
	float CurrentSpread; // 0x3b0(0x04)
	char pad_3B4[0x4]; // 0x3b4(0x04)
	struct TArray<struct AItem_Module_General*> CurrentWeaponModulesClass; // 0x3b8(0x10)
	struct TArray<struct AItem_Module_General*> CurrentWeaponModules; // 0x3c8(0x10)
	char WeaponShotCounter; // 0x3d8(0x01)
	char pad_3D9[0x3]; // 0x3d9(0x03)
	struct FVector_NetQuantize WeaponHitPoint; // 0x3dc(0x0c)
	char pad_3E8[0x10]; // 0x3e8(0x10)
	struct USkeletalMeshComponent* WeaponMesh; // 0x3f8(0x08)
	struct UStaticMeshComponent* Magazine; // 0x400(0x08)
	struct UStaticMeshComponent* PicatinnyRail; // 0x408(0x08)

	void StartReload_multicast(bool bFullReload); // Function POLYGON.Item_Weapon_General.StartReload_multicast // (Net|Native|Event|NetMulticast|Public) // @ game+0x1491170
	void SoftResetWeapon(); // Function POLYGON.Item_Weapon_General.SoftResetWeapon // (Native|Event|Public|BlueprintEvent) // @ game+0x14910c0
	void SetWeaponModules(struct UPlayFabJsonObject* modules); // Function POLYGON.Item_Weapon_General.SetWeaponModules // (Native|Public|BlueprintCallable) // @ game+0x1491030
	void RequestReload_server(char CurrentNumberAmmo); // Function POLYGON.Item_Weapon_General.RequestReload_server // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x14909e0
	void OnRep_WeaponShotCounter(char previousValue); // Function POLYGON.Item_Weapon_General.OnRep_WeaponShotCounter // (Final|Native|Private) // @ game+0x1490960
	void OnRep_WeaponHitPoint(struct FVector_NetQuantize previousValue); // Function POLYGON.Item_Weapon_General.OnRep_WeaponHitPoint // (Final|Native|Private) // @ game+0x14908d0
	void OnRep_CurrentWeaponModulesClass(); // Function POLYGON.Item_Weapon_General.OnRep_CurrentWeaponModulesClass // (Final|Native|Private) // @ game+0x1490870
	void OnRep_CurrentStockAmmo(); // Function POLYGON.Item_Weapon_General.OnRep_CurrentStockAmmo // (Final|Native|Private) // @ game+0x1490850
	void NotifyServerOfMiss(); // Function POLYGON.Item_Weapon_General.NotifyServerOfMiss // (Net|Native|Event|Public|NetServer|NetValidate) // @ game+0x14907c0
	void NotifyServerOfHit_Unreliable(struct FVector_NetQuantize HitLocation); // Function POLYGON.Item_Weapon_General.NotifyServerOfHit_Unreliable // (Net|Native|Event|Public|NetServer|NetValidate) // @ game+0x14906f0
	void NotifyServerOfHit_Reliable(struct FWeaponHitOnCharacter hitOnCharacter); // Function POLYGON.Item_Weapon_General.NotifyServerOfHit_Reliable // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x1490610
	struct TArray<struct AItem_Module_General*> GetWeaponModules(); // Function POLYGON.Item_Weapon_General.GetWeaponModules // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1490390
	struct USkeletalMeshComponent* GetWeaponMesh(); // Function POLYGON.Item_Weapon_General.GetWeaponMesh // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1490370
	struct UStaticMeshComponent* GetMagazine(); // Function POLYGON.Item_Weapon_General.GetMagazine // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1490240
	struct FVector GetForwardShot(); // Function POLYGON.Item_Weapon_General.GetForwardShot // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x14901e0
	int32_t GetCurrentStockAmmo(); // Function POLYGON.Item_Weapon_General.GetCurrentStockAmmo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1490130
	void CockBolt_server(); // Function POLYGON.Item_Weapon_General.CockBolt_server // (Net|Native|Event|Public|NetServer|NetValidate) // @ game+0x1490040
	void CockBolt_multicast(); // Function POLYGON.Item_Weapon_General.CockBolt_multicast // (Net|Native|Event|NetMulticast|Public) // @ game+0x1490020
	void AddStockAmmo_server(int8_t addAmmo); // Function POLYGON.Item_Weapon_General.AddStockAmmo_server // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x148ff70
};

// Class POLYGON.Item_Weapon_Grenade
// Size: 0x2b8 (Inherited: 0x270)
struct AItem_Weapon_Grenade : AItem_General {
	float GrenadeRaduis; // 0x270(0x04)
	float GrenadeDamage; // 0x274(0x04)
	struct UParticleSystem* ExplosionFX; // 0x278(0x08)
	struct USoundBase* SoundExplosion; // 0x280(0x08)
	struct UCameraShakeBase* ExplosionCameraShake; // 0x288(0x08)
	struct UCameraShakeBase* GrenadeThrowCameraShake; // 0x290(0x08)
	struct UStaticMeshComponent* Mesh; // 0x298(0x08)
	struct URadialForceComponent* RadialForce; // 0x2a0(0x08)
	struct USphereComponent* GrenadeSphereRadius; // 0x2a8(0x08)
	struct USmoothSync* SmoothSyncComponent; // 0x2b0(0x08)
};

// Class POLYGON.Item_Weapon_Pistol
// Size: 0x418 (Inherited: 0x410)
struct AItem_Weapon_Pistol : AItem_Weapon_General {
	struct UAnimSequence* NoAmmoWeaponAnimation; // 0x410(0x08)
};

// Class POLYGON.Item_Weapon_Rifle
// Size: 0x410 (Inherited: 0x410)
struct AItem_Weapon_Rifle : AItem_Weapon_General {
};

// Class POLYGON.Item_Weapon_Sniper
// Size: 0x410 (Inherited: 0x410)
struct AItem_Weapon_Sniper : AItem_Weapon_General {
};

// Class POLYGON.MenuCharacter
// Size: 0x260 (Inherited: 0x220)
struct AMenuCharacter : AActor {
	struct USkeletalMeshComponent* Mesh; // 0x220(0x08)
	struct UStaticMeshComponent* Hair; // 0x228(0x08)
	struct UStaticMeshComponent* Hat; // 0x230(0x08)
	struct UStaticMeshComponent* Mask; // 0x238(0x08)
	struct UStaticMeshComponent* Jacket; // 0x240(0x08)
	struct UStaticMeshComponent* Chevron; // 0x248(0x08)
	struct UStaticMeshComponent* Backpack; // 0x250(0x08)
	struct AItem_Weapon_General* Weapon; // 0x258(0x08)

	void ParsePlayerCombinedInfo(); // Function POLYGON.MenuCharacter.ParsePlayerCombinedInfo // (Final|Native|Public) // @ game+0x14955c0
};

// Class POLYGON.PG_AnimInstance
// Size: 0x2c0 (Inherited: 0x2c0)
struct UPG_AnimInstance : UAnimInstance {
};

// Class POLYGON.PG_Character
// Size: 0x590 (Inherited: 0x4c0)
struct APG_Character : ACharacter {
	struct FMulticastInlineDelegate OnSetPlayerState; // 0x4b8(0x10)
	enum class EPlayerAction PlayerAction; // 0x4c9(0x01)
	float TiltBodyAlpha; // 0x4cc(0x04)
	char pad_4D5[0x7]; // 0x4d5(0x07)
	enum class ECameraViewMode CameraViewMode; // 0x4dc(0x01)
	char pad_4DD[0x1b]; // 0x4dd(0x1b)
	struct AActor* LastFocusActor; // 0x4f8(0x08)
	struct AActor* CurrentInteractActor; // 0x500(0x08)
	char pad_508[0x8]; // 0x508(0x08)
	struct UParticleSystem* ParticleDamageBlood; // 0x510(0x08)
	struct USoundBase* SoundBullet; // 0x518(0x08)
	struct USceneComponent* ArmsRoot; // 0x520(0x08)
	struct USkeletalMeshComponent* Arms; // 0x528(0x08)
	struct UStaticMeshComponent* Hair; // 0x530(0x08)
	struct UStaticMeshComponent* Hat; // 0x538(0x08)
	struct UStaticMeshComponent* Mask; // 0x540(0x08)
	struct UStaticMeshComponent* Chevron; // 0x548(0x08)
	struct UStaticMeshComponent* Backpack; // 0x550(0x08)
	struct UCameraComponent* FirstPersonCamera; // 0x558(0x08)
	struct USpringArmComponent* ThirdPersonCameraBoom; // 0x560(0x08)
	struct UCameraComponent* ThirdPersonCamera; // 0x568(0x08)
	struct UInputComponent* PlayerInputComponent; // 0x570(0x08)
	struct UWidgetComponent* WidgetPlayerMarker; // 0x578(0x08)
	struct UHealthStatsComponent* HealthStatsComponent; // 0x580(0x08)
	struct UWeaponComponent* WeaponComponent; // 0x588(0x08)

	void TiltBody_server(int8_t tintBodyAlpha); // Function POLYGON.PG_Character.TiltBody_server // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x1495b20
	void StopInteract_server(); // Function POLYGON.PG_Character.StopInteract_server // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x1495ab0
	void StopInteract(); // Function POLYGON.PG_Character.StopInteract // (Final|Native|Protected) // @ game+0x1495a90
	void StartShooting(); // Function POLYGON.PG_Character.StartShooting // (Event|Public|BlueprintEvent) // @ game+0x1847880
	void StartInteract_server(); // Function POLYGON.PG_Character.StartInteract_server // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x14959b0
	void StartInteract(); // Function POLYGON.PG_Character.StartInteract // (Final|Native|Protected) // @ game+0x1495990
	void SetViewMode(enum class ECameraViewMode newViewMode); // Function POLYGON.PG_Character.SetViewMode // (Final|Native|Public|BlueprintCallable) // @ game+0x1495910
	void SetTargetFOV(float newTargetFOV); // Function POLYGON.PG_Character.SetTargetFOV // (Final|Native|Public|BlueprintCallable) // @ game+0x1495890
	void SetIsSprinting_server(bool NewState); // Function POLYGON.PG_Character.SetIsSprinting_server // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x14957d0
	void Respawn(); // Function POLYGON.PG_Character.Respawn // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x14956a0
	void PlayerDead_multicast(struct FVector_NetQuantize Impulse, char BoneIndex); // Function POLYGON.PG_Character.PlayerDead_multicast // (Final|Net|Native|Event|NetMulticast|Private) // @ game+0x14955e0
	void OnRep_PlayerAction(); // Function POLYGON.PG_Character.OnRep_PlayerAction // (Final|Native|Private) // @ game+0x1495340
	void OnRep_CameraViewMode(); // Function POLYGON.PG_Character.OnRep_CameraViewMode // (Final|Native|Private) // @ game+0x14952c0
	void InteractPlayerLooks(); // Function POLYGON.PG_Character.InteractPlayerLooks // (Final|Native|Private) // @ game+0x1494eb0
	enum class EPlayerAction GetPlayerAction(); // Function POLYGON.PG_Character.GetPlayerAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1494bf0
	bool GetIsSprinting(); // Function POLYGON.PG_Character.GetIsSprinting // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1494bb0
	struct UCameraComponent* GetActiveCamera(); // Function POLYGON.PG_Character.GetActiveCamera // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1494b10
	void EventTakeDamage(struct FVector Origin); // Function POLYGON.PG_Character.EventTakeDamage // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1847880
	void ChangeIsAlive(); // Function POLYGON.PG_Character.ChangeIsAlive // (Final|Native|Public) // @ game+0x1494ad0
	void CameraNeutralizationEffectEvent(float Damage); // Function POLYGON.PG_Character.CameraNeutralizationEffectEvent // (Event|Public|BlueprintEvent) // @ game+0x1847880
	void ActionWhenTakeDamage_client(char Damage, bool bHeadshot, struct FVector_NetQuantize Origin); // Function POLYGON.PG_Character.ActionWhenTakeDamage_client // (Final|Net|Native|Event|Private|NetClient) // @ game+0x14949c0
};

// Class POLYGON.PG_FunctionLibraryKit
// Size: 0x28 (Inherited: 0x28)
struct UPG_FunctionLibraryKit : UBlueprintFunctionLibrary {

	struct FString ParseOption(struct FString Options, struct FString Key, struct FString Separator); // Function POLYGON.PG_FunctionLibraryKit.ParseOption // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x1495400
	enum class ERegion GetRegionEnum(struct FString regionName); // Function POLYGON.PG_FunctionLibraryKit.GetRegionEnum // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x1494c60
	struct FString GetProjectVersion(); // Function POLYGON.PG_FunctionLibraryKit.GetProjectVersion // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x1494c10
	int32_t GetBuildNumber(); // Function POLYGON.PG_FunctionLibraryKit.GetBuildNumber // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x1494b40
	void ExitGame(); // Function POLYGON.PG_FunctionLibraryKit.ExitGame // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x1494af0
};

// Class POLYGON.PG_GameInstance
// Size: 0x1b0 (Inherited: 0x1a8)
struct UPG_GameInstance : UGameInstance {
	struct UClientTransfer* ClientTransfer; // 0x1a8(0x08)

	struct UClientTransfer* GetClientTransfer(); // Function POLYGON.PG_GameInstance.GetClientTransfer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1494b70
};

// Class POLYGON.PG_GameMode_Base
// Size: 0x308 (Inherited: 0x308)
struct APG_GameMode_Base : AGameMode {
};

// Class POLYGON.PG_GameMode_Game
// Size: 0x348 (Inherited: 0x308)
struct APG_GameMode_Game : APG_GameMode_Base {
	char pad_308[0x10]; // 0x308(0x10)
	int32_t MaxPlayers; // 0x318(0x04)
	int32_t GameTime; // 0x31c(0x04)
	enum class ECameraViewMode CameraViewMode; // 0x320(0x01)
	char pad_321[0xf]; // 0x321(0x0f)
	struct UPlayFabJsonObject* ServerSettings; // 0x330(0x08)
	struct FTimerHandle TimerShutdownServer; // 0x338(0x08)
	struct UServerBackendComponent* ServerBackendComponent; // 0x340(0x08)

	void LoginPlayer(struct APG_PlayerController_Game* PlayerController, struct FString PlayerMasterId); // Function POLYGON.PG_GameMode_Game.LoginPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x1494ed0
};

// Class POLYGON.PG_GameMode_Menu
// Size: 0x308 (Inherited: 0x308)
struct APG_GameMode_Menu : APG_GameMode_Base {
};

// Class POLYGON.PG_GameState_Game
// Size: 0x378 (Inherited: 0x290)
struct APG_GameState_Game : AGameState {
	struct FMulticastInlineDelegate OnChangeGameState; // 0x290(0x10)
	struct FMulticastInlineDelegate OnGameTimer; // 0x2a0(0x10)
	struct FMulticastInlineDelegate OnCanMovePlayers; // 0x2b0(0x10)
	struct FMulticastInlineDelegate OnTeamWon; // 0x2c0(0x10)
	struct FMulticastInlineDelegate OnChangePlayersArray; // 0x2d0(0x10)
	struct FMulticastInlineDelegate OnChangeTeamRedArray; // 0x2e0(0x10)
	struct FMulticastInlineDelegate OnChangeTeamBlueArray; // 0x2f0(0x10)
	struct FMulticastInlineDelegate OnChangeTotalScore; // 0x300(0x10)
	enum class EGameMode GameMode; // 0x310(0x01)
	enum class EGameState GameState; // 0x311(0x01)
	uint16_t GameTimer; // 0x312(0x02)
	bool bCanMovePlayers; // 0x314(0x01)
	enum class ETeam WinningTeam; // 0x315(0x01)
	char pad_316[0x2]; // 0x316(0x02)
	struct TArray<struct APG_PlayerState_Game*> Players; // 0x318(0x10)
	struct TArray<struct APG_PlayerState_Game*> TeamRed; // 0x328(0x10)
	struct TArray<struct APG_PlayerState_Game*> TeamBlue; // 0x338(0x10)
	struct TArray<struct ATeamBase*> AllTeamBases; // 0x348(0x10)
	struct TArray<struct AControlPoint*> AllControlPoints; // 0x358(0x10)
	uint16_t ScoreRedTeam; // 0x368(0x02)
	uint16_t ScoreBlueTeam; // 0x36a(0x02)
	char pad_36C[0xc]; // 0x36c(0x0c)

	void SetCanMovePlayers(bool newMoveState); // Function POLYGON.PG_GameState_Game.SetCanMovePlayers // (Final|Native|Public) // @ game+0x14956c0
	void OnRep_WinningTeam(); // Function POLYGON.PG_GameState_Game.OnRep_WinningTeam // (Final|Native|Private|Const) // @ game+0x14953e0
	void OnRep_TeamRed(); // Function POLYGON.PG_GameState_Game.OnRep_TeamRed // (Final|Native|Private|Const) // @ game+0x14953c0
	void OnRep_TeamBlue(); // Function POLYGON.PG_GameState_Game.OnRep_TeamBlue // (Final|Native|Private|Const) // @ game+0x14953a0
	void OnRep_ScoreRedTeam(); // Function POLYGON.PG_GameState_Game.OnRep_ScoreRedTeam // (Final|Native|Private|Const) // @ game+0x1495380
	void OnRep_ScoreBlueTeam(); // Function POLYGON.PG_GameState_Game.OnRep_ScoreBlueTeam // (Final|Native|Private|Const) // @ game+0x1495380
	void OnRep_Players(); // Function POLYGON.PG_GameState_Game.OnRep_Players // (Final|Native|Private|Const) // @ game+0x1495360
	void OnRep_GameTimer(); // Function POLYGON.PG_GameState_Game.OnRep_GameTimer // (Final|Native|Private|Const) // @ game+0x1495320
	void OnRep_GameState(); // Function POLYGON.PG_GameState_Game.OnRep_GameState // (Final|Native|Private|Const) // @ game+0x1495300
	void OnRep_CanMovePlayers(); // Function POLYGON.PG_GameState_Game.OnRep_CanMovePlayers // (Final|Native|Private|Const) // @ game+0x14952e0
	void NotifyPlayerWasKicked(struct FString badGuyName, bool bNameWasOptimized); // Function POLYGON.PG_GameState_Game.NotifyPlayerWasKicked // (Net|Native|Event|NetMulticast|Public) // @ game+0x14951d0
	void InformPlayerKilled_Multicast(struct APG_PlayerState_Game* Player, struct APG_PlayerState_Game* killer, bool isHeadshot, bool isGrenade); // Function POLYGON.PG_GameState_Game.InformPlayerKilled_Multicast // (Net|Native|Event|NetMulticast|Public) // @ game+0x1494d50
	int32_t GetScoreRedTeam(); // Function POLYGON.PG_GameState_Game.GetScoreRedTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1494d30
	int32_t GetScoreBlueTeam(); // Function POLYGON.PG_GameState_Game.GetScoreBlueTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1494d10
	int32_t GetMaxScoreForWin(); // Function POLYGON.PG_GameState_Game.GetMaxScoreForWin // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1494bd0
	int32_t GetGameTimer(); // Function POLYGON.PG_GameState_Game.GetGameTimer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1494b90
};

// Class POLYGON.PG_PlayerController_Base
// Size: 0x5a0 (Inherited: 0x570)
struct APG_PlayerController_Base : APlayerController {
	struct FMulticastInlineDelegate OnSetPawn; // 0x570(0x10)
	struct FMulticastInlineDelegate OnSetPlayerState; // 0x580(0x10)
	float MouseSensitivity; // 0x590(0x04)
	float ScopeSensitivityMultiplier; // 0x594(0x04)
	bool bIsInvertMouse; // 0x598(0x01)
	char pad_599[0x3]; // 0x599(0x03)
	float GameFOV; // 0x59c(0x04)

	void ShowError(struct FText ErrorMessage, struct FText ErrorDetails); // Function POLYGON.PG_PlayerController_Base.ShowError // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetGameFOV(float NewFOV); // Function POLYGON.PG_PlayerController_Base.SetGameFOV // (Final|Native|Public|BlueprintCallable) // @ game+0x1495750
};

// Class POLYGON.PG_PlayerController_Game
// Size: 0x5a8 (Inherited: 0x5a0)
struct APG_PlayerController_Game : APG_PlayerController_Base {
	float TimeVoteKick; // 0x5a0(0x04)
	char pad_5A4[0x4]; // 0x5a4(0x04)

	void VoteKick(struct APG_PlayerState_Game* badGuy); // Function POLYGON.PG_PlayerController_Game.VoteKick // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0x1495bd0
	void StopInteractionEvent(); // Function POLYGON.PG_PlayerController_Game.StopInteractionEvent // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void StopInteraction_Client(); // Function POLYGON.PG_PlayerController_Game.StopInteraction_Client // (Net|Native|Event|Public|NetClient) // @ game+0x1495b00
	void StartInteractionEvent(float interactionTime); // Function POLYGON.PG_PlayerController_Game.StartInteractionEvent // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void StartInteraction_Client(float interactionTime); // Function POLYGON.PG_PlayerController_Game.StartInteraction_Client // (Net|Native|Event|Public|NetClient) // @ game+0x1495a00
	void SetVisibleLoadingScreen(bool IsVisible); // Function POLYGON.PG_PlayerController_Game.SetVisibleLoadingScreen // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void NotifyPlayerKilledEvent(struct APG_PlayerState_Game* killed, struct APG_PlayerState_Game* killer, bool isHeadshot, bool isGrenade); // Function POLYGON.PG_PlayerController_Game.NotifyPlayerKilledEvent // (Event|Public|BlueprintEvent) // @ game+0x1847880
	void NotifyAddedGameScoreEvent(int32_t addedScore, enum class EAccrualTypeGameScore addGameScoreType, struct FString customString); // Function POLYGON.PG_PlayerController_Game.NotifyAddedGameScoreEvent // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void NotifyAddedGameScore_Client(int16_t addedPoints, enum class EAccrualTypeGameScore addGameScoreType, struct FString customString); // Function POLYGON.PG_PlayerController_Game.NotifyAddedGameScore_Client // (Net|Native|Event|Public|NetClient) // @ game+0x1495090
	void LoginPlayer_server(struct FString PlayerMasterId); // Function POLYGON.PG_PlayerController_Game.LoginPlayer_server // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x1494fc0
	void DisplayMessageToChatEvent(struct FChatMessage Message); // Function POLYGON.PG_PlayerController_Game.DisplayMessageToChatEvent // (Event|Public|BlueprintEvent) // @ game+0x1847880
};

// Class POLYGON.PG_PlayerController_Menu
// Size: 0x5a0 (Inherited: 0x5a0)
struct APG_PlayerController_Menu : APG_PlayerController_Base {
};

// Class POLYGON.PG_PlayerState_Base
// Size: 0x338 (Inherited: 0x320)
struct APG_PlayerState_Base : APlayerState {
	struct FMulticastInlineDelegate OnPlayerNameChanged; // 0x320(0x10)
	struct UClientBackendComponent* ClientBackendComponent; // 0x330(0x08)

	void UpdatePlayerCombinedInfo(); // Function POLYGON.PG_PlayerState_Base.UpdatePlayerCombinedInfo // (Native|Protected) // @ game+0x1499020
	void SetPlayerName(struct FString PlayerName); // Function POLYGON.PG_PlayerState_Base.SetPlayerName // (Native|Public|BlueprintCallable) // @ game+0x1498b30
};

// Class POLYGON.PG_PlayerState_Game
// Size: 0x3a8 (Inherited: 0x338)
struct APG_PlayerState_Game : APG_PlayerState_Base {
	struct FMulticastInlineDelegate OnSetTeam; // 0x338(0x10)
	struct FMulticastInlineDelegate OnChangeNumberKills; // 0x348(0x10)
	struct FMulticastInlineDelegate OnChangeNumberDeaths; // 0x358(0x10)
	struct FMulticastInlineDelegate OnVoteKick; // 0x368(0x10)
	char pad_378[0x4]; // 0x378(0x04)
	enum class ETeam Team; // 0x37c(0x01)
	char NumberKills; // 0x37d(0x01)
	char NumberDeaths; // 0x37e(0x01)
	char pad_37F[0x1]; // 0x37f(0x01)
	struct TArray<struct APG_PlayerState_Game*> VoteKickPlayers; // 0x380(0x10)
	char RespawnCounter; // 0x390(0x01)
	char pad_391[0x7]; // 0x391(0x07)
	struct UPlayerCoreComponent* PlayerCoreComponent; // 0x398(0x08)
	struct UChatSystemComponent* ChatSystemComponent; // 0x3a0(0x08)

	void SpawnCharacter_server(enum class EControlPoint spawnToControlPoint); // Function POLYGON.PG_PlayerState_Game.SpawnCharacter_server // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0x1498f20
	void SetTeam(enum class ETeam newTeam); // Function POLYGON.PG_PlayerState_Game.SetTeam // (Final|Native|Public|BlueprintCallable) // @ game+0x1498be0
	void OnRep_VoteKickPlayers(); // Function POLYGON.PG_PlayerState_Game.OnRep_VoteKickPlayers // (Final|Native|Private) // @ game+0x1498a20
	void OnRep_Team(); // Function POLYGON.PG_PlayerState_Game.OnRep_Team // (Final|Native|Private) // @ game+0x14989e0
	void OnRep_RespawnCounter(char previousValue); // Function POLYGON.PG_PlayerState_Game.OnRep_RespawnCounter // (Final|Native|Private) // @ game+0x1498940
	void OnRep_NumberKills(); // Function POLYGON.PG_PlayerState_Game.OnRep_NumberKills // (Final|Native|Private) // @ game+0x1498900
	void OnRep_NumberDeaths(); // Function POLYGON.PG_PlayerState_Game.OnRep_NumberDeaths // (Final|Native|Private) // @ game+0x14988e0
};

// Class POLYGON.PG_PlayerState_Menu
// Size: 0x338 (Inherited: 0x338)
struct APG_PlayerState_Menu : APG_PlayerState_Base {
};

// Class POLYGON.PlayerCoreComponent
// Size: 0x128 (Inherited: 0xb0)
struct UPlayerCoreComponent : UActorComponent {
	struct FMulticastInlineDelegate OnSetTotalProgress; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnNewLevelReceived; // 0xc0(0x10)
	int32_t PremiumScore; // 0xd0(0x04)
	int32_t TotalProgress; // 0xd4(0x04)
	int32_t Currency; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
	bool bHasPremiumAccount; // 0xe0(0x01)
	char pad_E1[0x47]; // 0xe1(0x47)

	void ParsePlayerCombinedInfo(); // Function POLYGON.PlayerCoreComponent.ParsePlayerCombinedInfo // (Final|Native|Private) // @ game+0x1498a40
	void OnRep_TotalProgress(); // Function POLYGON.PlayerCoreComponent.OnRep_TotalProgress // (Final|Native|Private) // @ game+0x1498a00
	struct FLevelInfo GetNextLevelInfo(); // Function POLYGON.PlayerCoreComponent.GetNextLevelInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x14986f0
	struct FLevelInfo GetNextLevelByLevelID(struct FName LevelID); // Function POLYGON.PlayerCoreComponent.GetNextLevelByLevelID // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x1498640
	struct FLevelInfo GetLevelByProgress(int32_t Progress); // Function POLYGON.PlayerCoreComponent.GetLevelByProgress // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x14984c0
	struct FLevelInfo GetCurrentLevelInfo(); // Function POLYGON.PlayerCoreComponent.GetCurrentLevelInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1498450
	void AddGameScore(int32_t addScore, enum class EAccrualTypeGameScore accrualTypeGameScore, struct FString customString); // Function POLYGON.PlayerCoreComponent.AddGameScore // (Final|Native|Public|BlueprintCallable) // @ game+0x1498270
	void AddCurrency(int32_t AddCurrency); // Function POLYGON.PlayerCoreComponent.AddCurrency // (Final|Native|Public|BlueprintCallable) // @ game+0x14981e0
};

// Class POLYGON.ServerBackendComponent
// Size: 0x100 (Inherited: 0xf0)
struct UServerBackendComponent : UGeneralBackendComponent {
	char pad_F0[0x10]; // 0xf0(0x10)

	struct FString GetLobbyID(); // Function POLYGON.ServerBackendComponent.GetLobbyID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1498570
};

// Class POLYGON.SupportBox
// Size: 0x248 (Inherited: 0x220)
struct ASupportBox : AActor {
	char pad_220[0x10]; // 0x220(0x10)
	struct UStaticMeshComponent* BoxMesh; // 0x230(0x08)
	struct UWidgetComponent* WidgetTypeSupportBox; // 0x238(0x08)
	struct UWidgetComponent* InteractionWidget; // 0x240(0x08)
};

// Class POLYGON.SupportBox_Ammo
// Size: 0x248 (Inherited: 0x248)
struct ASupportBox_Ammo : ASupportBox {
};

// Class POLYGON.SupportBox_Health
// Size: 0x248 (Inherited: 0x248)
struct ASupportBox_Health : ASupportBox {
};

// Class POLYGON.TeamBase
// Size: 0x228 (Inherited: 0x220)
struct ATeamBase : AActor {
	enum class ETeam Team; // 0x220(0x01)
	char pad_221[0x7]; // 0x221(0x07)
};

// Class POLYGON.WeaponComponent
// Size: 0x1a8 (Inherited: 0xb0)
struct UWeaponComponent : UActorComponent {
	struct FMulticastInlineDelegate OnSetCurrentWeapon; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnSetPrimaryWeapon; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnSetSecondaryWeapon; // 0xd0(0x10)
	struct FMulticastInlineDelegate OnChangeNumberGrenades; // 0xe0(0x10)
	struct FMulticastInlineDelegate OnAiming; // 0xf0(0x10)
	char pad_100[0x16]; // 0x100(0x16)
	char GrenadesNumber; // 0x116(0x01)
	bool bWeaponIsDown; // 0x117(0x01)
	struct AItem_Weapon_General* CurrentWeapon; // 0x118(0x08)
	struct AItem_Weapon_General* PrimaryWeapon; // 0x120(0x08)
	struct AItem_Weapon_General* SecondaryWeapon; // 0x128(0x08)
	struct UParticleSystem* FireFX; // 0x130(0x08)
	struct UParticleSystem* HitFX_Metal; // 0x138(0x08)
	struct UParticleSystem* HitFX_Stone; // 0x140(0x08)
	struct UParticleSystem* HitFX_Dirt; // 0x148(0x08)
	struct UParticleSystem* HitFX_Wood; // 0x150(0x08)
	struct UParticleSystem* HitFX_Water; // 0x158(0x08)
	struct UParticleSystem* HitFX_Glass; // 0x160(0x08)
	struct UParticleSystem* HitFX_Blood; // 0x168(0x08)
	struct UMaterialInterface* DecalImpact; // 0x170(0x08)
	struct USoundBase* SoundCharacterHit; // 0x178(0x08)
	struct USoundBase* SoundRicochetHit; // 0x180(0x08)
	struct USoundBase* SoundAiming; // 0x188(0x08)
	struct UAnimMontage* AnimChangeWeapon; // 0x190(0x08)
	struct UAnimMontage* AnimThrowGrenade; // 0x198(0x08)
	struct UAnimMontage* AnimLowThrowGrenade; // 0x1a0(0x08)

	void ToggleAiming_server(); // Function POLYGON.WeaponComponent.ToggleAiming_server // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x1498fd0
	void SetWeaponRecoilAlpha_Yaw(float newYawRecoil); // Function POLYGON.WeaponComponent.SetWeaponRecoilAlpha_Yaw // (Final|Native|Public|BlueprintCallable) // @ game+0x1498ea0
	void SetWeaponRecoilAlpha_Roll(float newRollRecoil); // Function POLYGON.WeaponComponent.SetWeaponRecoilAlpha_Roll // (Final|Native|Public|BlueprintCallable) // @ game+0x1498e20
	void SetWeaponRecoilAlpha_Pitch(float newPitchRecoil); // Function POLYGON.WeaponComponent.SetWeaponRecoilAlpha_Pitch // (Final|Native|Public|BlueprintCallable) // @ game+0x1498da0
	void SetWeaponRecoilAlpha_Backward(float newBackwardRecoil); // Function POLYGON.WeaponComponent.SetWeaponRecoilAlpha_Backward // (Final|Native|Public|BlueprintCallable) // @ game+0x1498d20
	void SetWantsToAiming_server(bool NewState); // Function POLYGON.WeaponComponent.SetWantsToAiming_server // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x1498c60
	void SelectWeaponSlot_server(char Slot); // Function POLYGON.WeaponComponent.SelectWeaponSlot_server // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x1498a80
	void ParsePlayerCombinedInfo(); // Function POLYGON.WeaponComponent.ParsePlayerCombinedInfo // (Final|Native|Private) // @ game+0x1498a60
	void OnRep_SecondaryWeapon(); // Function POLYGON.WeaponComponent.OnRep_SecondaryWeapon // (Final|Native|Private) // @ game+0x14989c0
	void OnRep_PrimaryWeapon(); // Function POLYGON.WeaponComponent.OnRep_PrimaryWeapon // (Final|Native|Private) // @ game+0x1498920
	void OnRep_GrenadesNumber(); // Function POLYGON.WeaponComponent.OnRep_GrenadesNumber // (Final|Native|Private) // @ game+0x14988c0
	void OnRep_CurrentWeapon(struct AItem_Weapon_General* previousWeapon); // Function POLYGON.WeaponComponent.OnRep_CurrentWeapon // (Final|Native|Private) // @ game+0x1498830
	void NotifyServerThrowGrenade(); // Function POLYGON.WeaponComponent.NotifyServerThrowGrenade // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x14987e0
	bool IsAiming(); // Function POLYGON.WeaponComponent.IsAiming // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x14987c0
	float GetWeaponRecoilAlpha_Yaw(); // Function POLYGON.WeaponComponent.GetWeaponRecoilAlpha_Yaw // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x14987a0
	float GetWeaponRecoilAlpha_Roll(); // Function POLYGON.WeaponComponent.GetWeaponRecoilAlpha_Roll // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1498780
	float GetWeaponRecoilAlpha_Pitch(); // Function POLYGON.WeaponComponent.GetWeaponRecoilAlpha_Pitch // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1498760
	float GetWeaponRecoilAlpha_Backward(); // Function POLYGON.WeaponComponent.GetWeaponRecoilAlpha_Backward // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1498740
	bool GetIsShooting(); // Function POLYGON.WeaponComponent.GetIsShooting // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x14984a0
	void AddGrenate_server(char Number); // Function POLYGON.WeaponComponent.AddGrenate_server // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x14983a0
};

