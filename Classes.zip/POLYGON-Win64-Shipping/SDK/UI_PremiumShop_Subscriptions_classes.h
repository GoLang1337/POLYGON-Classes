// WidgetBlueprintGeneratedClass UI_PremiumShop_Subscriptions.UI_PremiumShop_Subscriptions_C
// Size: 0x2a0 (Inherited: 0x260)
struct UUI_PremiumShop_Subscriptions_C : UUserWidget {
	struct UUI_PremiumItem_C* UI_PremiumItem_Subscription_14Days; // 0x260(0x08)
	struct UUI_PremiumItem_C* UI_PremiumItem_Subscription_180Days; // 0x268(0x08)
	struct UUI_PremiumItem_C* UI_PremiumItem_Subscription_1Days; // 0x270(0x08)
	struct UUI_PremiumItem_C* UI_PremiumItem_Subscription_30Days; // 0x278(0x08)
	struct UUI_PremiumItem_C* UI_PremiumItem_Subscription_360Days; // 0x280(0x08)
	struct UUI_PremiumItem_C* UI_PremiumItem_Subscription_3Days; // 0x288(0x08)
	struct UUI_PremiumItem_C* UI_PremiumItem_Subscription_7Days; // 0x290(0x08)
	struct UUI_PremiumItem_C* UI_PremiumItem_Subscription_90Days; // 0x298(0x08)
};

