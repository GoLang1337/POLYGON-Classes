// WidgetBlueprintGeneratedClass UI_ErrorMessage.UI_ErrorMessage_C
// Size: 0x2b8 (Inherited: 0x260)
struct UUI_ErrorMessage_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Anim_HideError; // 0x268(0x08)
	struct UWidgetAnimation* Anim_ShowError; // 0x270(0x08)
	struct UMultiLineEditableText* MultiLineEditableText_ErrorDetails; // 0x278(0x08)
	struct UMultiLineEditableText* MultiLineEditableText_ErrorMessage; // 0x280(0x08)
	struct FText ErrorMessage; // 0x288(0x18)
	struct FText ErrorDetails; // 0x2a0(0x18)

	void Construct(); // Function UI_ErrorMessage.UI_ErrorMessage_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_ErrorMessage(int32_t EntryPoint); // Function UI_ErrorMessage.UI_ErrorMessage_C.ExecuteUbergraph_UI_ErrorMessage // (Final|UbergraphFunction) // @ game+0x1847880
};

