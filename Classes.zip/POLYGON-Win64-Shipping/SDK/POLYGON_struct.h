// Enum POLYGON.EAccrualTypeGameScore
enum class EAccrualTypeGameScore : uint8 {
	NONE = 0,
	KILLED = 1,
	KILLED_IN_HEAD = 2,
	KILL_ASSIST = 3,
	CAPTURED = 4,
	EAccrualTypeGameScore_MAX = 5
};

// Enum POLYGON.ECameraViewMode
enum class ECameraViewMode : uint8 {
	FIRST_PERSON = 0,
	THIRD_PERSON = 1,
	ECameraViewMode_MAX = 2
};

// Enum POLYGON.ECharacterPoseState
enum class ECharacterPoseState : uint8 {
	NONE = 0,
	STAND = 1,
	CROUCN = 2,
	LIE = 3,
	AIR = 4,
	ECharacterPoseState_MAX = 5
};

// Enum POLYGON.EControlPoint
enum class EControlPoint : uint8 {
	NONE_ = 0,
	ALPHA_ = 1,
	BRAVO_ = 2,
	CHARLIE_ = 3,
	DELTA_ = 4,
	ECHO_ = 5,
	FOXTROT_ = 6,
	EControlPoint_MAX = 7
};

// Enum POLYGON.EGameMode
enum class EGameMode : uint8 {
	NONE = 0,
	CONQUEST = 1,
	CONQUEST_V2 = 2,
	EGameMode_MAX = 3
};

// Enum POLYGON.EGameState
enum class EGameState : uint8 {
	NONE = 0,
	WAITING_PLAYERS = 1,
	COUNTDOWN = 2,
	GAME = 3,
	ENDED = 4,
	EGameState_MAX = 5
};

// Enum POLYGON.EStaminaState
enum class EStaminaState : uint8 {
	IDLE = 0,
	INCREASE = 1,
	DECREASE = 2,
	EStaminaState_MAX = 3
};

// Enum POLYGON.EItemType
enum class EItemType : uint8 {
	NONE = 0,
	WEAPON = 1,
	GRENADE = 2,
	MODULE = 3,
	EItemType_MAX = 4
};

// Enum POLYGON.EMessageType
enum class EMessageType : uint8 {
	ALL = 0,
	TEAM = 1,
	SQUAD = 2,
	PRIVATE = 3,
	SYSTEM = 4,
	EMessageType_MAX = 5
};

// Enum POLYGON.EPlayerAction
enum class EPlayerAction : uint8 {
	NONE = 0,
	RELOADING = 1,
	BOLTING = 2,
	CHANGING = 3,
	THROW_GRENADE = 4,
	EPlayerAction_MAX = 5
};

// Enum POLYGON.ETeam
enum class ETeam : uchint8 {
	NONE = 0,
	NOBODY = 1,
	RED = 2,
	BLUE = 3,
	ETeam_MAX = 4
};

// Enum POLYGON.EWeaponModuleType
enum class EWeaponModuleType : uint8 {
	NONE = 0,
	OPTIC = 1,
	BARREL = 2,
	UNDERBARREL = 3,
	ACCESSORY = 4,
	SKIN = 5,
	EWeaponModuleType_MAX = 6
};

// Enum POLYGON.EWeaponShootingType
enum class EWeaponShootingType : uint8 {
	BOLT = 0,
	SEMI_AUTO = 1,
	AUTO = 2,
	EWeaponShootingType_MAX = 3
};

// Enum POLYGON.EWeaponType
enum class EWeaponType : uint8 {
	NONE = 0,
	RIFLE = 1,
	SNIPER = 2,
	PISTOL = 3,
	EWeaponType_MAX = 4
};

// ScriptStruct POLYGON.BattlePassReward
// Size: 0x58 (Inherited: 0x08)
struct FBattlePassReward : FTableRowBase {
	int32_t Level; // 0x08(0x04)
	int32_t RequiredExperience; // 0x0c(0x04)
	int32_t Price; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString FreeItemID; // 0x18(0x10)
	struct FString FreeItemCatalog; // 0x28(0x10)
	struct FString PremiumItemID; // 0x38(0x10)
	struct FString PremiumItemCatalog; // 0x48(0x10)
};

// ScriptStruct POLYGON.ChatMessage
// Size: 0x20 (Inherited: 0x00)
struct FChatMessage {
	struct APG_PlayerState_Game* Sender; // 0x00(0x08)
	enum class EMessageType MessageType; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FString Message; // 0x10(0x10)
};

// ScriptStruct POLYGON.PlayerAssist
// Size: 0x18 (Inherited: 0x00)
struct FPlayerAssist {
	struct APG_PlayerState_Game* PlayerAssist; // 0x00(0x08)
	int32_t Damage; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FTimerHandle TimerResetAssist; // 0x10(0x08)
};

// ScriptStruct POLYGON.WeaponHitOnCharacter
// Size: 0x18 (Inherited: 0x00)
struct FWeaponHitOnCharacter {
	struct FVector_NetQuantize Location; // 0x00(0x0c)
	struct TWeakObjectPtr<struct AActor> Actor; // 0x0c(0x08)
	char BoneIndex; // 0x14(0x01)
	enum class EPhysicalSurface PhysSurfaceType; // 0x15(0x01)
	bool bSpreadIsZero; // 0x16(0x01)
	char pad_17[0x1]; // 0x17(0x01)
};

// ScriptStruct POLYGON.ItemReference
// Size: 0x10 (Inherited: 0x08)
struct FItemReference : FTableRowBase {
	struct AItem_General* Item; // 0x08(0x08)
};

// ScriptStruct POLYGON.LevelInfo
// Size: 0x20 (Inherited: 0x08)
struct FLevelInfo : FTableRowBase {
	struct FName LevelID; // 0x08(0x08)
	int32_t Level; // 0x10(0x04)
	int32_t ProgressRequired; // 0x14(0x04)
	struct UTexture2D* LevelIcon; // 0x18(0x08)
};

// ScriptStruct POLYGON.MapInfo
// Size: 0x68 (Inherited: 0x08)
struct FMapInfo : FTableRowBase {
	struct FName MapRowName; // 0x08(0x08)
	struct FString MapName; // 0x10(0x10)
	struct FText MapDisplayName; // 0x20(0x18)
	int32_t MaxPlayers; // 0x38(0x04)
	int32_t MaxScoreForWin; // 0x3c(0x04)
	struct UTexture2D* MapPreview; // 0x40(0x08)
	struct UTexture2D* MinimapImage; // 0x48(0x08)
	float Dimension; // 0x50(0x04)
	struct FVector CameraPosition; // 0x54(0x0c)
	float CameraRotate; // 0x60(0x04)
	bool IsDevelopment; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
};

// ScriptStruct POLYGON.PlayerId
// Size: 0x20 (Inherited: 0x00)
struct FPlayerId {
	struct FString PlayerMasterId; // 0x00(0x10)
	struct FString PlayerTitleId; // 0x10(0x10)
};

