// WidgetBlueprintGeneratedClass UI_GameMenuScreen.UI_GameMenuScreen_C
// Size: 0x314 (Inherited: 0x260)
struct UUI_GameMenuScreen_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* BlinkDeploy; // 0x268(0x08)
	struct UBorder* Border_MyTeam; // 0x270(0x08)
	struct UButton* Button_Deploy; // 0x278(0x08)
	struct UImage* Image_Team; // 0x280(0x08)
	struct UProgressBar* ProgressBar_CaptureProcessBlueTeam; // 0x288(0x08)
	struct UProgressBar* ProgressBar_CaptureProcessRedTeam; // 0x290(0x08)
	struct UTextBlock* TextBlock_CapturePointsBlueTeam; // 0x298(0x08)
	struct UTextBlock* TextBlock_CapturePointsRedTeam; // 0x2a0(0x08)
	struct UTextBlock* TextBlock_TimeToSpawn_MiliSecond; // 0x2a8(0x08)
	struct UTextBlock* TextBlock_TimeToSpawn_Second; // 0x2b0(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_A_Board; // 0x2b8(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_B_Board; // 0x2c0(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_C_Board; // 0x2c8(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_D_Board; // 0x2d0(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_E_Board; // 0x2d8(0x08)
	struct UUI_ControlPointMarker_C* UI_ControlPointMarker_F_Board; // 0x2e0(0x08)
	struct UUI_GameMenu_Map_C* UI_GameMenu_Map; // 0x2e8(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Deploy; // 0x2f0(0x08)
	struct ABP_PG_GameState_Game_C* GameState; // 0x2f8(0x08)
	struct ABP_PG_PlayerController_Game_C* PlayerController; // 0x300(0x08)
	struct ABP_PG_PlayerState_Game_C* PlayerState; // 0x308(0x08)
	float TimeToSpawn; // 0x310(0x04)

	struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function UI_GameMenuScreen.UI_GameMenuScreen_C.OnKeyUp // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void GetControlPointMarkerByTypeFromBoard(enum class EControlPoint ControlPointType, struct UUI_ControlPointMarker_C* Marker); // Function UI_GameMenuScreen.UI_GameMenuScreen_C.GetControlPointMarkerByTypeFromBoard // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function UI_GameMenuScreen.UI_GameMenuScreen_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_GameMenuScreen.UI_GameMenuScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void Deploy(); // Function UI_GameMenuScreen.UI_GameMenuScreen_C.Deploy // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void StartTimeToSpawn(); // Function UI_GameMenuScreen.UI_GameMenuScreen_C.StartTimeToSpawn // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function UI_GameMenuScreen.UI_GameMenuScreen_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Deploy_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature(); // Function UI_GameMenuScreen.UI_GameMenuScreen_C.BndEvt__Button_Deploy_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void OnSetTeam_Event(); // Function UI_GameMenuScreen.UI_GameMenuScreen_C.OnSetTeam_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnChangeTotalScore_Event(); // Function UI_GameMenuScreen.UI_GameMenuScreen_C.OnChangeTotalScore_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_GameMenuScreen(int32_t EntryPoint); // Function UI_GameMenuScreen.UI_GameMenuScreen_C.ExecuteUbergraph_UI_GameMenuScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

