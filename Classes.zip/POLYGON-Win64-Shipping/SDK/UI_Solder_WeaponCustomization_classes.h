// WidgetBlueprintGeneratedClass UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C
// Size: 0x2e8 (Inherited: 0x260)
struct UUI_Solder_WeaponCustomization_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UButton* Button_Back; // 0x268(0x08)
	struct UUI_Solder_Customization_Slot_C* UI_Solder_CustomizationSlot_Barrel; // 0x270(0x08)
	struct UUI_Solder_Customization_Slot_C* UI_Solder_CustomizationSlot_Skin; // 0x278(0x08)
	struct UUI_Solder_Customization_Slot_C* UI_Solder_CustomizationSlot_Underbarrel; // 0x280(0x08)
	struct UUI_Solder_Customization_Slot_C* UI_SolderCustomizationSlot_Accessory; // 0x288(0x08)
	struct UUI_Solder_Customization_Slot_C* UI_SolderCustomizationSlot_Optic; // 0x290(0x08)
	struct UVerticalBox* VerticalBox_Accessory; // 0x298(0x08)
	struct UVerticalBox* VerticalBox_Barrel; // 0x2a0(0x08)
	struct UVerticalBox* VerticalBox_Equipped; // 0x2a8(0x08)
	struct UVerticalBox* VerticalBox_Optic; // 0x2b0(0x08)
	struct UVerticalBox* VerticalBox_Skin; // 0x2b8(0x08)
	struct UVerticalBox* VerticalBox_Underbarrel; // 0x2c0(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Inventory; // 0x2c8(0x08)
	struct TArray<struct UPlayFabJsonObject*> modules; // 0x2d0(0x10)
	struct UPlayFabJsonObject* WeaponJsonInfo; // 0x2e0(0x08)

	void SelectModuleSlot(int32_t Index, struct UUI_Solder_Customization_Slot_C* Slot); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.SelectModuleSlot // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void CheckModuleIsEquipped(struct FString ItemId, bool IsEquipped); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.CheckModuleIsEquipped // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void FindModuleInInventory(struct FString ItemId, struct UPlayFabJsonObject* Module); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.FindModuleInInventory // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void FindModuleInListByItemId(struct UWidget* ParentWidget, struct FString ItemId, struct UUI_Solder_WeaponCustomizationItem_C* Item); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.FindModuleInListByItemId // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void GetModuleSlotByModuleType(enum class EWeaponModuleType ModuleType, struct UUI_Solder_Customization_Slot_C* Slot); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.GetModuleSlotByModuleType // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void Get Module List by Module Type(enum class EWeaponModuleType Selection, struct UVerticalBox* List); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.Get Module List by Module Type // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void AddNewModule(struct UPlayFabJsonObject* ItemJson); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.AddNewModule // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ResetAllModules(); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.ResetAllModules // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void GrabModulesInfo(struct UPlayFabJsonObject* WeaponJsonInfo); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.GrabModulesInfo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Back_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.BndEvt__Button_Back_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Back_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.BndEvt__Button_Back_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Back_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature(); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.BndEvt__Button_Back_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_SolderCustomizationSlot_Optic_K2Node_ComponentBoundEvent_2_SelectDelegate__DelegateSignature(struct UUI_Solder_Customization_Slot_C* Slot); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.BndEvt__UI_SolderCustomizationSlot_Optic_K2Node_ComponentBoundEvent_2_SelectDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Solder_CustomizationSlot_Skin_K2Node_ComponentBoundEvent_4_SelectDelegate__DelegateSignature(struct UUI_Solder_Customization_Slot_C* Slot); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.BndEvt__UI_Solder_CustomizationSlot_Skin_K2Node_ComponentBoundEvent_4_SelectDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Solder_CustomizationSlot_Barrel_K2Node_ComponentBoundEvent_5_SelectDelegate__DelegateSignature(struct UUI_Solder_Customization_Slot_C* Slot); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.BndEvt__UI_Solder_CustomizationSlot_Barrel_K2Node_ComponentBoundEvent_5_SelectDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Solder_CustomizationSlot_Underbarrel_K2Node_ComponentBoundEvent_6_SelectDelegate__DelegateSignature(struct UUI_Solder_Customization_Slot_C* Slot); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.BndEvt__UI_Solder_CustomizationSlot_Underbarrel_K2Node_ComponentBoundEvent_6_SelectDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_SolderCustomizationSlot_Accessory_K2Node_ComponentBoundEvent_7_SelectDelegate__DelegateSignature(struct UUI_Solder_Customization_Slot_C* Slot); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.BndEvt__UI_SolderCustomizationSlot_Accessory_K2Node_ComponentBoundEvent_7_SelectDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Solder_WeaponCustomization(int32_t EntryPoint); // Function UI_Solder_WeaponCustomization.UI_Solder_WeaponCustomization_C.ExecuteUbergraph_UI_Solder_WeaponCustomization // (Final|UbergraphFunction) // @ game+0x1847880
};

