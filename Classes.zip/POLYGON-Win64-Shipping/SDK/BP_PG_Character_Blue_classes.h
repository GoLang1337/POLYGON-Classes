// BlueprintGeneratedClass BP_PG_Character_Blue.BP_PG_Character_Blue_C
// Size: 0x638 (Inherited: 0x630)
struct ABP_PG_Character_Blue_C : ABP_PG_Character_General_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x630(0x08)

	void ReceiveBeginPlay(); // Function BP_PG_Character_Blue.BP_PG_Character_Blue_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void OnSetTeam_Event(); // Function BP_PG_Character_Blue.BP_PG_Character_Blue_C.OnSetTeam_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnSetPlayerState_Event(); // Function BP_PG_Character_Blue.BP_PG_Character_Blue_C.OnSetPlayerState_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_PG_Character_Blue(int32_t EntryPoint); // Function BP_PG_Character_Blue.BP_PG_Character_Blue_C.ExecuteUbergraph_BP_PG_Character_Blue // (Final|UbergraphFunction) // @ game+0x1847880
};

