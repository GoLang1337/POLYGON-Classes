// WidgetBlueprintGeneratedClass UI_Solder_Customization.UI_Solder_Customization_C
// Size: 0x2b8 (Inherited: 0x260)
struct UUI_Solder_Customization_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UScrollBox* ScrollBox_PrimaryWeapons; // 0x268(0x08)
	struct UScrollBox* ScrollBox_SecondaryWeapons; // 0x270(0x08)
	struct UUI_Solder_Customization_ItemInfo_C* UI_Solder_Customization_ItemInfo; // 0x278(0x08)
	struct UUI_Solder_WeaponCustomization_C* UI_Solder_CustomizationSlot_WeaponSetup; // 0x280(0x08)
	struct UUI_Solder_Customization_Slot_C* UI_SolderCustomizationSlot_PrimaryWeapon; // 0x288(0x08)
	struct UUI_Solder_Customization_Slot_C* UI_SolderCustomizationSlot_SecondaryWeapon; // 0x290(0x08)
	struct UVerticalBox* VerticalBox_Equipped; // 0x298(0x08)
	struct UWidgetSwitcher* WidgetSwitcher; // 0x2a0(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Inventory; // 0x2a8(0x08)
	struct ABP_PG_PlayerState_Menu_C* PlayerState; // 0x2b0(0x08)

	void Get List by Item Class(struct AItem_General* ItemClass, struct UScrollBox* ScrollBox); // Function UI_Solder_Customization.UI_Solder_Customization_C.Get List by Item Class // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void Get Slot by Item Class(struct AItem_General* ShortItemData, struct UUI_Solder_Customization_Slot_C* Slot); // Function UI_Solder_Customization.UI_Solder_Customization_C.Get Slot by Item Class // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1847880
	void AddItemToList(struct UPlayFabJsonObject* ItemJson); // Function UI_Solder_Customization.UI_Solder_Customization_C.AddItemToList // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ParsePlayerInventory(); // Function UI_Solder_Customization.UI_Solder_Customization_C.ParsePlayerInventory // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Solder_Customization.UI_Solder_Customization_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void SelectDelegate_Event(struct UUI_Solder_Customization_Slot_C* Slot); // Function UI_Solder_Customization.UI_Solder_Customization_C.SelectDelegate_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_SolderCustomizationSlot_K2Node_ComponentBoundEvent_2_SelectDelegate__DelegateSignature(struct UUI_Solder_Customization_Slot_C* Slot); // Function UI_Solder_Customization.UI_Solder_Customization_C.BndEvt__UI_SolderCustomizationSlot_K2Node_ComponentBoundEvent_2_SelectDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_SolderCustomizationSlot_C_1_K2Node_ComponentBoundEvent_3_SelectDelegate__DelegateSignature(struct UUI_Solder_Customization_Slot_C* Slot); // Function UI_Solder_Customization.UI_Solder_Customization_C.BndEvt__UI_SolderCustomizationSlot_C_1_K2Node_ComponentBoundEvent_3_SelectDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void Slot_HoveredDelegate_Event(struct UUI_Solder_Customization_Slot_C* Slot, bool IsHover); // Function UI_Solder_Customization.UI_Solder_Customization_C.Slot_HoveredDelegate_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Item_HoveredDelegate_Event(struct UUI_Solder_Customization_Item_C* Item, bool IsHover); // Function UI_Solder_Customization.UI_Solder_Customization_C.Item_HoveredDelegate_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void InventoryIsReady(); // Function UI_Solder_Customization.UI_Solder_Customization_C.InventoryIsReady // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void OnUpdatePlayerCombinedInfo_Event(); // Function UI_Solder_Customization.UI_Solder_Customization_C.OnUpdatePlayerCombinedInfo_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Solder_Customization(int32_t EntryPoint); // Function UI_Solder_Customization.UI_Solder_Customization_C.ExecuteUbergraph_UI_Solder_Customization // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

