// WidgetBlueprintGeneratedClass UI_HomeScreen.UI_HomeScreen_C
// Size: 0x298 (Inherited: 0x260)
struct UUI_HomeScreen_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* BattleHovered; // 0x268(0x08)
	struct UButton* Button_Matchmaking; // 0x270(0x08)
	struct UUI_HomeScreen_BattlePass_C* UI_HomeScreen_BattlePass; // 0x278(0x08)
	struct UUI_LoadingIcon_C* UI_LoadingIcon; // 0x280(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Matchmaking; // 0x288(0x08)
	struct ABP_PG_PlayerController_Menu_C* PlayerController; // 0x290(0x08)

	void BndEvt__Button_Play_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function UI_HomeScreen.UI_HomeScreen_C.BndEvt__Button_Play_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_HomeScreen.UI_HomeScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Play_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function UI_HomeScreen.UI_HomeScreen_C.BndEvt__Button_Play_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__Button_Play_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function UI_HomeScreen.UI_HomeScreen_C.BndEvt__Button_Play_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_HomeScreen(int32_t EntryPoint); // Function UI_HomeScreen.UI_HomeScreen_C.ExecuteUbergraph_UI_HomeScreen // (Final|UbergraphFunction) // @ game+0x1847880
};

