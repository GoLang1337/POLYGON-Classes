// BlueprintGeneratedClass BP_RedLine.BP_RedLine_C
// Size: 0x23a (Inherited: 0x220)
struct ABP_RedLine_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct USplineComponent* Spline; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
	bool Close?; // 0x238(0x01)
	enum class ETeam Team; // 0x239(0x01)

	void SetPosition(int32_t PointIndex); // Function BP_RedLine.BP_RedLine_C.SetPosition // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void UserConstructionScript(); // Function BP_RedLine.BP_RedLine_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ReceiveBeginPlay(); // Function BP_RedLine.BP_RedLine_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1847880
	void OnSetTeam_Event(); // Function BP_RedLine.BP_RedLine_C.OnSetTeam_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_RedLine(int32_t EntryPoint); // Function BP_RedLine.BP_RedLine_C.ExecuteUbergraph_BP_RedLine // (Final|UbergraphFunction) // @ game+0x1847880
};

