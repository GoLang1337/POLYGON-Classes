// WidgetBlueprintGeneratedClass UI_Shop_Premium.UI_Shop_Premium_C
// Size: 0x2b8 (Inherited: 0x260)
struct UUI_Shop_Premium_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UHorizontalBox* HorizontalBox_Header; // 0x268(0x08)
	struct UUI_Button_C* UI_Button_BattlePass; // 0x270(0x08)
	struct UUI_Button_C* UI_Button_Crowns; // 0x278(0x08)
	struct UUI_Button_C* UI_Button_Skins; // 0x280(0x08)
	struct UUI_Button_C* UI_Button_VIP; // 0x288(0x08)
	struct UUI_Shop_BattlePass_C* UI_Shop_BattlePass; // 0x290(0x08)
	struct UUI_Shop_Crowns_C* UI_Shop_Crowns; // 0x298(0x08)
	struct UUI_Shop_VIP_C* UI_Shop_VIP; // 0x2a0(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Main; // 0x2a8(0x08)
	struct UWrapBox* WrapBox_Skin; // 0x2b0(0x08)

	void SetActivePage(int32_t Index, struct UUI_Button_C* Button); // Function UI_Shop_Premium.UI_Shop_Premium_C.SetActivePage // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void PreConstruct(bool IsDesignTime); // Function UI_Shop_Premium.UI_Shop_Premium_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_Premium_UI_Button_Crowns_K2Node_ComponentBoundEvent_0_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Shop_Premium.UI_Shop_Premium_C.BndEvt__UI_Shop_Premium_UI_Button_Crowns_K2Node_ComponentBoundEvent_0_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_Premium_UI_Button_VIP_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Shop_Premium.UI_Shop_Premium_C.BndEvt__UI_Shop_Premium_UI_Button_VIP_K2Node_ComponentBoundEvent_1_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_Premium_UI_Button_Skins_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Shop_Premium.UI_Shop_Premium_C.BndEvt__UI_Shop_Premium_UI_Button_Skins_K2Node_ComponentBoundEvent_2_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Shop_Premium_UI_Button_BattlePass_K2Node_ComponentBoundEvent_3_OnClick__DelegateSignature(struct UUI_Button_C* Button); // Function UI_Shop_Premium.UI_Shop_Premium_C.BndEvt__UI_Shop_Premium_UI_Button_BattlePass_K2Node_ComponentBoundEvent_3_OnClick__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Shop_Premium(int32_t EntryPoint); // Function UI_Shop_Premium.UI_Shop_Premium_C.ExecuteUbergraph_UI_Shop_Premium // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

