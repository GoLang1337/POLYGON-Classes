// AnimBlueprintGeneratedClass BP_PG_AnimBluerpint_Menu.BP_PG_AnimBluerpint_Menu_C
// Size: 0x810 (Inherited: 0x2c0)
struct UBP_PG_AnimBluerpint_Menu_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2c8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x2f8(0x80)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x378(0x48)
	struct FAnimNode_HandIKRetargeting AnimGraphNode_HandIKRetargeting; // 0x3c0(0x120)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x4e0(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x500(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x520(0x108)
	char pad_628[0x8]; // 0x628(0x08)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK; // 0x630(0x1e0)

	void AnimGraph(struct FPoseLink AnimGraph); // Function BP_PG_AnimBluerpint_Menu.BP_PG_AnimBluerpint_Menu_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_PG_AnimBluerpint_Menu(int32_t EntryPoint); // Function BP_PG_AnimBluerpint_Menu.BP_PG_AnimBluerpint_Menu_C.ExecuteUbergraph_BP_PG_AnimBluerpint_Menu // (Final|UbergraphFunction) // @ game+0x1847880
};

