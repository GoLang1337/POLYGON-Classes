// WidgetBlueprintGeneratedClass DefaultActionLabel.DefaultActionLabel_C
// Size: 0x2f8 (Inherited: 0x2f8)
struct UDefaultActionLabel_C : UActionLabel {
};

