// WidgetBlueprintGeneratedClass UI_Scoreboard_Player_Menu.UI_Scoreboard_Player_Menu_C
// Size: 0x288 (Inherited: 0x260)
struct UUI_Scoreboard_Player_Menu_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UBorder* Border_129; // 0x268(0x08)
	struct UButton* Button_VoteKick; // 0x270(0x08)
	struct UOverlay* Overlay_Menu; // 0x278(0x08)
	struct APG_PlayerState_Game* PlayerState; // 0x280(0x08)

	struct FEventReply OnMouseButtonDown_Background(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function UI_Scoreboard_Player_Menu.UI_Scoreboard_Player_Menu_C.OnMouseButtonDown_Background // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void SetFocusToScoreboard(); // Function UI_Scoreboard_Player_Menu.UI_Scoreboard_Player_Menu_C.SetFocusToScoreboard // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1847880
	void Construct(); // Function UI_Scoreboard_Player_Menu.UI_Scoreboard_Player_Menu_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1847880
	void OnMouseLeave(struct FPointerEvent MouseEvent); // Function UI_Scoreboard_Player_Menu.UI_Scoreboard_Player_Menu_C.OnMouseLeave // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1847880
	void BndEvt__UI_Scoreboard_Player_Menu_Button_VoteKick_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function UI_Scoreboard_Player_Menu.UI_Scoreboard_Player_Menu_C.BndEvt__UI_Scoreboard_Player_Menu_Button_VoteKick_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_UI_Scoreboard_Player_Menu(int32_t EntryPoint); // Function UI_Scoreboard_Player_Menu.UI_Scoreboard_Player_Menu_C.ExecuteUbergraph_UI_Scoreboard_Player_Menu // (Final|UbergraphFunction|HasDefaults) // @ game+0x1847880
};

