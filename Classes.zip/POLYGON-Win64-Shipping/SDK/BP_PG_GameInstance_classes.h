// BlueprintGeneratedClass BP_PG_GameInstance.BP_PG_GameInstance_C
// Size: 0x1b8 (Inherited: 0x1b0)
struct UBP_PG_GameInstance_C : UPG_GameInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1b0(0x08)

	void ReceiveInit(); // Function BP_PG_GameInstance.BP_PG_GameInstance_C.ReceiveInit // (Event|Public|BlueprintEvent) // @ game+0x1847880
	void ExecuteUbergraph_BP_PG_GameInstance(int32_t EntryPoint); // Function BP_PG_GameInstance.BP_PG_GameInstance_C.ExecuteUbergraph_BP_PG_GameInstance // (Final|UbergraphFunction) // @ game+0x1847880
};

